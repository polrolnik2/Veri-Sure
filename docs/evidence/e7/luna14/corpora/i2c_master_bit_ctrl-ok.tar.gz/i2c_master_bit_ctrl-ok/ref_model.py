"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['cscl', 'csda', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'filter_cnt_expired', 'filter_cnt_nonzero', 'clk_en', 'cnt_zero', 'slave_wait', 'scl_sync', 'sta_condition', 'sto_condition', 'sda_chk', 'idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence', 'write_high_phase']
    PROBE_WIDTHS = {'cscl': 1, 'csda': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'filter_cnt_expired': 1, 'filter_cnt_nonzero': 1, 'clk_en': 1, 'cnt_zero': 1, 'slave_wait': 1, 'scl_sync': 1, 'sta_condition': 1, 'sto_condition': 1, 'sda_chk': 1, 'idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1, 'write_high_phase': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self._state = 'idle'
        self.scl_oen = 1
        self.sda_oen = 1
        self.cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0
        self._sda_chk = 0
        self._cnt = 0
        self._clk_en = 0
        self._filter_cnt = 0
        self._cscl = 1
        self._csda = 1
        self._fscl = 7
        self._fsda = 7
        self._dscl = 1
        self._dsda = 1

    def _majority(self, history):
        ones = (history & 1) + ((history >> 1) & 1) + ((history >> 2) & 1)
        return int(ones >= 2)

    def _bus_signals(self):
        sscl = self._majority(self._fscl)
        ssda = self._majority(self._fsda)
        sta = int((not ssda) and self._dsda and sscl)
        sto = int(ssda and (not self._dsda) and sscl)
        slave_wait = int(self.scl_oen and (not sscl))
        scl_sync = int(self.scl_oen and self._dscl and (not sscl))
        return sscl, ssda, sta, sto, slave_wait, scl_sync

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        if not i['nReset']:
            o['cmd_ack'] = 0
            o['busy'] = 0
            o['al'] = 0
            o['dout'] = 0
            o['scl_o'] = 0
            o['scl_oen'] = 1
            o['sda_o'] = 0
            o['sda_oen'] = 1
            self.cscl = 1
            self.csda = 1
            self.fscl = 7
            self.fsda = 7
            self.sscl = 1
            self.ssda = 1
            self.dscl = 1
            self.dsda = 1
            self.filter_cnt_expired = True
            self.filter_cnt_nonzero = False
            self.clk_en = False
            self.cnt_zero = True
            self.slave_wait = False
            self.scl_sync = False
            self.sta_condition = False
            self.sto_condition = False
            self.sda_chk = False
            self.idle = True
            self.fsm_active = False
            self.in_start_sequence = False
            self.in_stop_sequence = False
            self.in_read_sequence = False
            self.in_write_sequence = False
            self.write_high_phase = False
            return o

        sscl, ssda, sta, sto, slave_wait, scl_sync = self._bus_signals()
        o['cmd_ack'] = self.cmd_ack & 1
        o['busy'] = self.busy & 1
        o['al'] = self.al & 1
        o['dout'] = self.dout & 1
        o['scl_o'] = 0
        o['scl_oen'] = self.scl_oen & 1
        o['sda_o'] = 0
        o['sda_oen'] = self.sda_oen & 1

        self.cscl = self._cscl & 1
        self.csda = self._csda & 1
        self.fscl = self._fscl & 7
        self.fsda = self._fsda & 7
        self.sscl = sscl
        self.ssda = ssda
        self.dscl = self._dscl & 1
        self.dsda = self._dsda & 1
        self.filter_cnt_expired = (self._filter_cnt == 0)
        self.filter_cnt_nonzero = (self._filter_cnt != 0)
        self.clk_en = bool(self._clk_en)
        self.cnt_zero = (self._cnt == 0)
        self.slave_wait = bool(slave_wait)
        self.scl_sync = bool(scl_sync)
        self.sta_condition = bool(sta)
        self.sto_condition = bool(sto)
        self.sda_chk = bool(self._sda_chk)
        self.idle = (self._state == 'idle')
        self.fsm_active = (self._state != 'idle')
        self.in_start_sequence = self._state.startswith('start_')
        self.in_stop_sequence = self._state.startswith('stop_')
        self.in_read_sequence = self._state.startswith('rd_')
        self.in_write_sequence = self._state.startswith('wr_')
        self.write_high_phase = (self._state == 'wr_d')
        return o

    def advance(self, i):
        if (not i['nReset']) or i['rst']:
            self.reset()
            return

        sscl, ssda, sta, sto, slave_wait, scl_sync = self._bus_signals()
        old_state = self._state
        old_cnt = self._cnt
        old_clk_en = self._clk_en
        old_filter_cnt = self._filter_cnt
        old_cscl = self._cscl
        old_csda = self._csda
        old_fscl = self._fscl
        old_fsda = self._fsda
        old_dscl = self._dscl
        old_dsda = self._dsda
        old_al = self.al
        old_sda_chk = self._sda_chk
        old_sda_oen = self.sda_oen

        self.cmd_ack = 0

        # Synchronizer capture and filter-history update use the values present
        # before this edge, as do the delayed signals and rising-edge sampler.
        if i['ena']:
            if old_filter_cnt == 0:
                self._filter_cnt = (i['clk_cnt'] & 0xffff) >> 2
                self._fscl = ((old_fscl << 1) | old_cscl) & 7
                self._fsda = ((old_fsda << 1) | old_csda) & 7
            else:
                self._filter_cnt = old_filter_cnt - 1
        else:
            self._filter_cnt = 0
        self._cscl = i['scl_i'] & 1
        self._csda = i['sda_i'] & 1
        self._dscl = sscl
        self._dsda = ssda
        if sscl and (not old_dscl):
            self.dout = ssda

        if sta:
            self.busy = 1
        elif sto:
            self.busy = 0

        arbitration_lost = (old_sda_chk and old_sda_oen and (not ssda))
        if sto and (old_state != 'idle') and (not old_state.startswith('stop_')):
            arbitration_lost = True
        if arbitration_lost:
            self.al = 1

        clk_cnt = i['clk_cnt'] & 0xffff
        if not i['ena']:
            self._cnt = clk_cnt
            self._clk_en = 0
        elif scl_sync:
            self._cnt = clk_cnt
            self._clk_en = 1
        elif slave_wait:
            self._cnt = old_cnt
            self._clk_en = 0
        elif old_cnt == 0:
            self._cnt = clk_cnt
            self._clk_en = 1
        else:
            self._cnt = (old_cnt - 1) & 0xffff
            self._clk_en = 0

        if old_al:
            self._state = 'idle'
            self.scl_oen = 1
            self.sda_oen = 1
            self._sda_chk = 0
        elif old_clk_en and i['ena'] and (not slave_wait):
            if old_state == 'idle':
                command = i['cmd'] & 0xf
                if command == 1:
                    self._state = 'start_a'
                elif command == 2:
                    self._state = 'stop_a'
                elif command == 4:
                    self._state = 'wr_a'
                elif command == 8:
                    self._state = 'rd_a'
            elif old_state == 'start_a':
                self.scl_oen = 1
                self.sda_oen = 1
                self._sda_chk = 0
                self._state = 'start_b'
            elif old_state == 'start_b':
                self.sda_oen = 0
                self._state = 'start_c'
            elif old_state == 'start_c':
                self.scl_oen = 0
                self._state = 'start_d'
            elif old_state == 'start_d':
                self._state = 'idle'
                self.cmd_ack = 1
            elif old_state == 'stop_a':
                self.scl_oen = 0
                self.sda_oen = 0
                self._state = 'stop_b'
            elif old_state == 'stop_b':
                self.scl_oen = 1
                self._state = 'stop_c'
            elif old_state == 'stop_c':
                self.sda_oen = 1
                self._state = 'idle'
                self.cmd_ack = 1
            elif old_state == 'rd_a':
                self.sda_oen = 1
                self._sda_chk = 0
                self._state = 'rd_b'
            elif old_state == 'rd_b':
                self.scl_oen = 1
                self._state = 'rd_c'
            elif old_state == 'rd_c':
                self._state = 'rd_d'
            elif old_state == 'rd_d':
                self.scl_oen = 0
                self._state = 'idle'
                self.cmd_ack = 1
            elif old_state == 'wr_a':
                self.sda_oen = i['din'] & 1
                self._sda_chk = 0
                self._state = 'wr_b'
            elif old_state == 'wr_b':
                self.scl_oen = 1
                self._state = 'wr_c'
            elif old_state == 'wr_c':
                self._sda_chk = 1
                self._state = 'wr_d'
            elif old_state == 'wr_d':
                self.scl_oen = 0
                self._sda_chk = 0
                self._state = 'idle'
                self.cmd_ack = 1
