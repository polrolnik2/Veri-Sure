"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['cscl', 'csda', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'filter_cnt_expired', 'filter_cnt_nonzero', 'clk_en', 'cnt_zero', 'slave_wait', 'scl_sync', 'sta_condition', 'sto_condition', 'sda_chk', 'idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence', 'write_high_phase']
    PROBE_WIDTHS = {'cscl': 1, 'csda': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'filter_cnt_expired': 1, 'filter_cnt_nonzero': 1, 'clk_en': 1, 'cnt_zero': 1, 'slave_wait': 1, 'scl_sync': 1, 'sta_condition': 1, 'sto_condition': 1, 'sda_chk': 1, 'idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1, 'write_high_phase': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'idle'
        self.cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0
        self.scl_oen = 1
        self.sda_oen = 1
        self.c_scl_meta = 0
        self.c_scl = 0
        self.c_sda_meta = 0
        self.c_sda = 0
        self.fscl = 7
        self.fsda = 7
        self.dscl = 1
        self.dsda = 1
        self.filter_cnt = 0
        self.cnt = 0
        self.clk_en = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        if (int(i.get('nReset', 1)) & 1) == 0:
            state = 'idle'
            cmd_ack = 0
            busy = 0
            al = 0
            dout = 0
            scl_oen = 1
            sda_oen = 1
            cscl = 0
            csda = 0
            fscl = 7
            fsda = 7
            sscl = 1
            ssda = 1
            dscl = 1
            dsda = 1
            filter_cnt = 0
            cnt = 0
            clk_en = 0
        else:
            state = self.state
            cmd_ack = self.cmd_ack
            busy = self.busy
            al = self.al
            dout = self.dout
            scl_oen = self.scl_oen
            sda_oen = self.sda_oen
            cscl = self.c_scl
            csda = self.c_sda
            fscl = self.fscl
            fsda = self.fsda
            sscl = int(((fscl >> 2) & 1) + ((fscl >> 1) & 1) + (fscl & 1) >= 2)
            ssda = int(((fsda >> 2) & 1) + ((fsda >> 1) & 1) + (fsda & 1) >= 2)
            dscl = self.dscl
            dsda = self.dsda
            filter_cnt = self.filter_cnt
            cnt = self.cnt
            clk_en = self.clk_en

        self.cscl = bool(cscl)
        self.csda = bool(csda)
        self.fscl = fscl
        self.fsda = fsda
        self.sscl = bool(sscl)
        self.ssda = bool(ssda)
        self.dscl = bool(dscl)
        self.dsda = bool(dsda)
        self.filter_cnt_expired = bool(filter_cnt == 0)
        self.filter_cnt_nonzero = bool(filter_cnt != 0)
        self.clk_en = bool(clk_en)
        self.cnt_zero = bool(cnt == 0)
        self.slave_wait = bool(scl_oen and not sscl)
        self.scl_sync = bool(scl_oen and dscl and not sscl)
        self.sta_condition = bool((not ssda) and dsda and sscl)
        self.sto_condition = bool(ssda and (not dsda) and sscl)
        self.sda_chk = bool(state == 'write_b')
        self.idle = bool(state == 'idle')
        self.fsm_active = bool(state != 'idle')
        self.in_start_sequence = bool(state in ('start_a', 'start_b', 'start_c'))
        self.in_stop_sequence = bool(state in ('stop_a', 'stop_b', 'stop_c'))
        self.in_read_sequence = bool(state in ('read_a', 'read_b', 'read_c'))
        self.in_write_sequence = bool(state in ('write_a', 'write_b', 'write_c'))
        self.write_high_phase = bool(state == 'write_b')

        o['cmd_ack'] = int(cmd_ack)
        o['busy'] = int(busy)
        o['al'] = int(al)
        o['dout'] = int(dout)
        o['scl_o'] = 0
        o['scl_oen'] = int(scl_oen)
        o['sda_o'] = 0
        o['sda_oen'] = int(sda_oen)
        return o

    def advance(self, i):
        if (int(i.get('nReset', 1)) & 1) == 0:
            self.reset()
            return
        if int(i['rst']) & 1:
            self.reset()
            return

        ena = int(i['ena']) & 1
        clk_cnt = self.mask(int(i['clk_cnt']), 16)
        sscl = int(((self.fscl >> 2) & 1) + ((self.fscl >> 1) & 1) + (self.fscl & 1) >= 2)
        ssda = int(((self.fsda >> 2) & 1) + ((self.fsda >> 1) & 1) + (self.fsda & 1) >= 2)
        old_dscl = self.dscl
        old_dsda = self.dsda
        state = self.state
        scl_sync = bool(self.scl_oen and old_dscl and not sscl)
        slave_wait = bool(self.scl_oen and not sscl)
        sta_condition = bool((not ssda) and old_dsda and sscl)
        sto_condition = bool(ssda and (not old_dsda) and sscl)
        sda_chk = state == 'write_b'
        active = state != 'idle'
        stop_requested = state in ('stop_a', 'stop_b', 'stop_c')
        arbitration_lost = bool((sda_chk and self.sda_oen and not ssda) or
                                (active and not stop_requested and sto_condition))
        tick = self.clk_en
        old_c_scl = self.c_scl
        old_c_sda = self.c_sda

        if sscl and not old_dscl:
            self.dout = ssda
        self.dscl = sscl
        self.dsda = ssda
        self.c_scl = int(i['scl_i']) & 1
        self.c_scl_meta = old_c_scl
        self.c_sda = int(i['sda_i']) & 1
        self.c_sda_meta = old_c_sda

        if not ena:
            self.filter_cnt = 0
        elif self.filter_cnt == 0:
            self.filter_cnt = self.mask(clk_cnt >> 2, 14)
            self.fscl = self.mask((self.fscl << 1) | old_c_scl, 3)
            self.fsda = self.mask((self.fsda << 1) | old_c_sda, 3)
        else:
            self.filter_cnt = self.mask(self.filter_cnt - 1, 14)

        if sta_condition:
            self.busy = 1
        elif sto_condition:
            self.busy = 0

        self.cmd_ack = 0
        self.al = int(arbitration_lost)

        if not ena:
            self.cnt = clk_cnt
            self.clk_en = 1
        elif scl_sync or self.cnt == 0:
            self.cnt = clk_cnt
            self.clk_en = 1
        elif slave_wait:
            self.clk_en = 0
        else:
            self.cnt = self.mask(self.cnt - 1, 16)
            self.clk_en = 0

        if arbitration_lost:
            self.state = 'idle'
            self.scl_oen = 1
            self.sda_oen = 1
            return

        if not (ena and tick and not slave_wait):
            return

        if state == 'idle':
            cmd = int(i['cmd']) & 15
            if cmd == 1:
                self.state = 'start_a'
                self.scl_oen = 1
                self.sda_oen = 1
            elif cmd == 2:
                self.state = 'stop_a'
                self.sda_oen = 0
            elif cmd == 8:
                self.state = 'read_a'
                self.sda_oen = 1
            elif cmd == 4:
                self.state = 'write_a'
                self.sda_oen = int(i['din']) & 1
        elif state == 'start_a':
            self.state = 'start_b'
            self.sda_oen = 0
        elif state == 'start_b':
            self.state = 'start_c'
            self.scl_oen = 0
        elif state == 'start_c':
            self.state = 'idle'
            self.cmd_ack = 1
        elif state == 'stop_a':
            self.state = 'stop_b'
            self.scl_oen = 1
        elif state == 'stop_b':
            self.state = 'stop_c'
            self.sda_oen = 1
        elif state == 'stop_c':
            self.state = 'idle'
            self.cmd_ack = 1
        elif state == 'read_a':
            self.state = 'read_b'
            self.sda_oen = 1
            self.scl_oen = 1
        elif state == 'read_b':
            self.state = 'read_c'
            self.scl_oen = 0
        elif state == 'read_c':
            self.state = 'idle'
            self.cmd_ack = 1
        elif state == 'write_a':
            self.state = 'write_b'
            self.scl_oen = 1
        elif state == 'write_b':
            self.state = 'write_c'
            self.scl_oen = 0
        elif state == 'write_c':
            self.state = 'idle'
            self.cmd_ack = 1
        else:
            self.state = 'idle'
