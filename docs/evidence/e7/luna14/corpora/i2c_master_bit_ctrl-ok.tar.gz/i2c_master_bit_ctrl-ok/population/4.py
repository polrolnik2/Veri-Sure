"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['cscl', 'csda', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'filter_cnt_expired', 'filter_cnt_nonzero', 'clk_en', 'cnt_zero', 'slave_wait', 'scl_sync', 'sta_condition', 'sto_condition', 'sda_chk', 'idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence', 'write_high_phase']
    PROBE_WIDTHS = {'cscl': 1, 'csda': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'filter_cnt_expired': 1, 'filter_cnt_nonzero': 1, 'clk_en': 1, 'cnt_zero': 1, 'slave_wait': 1, 'scl_sync': 1, 'sta_condition': 1, 'sto_condition': 1, 'sda_chk': 1, 'idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1, 'write_high_phase': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'idle'
        self.cmd_ack_state = 0
        self.busy_state = 0
        self.al_state = 0
        self.dout_state = 0
        self.scl_oen_state = 1
        self.sda_oen_state = 1
        self.sda_chk_state = 0
        self.cSCL_meta = 1
        self.cSDA_meta = 1
        self.cSCL = 1
        self.cSDA = 1
        self.fSCL = 7
        self.fSDA = 7
        self.sSCL = 1
        self.sSDA = 1
        self.dSCL = 1
        self.dSDA = 1
        self.filter_cnt = 0
        self.cnt = 0
        self.clk_en_state = 1

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        async_reset = int(i['nReset']) == 0
        if async_reset:
            cmd_ack = 0
            busy = 0
            al = 0
            dout = 0
            scl_oen = 1
            sda_oen = 1
            cscl = 1
            csda = 1
            fscl = 7
            fsda = 7
            sscl = 1
            ssda = 1
            dscl = 1
            dsda = 1
            filter_cnt = 0
            cnt = 0
            clk_en = 1
            sda_chk = 0
            state = 'idle'
        else:
            cmd_ack = self.cmd_ack_state
            busy = self.busy_state
            al = self.al_state
            dout = self.dout_state
            scl_oen = self.scl_oen_state
            sda_oen = self.sda_oen_state
            cscl = self.cSCL
            csda = self.cSDA
            fscl = self.fSCL
            fsda = self.fSDA
            sscl = self.sSCL
            ssda = self.sSDA
            dscl = self.dSCL
            dsda = self.dSDA
            filter_cnt = self.filter_cnt
            cnt = self.cnt
            clk_en = self.clk_en_state
            sda_chk = self.sda_chk_state
            state = self.state

        slave_wait = bool(scl_oen and not sscl)
        scl_sync = bool(scl_oen and dscl and not sscl)
        sta_condition = bool((not ssda) and dsda and sscl)
        sto_condition = bool(ssda and (not dsda) and sscl)

        self.cscl = int(cscl)
        self.csda = int(csda)
        self.fscl = int(fscl)
        self.fsda = int(fsda)
        self.sscl = bool(sscl)
        self.ssda = bool(ssda)
        self.dscl = bool(dscl)
        self.dsda = bool(dsda)
        self.filter_cnt_expired = bool(filter_cnt == 0)
        self.filter_cnt_nonzero = bool(filter_cnt != 0)
        self.clk_en = bool(clk_en)
        self.cnt_zero = bool(cnt == 0)
        self.slave_wait = slave_wait
        self.scl_sync = scl_sync
        self.sta_condition = sta_condition
        self.sto_condition = sto_condition
        self.sda_chk = bool(sda_chk)
        self.idle = state == 'idle'
        self.fsm_active = state != 'idle'
        self.in_start_sequence = state.startswith('start_')
        self.in_stop_sequence = state.startswith('stop_')
        self.in_read_sequence = state.startswith('read_')
        self.in_write_sequence = state.startswith('write_')
        self.write_high_phase = state == 'write_high'

        o['cmd_ack'] = int(cmd_ack)
        o['busy'] = int(busy)
        o['al'] = int(al)
        o['dout'] = int(dout)
        o['scl_o'] = 0
        o['scl_oen'] = int(scl_oen)
        o['sda_o'] = 0
        o['sda_oen'] = int(sda_oen)
        return o

    def advance(self, i):
        if int(i['nReset']) == 0 or int(i['rst']) != 0:
            self.reset()
            return

        ena = int(i['ena']) != 0
        clk_cnt = self.mask(i['clk_cnt'], 16)
        old_state = self.state
        old_cnt = self.cnt
        old_clk_en = self.clk_en_state
        old_scl_oen = self.scl_oen_state
        old_sda_oen = self.sda_oen_state
        old_sda_chk = self.sda_chk_state
        old_sscl = self.sSCL
        old_ssda = self.sSDA
        old_dscl = self.dSCL
        old_dsda = self.dSDA
        old_fscl = self.fSCL
        old_fsda = self.fSDA
        old_cSCL = self.cSCL
        old_cSDA = self.cSDA

        slave_wait = bool(old_scl_oen and not old_sscl)
        scl_sync = bool(old_scl_oen and old_dscl and not old_sscl)
        sta_condition = bool((not old_ssda) and old_dsda and old_sscl)
        sto_condition = bool(old_ssda and (not old_dsda) and old_sscl)
        unexpected_stop = bool(sto_condition and old_state != 'idle' and not old_state.startswith('stop_'))
        arbitration_check_lost = bool(old_sda_chk and old_sda_oen and not old_ssda)
        arbitration_lost_now = arbitration_check_lost or unexpected_stop
        tick = bool(old_clk_en and ena and not slave_wait)

        if sta_condition:
            self.busy_state = 1
        elif sto_condition:
            self.busy_state = 0

        if old_sscl and not old_dscl:
            self.dout_state = int(old_ssda)

        self.cSCL_meta = int(i['scl_i']) & 1
        self.cSDA_meta = int(i['sda_i']) & 1
        self.cSCL = old_cSCL if False else self.cSCL
        self.cSCL = self.cSCL
        self.cSDA = self.cSDA
        self.cSCL = old_cSCL
        self.cSDA = old_cSDA
        self.cSCL_meta, self.cSCL = int(i['scl_i']) & 1, self.cSCL_meta
        self.cSDA_meta, self.cSDA = int(i['sda_i']) & 1, self.cSDA_meta

        if ena:
            if self.filter_cnt == 0:
                interval = clk_cnt >> 2
                self.filter_cnt = self.mask(interval, 16)
                self.fSCL = self.mask(((old_fscl & 3) << 1) | old_cSCL, 3)
                self.fSDA = self.mask(((old_fsda & 3) << 1) | old_cSDA, 3)
            else:
                self.filter_cnt = self.mask(self.filter_cnt - 1, 16)
        else:
            self.filter_cnt = 0

        self.sSCL = int(((old_fscl >> 2) & 1) + ((old_fscl >> 1) & 1) + (old_fscl & 1) >= 2)
        self.sSDA = int(((old_fsda >> 2) & 1) + ((old_fsda >> 1) & 1) + (old_fsda & 1) >= 2)
        self.dSCL = old_sscl
        self.dSDA = old_ssda

        if not ena:
            self.cnt = clk_cnt
            self.clk_en_state = 1
        elif scl_sync:
            self.cnt = clk_cnt
            self.clk_en_state = 0 if slave_wait else 1
        elif slave_wait:
            self.clk_en_state = 0
        elif old_cnt == 0:
            self.cnt = clk_cnt
            self.clk_en_state = 1
        else:
            self.cnt = self.mask(old_cnt - 1, 16)
            self.clk_en_state = 0

        self.cmd_ack_state = 0
        if arbitration_lost_now:
            self.al_state = 1
            self.state = 'idle'
            self.scl_oen_state = 1
            self.sda_oen_state = 1
            self.sda_chk_state = 0
        elif tick:
            cmd = self.mask(i['cmd'], 4)
            if old_state == 'idle':
                if cmd == 1:
                    self.state = 'start_release'
                    self.scl_oen_state = 1
                    self.sda_oen_state = 1
                    self.sda_chk_state = 0
                elif cmd == 2:
                    self.state = 'stop_sda_low'
                    self.scl_oen_state = 0
                    self.sda_oen_state = 0
                    self.sda_chk_state = 0
                elif cmd == 8:
                    self.state = 'read_sda_release'
                    self.scl_oen_state = 0
                    self.sda_oen_state = 1
                    self.sda_chk_state = 0
                elif cmd == 4:
                    self.state = 'write_data'
                    self.scl_oen_state = 0
                    self.sda_oen_state = int(i['din']) & 1
                    self.sda_chk_state = 0
            elif old_state == 'start_release':
                self.state = 'start_data_low'
                self.scl_oen_state = 1
                self.sda_oen_state = 0
            elif old_state == 'start_data_low':
                self.state = 'start_scl_low'
                self.scl_oen_state = 0
                self.sda_oen_state = 0
            elif old_state == 'start_scl_low':
                self.state = 'idle'
                self.cmd_ack_state = 1
            elif old_state == 'stop_sda_low':
                self.state = 'stop_scl_release'
                self.scl_oen_state = 1
                self.sda_oen_state = 0
            elif old_state == 'stop_scl_release':
                self.state = 'stop_sda_release'
                self.scl_oen_state = 1
                self.sda_oen_state = 1
            elif old_state == 'stop_sda_release':
                self.state = 'idle'
                self.cmd_ack_state = 1
            elif old_state == 'read_sda_release':
                self.state = 'read_scl_release'
                self.scl_oen_state = 1
                self.sda_oen_state = 1
            elif old_state == 'read_scl_release':
                self.state = 'read_scl_low'
                self.scl_oen_state = 0
                self.sda_oen_state = 1
            elif old_state == 'read_scl_low':
                self.state = 'idle'
                self.cmd_ack_state = 1
            elif old_state == 'write_data':
                self.state = 'write_high'
                self.scl_oen_state = 1
                self.sda_oen_state = int(i['din']) & 1
                self.sda_chk_state = 1
            elif old_state == 'write_high':
                self.state = 'write_low'
                self.scl_oen_state = 0
                self.sda_oen_state = int(i['din']) & 1
                self.sda_chk_state = 0
            elif old_state == 'write_low':
                self.state = 'idle'
                self.cmd_ack_state = 1
                self.sda_chk_state = 0
