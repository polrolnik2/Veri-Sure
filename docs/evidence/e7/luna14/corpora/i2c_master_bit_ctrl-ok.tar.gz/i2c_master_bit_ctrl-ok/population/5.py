"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['cscl', 'csda', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'filter_cnt_expired', 'filter_cnt_nonzero', 'clk_en', 'cnt_zero', 'slave_wait', 'scl_sync', 'sta_condition', 'sto_condition', 'sda_chk', 'idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence', 'write_high_phase']
    PROBE_WIDTHS = {'cscl': 1, 'csda': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'filter_cnt_expired': 1, 'filter_cnt_nonzero': 1, 'clk_en': 1, 'cnt_zero': 1, 'slave_wait': 1, 'scl_sync': 1, 'sta_condition': 1, 'sto_condition': 1, 'sda_chk': 1, 'idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1, 'write_high_phase': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'idle'
        self._scl_oen = 1
        self._sda_oen = 1
        self._cmd_ack = 0
        self._busy = 0
        self._al = 0
        self._dout = 0
        self._sync_scl1 = 1
        self._sync_sda1 = 1
        self._cscl_state = 1
        self._csda_state = 1
        self._fscl_state = 7
        self._fsda_state = 7
        self._dscl_state = 1
        self._dsda_state = 1
        self._filter_cnt = 0
        self._cnt = 0
        self._clk_en = 1

    def _majority(self, value):
        return int(((value >> 0) & 1) + ((value >> 1) & 1) + ((value >> 2) & 1) >= 2)

    def _signals(self):
        sscl = self._majority(self._fscl_state)
        ssda = self._majority(self._fsda_state)
        sta = int((not ssda) and self._dsda_state and sscl)
        sto = int(ssda and (not self._dsda_state) and sscl)
        slave_wait = bool(self._scl_oen and not sscl)
        scl_sync = bool(self._scl_oen and self._dscl_state and not sscl)
        return sscl, ssda, sta, sto, slave_wait, scl_sync

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        if not (i['nReset'] & 1):
            self.cscl = 1
            self.csda = 1
            self.fscl = 7
            self.fsda = 7
            self.sscl = 1
            self.ssda = 1
            self.dscl = 1
            self.dsda = 1
            self.filter_cnt_expired = True
            self.filter_cnt_nonzero = False
            self.clk_en = True
            self.cnt_zero = True
            self.slave_wait = False
            self.scl_sync = False
            self.sta_condition = False
            self.sto_condition = False
            self.sda_chk = False
            self.idle = True
            self.fsm_active = False
            self.in_start_sequence = False
            self.in_stop_sequence = False
            self.in_read_sequence = False
            self.in_write_sequence = False
            self.write_high_phase = False
            o['cmd_ack'] = 0
            o['busy'] = 0
            o['al'] = 0
            o['dout'] = 0
            o['scl_o'] = 0
            o['scl_oen'] = 1
            o['sda_o'] = 0
            o['sda_oen'] = 1
            return o

        sscl, ssda, sta, sto, slave_wait, scl_sync = self._signals()
        self.cscl = self._cscl_state
        self.csda = self._csda_state
        self.fscl = self._fscl_state
        self.fsda = self._fsda_state
        self.sscl = sscl
        self.ssda = ssda
        self.dscl = self._dscl_state
        self.dsda = self._dsda_state
        self.filter_cnt_expired = bool(self._filter_cnt == 0)
        self.filter_cnt_nonzero = bool(self._filter_cnt != 0)
        self.clk_en = bool(self._clk_en)
        self.cnt_zero = bool(self._cnt == 0)
        self.slave_wait = slave_wait
        self.scl_sync = scl_sync
        self.sta_condition = bool(sta)
        self.sto_condition = bool(sto)
        self.sda_chk = bool(self.state == 'write_b')
        self.idle = bool(self.state == 'idle')
        self.fsm_active = bool(self.state != 'idle')
        self.in_start_sequence = bool(self.state in ('start_a', 'start_b'))
        self.in_stop_sequence = bool(self.state in ('stop_a', 'stop_b'))
        self.in_read_sequence = bool(self.state in ('read_a', 'read_b'))
        self.in_write_sequence = bool(self.state in ('write_a', 'write_b'))
        self.write_high_phase = bool(self.state == 'write_b')
        o['cmd_ack'] = self._cmd_ack
        o['busy'] = self._busy
        o['al'] = self._al
        o['dout'] = self._dout
        o['scl_o'] = 0
        o['scl_oen'] = self._scl_oen
        o['sda_o'] = 0
        o['sda_oen'] = self._sda_oen
        return o

    def advance(self, i):
        if not (i['nReset'] & 1) or (i['rst'] & 1):
            self.reset()
            return

        sscl, ssda, sta, sto, slave_wait, scl_sync = self._signals()
        old_state = self.state
        old_tick = self._clk_en
        old_cnt = self._cnt
        old_cscl = self._cscl_state
        old_csda = self._csda_state
        old_sync_scl1 = self._sync_scl1
        old_sync_sda1 = self._sync_sda1
        old_sscl = sscl
        old_ssda = ssda
        old_dscl = self._dscl_state
        old_dsda = self._dsda_state

        arbitration_loss = bool(old_state == 'write_b' and self._sda_oen and not ssda)
        unexpected_stop = bool(sto and old_state != 'idle' and old_state not in ('stop_a', 'stop_b'))
        lose = arbitration_loss or unexpected_stop

        self._cmd_ack = 0
        if sta:
            self._busy = 1
        elif sto:
            self._busy = 0

        if old_sscl and not old_dscl:
            self._dout = old_ssda

        self._dscl_state = old_sscl
        self._dsda_state = old_ssda
        self._sync_scl1 = i['scl_i'] & 1
        self._sync_sda1 = i['sda_i'] & 1
        self._cscl_state = old_sync_scl1
        self._csda_state = old_sync_sda1

        if not (i['ena'] & 1):
            self._filter_cnt = 0
        elif self._filter_cnt == 0:
            self._fscl_state = ((self._fscl_state << 1) | old_cscl) & 7
            self._fsda_state = ((self._fsda_state << 1) | old_csda) & 7
            self._filter_cnt = ((i['clk_cnt'] & 65535) >> 2) & 16383
        else:
            self._filter_cnt = (self._filter_cnt - 1) & 16383

        if not (i['ena'] & 1):
            self._cnt = i['clk_cnt'] & 65535
            self._clk_en = 1
        elif scl_sync:
            self._cnt = i['clk_cnt'] & 65535
            self._clk_en = 1
        elif slave_wait:
            self._cnt = old_cnt
            self._clk_en = 0
        elif old_cnt == 0:
            self._cnt = i['clk_cnt'] & 65535
            self._clk_en = 1
        else:
            self._cnt = (old_cnt - 1) & 65535
            self._clk_en = 0

        if self._al:
            self.state = 'idle'
            self._scl_oen = 1
            self._sda_oen = 1
        elif lose:
            self._al = 1
            self.state = 'idle'
            self._scl_oen = 1
            self._sda_oen = 1
        elif old_tick and (i['ena'] & 1) and not slave_wait:
            if old_state == 'idle':
                cmd = i['cmd'] & 15
                if cmd == 1:
                    self.state = 'start_a'
                    self._scl_oen = 1
                    self._sda_oen = 1
                elif cmd == 2:
                    self.state = 'stop_a'
                    self._scl_oen = 0
                    self._sda_oen = 0
                elif cmd == 8:
                    self.state = 'read_a'
                    self._scl_oen = 0
                    self._sda_oen = 1
                elif cmd == 4:
                    self.state = 'write_a'
                    self._scl_oen = 0
                    self._sda_oen = i['din'] & 1
            elif old_state == 'start_a':
                self.state = 'start_b'
                self._sda_oen = 0
            elif old_state == 'start_b':
                self.state = 'idle'
                self._scl_oen = 0
                self._cmd_ack = 1
            elif old_state == 'stop_a':
                self.state = 'stop_b'
                self._scl_oen = 1
            elif old_state == 'stop_b':
                self.state = 'idle'
                self._sda_oen = 1
                self._cmd_ack = 1
            elif old_state == 'read_a':
                self.state = 'read_b'
                self._scl_oen = 1
            elif old_state == 'read_b':
                self.state = 'idle'
                self._scl_oen = 0
                self._cmd_ack = 1
            elif old_state == 'write_a':
                self.state = 'write_b'
                self._scl_oen = 1
            elif old_state == 'write_b':
                self.state = 'idle'
                self._scl_oen = 0
                self._cmd_ack = 1
