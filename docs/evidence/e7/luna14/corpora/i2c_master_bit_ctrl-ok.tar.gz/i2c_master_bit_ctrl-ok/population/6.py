"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['cscl', 'csda', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'filter_cnt_expired', 'filter_cnt_nonzero', 'clk_en', 'cnt_zero', 'slave_wait', 'scl_sync', 'sta_condition', 'sto_condition', 'sda_chk', 'idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence', 'write_high_phase']
    PROBE_WIDTHS = {'cscl': 1, 'csda': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'filter_cnt_expired': 1, 'filter_cnt_nonzero': 1, 'clk_en': 1, 'cnt_zero': 1, 'slave_wait': 1, 'scl_sync': 1, 'sta_condition': 1, 'sto_condition': 1, 'sda_chk': 1, 'idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1, 'write_high_phase': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'idle'
        self.cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0
        self.scl_oen = 1
        self.sda_oen = 1
        self.sda_check = 0
        self.timing_count = 0
        self.clk_enable = 1
        self.filter_count = 0
        self.cSCL = 1
        self.cSDA = 1
        self.fSCL = 7
        self.fSDA = 7
        self.dSCL = 1
        self.dSDA = 1
        self.cscl = 1
        self.csda = 1
        self.fscl = 7
        self.fsda = 7
        self.sscl = 1
        self.ssda = 1
        self.dscl = 1
        self.dsda = 1
        self.filter_cnt_expired = True
        self.filter_cnt_nonzero = False
        self.clk_en = True
        self.cnt_zero = True
        self.slave_wait = False
        self.scl_sync = False
        self.sta_condition = False
        self.sto_condition = False
        self.sda_chk = False
        self.idle = True
        self.fsm_active = False
        self.in_start_sequence = False
        self.in_stop_sequence = False
        self.in_read_sequence = False
        self.in_write_sequence = False
        self.write_high_phase = False

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        if not (i['nReset'] & 1):
            o['cmd_ack'] = 0
            o['busy'] = 0
            o['al'] = 0
            o['dout'] = 0
            o['scl_o'] = 0
            o['scl_oen'] = 1
            o['sda_o'] = 0
            o['sda_oen'] = 1
            self.cscl = 1
            self.csda = 1
            self.fscl = 7
            self.fsda = 7
            self.sscl = 1
            self.ssda = 1
            self.dscl = 1
            self.dsda = 1
            self.filter_cnt_expired = True
            self.filter_cnt_nonzero = False
            self.clk_en = True
            self.cnt_zero = True
            self.slave_wait = False
            self.scl_sync = False
            self.sta_condition = False
            self.sto_condition = False
            self.sda_chk = False
            self.idle = True
            self.fsm_active = False
            self.in_start_sequence = False
            self.in_stop_sequence = False
            self.in_read_sequence = False
            self.in_write_sequence = False
            self.write_high_phase = False
            return o

        scl_ones = ((self.fSCL >> 2) & 1) + ((self.fSCL >> 1) & 1) + (self.fSCL & 1)
        sda_ones = ((self.fSDA >> 2) & 1) + ((self.fSDA >> 1) & 1) + (self.fSDA & 1)
        sscl = int(scl_ones >= 2)
        ssda = int(sda_ones >= 2)
        scl_sync = bool(self.dSCL and not sscl and self.scl_oen)
        slave_wait = bool(self.scl_oen and not sscl)
        sta = bool((not ssda) and self.dSDA and sscl)
        sto = bool(ssda and (not self.dSDA) and sscl)

        o['cmd_ack'] = self.cmd_ack
        o['busy'] = self.busy
        o['al'] = self.al
        o['dout'] = self.dout
        o['scl_o'] = 0
        o['scl_oen'] = self.scl_oen
        o['sda_o'] = 0
        o['sda_oen'] = self.sda_oen

        self.cscl = self.cSCL
        self.csda = self.cSDA
        self.fscl = self.fSCL
        self.fsda = self.fSDA
        self.sscl = sscl
        self.ssda = ssda
        self.dscl = self.dSCL
        self.dsda = self.dSDA
        self.filter_cnt_expired = self.filter_count == 0
        self.filter_cnt_nonzero = self.filter_count != 0
        self.clk_en = bool(self.clk_enable)
        self.cnt_zero = self.timing_count == 0
        self.slave_wait = slave_wait
        self.scl_sync = scl_sync
        self.sta_condition = sta
        self.sto_condition = sto
        self.sda_chk = bool(self.sda_check)
        self.idle = self.state == 'idle'
        self.fsm_active = self.state != 'idle'
        self.in_start_sequence = self.state.startswith('start_')
        self.in_stop_sequence = self.state.startswith('stop_')
        self.in_read_sequence = self.state.startswith('rd_')
        self.in_write_sequence = self.state.startswith('wr_')
        self.write_high_phase = bool(self.state == 'wr_d' and self.sda_check)
        return o

    def advance(self, i):
        if not (i['nReset'] & 1) or (i['rst'] & 1):
            self.reset()
            return

        old_scl_ones = ((self.fSCL >> 2) & 1) + ((self.fSCL >> 1) & 1) + (self.fSCL & 1)
        old_sda_ones = ((self.fSDA >> 2) & 1) + ((self.fSDA >> 1) & 1) + (self.fSDA & 1)
        old_sscl = int(old_scl_ones >= 2)
        old_ssda = int(old_sda_ones >= 2)
        old_sta = bool((not old_ssda) and self.dSDA and old_sscl)
        old_sto = bool(old_ssda and (not self.dSDA) and old_sscl)
        old_scl_sync = bool(self.dSCL and not old_sscl and self.scl_oen)
        old_slave_wait = bool(self.scl_oen and not old_sscl)
        old_state = self.state
        old_al = self.al
        old_clk_enable = self.clk_enable
        old_cSCL = self.cSCL
        old_cSDA = self.cSDA

        arbitration_loss = bool(self.sda_check and self.sda_oen and not old_ssda)
        unexpected_stop = bool(old_sto and old_state != 'idle' and not old_state.startswith('stop_'))
        lost_now = bool(arbitration_loss or unexpected_stop)

        if old_sta:
            self.busy = 1
        elif old_sto:
            self.busy = 0

        if old_sscl and not self.dSCL:
            self.dout = old_ssda

        self.dSCL = old_sscl
        self.dSDA = old_ssda
        self.cSCL = i['scl_i'] & 1
        self.cSDA = i['sda_i'] & 1

        if not (i['ena'] & 1):
            self.filter_count = 0
        elif self.filter_count == 0:
            self.filter_count = (self.mask(i['clk_cnt'], 16) >> 2) & 16383
            self.fSCL = ((self.fSCL << 1) | old_cSCL) & 7
            self.fSDA = ((self.fSDA << 1) | old_cSDA) & 7
        else:
            self.filter_count = (self.filter_count - 1) & 16383

        self.cmd_ack = 0
        if lost_now or old_al:
            self.al = 1 if (lost_now or old_al) else 0
            self.state = 'idle'
            self.scl_oen = 1
            self.sda_oen = 1
            self.sda_check = 0
        else:
            tick = bool(old_clk_enable and (i['ena'] & 1) and not old_slave_wait)
            if tick:
                if old_state == 'idle':
                    self.scl_oen = 1
                    self.sda_oen = 1
                    self.sda_check = 0
                    command = self.mask(i['cmd'], 4)
                    if command == 1:
                        self.state = 'start_a'
                    elif command == 2:
                        self.state = 'stop_a'
                    elif command == 4:
                        self.state = 'wr_a'
                    elif command == 8:
                        self.state = 'rd_a'
                    else:
                        self.state = 'idle'
                elif old_state == 'start_a':
                    self.scl_oen = 1
                    self.sda_oen = 1
                    self.sda_check = 0
                    self.state = 'start_b'
                elif old_state == 'start_b':
                    self.scl_oen = 1
                    self.sda_oen = 1
                    self.sda_check = 0
                    self.state = 'start_c'
                elif old_state == 'start_c':
                    self.scl_oen = 1
                    self.sda_oen = 0
                    self.sda_check = 0
                    self.state = 'start_d'
                elif old_state == 'start_d':
                    self.scl_oen = 1
                    self.sda_oen = 0
                    self.sda_check = 0
                    self.state = 'start_e'
                elif old_state == 'start_e':
                    self.scl_oen = 0
                    self.sda_oen = 0
                    self.sda_check = 0
                    self.state = 'idle'
                    self.cmd_ack = 1
                elif old_state == 'stop_a':
                    self.scl_oen = 0
                    self.sda_oen = 0
                    self.sda_check = 0
                    self.state = 'stop_b'
                elif old_state == 'stop_b':
                    self.scl_oen = 1
                    self.sda_oen = 0
                    self.sda_check = 0
                    self.state = 'stop_c'
                elif old_state == 'stop_c':
                    self.scl_oen = 1
                    self.sda_oen = 0
                    self.sda_check = 0
                    self.state = 'stop_d'
                elif old_state == 'stop_d':
                    self.scl_oen = 1
                    self.sda_oen = 1
                    self.sda_check = 0
                    self.state = 'idle'
                    self.cmd_ack = 1
                elif old_state == 'rd_a':
                    self.scl_oen = 0
                    self.sda_oen = 1
                    self.sda_check = 0
                    self.state = 'rd_b'
                elif old_state == 'rd_b':
                    self.scl_oen = 0
                    self.sda_oen = 1
                    self.sda_check = 0
                    self.state = 'rd_c'
                elif old_state == 'rd_c':
                    self.scl_oen = 1
                    self.sda_oen = 1
                    self.sda_check = 0
                    self.state = 'rd_d'
                elif old_state == 'rd_d':
                    self.scl_oen = 0
                    self.sda_oen = 1
                    self.sda_check = 0
                    self.state = 'idle'
                    self.cmd_ack = 1
                elif old_state == 'wr_a':
                    self.scl_oen = 0
                    self.sda_oen = 1 - (i['din'] & 1)
                    self.sda_check = 0
                    self.state = 'wr_b'
                elif old_state == 'wr_b':
                    self.scl_oen = 0
                    self.sda_oen = 1 - (i['din'] & 1)
                    self.sda_check = 0
                    self.state = 'wr_c'
                elif old_state == 'wr_c':
                    self.scl_oen = 1
                    self.sda_oen = 1 - (i['din'] & 1)
                    self.sda_check = 1
                    self.state = 'wr_d'
                elif old_state == 'wr_d':
                    self.scl_oen = 0
                    self.sda_oen = 1 - (i['din'] & 1)
                    self.sda_check = 0
                    self.state = 'idle'
                    self.cmd_ack = 1

        if not (i['ena'] & 1):
            self.timing_count = self.mask(i['clk_cnt'], 16)
            self.clk_enable = 1
        elif old_scl_sync:
            self.timing_count = self.mask(i['clk_cnt'], 16)
            self.clk_enable = 1
        elif old_slave_wait:
            self.clk_enable = 0
        elif self.timing_count == 0:
            self.timing_count = self.mask(i['clk_cnt'], 16)
            self.clk_enable = 1
        else:
            self.timing_count = (self.timing_count - 1) & 65535
            self.clk_enable = 0
