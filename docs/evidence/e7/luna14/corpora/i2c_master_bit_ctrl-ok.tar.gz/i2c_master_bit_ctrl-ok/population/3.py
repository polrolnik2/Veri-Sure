"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['cscl', 'csda', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'filter_cnt_expired', 'filter_cnt_nonzero', 'clk_en', 'cnt_zero', 'slave_wait', 'scl_sync', 'sta_condition', 'sto_condition', 'sda_chk', 'idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence', 'write_high_phase']
    PROBE_WIDTHS = {'cscl': 1, 'csda': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'filter_cnt_expired': 1, 'filter_cnt_nonzero': 1, 'clk_en': 1, 'cnt_zero': 1, 'slave_wait': 1, 'scl_sync': 1, 'sta_condition': 1, 'sto_condition': 1, 'sda_chk': 1, 'idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1, 'write_high_phase': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'idle'
        self.cnt = 0
        self.filter_cnt = 0
        self.clk_en = 0
        self.cSCL1 = 1
        self.cSCL2 = 1
        self.cSDA1 = 1
        self.cSDA2 = 1
        self.fSCL = 7
        self.fSDA = 7
        self.dSCL = 1
        self.dSDA = 1
        self.scl_oen = 1
        self.sda_oen = 1
        self.cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0
        self.write_din = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        async_reset = (i['nReset'] & 1) == 0

        if async_reset:
            state = 'idle'
            cnt = 0
            filter_cnt = 0
            clk_en = 0
            cscl = 1
            csda = 1
            fscl = 7
            fsda = 7
            dscl = 1
            dsda = 1
            scl_oen = 1
            sda_oen = 1
            cmd_ack = 0
            busy = 0
            al = 0
            dout = 0
        else:
            state = self.state
            cnt = self.cnt
            filter_cnt = self.filter_cnt
            clk_en = self.clk_en
            cscl = self.cSCL2
            csda = self.cSDA2
            fscl = self.fSCL
            fsda = self.fSDA
            dscl = self.dSCL
            dsda = self.dSDA
            scl_oen = self.scl_oen
            sda_oen = self.sda_oen
            cmd_ack = self.cmd_ack
            busy = self.busy
            al = self.al
            dout = self.dout

        sscl = int(((fscl >> 0) & 1) + ((fscl >> 1) & 1) + ((fscl >> 2) & 1) >= 2)
        ssda = int(((fsda >> 0) & 1) + ((fsda >> 1) & 1) + ((fsda >> 2) & 1) >= 2)
        slave_wait = bool(scl_oen and not sscl)
        scl_sync = bool(scl_oen and dscl and not sscl)
        sta_condition = bool((not ssda) and dsda and sscl)
        sto_condition = bool(ssda and (not dsda) and sscl)
        sda_chk = state == 'write_c'

        o['cmd_ack'] = int(cmd_ack)
        o['busy'] = int(busy)
        o['al'] = int(al)
        o['dout'] = int(dout)
        o['scl_o'] = 0
        o['scl_oen'] = int(scl_oen)
        o['sda_o'] = 0
        o['sda_oen'] = int(sda_oen)

        self.cscl = bool(cscl)
        self.csda = bool(csda)
        self.fscl = fscl
        self.fsda = fsda
        self.sscl = bool(sscl)
        self.ssda = bool(ssda)
        self.dscl = bool(dscl)
        self.dsda = bool(dsda)
        self.filter_cnt_expired = bool(filter_cnt == 0)
        self.filter_cnt_nonzero = bool(filter_cnt != 0)
        self.clk_en = bool(clk_en)
        self.cnt_zero = bool(cnt == 0)
        self.slave_wait = slave_wait
        self.scl_sync = scl_sync
        self.sta_condition = sta_condition
        self.sto_condition = sto_condition
        self.sda_chk = bool(sda_chk)
        self.idle = state == 'idle'
        self.fsm_active = state != 'idle'
        self.in_start_sequence = state in ('start_a', 'start_b', 'start_c')
        self.in_stop_sequence = state in ('stop_a', 'stop_b', 'stop_c')
        self.in_read_sequence = state in ('read_a', 'read_b', 'read_c', 'read_d')
        self.in_write_sequence = state in ('write_a', 'write_b', 'write_c', 'write_d')
        self.write_high_phase = state == 'write_c'
        return o

    def advance(self, i):
        if (i['nReset'] & 1) == 0 or (i['rst'] & 1):
            self.reset()
            return

        ena = i['ena'] & 1
        clk_cnt = self.mask(i['clk_cnt'], 16)
        scl_raw = i['scl_i'] & 1
        sda_raw = i['sda_i'] & 1
        cmd = self.mask(i['cmd'], 4)

        old_sscl = int(((self.fSCL >> 0) & 1) + ((self.fSCL >> 1) & 1) + ((self.fSCL >> 2) & 1) >= 2)
        old_ssda = int(((self.fSDA >> 0) & 1) + ((self.fSDA >> 1) & 1) + ((self.fSDA >> 2) & 1) >= 2)
        sta_condition = bool((not old_ssda) and self.dSDA and old_sscl)
        sto_condition = bool(old_ssda and (not self.dSDA) and old_sscl)
        slave_wait = bool(self.scl_oen and not old_sscl)
        scl_sync = bool(self.scl_oen and self.dSCL and not old_sscl)
        sda_chk = self.state == 'write_c'
        arbitration_loss = bool((sda_chk and self.sda_oen and not old_ssda) or
                                (sto_condition and self.state != 'idle' and not self.state.startswith('stop_')))
        old_clk_en = self.clk_en
        old_cnt = self.cnt
        old_filter_cnt = self.filter_cnt
        old_cSCL1 = self.cSCL1
        old_cSDA1 = self.cSDA1

        self.cmd_ack = 0
        if sta_condition:
            self.busy = 1
        elif sto_condition:
            self.busy = 0

        if old_sscl and not self.dSCL:
            self.dout = old_ssda

        if arbitration_loss:
            self.al = 1

        # Delayed filtered samples follow the previous histories; the filter uses
        # the previously synchronized input sample on an expiration.
        self.dSCL = old_sscl
        self.dSDA = old_ssda
        self.cSCL2 = old_cSCL1
        self.cSDA2 = old_cSDA1
        self.cSCL1 = scl_raw
        self.cSDA1 = sda_raw

        if not ena:
            self.filter_cnt = 0
        elif old_filter_cnt == 0:
            self.fSCL = self.mask((self.fSCL << 1) | self.cSCL2, 3)
            self.fSDA = self.mask((self.fSDA << 1) | self.cSDA2, 3)
            self.filter_cnt = self.mask(clk_cnt >> 2, 16)
        else:
            self.filter_cnt = self.mask(old_filter_cnt - 1, 16)

        if arbitration_loss:
            self.state = 'idle'
            self.scl_oen = 1
            self.sda_oen = 1
        elif old_clk_en and ena and not slave_wait and not scl_sync:
            if self.state == 'idle':
                if cmd == 1:  # START
                    self.state = 'start_a'
                    self.scl_oen = 1
                    self.sda_oen = 1
                elif cmd == 2:  # STOP
                    self.state = 'stop_a'
                    self.scl_oen = 0
                    self.sda_oen = 0
                elif cmd == 8:  # READ
                    self.state = 'read_a'
                    self.scl_oen = 0
                    self.sda_oen = 1
                elif cmd == 4:  # WRITE
                    self.state = 'write_a'
                    self.write_din = i['din'] & 1
                    self.scl_oen = 0
                    self.sda_oen = self.write_din
            elif self.state == 'start_a':
                self.state = 'start_b'
                self.scl_oen = 1
                self.sda_oen = 0
            elif self.state == 'start_b':
                self.state = 'start_c'
                self.scl_oen = 0
                self.sda_oen = 0
            elif self.state == 'start_c':
                self.state = 'idle'
                self.cmd_ack = 1
            elif self.state == 'stop_a':
                self.state = 'stop_b'
                self.scl_oen = 1
                self.sda_oen = 0
            elif self.state == 'stop_b':
                self.state = 'stop_c'
                self.scl_oen = 1
                self.sda_oen = 1
            elif self.state == 'stop_c':
                self.state = 'idle'
                self.cmd_ack = 1
            elif self.state == 'read_a':
                self.state = 'read_b'
                self.scl_oen = 1
                self.sda_oen = 1
            elif self.state == 'read_b':
                self.state = 'read_c'
                self.scl_oen = 1
                self.sda_oen = 1
            elif self.state == 'read_c':
                self.state = 'read_d'
                self.scl_oen = 0
                self.sda_oen = 1
            elif self.state == 'read_d':
                self.state = 'idle'
                self.cmd_ack = 1
            elif self.state == 'write_a':
                self.state = 'write_b'
                self.scl_oen = 1
                self.sda_oen = self.write_din
            elif self.state == 'write_b':
                self.state = 'write_c'
                self.scl_oen = 1
                self.sda_oen = self.write_din
            elif self.state == 'write_c':
                self.state = 'write_d'
                self.scl_oen = 0
                self.sda_oen = self.write_din
            elif self.state == 'write_d':
                self.state = 'idle'
                self.cmd_ack = 1

        # The divider tick is registered and is consumed by the FSM on a later edge.
        if not ena:
            self.cnt = clk_cnt
            self.clk_en = 1
        elif scl_sync:
            self.cnt = clk_cnt
            self.clk_en = 1
        elif slave_wait:
            self.cnt = old_cnt
            self.clk_en = 0
        elif old_cnt == 0:
            self.cnt = clk_cnt
            self.clk_en = 1
        else:
            self.cnt = self.mask(old_cnt - 1, 16)
            self.clk_en = 0
