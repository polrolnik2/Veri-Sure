"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['cscl', 'csda', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'filter_cnt_expired', 'filter_cnt_nonzero', 'clk_en', 'cnt_zero', 'slave_wait', 'scl_sync', 'sta_condition', 'sto_condition', 'sda_chk', 'idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence', 'write_high_phase']
    PROBE_WIDTHS = {'cscl': 1, 'csda': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'filter_cnt_expired': 1, 'filter_cnt_nonzero': 1, 'clk_en': 1, 'cnt_zero': 1, 'slave_wait': 1, 'scl_sync': 1, 'sta_condition': 1, 'sto_condition': 1, 'sda_chk': 1, 'idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1, 'write_high_phase': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self._reset_state()

    def _reset_state(self):
        self.state = 'idle'
        self.command = 0
        self.scl_oen = 1
        self.sda_oen = 1
        self.cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0
        self.cSCL1 = 1
        self.cSCL = 1
        self.cSDA1 = 1
        self.cSDA = 1
        self.fSCL = 7
        self.fSDA = 7
        self.dSCL = 1
        self.dSDA = 1
        self.filter_cnt = 0
        self.cnt = 0
        self.clk_en = 0
        self.write_bit = 1

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        if int(i['nReset']) == 0:
            self.cscl = 1
            self.csda = 1
            self.fscl = 7
            self.fsda = 7
            self.sscl = 1
            self.ssda = 1
            self.dscl = 1
            self.dsda = 1
            self.filter_cnt_expired = True
            self.filter_cnt_nonzero = False
            self.clk_en = False
            self.cnt_zero = True
            self.slave_wait = False
            self.scl_sync = False
            self.sta_condition = False
            self.sto_condition = False
            self.sda_chk = False
            self.idle = True
            self.fsm_active = False
            self.in_start_sequence = False
            self.in_stop_sequence = False
            self.in_read_sequence = False
            self.in_write_sequence = False
            self.write_high_phase = False
            o['cmd_ack'] = 0
            o['busy'] = 0
            o['al'] = 0
            o['dout'] = 0
            o['scl_o'] = 0
            o['scl_oen'] = 1
            o['sda_o'] = 0
            o['sda_oen'] = 1
            return o

        sscl = int(((self.fSCL & 1) + ((self.fSCL >> 1) & 1) + ((self.fSCL >> 2) & 1)) >= 2)
        ssda = int(((self.fSDA & 1) + ((self.fSDA >> 1) & 1) + ((self.fSDA >> 2) & 1)) >= 2)
        slave_wait = bool(self.scl_oen and not sscl)
        scl_sync = bool(self.scl_oen and self.dSCL and not sscl)

        self.cscl = self.cSCL
        self.csda = self.cSDA
        self.fscl = self.fSCL
        self.fsda = self.fSDA
        self.sscl = sscl
        self.ssda = ssda
        self.dscl = self.dSCL
        self.dsda = self.dSDA
        self.filter_cnt_expired = self.filter_cnt == 0
        self.filter_cnt_nonzero = self.filter_cnt != 0
        self.clk_en = bool(self.clk_en and not slave_wait)
        self.cnt_zero = self.cnt == 0
        self.slave_wait = slave_wait
        self.scl_sync = scl_sync
        self.sta_condition = bool(not ssda and self.dSDA and sscl)
        self.sto_condition = bool(ssda and not self.dSDA and sscl)
        self.sda_chk = self.state == 'write_high'
        self.idle = self.state == 'idle'
        self.fsm_active = self.state != 'idle'
        self.in_start_sequence = self.state.startswith('start_')
        self.in_stop_sequence = self.state.startswith('stop_')
        self.in_read_sequence = self.state.startswith('read_')
        self.in_write_sequence = self.state.startswith('write_')
        self.write_high_phase = self.state == 'write_high'

        o['cmd_ack'] = self.cmd_ack
        o['busy'] = self.busy
        o['al'] = self.al
        o['dout'] = self.dout
        o['scl_o'] = 0
        o['scl_oen'] = self.scl_oen
        o['sda_o'] = 0
        o['sda_oen'] = self.sda_oen
        return o

    def advance(self, i):
        if int(i['nReset']) == 0 or int(i['rst']) != 0:
            self._reset_state()
            return

        ena = int(i['ena']) & 1
        clk_cnt = self.mask(int(i['clk_cnt']), 16)
        filter_period = self.mask(clk_cnt >> 2, 14)

        sscl = int(((self.fSCL & 1) + ((self.fSCL >> 1) & 1) + ((self.fSCL >> 2) & 1)) >= 2)
        ssda = int(((self.fSDA & 1) + ((self.fSDA >> 1) & 1) + ((self.fSDA >> 2) & 1)) >= 2)
        slave_wait = bool(self.scl_oen and not sscl)
        scl_sync = bool(self.scl_oen and self.dSCL and not sscl)
        sta_condition = bool(not ssda and self.dSDA and sscl)
        sto_condition = bool(ssda and not self.dSDA and sscl)
        filter_expired = self.filter_cnt == 0
        fsm_tick = bool(self.clk_en and ena and not slave_wait and not scl_sync)

        arbitration_lost = bool(
            (self.state == 'write_high' and self.sda_oen and not ssda)
            or (self.state != 'idle' and self.command != 2 and sto_condition)
        )

        old_cSCL = self.cSCL
        old_cSDA = self.cSDA
        old_cSCL1 = self.cSCL1
        old_cSDA1 = self.cSDA1

        if sscl and not self.dSCL:
            self.dout = ssda

        if sta_condition:
            self.busy = 1
        elif sto_condition:
            self.busy = 0

        self.dSCL = sscl
        self.dSDA = ssda
        self.cSCL1 = int(i['scl_i']) & 1
        self.cSDA1 = int(i['sda_i']) & 1
        self.cSCL = old_cSCL1
        self.cSDA = old_cSDA1

        if not ena:
            self.filter_cnt = 0
        elif filter_expired:
            self.filter_cnt = filter_period
            self.fSCL = self.mask((self.fSCL << 1) | old_cSCL, 3)
            self.fSDA = self.mask((self.fSDA << 1) | old_cSDA, 3)
        else:
            self.filter_cnt = self.mask(self.filter_cnt - 1, 14)

        old_clk_en = self.clk_en
        if not ena:
            self.cnt = clk_cnt
            self.clk_en = 1
        elif slave_wait:
            self.clk_en = 0
        elif scl_sync or self.cnt == 0:
            self.cnt = clk_cnt
            self.clk_en = 1
        else:
            self.cnt = self.mask(self.cnt - 1, 16)
            self.clk_en = 0

        self.cmd_ack = 0
        if arbitration_lost:
            self.al = 1
            self.state = 'idle'
            self.command = 0
            self.scl_oen = 1
            self.sda_oen = 1
        elif fsm_tick and old_clk_en:
            if self.state == 'idle':
                command = int(i['cmd']) & 15
                if command == 1:
                    self.command = 1
                    self.state = 'start_release'
                    self.scl_oen = 1
                    self.sda_oen = 1
                elif command == 2:
                    self.command = 2
                    self.state = 'stop_data_low'
                    self.scl_oen = 0
                    self.sda_oen = 0
                elif command == 8:
                    self.command = 8
                    self.state = 'read_setup'
                    self.scl_oen = 0
                    self.sda_oen = 1
                elif command == 4:
                    self.command = 4
                    self.write_bit = int(i['din']) & 1
                    self.state = 'write_setup'
                    self.scl_oen = 0
                    self.sda_oen = self.write_bit
            elif self.state == 'start_release':
                self.state = 'start_data_low'
                self.scl_oen = 1
                self.sda_oen = 0
            elif self.state == 'start_data_low':
                self.state = 'start_clock_low'
                self.scl_oen = 0
                self.sda_oen = 0
            elif self.state == 'start_clock_low':
                self.state = 'idle'
                self.command = 0
                self.cmd_ack = 1
            elif self.state == 'stop_data_low':
                self.state = 'stop_clock_high'
                self.scl_oen = 1
                self.sda_oen = 0
            elif self.state == 'stop_clock_high':
                self.state = 'stop_data_high'
                self.scl_oen = 1
                self.sda_oen = 1
            elif self.state == 'stop_data_high':
                self.state = 'idle'
                self.command = 0
                self.cmd_ack = 1
            elif self.state == 'read_setup':
                self.state = 'read_clock_high'
                self.scl_oen = 1
                self.sda_oen = 1
            elif self.state == 'read_clock_high':
                self.state = 'read_clock_low'
                self.scl_oen = 0
                self.sda_oen = 1
            elif self.state == 'read_clock_low':
                self.state = 'idle'
                self.command = 0
                self.cmd_ack = 1
            elif self.state == 'write_setup':
                self.state = 'write_high'
                self.scl_oen = 1
                self.sda_oen = self.write_bit
            elif self.state == 'write_high':
                self.state = 'write_low'
                self.scl_oen = 0
                self.sda_oen = self.write_bit
            elif self.state == 'write_low':
                self.state = 'idle'
                self.command = 0
                self.cmd_ack = 1
