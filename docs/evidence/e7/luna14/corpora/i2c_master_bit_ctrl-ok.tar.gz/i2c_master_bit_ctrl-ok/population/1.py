"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['cscl', 'csda', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'filter_cnt_expired', 'filter_cnt_nonzero', 'clk_en', 'cnt_zero', 'slave_wait', 'scl_sync', 'sta_condition', 'sto_condition', 'sda_chk', 'idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence', 'write_high_phase']
    PROBE_WIDTHS = {'cscl': 1, 'csda': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'filter_cnt_expired': 1, 'filter_cnt_nonzero': 1, 'clk_en': 1, 'cnt_zero': 1, 'slave_wait': 1, 'scl_sync': 1, 'sta_condition': 1, 'sto_condition': 1, 'sda_chk': 1, 'idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1, 'write_high_phase': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'idle'
        self.cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0
        self.scl_oen = 1
        self.sda_oen = 1
        self.sda_chk_q = False
        self.cSCL0 = 1
        self.cSCL1 = 1
        self.cSDA0 = 1
        self.cSDA1 = 1
        self.fSCL_q = 7
        self.fSDA_q = 7
        self.dSCL_q = 1
        self.dSDA_q = 1
        self.filter_cnt = 0
        self.cnt = 0
        self.clk_en = 1
        self.cscl = True
        self.csda = True
        self.fscl = 7
        self.fsda = 7
        self.sscl = True
        self.ssda = True
        self.dscl = True
        self.dsda = True
        self.filter_cnt_expired = True
        self.filter_cnt_nonzero = False
        self.cnt_zero = True
        self.slave_wait = False
        self.scl_sync = False
        self.sta_condition = False
        self.sto_condition = False
        self.sda_chk = False
        self.idle = True
        self.fsm_active = False
        self.in_start_sequence = False
        self.in_stop_sequence = False
        self.in_read_sequence = False
        self.in_write_sequence = False
        self.write_high_phase = False

    def _majority(self, value):
        b0 = value & 1
        b1 = (value >> 1) & 1
        b2 = (value >> 2) & 1
        return int((b0 + b1 + b2) >= 2)

    def _signals(self):
        sscl = self._majority(self.fSCL_q)
        ssda = self._majority(self.fSDA_q)
        slave_wait = bool(self.scl_oen and not sscl)
        scl_sync = bool(self.scl_oen and self.dSCL_q and not sscl)
        sta_condition = bool((not ssda) and self.dSDA_q and sscl)
        sto_condition = bool(ssda and (not self.dSDA_q) and sscl)
        return {
            'sscl': sscl,
            'ssda': ssda,
            'slave_wait': slave_wait,
            'scl_sync': scl_sync,
            'sta_condition': sta_condition,
            'sto_condition': sto_condition
        }

    def _abort(self):
        self.state = 'idle'
        self.scl_oen = 1
        self.sda_oen = 1
        self.sda_chk_q = False
        self.cmd_ack = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        if not i['nReset']:
            o['cmd_ack'] = 0
            o['busy'] = 0
            o['al'] = 0
            o['dout'] = 0
            o['scl_o'] = 0
            o['scl_oen'] = 1
            o['sda_o'] = 0
            o['sda_oen'] = 1
            probes = {
                'cscl': True, 'csda': True, 'fscl': 7, 'fsda': 7,
                'sscl': True, 'ssda': True, 'dscl': True, 'dsda': True,
                'filter_cnt_expired': True, 'filter_cnt_nonzero': False,
                'clk_en': True, 'cnt_zero': True, 'slave_wait': False,
                'scl_sync': False, 'sta_condition': False, 'sto_condition': False,
                'sda_chk': False, 'idle': True, 'fsm_active': False,
                'in_start_sequence': False, 'in_stop_sequence': False,
                'in_read_sequence': False, 'in_write_sequence': False,
                'write_high_phase': False
            }
        else:
            sig = self._signals()
            o['cmd_ack'] = int(bool(self.cmd_ack))
            o['busy'] = int(bool(self.busy))
            o['al'] = int(bool(self.al))
            o['dout'] = int(bool(self.dout))
            o['scl_o'] = 0
            o['scl_oen'] = int(bool(self.scl_oen))
            o['sda_o'] = 0
            o['sda_oen'] = int(bool(self.sda_oen))
            probes = {
                'cscl': bool(self.cSCL1),
                'csda': bool(self.cSDA1),
                'fscl': self.fSCL_q & 7,
                'fsda': self.fSDA_q & 7,
                'sscl': bool(sig['sscl']),
                'ssda': bool(sig['ssda']),
                'dscl': bool(self.dSCL_q),
                'dsda': bool(self.dSDA_q),
                'filter_cnt_expired': bool(self.filter_cnt == 0),
                'filter_cnt_nonzero': bool(self.filter_cnt != 0),
                'clk_en': bool(self.clk_en),
                'cnt_zero': bool(self.cnt == 0),
                'slave_wait': sig['slave_wait'],
                'scl_sync': sig['scl_sync'],
                'sta_condition': sig['sta_condition'],
                'sto_condition': sig['sto_condition'],
                'sda_chk': bool(self.sda_chk_q),
                'idle': self.state == 'idle',
                'fsm_active': self.state != 'idle',
                'in_start_sequence': self.state in ('start_release', 'start_data'),
                'in_stop_sequence': self.state in ('stop_drive', 'stop_high'),
                'in_read_sequence': self.state in ('read_setup', 'read_high'),
                'in_write_sequence': self.state in ('write_data', 'write_high'),
                'write_high_phase': self.state == 'write_high'
            }
        for name, value in probes.items():
            setattr(self, name, value)
        return o

    def advance(self, i):
        if not i['nReset'] or i['rst']:
            self.reset()
            return

        sig = self._signals()
        tick = bool(self.clk_en)
        active_stop = self.state in ('stop_drive', 'stop_high')
        arb_lost_now = bool(
            (self.sda_chk_q and self.sda_oen and not sig['ssda']) or
            (sig['sto_condition'] and self.state != 'idle' and not active_stop)
        )

        self.cmd_ack = 0
        if sig['sta_condition']:
            self.busy = 1
        elif sig['sto_condition']:
            self.busy = 0

        if sig['sscl'] and not self.dSCL_q:
            self.dout = int(bool(sig['ssda']))

        old_cSCL0 = self.cSCL0
        old_cSDA0 = self.cSDA0
        old_cSCL1 = self.cSCL1
        old_cSDA1 = self.cSDA1
        self.cSCL0 = int(i['scl_i']) & 1
        self.cSDA0 = int(i['sda_i']) & 1
        self.cSCL1 = old_cSCL0
        self.cSDA1 = old_cSDA0
        self.dSCL_q = int(bool(sig['sscl']))
        self.dSDA_q = int(bool(sig['ssda']))

        clk_cnt = self.mask(i['clk_cnt'], 16)
        filter_interval = (clk_cnt >> 2) & 0x3fff
        if not i['ena']:
            self.filter_cnt = 0
        elif self.filter_cnt == 0:
            self.fSCL_q = (((self.fSCL_q & 3) << 1) | int(bool(old_cSCL1))) & 7
            self.fSDA_q = (((self.fSDA_q & 3) << 1) | int(bool(old_cSDA1))) & 7
            self.filter_cnt = filter_interval
        else:
            self.filter_cnt = (self.filter_cnt - 1) & 0x3fff

        if not i['ena']:
            self.cnt = clk_cnt
            self.clk_en = 1
        elif sig['scl_sync']:
            self.cnt = clk_cnt
            self.clk_en = 1
        elif sig['slave_wait']:
            self.clk_en = 0
        elif self.cnt == 0:
            self.cnt = clk_cnt
            self.clk_en = 1
        else:
            self.cnt = (self.cnt - 1) & 0xffff
            self.clk_en = 0

        if self.al or arb_lost_now:
            if arb_lost_now:
                self.al = 1
            self._abort()
            return

        if not (tick and i['ena'] and not sig['slave_wait']):
            return

        if self.state == 'idle':
            command = int(i['cmd']) & 0xf
            if command == 1:
                self.state = 'start_release'
                self.scl_oen = 1
                self.sda_oen = 1
                self.sda_chk_q = False
            elif command == 2:
                self.state = 'stop_drive'
                self.scl_oen = 0
                self.sda_oen = 0
                self.sda_chk_q = False
            elif command == 8:
                self.state = 'read_setup'
                self.scl_oen = 0
                self.sda_oen = 1
                self.sda_chk_q = False
            elif command == 4:
                self.state = 'write_data'
                self.scl_oen = 0
                self.sda_oen = int(bool(int(i['din']) & 1))
                self.sda_chk_q = False
        elif self.state == 'start_release':
            self.state = 'start_data'
            self.scl_oen = 1
            self.sda_oen = 0
        elif self.state == 'start_data':
            self.state = 'idle'
            self.scl_oen = 0
            self.cmd_ack = 1
        elif self.state == 'stop_drive':
            self.state = 'stop_high'
            self.scl_oen = 1
            self.sda_oen = 0
        elif self.state == 'stop_high':
            self.state = 'idle'
            self.scl_oen = 1
            self.sda_oen = 1
            self.cmd_ack = 1
        elif self.state == 'read_setup':
            self.state = 'read_high'
            self.scl_oen = 1
            self.sda_oen = 1
        elif self.state == 'read_high':
            self.state = 'idle'
            self.scl_oen = 0
            self.sda_oen = 1
            self.cmd_ack = 1
        elif self.state == 'write_data':
            self.state = 'write_high'
            self.scl_oen = 1
            self.sda_chk_q = True
        elif self.state == 'write_high':
            self.state = 'idle'
            self.scl_oen = 0
            self.sda_chk_q = False
            self.cmd_ack = 1
