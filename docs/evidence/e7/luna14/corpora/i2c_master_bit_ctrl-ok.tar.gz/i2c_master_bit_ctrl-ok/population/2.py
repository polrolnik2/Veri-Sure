"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['cscl', 'csda', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'filter_cnt_expired', 'filter_cnt_nonzero', 'clk_en', 'cnt_zero', 'slave_wait', 'scl_sync', 'sta_condition', 'sto_condition', 'sda_chk', 'idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence', 'write_high_phase']
    PROBE_WIDTHS = {'cscl': 1, 'csda': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'filter_cnt_expired': 1, 'filter_cnt_nonzero': 1, 'clk_en': 1, 'cnt_zero': 1, 'slave_wait': 1, 'scl_sync': 1, 'sta_condition': 1, 'sto_condition': 1, 'sda_chk': 1, 'idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1, 'write_high_phase': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.current_cmd = 0
        self.write_data = 0
        self._cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0
        self.cSCL_meta = 1
        self.cSDA_meta = 1
        self.cSCL = 1
        self.cSDA = 1
        self.fSCL = 7
        self.fSDA = 7
        self.dSCL = 1
        self.dSDA = 1
        self.filter_cnt = 0
        self.cnt = 0
        self.clk_en_q = 1
        self.cscl = True
        self.csda = True
        self.fscl = 7
        self.fsda = 7
        self.sscl = True
        self.ssda = True
        self.dscl = True
        self.dsda = True
        self.filter_cnt_expired = False
        self.filter_cnt_nonzero = False
        self.clk_en = True
        self.cnt_zero = True
        self.slave_wait = False
        self.scl_sync = False
        self.sta_condition = False
        self.sto_condition = False
        self.sda_chk = False
        self.idle = True
        self.fsm_active = False
        self.in_start_sequence = False
        self.in_stop_sequence = False
        self.in_read_sequence = False
        self.in_write_sequence = False
        self.write_high_phase = False

    def _majority3(self, value):
        value = value & 7
        bit0 = value & 1
        bit1 = (value >> 1) & 1
        bit2 = (value >> 2) & 1
        return bool((bit0 & bit1) | (bit0 & bit2) | (bit1 & bit2))

    def _phase_controls(self):
        state = self.state
        if state in ('IDLE', 'START_RELEASE', 'STOP_SDA_HIGH'):
            return 1, 1, False
        if state == 'START_SDA_LOW':
            return 1, 0, False
        if state in ('START_SCL_LOW', 'STOP_SDA_LOW'):
            return 0, 0, False
        if state == 'STOP_SCL_HIGH':
            return 1, 0, False
        if state in ('READ_LOW', 'READ_FINISH'):
            return 0, 1, False
        if state == 'READ_HIGH':
            return 1, 1, False
        if state == 'WRITE_LOW' or state == 'WRITE_FINISH':
            return 0, self.write_data, False
        if state == 'WRITE_HIGH':
            return 1, self.write_data, True
        return 1, 1, False

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        scl_oen, sda_oen, sda_chk = self._phase_controls()
        sscl = self._majority3(self.fSCL)
        ssda = self._majority3(self.fSDA)
        slave_wait = bool(scl_oen and not sscl)
        scl_sync = bool(scl_oen and self.dSCL and not sscl)
        sta_condition = bool((not ssda) and self.dSDA and sscl)
        sto_condition = bool(ssda and (not self.dSDA) and sscl)

        self.cscl = bool(self.cSCL)
        self.csda = bool(self.cSDA)
        self.fscl = self.fSCL & 7
        self.fsda = self.fSDA & 7
        self.sscl = sscl
        self.ssda = ssda
        self.dscl = bool(self.dSCL)
        self.dsda = bool(self.dSDA)
        self.filter_cnt_expired = bool((i['ena'] & 1) and self.filter_cnt == 0)
        self.filter_cnt_nonzero = bool(self.filter_cnt != 0)
        self.clk_en = bool(self.clk_en_q and not slave_wait)
        self.cnt_zero = bool(self.cnt == 0)
        self.slave_wait = slave_wait
        self.scl_sync = scl_sync
        self.sta_condition = sta_condition
        self.sto_condition = sto_condition
        self.sda_chk = bool(sda_chk)
        self.idle = self.state == 'IDLE'
        self.fsm_active = self.state != 'IDLE'
        self.in_start_sequence = self.state in ('START_RELEASE', 'START_SDA_LOW', 'START_SCL_LOW')
        self.in_stop_sequence = self.state in ('STOP_SDA_LOW', 'STOP_SCL_HIGH', 'STOP_SDA_HIGH')
        self.in_read_sequence = self.state in ('READ_LOW', 'READ_HIGH', 'READ_FINISH')
        self.in_write_sequence = self.state in ('WRITE_LOW', 'WRITE_HIGH', 'WRITE_FINISH')
        self.write_high_phase = self.state == 'WRITE_HIGH'

        o['cmd_ack'] = int(bool(self._cmd_ack))
        o['busy'] = int(bool(self.busy))
        o['al'] = int(bool(self.al))
        o['dout'] = int(bool(self.dout))
        o['scl_o'] = 0
        o['scl_oen'] = int(scl_oen)
        o['sda_o'] = 0
        o['sda_oen'] = int(sda_oen)
        return o

    def advance(self, i):
        if (i['nReset'] & 1) == 0:
            self.reset()
            return
        if i['rst'] & 1:
            self.reset()
            return

        ena = i['ena'] & 1
        clk_cnt = i['clk_cnt'] & 65535
        sscl = self._majority3(self.fSCL)
        ssda = self._majority3(self.fSDA)
        scl_oen, sda_oen, sda_chk = self._phase_controls()
        slave_wait = bool(scl_oen and not sscl)
        scl_sync = bool(scl_oen and self.dSCL and not sscl)
        sta_condition = bool((not ssda) and self.dSDA and sscl)
        sto_condition = bool(ssda and (not self.dSDA) and sscl)
        tick = bool(self.clk_en_q and not slave_wait)

        arbitration_loss = bool(
            (sda_chk and sda_oen and not ssda)
            or (self.state != 'IDLE' and sto_condition and self.current_cmd != 2)
        )

        if sscl and not self.dSCL:
            self.dout = int(ssda)
        self.dSCL = int(sscl)
        self.dSDA = int(ssda)

        if sta_condition:
            self.busy = 1
        elif sto_condition:
            self.busy = 0

        self._cmd_ack = 0
        if arbitration_loss:
            self.al = 1
            self.state = 'IDLE'
            self.current_cmd = 0
        elif self.al:
            self.state = 'IDLE'
            self.current_cmd = 0
        elif ena and tick:
            state = self.state
            if state == 'IDLE':
                command = i['cmd'] & 15
                if command == 1:
                    self.state = 'START_RELEASE'
                    self.current_cmd = 1
                elif command == 2:
                    self.state = 'STOP_SDA_LOW'
                    self.current_cmd = 2
                elif command == 4:
                    self.state = 'WRITE_LOW'
                    self.current_cmd = 4
                    self.write_data = i['din'] & 1
                elif command == 8:
                    self.state = 'READ_LOW'
                    self.current_cmd = 8
            elif state == 'START_RELEASE':
                self.state = 'START_SDA_LOW'
            elif state == 'START_SDA_LOW':
                self.state = 'START_SCL_LOW'
            elif state == 'START_SCL_LOW':
                self.state = 'IDLE'
                self.current_cmd = 0
                self._cmd_ack = 1
            elif state == 'STOP_SDA_LOW':
                self.state = 'STOP_SCL_HIGH'
            elif state == 'STOP_SCL_HIGH':
                self.state = 'STOP_SDA_HIGH'
            elif state == 'STOP_SDA_HIGH':
                self.state = 'IDLE'
                self.current_cmd = 0
                self._cmd_ack = 1
            elif state == 'READ_LOW':
                self.state = 'READ_HIGH'
            elif state == 'READ_HIGH':
                self.state = 'READ_FINISH'
            elif state == 'READ_FINISH':
                self.state = 'IDLE'
                self.current_cmd = 0
                self._cmd_ack = 1
            elif state == 'WRITE_LOW':
                self.state = 'WRITE_HIGH'
            elif state == 'WRITE_HIGH':
                self.state = 'WRITE_FINISH'
            elif state == 'WRITE_FINISH':
                self.state = 'IDLE'
                self.current_cmd = 0
                self._cmd_ack = 1
            else:
                self.state = 'IDLE'
                self.current_cmd = 0

        if not ena:
            self.cnt = clk_cnt
            self.clk_en_q = 1
        elif scl_sync:
            self.cnt = clk_cnt
            self.clk_en_q = 1
        elif slave_wait:
            self.clk_en_q = 0
        elif self.cnt == 0:
            self.cnt = clk_cnt
            self.clk_en_q = 1
        else:
            self.cnt = (self.cnt - 1) & 65535
            self.clk_en_q = 0

        if ena:
            if self.filter_cnt == 0:
                self.filter_cnt = (clk_cnt >> 2) & 65535
                self.fSCL = ((self.fSCL << 1) | self.cSCL) & 7
                self.fSDA = ((self.fSDA << 1) | self.cSDA) & 7
            else:
                self.filter_cnt = (self.filter_cnt - 1) & 65535
        else:
            self.filter_cnt = 0

        old_meta_scl = self.cSCL_meta
        old_meta_sda = self.cSDA_meta
        self.cSCL_meta = i['scl_i'] & 1
        self.cSDA_meta = i['sda_i'] & 1
        self.cSCL = old_meta_scl
        self.cSDA = old_meta_sda
