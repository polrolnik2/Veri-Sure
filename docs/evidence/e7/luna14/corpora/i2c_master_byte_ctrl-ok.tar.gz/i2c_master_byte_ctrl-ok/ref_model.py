"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'cnt_nonzero', 'cnt_done', 'core_ack', 'core_txd', 'core_rxd', 'i2c_cmd_start', 'i2c_cmd_stop', 'i2c_cmd_read', 'i2c_cmd_write', 'core_cmd_is_nop', 'bit_controller', 'i2c_master_bit_ctrl', 'core_cmd', 'contentreference']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'cnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_txd': 1, 'core_rxd': 1, 'i2c_cmd_start': 1, 'i2c_cmd_stop': 1, 'i2c_cmd_read': 1, 'i2c_cmd_write': 1, 'core_cmd_is_nop': 1, 'bit_controller': 1, 'i2c_master_bit_ctrl': 1, 'core_cmd': 1, 'contentreference': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'ST_IDLE'
        self.command = 'NOP'
        self.sr = 0
        self.dcnt = 0
        self.cmd_ack_reg = 0
        self.ack_out_reg = 0
        self.bit_busy = 0
        self.bit_al = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        async_reset = not (int(i['nReset']) & 1)
        if async_reset:
            state = 'ST_IDLE'
            command = 'NOP'
            sr = 0
            dcnt = 0
            cmd_ack = 0
            ack_out = 0
            busy = 0
            arbitration_lost = 0
        else:
            state = self.state
            command = self.command
            sr = self.sr
            dcnt = self.dcnt
            cmd_ack = self.cmd_ack_reg
            ack_out = self.ack_out_reg
            busy = self.bit_busy
            arbitration_lost = self.bit_al

        start = int(i['start']) & 1
        stop = int(i['stop']) & 1
        read = int(i['read']) & 1
        write = int(i['write']) & 1
        ack_in = int(i['ack_in']) & 1
        go = int(bool(read or write or stop) and not cmd_ack)
        core_ack = int(command != 'NOP' and not arbitration_lost and not async_reset)
        core_rxd = 0
        cnt_done = int(dcnt == 0)
        ld = int(state == 'ST_IDLE' and go)
        shift = int((state == 'ST_READ' and core_ack) or
                    (state == 'ST_WRITE' and core_ack and not cnt_done))
        core_txd = (sr >> 7) & 1
        if state == 'ST_ACK' and command == 'WRITE':
            core_txd = ack_in

        self.st_idle = bool(state == 'ST_IDLE')
        self.st_start = bool(state == 'ST_START')
        self.st_read = bool(state == 'ST_READ')
        self.st_write = bool(state == 'ST_WRITE')
        self.st_ack = bool(state == 'ST_ACK')
        self.st_stop = bool(state == 'ST_STOP')
        self.go = bool(go)
        self.ld = bool(ld)
        self.shift = bool(shift)
        self.cnt_nonzero = bool(dcnt != 0)
        self.cnt_done = bool(cnt_done)
        self.core_ack = bool(core_ack)
        self.core_txd = bool(core_txd)
        self.core_rxd = bool(core_rxd)
        self.i2c_cmd_start = bool(command == 'START')
        self.i2c_cmd_stop = bool(command == 'STOP')
        self.i2c_cmd_read = bool(command == 'READ')
        self.i2c_cmd_write = bool(command == 'WRITE')
        self.core_cmd_is_nop = bool(command == 'NOP')
        self.bit_controller = True
        self.i2c_master_bit_ctrl = True
        self.core_cmd = True
        self.contentreference = True

        o['cmd_ack'] = int(cmd_ack)
        o['ack_out'] = int(ack_out)
        o['dout'] = self.mask(sr, 8)
        o['i2c_busy'] = int(busy)
        o['i2c_al'] = int(arbitration_lost)
        o['scl_o'] = 0
        o['scl_oen'] = 1
        o['sda_o'] = 0
        o['sda_oen'] = 1
        return o

    def advance(self, i):
        if not (int(i['nReset']) & 1):
            self.reset()
            return
        if int(i['rst']) & 1:
            self.reset()
            return

        if self.bit_al:
            self.state = 'ST_IDLE'
            self.command = 'NOP'
            self.cmd_ack_reg = 0
            self.ack_out_reg = 0
            return

        state = self.state
        command = self.command
        start = int(i['start']) & 1
        stop = int(i['stop']) & 1
        read = int(i['read']) & 1
        write = int(i['write']) & 1
        go = int(bool(read or write or stop) and not self.cmd_ack_reg)
        core_ack = int(command != 'NOP' and not self.bit_al)
        core_rxd = 0
        cnt_done = self.dcnt == 0
        ld = state == 'ST_IDLE' and bool(go)
        shift = ((state == 'ST_READ' and bool(core_ack)) or
                 (state == 'ST_WRITE' and bool(core_ack) and not cnt_done))

        if ld:
            self.sr = self.mask(i['din'], 8)
            self.dcnt = 7
        elif shift:
            self.sr = self.mask((self.sr << 1) | core_rxd, 8)
            self.dcnt = self.mask(self.dcnt - 1, 3)

        if core_ack and command == 'START':
            self.bit_busy = 1
        elif core_ack and command == 'STOP':
            self.bit_busy = 0

        self.cmd_ack_reg = 0
        if state == 'ST_IDLE':
            if go:
                if start:
                    self.state = 'ST_START'
                    self.command = 'START'
                elif read:
                    self.state = 'ST_READ'
                    self.command = 'READ'
                elif write:
                    self.state = 'ST_WRITE'
                    self.command = 'WRITE'
                else:
                    self.state = 'ST_STOP'
                    self.command = 'STOP'
        elif state == 'ST_START':
            if core_ack:
                if read:
                    self.state = 'ST_READ'
                    self.command = 'READ'
                else:
                    self.state = 'ST_WRITE'
                    self.command = 'WRITE'
        elif state == 'ST_WRITE':
            if core_ack:
                if cnt_done:
                    self.state = 'ST_ACK'
                    self.command = 'READ'
                else:
                    self.state = 'ST_WRITE'
                    self.command = 'WRITE'
        elif state == 'ST_READ':
            if core_ack:
                if cnt_done:
                    self.state = 'ST_ACK'
                    self.command = 'WRITE'
                else:
                    self.state = 'ST_READ'
                    self.command = 'READ'
        elif state == 'ST_ACK':
            if core_ack:
                if command == 'READ':
                    self.ack_out_reg = core_rxd
                if stop:
                    self.state = 'ST_STOP'
                    self.command = 'STOP'
                else:
                    self.state = 'ST_IDLE'
                    self.command = 'NOP'
                    self.cmd_ack_reg = 1
        elif state == 'ST_STOP':
            if core_ack:
                self.state = 'ST_IDLE'
                self.command = 'NOP'
                self.cmd_ack_reg = 1
