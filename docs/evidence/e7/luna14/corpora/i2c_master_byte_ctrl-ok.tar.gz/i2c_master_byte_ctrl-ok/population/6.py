"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'cnt_nonzero', 'cnt_done', 'core_ack', 'core_txd', 'core_rxd', 'i2c_cmd_start', 'i2c_cmd_stop', 'i2c_cmd_read', 'i2c_cmd_write', 'core_cmd_is_nop', 'bit_controller', 'i2c_master_bit_ctrl', 'core_cmd', 'contentreference']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'cnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_txd': 1, 'core_rxd': 1, 'i2c_cmd_start': 1, 'i2c_cmd_stop': 1, 'i2c_cmd_read': 1, 'i2c_cmd_write': 1, 'core_cmd_is_nop': 1, 'bit_controller': 1, 'i2c_master_bit_ctrl': 1, 'core_cmd': 1, 'contentreference': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.sr = 0
        self.dcnt = 0
        self.pending = 0
        self.cmd_ack = 0
        self.ack_out = 0
        self.transfer_read = False
        self.busy = 0

    def _logic(self, i):
        async_reset = not int(i.get('nReset', 1))
        if async_reset:
            state = 'IDLE'
            sr = 0
            dcnt = 0
            pending = 0
            cmd_ack = 0
            ack_out = 0
            transfer_read = False
            busy = 0
        else:
            state = self.state
            sr = self.sr
            dcnt = self.dcnt
            pending = self.pending
            cmd_ack = self.cmd_ack
            ack_out = self.ack_out
            transfer_read = self.transfer_read
            busy = self.busy

        read = bool(i['read'])
        write = bool(i['write'])
        stop = bool(i['stop'])
        start = bool(i['start'])
        go = int((read or write or stop) and not cmd_ack)
        core_ack = int(bool(pending) and not async_reset)
        core_rxd = int(i['sda_i']) & 1
        command = 'NOP'
        ld = 0
        shift = 0
        next_state = state
        next_read = transfer_read
        complete = 0

        if not async_reset:
            if state == 'IDLE' and go:
                ld = 1
                if start:
                    next_state = 'START'
                    next_read = read
                    command = 'START'
                elif read:
                    next_state = 'READ'
                    next_read = True
                    command = 'READ'
                elif write:
                    next_state = 'WRITE'
                    next_read = False
                    command = 'WRITE'
                else:
                    next_state = 'STOP'
                    next_read = False
                    command = 'STOP'
            elif state == 'START' and core_ack:
                if read:
                    next_state = 'READ'
                    next_read = True
                    command = 'READ'
                else:
                    next_state = 'WRITE'
                    next_read = False
                    command = 'WRITE'
            elif state == 'READ' and core_ack:
                shift = 1
                if dcnt == 0:
                    next_state = 'ACK'
                    command = 'WRITE'
                else:
                    command = 'READ'
            elif state == 'WRITE' and core_ack:
                if dcnt == 0:
                    next_state = 'ACK'
                    command = 'READ'
                else:
                    shift = 1
                    command = 'WRITE'
            elif state == 'ACK' and core_ack:
                if stop:
                    next_state = 'STOP'
                    command = 'STOP'
                else:
                    next_state = 'IDLE'
                    complete = 1
            elif state == 'STOP' and core_ack:
                next_state = 'IDLE'
                complete = 1

        core_txd = (sr >> 7) & 1
        if (state == 'ACK' and transfer_read) or (state == 'READ' and core_ack and dcnt == 0):
            core_txd = int(i['ack_in']) & 1

        return {
            'async_reset': async_reset,
            'state': state,
            'sr': sr,
            'dcnt': dcnt,
            'pending': pending,
            'cmd_ack': cmd_ack,
            'ack_out': ack_out,
            'busy': busy,
            'transfer_read': transfer_read,
            'go': go,
            'core_ack': core_ack,
            'core_rxd': core_rxd,
            'core_txd': core_txd,
            'command': command,
            'ld': ld,
            'shift': shift,
            'next_state': next_state,
            'next_read': next_read,
            'complete': complete
        }

    def outputs(self, i):
        d = self._logic(i)
        o = {p: None for p in self.OUTPUT_PORTS}
        o['cmd_ack'] = d['cmd_ack']
        o['ack_out'] = d['ack_out']
        o['dout'] = d['sr']
        o['i2c_busy'] = d['busy']
        o['i2c_al'] = 0
        o['scl_o'] = 0
        o['scl_oen'] = 1
        o['sda_o'] = 0
        o['sda_oen'] = 1

        self.st_idle = d['state'] == 'IDLE'
        self.st_start = d['state'] == 'START'
        self.st_read = d['state'] == 'READ'
        self.st_write = d['state'] == 'WRITE'
        self.st_ack = d['state'] == 'ACK'
        self.st_stop = d['state'] == 'STOP'
        self.go = bool(d['go'])
        self.ld = bool(d['ld'])
        self.shift = bool(d['shift'])
        self.cnt_nonzero = d['dcnt'] != 0
        self.cnt_done = d['dcnt'] == 0
        self.core_ack = bool(d['core_ack'])
        self.core_txd = d['core_txd']
        self.core_rxd = d['core_rxd']
        self.i2c_cmd_start = d['command'] == 'START'
        self.i2c_cmd_stop = d['command'] == 'STOP'
        self.i2c_cmd_read = d['command'] == 'READ'
        self.i2c_cmd_write = d['command'] == 'WRITE'
        self.core_cmd_is_nop = d['command'] == 'NOP'
        self.bit_controller = True
        self.i2c_master_bit_ctrl = True
        self.core_cmd = True
        self.contentreference = True
        return o

    def advance(self, i):
        if not int(i.get('nReset', 1)) or int(i['rst']):
            self.reset()
            return

        d = self._logic(i)
        if d['ld']:
            self.sr = self.mask(i['din'], 8)
            self.dcnt = 7
        elif d['shift']:
            self.sr = self.mask((self.sr << 1) | d['core_rxd'], 8)
            self.dcnt = self.mask(self.dcnt - 1, 3)

        if d['state'] == 'ACK' and d['core_ack']:
            self.ack_out = d['core_rxd']
        if d['state'] == 'START' and d['core_ack']:
            self.busy = 1
        if d['state'] == 'STOP' and d['core_ack']:
            self.busy = 0

        self.state = d['next_state']
        self.transfer_read = d['next_read']
        self.pending = int(d['command'] != 'NOP')
        self.cmd_ack = d['complete']
