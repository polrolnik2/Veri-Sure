"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'cnt_nonzero', 'cnt_done', 'core_ack', 'core_txd', 'core_rxd', 'i2c_cmd_start', 'i2c_cmd_stop', 'i2c_cmd_read', 'i2c_cmd_write', 'core_cmd_is_nop', 'bit_controller', 'i2c_master_bit_ctrl', 'core_cmd', 'contentreference']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'cnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_txd': 1, 'core_rxd': 1, 'i2c_cmd_start': 1, 'i2c_cmd_stop': 1, 'i2c_cmd_read': 1, 'i2c_cmd_write': 1, 'core_cmd_is_nop': 1, 'bit_controller': 1, 'i2c_master_bit_ctrl': 1, 'core_cmd': 1, 'contentreference': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.cmd = 'NOP'
        self.sr = 0
        self.dcnt = 0
        self.cmd_ack = 0
        self.ack_out = 0
        self.mode_read = False
        self.busy = 0

    def _core_ack(self, i, cmd, reset_view=False):
        if reset_view:
            return 0
        return int(bool(i.get('core_ack', cmd != 'NOP')))

    def _core_rxd(self, i, reset_view=False):
        if reset_view:
            return 0
        return int(i.get('core_rxd', 0)) & 1

    def _abort(self, i):
        return int(bool(i.get('i2c_al', 0)))

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        reset_view = int(i.get('nReset', 1)) == 0
        state = 'IDLE' if reset_view else self.state
        cmd = 'NOP' if reset_view else self.cmd
        sr = 0 if reset_view else self.sr
        dcnt = 0 if reset_view else self.dcnt
        cmd_ack = 0 if reset_view else self.cmd_ack
        ack_out = 0 if reset_view else self.ack_out
        busy = 0 if reset_view else self.busy
        mode_read = False if reset_view else self.mode_read
        core_ack = self._core_ack(i, cmd, reset_view)
        core_rxd = self._core_rxd(i, reset_view)
        go = bool((i.get('read', 0) or i.get('write', 0) or i.get('stop', 0)) and not cmd_ack)
        ld = bool(state == 'IDLE' and go)
        shift = bool((state == 'READ' and core_ack) or
                     (state == 'WRITE' and core_ack and dcnt != 0))
        core_txd = (int(i.get('ack_in', 0)) & 1) if state == 'ACK' and mode_read else ((sr >> 7) & 1)

        self.st_idle = state == 'IDLE'
        self.st_start = state == 'START'
        self.st_read = state == 'READ'
        self.st_write = state == 'WRITE'
        self.st_ack = state == 'ACK'
        self.st_stop = state == 'STOP'
        self.go = go
        self.ld = ld
        self.shift = shift
        self.cnt_nonzero = dcnt != 0
        self.cnt_done = dcnt == 0
        self.core_ack = bool(core_ack)
        self.core_txd = bool(core_txd)
        self.core_rxd = bool(core_rxd)
        self.i2c_cmd_start = cmd == 'START'
        self.i2c_cmd_stop = cmd == 'STOP'
        self.i2c_cmd_read = cmd == 'READ'
        self.i2c_cmd_write = cmd == 'WRITE'
        self.core_cmd_is_nop = cmd == 'NOP'
        self.bit_controller = True
        self.i2c_master_bit_ctrl = True
        self.core_cmd = True
        self.contentreference = True

        o['cmd_ack'] = int(bool(cmd_ack))
        o['ack_out'] = int(bool(ack_out))
        o['dout'] = self.mask(sr, 8)
        o['i2c_busy'] = int(bool(busy))
        o['i2c_al'] = 0 if reset_view else self._abort(i)
        # The byte controller schedules commands; the unspecified bit controller
        # is abstracted as released, open-drain pads in this reference model.
        o['scl_o'] = 0
        o['scl_oen'] = 1
        o['sda_o'] = 0
        o['sda_oen'] = 1
        return o

    def advance(self, i):
        if int(i.get('nReset', 1)) == 0:
            self.reset()
            return
        if int(i.get('rst', 0)) != 0:
            self.reset()
            return
        if self._abort(i):
            # Arbitration loss aborts the FSM command sequence. The datapath holds
            # its last contents unless reset or an active load/shift changes it.
            self.state = 'IDLE'
            self.cmd = 'NOP'
            self.cmd_ack = 0
            self.mode_read = False
            return

        go = bool((i.get('read', 0) or i.get('write', 0) or i.get('stop', 0)) and not self.cmd_ack)
        core_ack = self._core_ack(i, self.cmd)
        core_rxd = self._core_rxd(i)
        ld = self.state == 'IDLE' and go
        shift = ((self.state == 'READ' and core_ack) or
                 (self.state == 'WRITE' and core_ack and self.dcnt != 0))

        if ld:
            self.sr = self.mask(i.get('din', 0), 8)
            self.dcnt = 7
        elif shift:
            self.sr = self.mask((self.sr << 1) | core_rxd, 8)
            self.dcnt = self.mask(self.dcnt - 1, 3)

        next_state = self.state
        next_cmd = 'NOP'
        next_cmd_ack = 0

        if self.state == 'IDLE':
            if go:
                if i.get('start', 0):
                    next_state = 'START'
                    next_cmd = 'START'
                    self.mode_read = bool(i.get('read', 0))
                elif i.get('read', 0):
                    next_state = 'READ'
                    next_cmd = 'READ'
                    self.mode_read = True
                elif i.get('write', 0):
                    next_state = 'WRITE'
                    next_cmd = 'WRITE'
                    self.mode_read = False
                else:
                    next_state = 'STOP'
                    next_cmd = 'STOP'
                    self.mode_read = False
        elif self.state == 'START':
            if core_ack:
                if i.get('read', 0):
                    next_state = 'READ'
                    next_cmd = 'READ'
                    self.mode_read = True
                else:
                    next_state = 'WRITE'
                    next_cmd = 'WRITE'
                    self.mode_read = False
                self.busy = 1
            else:
                next_cmd = 'START'
        elif self.state == 'WRITE':
            if core_ack and self.dcnt == 0:
                next_state = 'ACK'
                next_cmd = 'READ'
                self.mode_read = False
            else:
                next_cmd = 'WRITE'
        elif self.state == 'READ':
            if core_ack and self.dcnt == 0:
                next_state = 'ACK'
                next_cmd = 'WRITE'
                self.mode_read = True
            else:
                next_cmd = 'READ'
        elif self.state == 'ACK':
            next_cmd = 'WRITE' if self.mode_read else 'READ'
            if core_ack:
                if not self.mode_read:
                    self.ack_out = core_rxd
                if i.get('stop', 0):
                    next_state = 'STOP'
                    next_cmd = 'STOP'
                else:
                    next_state = 'IDLE'
                    next_cmd = 'NOP'
                    next_cmd_ack = 1
        elif self.state == 'STOP':
            if core_ack:
                next_state = 'IDLE'
                next_cmd = 'NOP'
                next_cmd_ack = 1
                self.busy = 0
            else:
                next_cmd = 'STOP'

        self.state = next_state
        self.cmd = next_cmd
        self.cmd_ack = next_cmd_ack
