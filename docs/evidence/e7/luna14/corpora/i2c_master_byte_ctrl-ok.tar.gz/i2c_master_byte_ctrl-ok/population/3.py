"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'cnt_nonzero', 'cnt_done', 'core_ack', 'core_txd', 'core_rxd', 'i2c_cmd_start', 'i2c_cmd_stop', 'i2c_cmd_read', 'i2c_cmd_write', 'core_cmd_is_nop', 'bit_controller', 'i2c_master_bit_ctrl', 'core_cmd', 'contentreference']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'cnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_txd': 1, 'core_rxd': 1, 'i2c_cmd_start': 1, 'i2c_cmd_stop': 1, 'i2c_cmd_read': 1, 'i2c_cmd_write': 1, 'core_cmd_is_nop': 1, 'bit_controller': 1, 'i2c_master_bit_ctrl': 1, 'core_cmd': 1, 'contentreference': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'ST_IDLE'
        self.sr = 0
        self.dcnt = 0
        self.cmd = 'NOP'
        self.cmd_ack = 0
        self.ack_out = 0
        self.ack_pending = False
        self.op_read = False
        self.busy = 0
        self.al_status = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        async_reset = (i['nReset'] == 0)

        if async_reset:
            state = 'ST_IDLE'
            sr = 0
            dcnt = 0
            cmd = 'NOP'
            cmd_ack = 0
            ack_out = 0
            ack_pending = False
            op_read = False
            busy = 0
            al_status = 0
        else:
            state = self.state
            sr = self.sr
            dcnt = self.dcnt
            cmd = self.cmd
            cmd_ack = self.cmd_ack
            ack_out = self.ack_out
            ack_pending = self.ack_pending
            op_read = self.op_read
            busy = self.busy
            al_status = self.al_status

        go = bool((i['read'] | i['write'] | i['stop']) and not cmd_ack)
        ld = bool(not async_reset and state == 'ST_IDLE' and go)
        cnt_done = (dcnt == 0)
        shift = bool(
            not async_reset
            and ack_pending
            and (
                state == 'ST_READ'
                or (state == 'ST_WRITE' and not cnt_done)
            )
        )
        core_rxd = i['sda_i'] & 1
        core_txd = (i['ack_in'] & 1) if (state == 'ST_ACK' and op_read) else ((sr >> 7) & 1)

        self.st_idle = (state == 'ST_IDLE')
        self.st_start = (state == 'ST_START')
        self.st_read = (state == 'ST_READ')
        self.st_write = (state == 'ST_WRITE')
        self.st_ack = (state == 'ST_ACK')
        self.st_stop = (state == 'ST_STOP')
        self.go = go
        self.ld = ld
        self.shift = shift
        self.cnt_nonzero = (dcnt != 0)
        self.cnt_done = cnt_done
        self.core_ack = bool(ack_pending)
        self.core_txd = bool(core_txd)
        self.core_rxd = bool(core_rxd)
        self.i2c_cmd_start = (cmd == 'START')
        self.i2c_cmd_stop = (cmd == 'STOP')
        self.i2c_cmd_read = (cmd == 'READ')
        self.i2c_cmd_write = (cmd == 'WRITE')
        self.core_cmd_is_nop = (cmd == 'NOP')
        self.bit_controller = True
        self.i2c_master_bit_ctrl = True
        self.core_cmd = True
        self.contentreference = True

        o['cmd_ack'] = int(cmd_ack)
        o['ack_out'] = int(ack_out) & 1
        o['dout'] = self.mask(sr, 8)
        o['i2c_busy'] = int(busy) & 1
        o['i2c_al'] = int(al_status) & 1
        o['scl_o'] = 0
        o['scl_oen'] = 1
        o['sda_o'] = 0
        o['sda_oen'] = 1
        return o

    def advance(self, i):
        if i['nReset'] == 0:
            self.reset()
            return
        if i['rst']:
            self.reset()
            return
        if self.al_status:
            self.state = 'ST_IDLE'
            self.cmd = 'NOP'
            self.cmd_ack = 0
            self.ack_pending = False
            self.op_read = False
            return

        old_state = self.state
        old_cmd = self.cmd
        old_ack = self.ack_pending
        old_cnt_done = (self.dcnt == 0)
        go = bool((i['read'] | i['write'] | i['stop']) and not self.cmd_ack)
        ld = (old_state == 'ST_IDLE' and go)
        shift = bool(
            old_ack
            and (
                old_state == 'ST_READ'
                or (old_state == 'ST_WRITE' and not old_cnt_done)
            )
        )
        core_rxd = i['sda_i'] & 1

        if ld:
            self.sr = self.mask(i['din'], 8)
            self.dcnt = 7
        elif shift:
            self.sr = self.mask((self.sr << 1) | core_rxd, 8)
            self.dcnt = self.mask(self.dcnt - 1, 3)

        next_state = old_state
        next_cmd = 'NOP'
        next_cmd_ack = 0

        if old_state == 'ST_IDLE':
            if go:
                if i['start']:
                    next_state = 'ST_START'
                    next_cmd = 'START'
                elif i['read']:
                    next_state = 'ST_READ'
                    self.op_read = True
                    next_cmd = 'READ'
                elif i['write']:
                    next_state = 'ST_WRITE'
                    self.op_read = False
                    next_cmd = 'WRITE'
                else:
                    next_state = 'ST_STOP'
                    self.op_read = False
                    next_cmd = 'STOP'
        elif old_state == 'ST_START':
            if old_ack:
                self.busy = 1
                if i['read']:
                    next_state = 'ST_READ'
                    self.op_read = True
                    next_cmd = 'READ'
                else:
                    next_state = 'ST_WRITE'
                    self.op_read = False
                    next_cmd = 'WRITE'
        elif old_state == 'ST_WRITE':
            if old_ack:
                if old_cnt_done:
                    next_state = 'ST_ACK'
                    next_cmd = 'READ'
                else:
                    next_cmd = 'WRITE'
        elif old_state == 'ST_READ':
            if old_ack:
                if old_cnt_done:
                    next_state = 'ST_ACK'
                    next_cmd = 'WRITE'
                else:
                    next_cmd = 'READ'
        elif old_state == 'ST_ACK':
            if old_ack:
                if not self.op_read:
                    self.ack_out = core_rxd
                if i['stop']:
                    next_state = 'ST_STOP'
                    next_cmd = 'STOP'
                else:
                    next_state = 'ST_IDLE'
                    next_cmd_ack = 1
        elif old_state == 'ST_STOP':
            if old_ack:
                next_state = 'ST_IDLE'
                next_cmd_ack = 1
                self.busy = 0

        self.state = next_state
        self.cmd = next_cmd
        self.cmd_ack = next_cmd_ack
        self.ack_pending = (old_cmd != 'NOP')
