"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'cnt_nonzero', 'cnt_done', 'core_ack', 'core_txd', 'core_rxd', 'i2c_cmd_start', 'i2c_cmd_stop', 'i2c_cmd_read', 'i2c_cmd_write', 'core_cmd_is_nop', 'bit_controller', 'i2c_master_bit_ctrl', 'core_cmd', 'contentreference']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'cnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_txd': 1, 'core_rxd': 1, 'i2c_cmd_start': 1, 'i2c_cmd_stop': 1, 'i2c_cmd_read': 1, 'i2c_cmd_write': 1, 'core_cmd_is_nop': 1, 'bit_controller': 1, 'i2c_master_bit_ctrl': 1, 'core_cmd': 1, 'contentreference': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'ST_IDLE'
        self.sr = 0
        self.dcnt = 0
        self.cmd = 'NOP'
        self._ld = 0
        self._shift = 0
        self.cmd_ack = 0
        self.ack_out = 0
        self.ack_read = False
        self.waiting = False
        self.wait_age = 0
        self.busy = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        async_reset = int(i['nReset']) == 0
        if async_reset:
            state = 'ST_IDLE'
            sr = 0
            dcnt = 0
            cmd = 'NOP'
            ld = 0
            shift = 0
            cmd_ack = 0
            ack_out = 0
            ack_read = False
            waiting = False
            wait_age = 0
            busy = 0
        else:
            state = self.state
            sr = self.sr
            dcnt = self.dcnt
            cmd = self.cmd
            ld = self._ld
            shift = self._shift
            cmd_ack = self.cmd_ack
            ack_out = self.ack_out
            ack_read = self.ack_read
            waiting = self.waiting
            wait_age = self.wait_age
            busy = self.busy

        auto_ack = int((not waiting and state == 'ST_IDLE') or
                       (waiting and wait_age >= 1))
        core_ack = int(i.get('core_ack', auto_ack)) & 1
        core_rxd = int(i.get('core_rxd', i['sda_i'])) & 1
        i2c_al = 0 if async_reset else (int(i.get('i2c_al', 0)) & 1)
        go = int(bool(i['read'] or i['write'] or i['stop']) and not cmd_ack)
        core_txd = (int(i['ack_in']) & 1) if state == 'ST_ACK' and ack_read else ((sr >> 7) & 1)

        self.st_idle = state == 'ST_IDLE'
        self.st_start = state == 'ST_START'
        self.st_read = state == 'ST_READ'
        self.st_write = state == 'ST_WRITE'
        self.st_ack = state == 'ST_ACK'
        self.st_stop = state == 'ST_STOP'
        self.go = bool(go)
        self.ld = bool(ld)
        self.shift = bool(shift)
        self.cnt_nonzero = dcnt != 0
        self.cnt_done = dcnt == 0
        self.core_ack = bool(core_ack)
        self.core_txd = bool(core_txd)
        self.core_rxd = bool(core_rxd)
        self.i2c_cmd_start = cmd == 'START'
        self.i2c_cmd_stop = cmd == 'STOP'
        self.i2c_cmd_read = cmd == 'READ'
        self.i2c_cmd_write = cmd == 'WRITE'
        self.core_cmd_is_nop = cmd == 'NOP'
        self.bit_controller = True
        self.i2c_master_bit_ctrl = True
        self.core_cmd = True
        self.contentreference = True

        o['cmd_ack'] = int(cmd_ack)
        o['ack_out'] = int(ack_out)
        o['dout'] = self.mask(sr, 8)
        o['i2c_busy'] = int(busy)
        o['i2c_al'] = int(i2c_al)
        # The lower-level bit controller owns physical timing. Model released pads.
        o['scl_o'] = 0
        o['scl_oen'] = 1
        o['sda_o'] = 0
        o['sda_oen'] = 1
        return o

    def advance(self, i):
        if int(i['nReset']) == 0:
            self.reset()
            return
        if int(i['rst']):
            self.reset()
            return

        # Arbitration loss aborts the byte-level command sequence.
        if int(i.get('i2c_al', 0)) & 1:
            self.state = 'ST_IDLE'
            self.cmd = 'NOP'
            self._ld = 0
            self._shift = 0
            self.cmd_ack = 0
            self.ack_out = 0
            self.waiting = False
            self.wait_age = 0
            return

        core_rxd = int(i.get('core_rxd', i['sda_i'])) & 1
        auto_ack = int((not self.waiting and self.state == 'ST_IDLE') or
                       (self.waiting and self.wait_age >= 1))
        core_ack = int(i.get('core_ack', auto_ack)) & 1
        go = bool(i['read'] or i['write'] or i['stop']) and not self.cmd_ack

        self._ld = 0
        self._shift = 0
        self.cmd_ack = 0
        self.cmd = 'NOP'

        if self.waiting:
            if not core_ack:
                if self.wait_age < 1:
                    self.wait_age = 1
                return

            self.waiting = False
            self.wait_age = 0

            if self.state == 'ST_START':
                self.busy = 1
                if int(i['read']):
                    self.state = 'ST_READ'
                    self.ack_read = True
                    self.cmd = 'READ'
                else:
                    self.state = 'ST_WRITE'
                    self.ack_read = False
                    self.cmd = 'WRITE'
                self.waiting = True

            elif self.state == 'ST_WRITE':
                if self.dcnt == 0:
                    self.state = 'ST_ACK'
                    self.ack_read = False
                    self.cmd = 'READ'
                    self.waiting = True
                else:
                    self.sr = self.mask((self.sr << 1) | core_rxd, 8)
                    self.dcnt = self.mask(self.dcnt - 1, 3)
                    self._shift = 1
                    self.cmd = 'WRITE'
                    self.waiting = True

            elif self.state == 'ST_READ':
                last_bit = self.dcnt == 0
                self.sr = self.mask((self.sr << 1) | core_rxd, 8)
                self.dcnt = self.mask(self.dcnt - 1, 3)
                self._shift = 1
                if last_bit:
                    self.state = 'ST_ACK'
                    self.ack_read = True
                    self.cmd = 'WRITE'
                else:
                    self.cmd = 'READ'
                self.waiting = True

            elif self.state == 'ST_ACK':
                if not self.ack_read:
                    self.ack_out = core_rxd
                if int(i['stop']):
                    self.state = 'ST_STOP'
                    self.cmd = 'STOP'
                    self.waiting = True
                else:
                    self.state = 'ST_IDLE'
                    self.cmd_ack = 1

            elif self.state == 'ST_STOP':
                self.state = 'ST_IDLE'
                self.busy = 0
                self.cmd_ack = 1

            return

        if self.state == 'ST_IDLE' and core_ack and go:
            if int(i['start']):
                self.state = 'ST_START'
                self.cmd = 'START'
                self._ld = 1
                self.sr = self.mask(i['din'], 8)
                self.dcnt = 7
                self.waiting = True
                self.wait_age = 0
            elif int(i['read']):
                self.state = 'ST_READ'
                self.cmd = 'READ'
                self._ld = 1
                self.sr = self.mask(i['din'], 8)
                self.dcnt = 7
                self.ack_read = True
                self.waiting = True
                self.wait_age = 0
            elif int(i['write']):
                self.state = 'ST_WRITE'
                self.cmd = 'WRITE'
                self._ld = 1
                self.sr = self.mask(i['din'], 8)
                self.dcnt = 7
                self.ack_read = False
                self.waiting = True
                self.wait_age = 0
            else:
                self.state = 'ST_STOP'
                self.cmd = 'STOP'
                self.waiting = True
                self.wait_age = 0
