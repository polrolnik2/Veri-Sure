"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'cnt_nonzero', 'cnt_done', 'core_ack', 'core_txd', 'core_rxd', 'i2c_cmd_start', 'i2c_cmd_stop', 'i2c_cmd_read', 'i2c_cmd_write', 'core_cmd_is_nop', 'bit_controller', 'i2c_master_bit_ctrl', 'core_cmd', 'contentreference']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'cnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_txd': 1, 'core_rxd': 1, 'i2c_cmd_start': 1, 'i2c_cmd_stop': 1, 'i2c_cmd_read': 1, 'i2c_cmd_write': 1, 'core_cmd_is_nop': 1, 'bit_controller': 1, 'i2c_master_bit_ctrl': 1, 'core_cmd': 1, 'contentreference': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'ST_IDLE'
        self.sr = 0
        self.dcnt = 0
        self.cmd = 'NOP'
        self._ld = 0
        self._shift = 0
        self.ld = False
        self.shift = False
        self.cmd_ack = 0
        self.ack_out = 0
        self.busy = 0
        self.i2c_al = 0
        self.bit_pending = 0
        self.last_rxd = 0
        self.transfer_read = 0

    def _core_ack_value(self):
        return bool(self.bit_pending)

    def outputs(self, i):
        async_reset = (i['nReset'] & 1) == 0
        if async_reset:
            state = 'ST_IDLE'
            cmd = 'NOP'
            sr = 0
            dcnt = 0
            ld = 0
            shift = 0
            cmd_ack = 0
            ack_out = 0
            busy = 0
            core_ack = 0
        else:
            state = self.state
            cmd = self.cmd
            sr = self.sr
            dcnt = self.dcnt
            ld = self._ld
            shift = self._shift
            cmd_ack = self.cmd_ack
            ack_out = self.ack_out
            busy = self.busy
            core_ack = int(self._core_ack_value())

        rxd = i['sda_i'] & 1
        txd = (i['ack_in'] & 1) if state == 'ST_ACK' else ((sr >> 7) & 1)
        go = int(bool((i['read'] | i['write'] | i['stop']) & (not cmd_ack)))

        self.st_idle = (state == 'ST_IDLE')
        self.st_start = (state == 'ST_START')
        self.st_read = (state == 'ST_READ')
        self.st_write = (state == 'ST_WRITE')
        self.st_ack = (state == 'ST_ACK')
        self.st_stop = (state == 'ST_STOP')
        self.go = bool(go)
        self.ld = bool(ld)
        self.shift = bool(shift)
        self.cnt_nonzero = (dcnt != 0)
        self.cnt_done = (dcnt == 0)
        self.core_ack = bool(core_ack)
        self.core_txd = bool(txd)
        self.core_rxd = bool(rxd)
        self.i2c_cmd_start = (cmd == 'START')
        self.i2c_cmd_stop = (cmd == 'STOP')
        self.i2c_cmd_read = (cmd == 'READ')
        self.i2c_cmd_write = (cmd == 'WRITE')
        self.core_cmd_is_nop = (cmd == 'NOP')
        self.bit_controller = True
        self.i2c_master_bit_ctrl = True
        self.core_cmd = True
        self.contentreference = True

        o = {p: None for p in self.OUTPUT_PORTS}
        o['cmd_ack'] = int(bool(cmd_ack))
        o['ack_out'] = int(bool(ack_out))
        o['dout'] = self.mask(sr, 8)
        o['i2c_busy'] = int(bool(busy))
        o['i2c_al'] = 0 if async_reset else int(bool(self.i2c_al))
        o['scl_o'] = 0
        o['scl_oen'] = 1
        o['sda_o'] = 0
        o['sda_oen'] = 1
        return o

    def advance(self, i):
        if (i['nReset'] & 1) == 0:
            self.reset()
            return
        if i['rst'] & 1:
            self.reset()
            return

        ack_now = self._core_ack_value()
        rxd = i['sda_i'] & 1
        old_cmd = self.cmd
        old_pending = bool(self.bit_pending)
        launch = bool((i['read'] | i['write'] | i['stop']) & (not self.cmd_ack))

        if self._ld:
            self.sr = self.mask(i['din'], 8)
            self.dcnt = 7
        elif self._shift:
            self.sr = self.mask((self.sr << 1) | self.last_rxd, 8)
            self.dcnt = self.mask(self.dcnt - 1, 3)

        if self.i2c_al:
            self.state = 'ST_IDLE'
            self.cmd = 'NOP'
            self._ld = 0
            self._shift = 0
            self.cmd_ack = 0
            self.ack_out = 0
            self.transfer_read = 0
            self.bit_pending = 0
            self.i2c_al = 0
            return

        self.cmd = 'NOP'
        self._ld = 0
        self._shift = 0
        self.cmd_ack = 0

        if self.state == 'ST_IDLE':
            if launch:
                self._ld = 1
                if i['start'] & 1:
                    self.state = 'ST_START'
                    self.cmd = 'START'
                    self.transfer_read = int(bool(i['read'] & 1))
                elif i['read'] & 1:
                    self.state = 'ST_READ'
                    self.cmd = 'READ'
                    self.transfer_read = 1
                elif i['write'] & 1:
                    self.state = 'ST_WRITE'
                    self.cmd = 'WRITE'
                    self.transfer_read = 0
                else:
                    self.state = 'ST_STOP'
                    self.cmd = 'STOP'
                    self.transfer_read = 0

        elif self.state == 'ST_START':
            if ack_now:
                if i['read'] & 1:
                    self.state = 'ST_READ'
                    self.cmd = 'READ'
                    self.transfer_read = 1
                else:
                    self.state = 'ST_WRITE'
                    self.cmd = 'WRITE'
                    self.transfer_read = 0
                self.busy = 1

        elif self.state == 'ST_WRITE':
            if ack_now:
                if self.dcnt == 0:
                    self.state = 'ST_ACK'
                    self.cmd = 'READ'
                else:
                    self._shift = 1
                    self.last_rxd = rxd
                    self.cmd = 'WRITE'

        elif self.state == 'ST_READ':
            if ack_now:
                self._shift = 1
                self.last_rxd = rxd
                if self.dcnt == 0:
                    self.state = 'ST_ACK'
                    self.cmd = 'WRITE'
                else:
                    self.cmd = 'READ'

        elif self.state == 'ST_ACK':
            if ack_now:
                self.ack_out = rxd
                if i['stop'] & 1:
                    self.state = 'ST_STOP'
                    self.cmd = 'STOP'
                else:
                    self.state = 'ST_IDLE'
                    self.cmd_ack = 1

        elif self.state == 'ST_STOP':
            if ack_now:
                self.state = 'ST_IDLE'
                self.cmd_ack = 1
                self.busy = 0

        if old_pending:
            if ack_now:
                self.bit_pending = 0
        elif old_cmd != 'NOP':
            self.bit_pending = 1
        else:
            self.bit_pending = 0
