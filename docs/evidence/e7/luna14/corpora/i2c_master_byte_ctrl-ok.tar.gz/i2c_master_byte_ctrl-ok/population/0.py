"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'cnt_nonzero', 'cnt_done', 'core_ack', 'core_txd', 'core_rxd', 'i2c_cmd_start', 'i2c_cmd_stop', 'i2c_cmd_read', 'i2c_cmd_write', 'core_cmd_is_nop', 'bit_controller', 'i2c_master_bit_ctrl', 'core_cmd', 'contentreference']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'cnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_txd': 1, 'core_rxd': 1, 'i2c_cmd_start': 1, 'i2c_cmd_stop': 1, 'i2c_cmd_read': 1, 'i2c_cmd_write': 1, 'core_cmd_is_nop': 1, 'bit_controller': 1, 'i2c_master_bit_ctrl': 1, 'core_cmd': 1, 'contentreference': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'ST_IDLE'
        self.cmd = 'NOP'
        self.sr = 0
        self.dcnt = 0
        self.cmd_ack = 0
        self.ack_out = 0
        self.mode = None
        self.busy = 0
        self.arb_lost = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        async_reset = not i['nReset']
        state = 'ST_IDLE' if async_reset else self.state
        cmd = 'NOP' if async_reset else self.cmd
        sr = 0 if async_reset else self.sr
        dcnt = 0 if async_reset else self.dcnt
        cmd_ack = 0 if async_reset else self.cmd_ack
        ack_out = 0 if async_reset else self.ack_out
        busy = 0 if async_reset else self.busy
        arb_lost = 0 if async_reset else self.arb_lost
        mode = None if async_reset else self.mode

        go = bool((i['read'] or i['write'] or i['stop']) and not cmd_ack)
        cnt_done = dcnt == 0
        core_ack = cmd != 'NOP'
        ld = state == 'ST_IDLE' and go
        shift = core_ack and (
            (state == 'ST_READ') or
            (state == 'ST_WRITE' and not cnt_done)
        )
        core_rxd = i['sda_i'] & 1
        core_txd = (sr >> 7) & 1
        if mode == 'read' and (
            state == 'ST_ACK' or
            (state == 'ST_READ' and core_ack and cnt_done)
        ):
            core_txd = i['ack_in'] & 1

        self.st_idle = state == 'ST_IDLE'
        self.st_start = state == 'ST_START'
        self.st_read = state == 'ST_READ'
        self.st_write = state == 'ST_WRITE'
        self.st_ack = state == 'ST_ACK'
        self.st_stop = state == 'ST_STOP'
        self.go = go
        self.ld = bool(ld)
        self.shift = bool(shift)
        self.cnt_nonzero = dcnt != 0
        self.cnt_done = cnt_done
        self.core_ack = bool(core_ack)
        self.core_txd = core_txd
        self.core_rxd = core_rxd
        self.i2c_cmd_start = cmd == 'START'
        self.i2c_cmd_stop = cmd == 'STOP'
        self.i2c_cmd_read = cmd == 'READ'
        self.i2c_cmd_write = cmd == 'WRITE'
        self.core_cmd_is_nop = cmd == 'NOP'
        self.bit_controller = True
        self.i2c_master_bit_ctrl = True
        self.core_cmd = True
        self.contentreference = True

        o['cmd_ack'] = cmd_ack
        o['ack_out'] = ack_out
        o['dout'] = sr
        o['i2c_busy'] = busy
        o['i2c_al'] = arb_lost
        # The lower-level controller's waveform is unspecified; use released pads.
        o['scl_o'] = 0
        o['scl_oen'] = 1
        o['sda_o'] = 0
        o['sda_oen'] = 1
        return o

    def advance(self, i):
        if not i['nReset'] or i['rst']:
            self.reset()
            return

        if self.arb_lost:
            self.state = 'ST_IDLE'
            self.cmd = 'NOP'
            self.cmd_ack = 0
            self.mode = None
            return

        state = self.state
        core_ack = self.cmd != 'NOP'
        core_rxd = i['sda_i'] & 1
        go = bool((i['read'] or i['write'] or i['stop']) and not self.cmd_ack)
        cnt_done = self.dcnt == 0
        ld = state == 'ST_IDLE' and go
        shift = core_ack and (
            state == 'ST_READ' or
            (state == 'ST_WRITE' and not cnt_done)
        )

        if ld:
            self.sr = self.mask(i['din'], 8)
            self.dcnt = 7
        elif shift:
            self.sr = self.mask((self.sr << 1) | core_rxd, 8)
            self.dcnt = self.mask(self.dcnt - 1, 3)

        next_state = state
        next_cmd = self.cmd
        next_mode = self.mode
        next_cmd_ack = 0
        next_ack_out = self.ack_out
        next_busy = self.busy

        if state == 'ST_IDLE':
            next_cmd = 'NOP'
            if go:
                if i['start']:
                    next_state = 'ST_START'
                    next_cmd = 'START'
                    next_mode = 'read' if i['read'] else 'write'
                elif i['read']:
                    next_state = 'ST_READ'
                    next_cmd = 'READ'
                    next_mode = 'read'
                elif i['write']:
                    next_state = 'ST_WRITE'
                    next_cmd = 'WRITE'
                    next_mode = 'write'
                else:
                    next_state = 'ST_STOP'
                    next_cmd = 'STOP'
                    next_mode = None

        elif state == 'ST_START':
            next_cmd = 'START'
            if core_ack:
                if i['read']:
                    next_state = 'ST_READ'
                    next_cmd = 'READ'
                    next_mode = 'read'
                else:
                    next_state = 'ST_WRITE'
                    next_cmd = 'WRITE'
                    next_mode = 'write'
                next_busy = 1

        elif state == 'ST_READ':
            next_cmd = 'READ'
            if core_ack:
                if cnt_done:
                    next_state = 'ST_ACK'
                    next_cmd = 'WRITE'
                    next_mode = 'read'

        elif state == 'ST_WRITE':
            next_cmd = 'WRITE'
            if core_ack and cnt_done:
                next_state = 'ST_ACK'
                next_cmd = 'READ'
                next_mode = 'write'

        elif state == 'ST_ACK':
            next_cmd = 'WRITE' if self.mode == 'read' else 'READ'
            if core_ack:
                next_ack_out = core_rxd
                if i['stop']:
                    next_state = 'ST_STOP'
                    next_cmd = 'STOP'
                else:
                    next_state = 'ST_IDLE'
                    next_cmd = 'NOP'
                    next_cmd_ack = 1

        elif state == 'ST_STOP':
            next_cmd = 'STOP'
            if core_ack:
                next_state = 'ST_IDLE'
                next_cmd = 'NOP'
                next_cmd_ack = 1
                next_busy = 0

        self.state = next_state
        self.cmd = next_cmd
        self.mode = next_mode
        self.cmd_ack = next_cmd_ack
        self.ack_out = next_ack_out
        self.busy = next_busy
