"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'cnt_nonzero', 'cnt_done', 'core_ack', 'core_txd', 'core_rxd', 'i2c_cmd_start', 'i2c_cmd_stop', 'i2c_cmd_read', 'i2c_cmd_write', 'core_cmd_is_nop', 'bit_controller', 'i2c_master_bit_ctrl', 'core_cmd', 'contentreference']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'cnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_txd': 1, 'core_rxd': 1, 'i2c_cmd_start': 1, 'i2c_cmd_stop': 1, 'i2c_cmd_read': 1, 'i2c_cmd_write': 1, 'core_cmd_is_nop': 1, 'bit_controller': 1, 'i2c_master_bit_ctrl': 1, 'core_cmd': 1, 'contentreference': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.sr = 0
        self.dcnt = 0
        self.core_cmd_value = 'NOP'
        self.cmd_ack = 0
        self.ack_out = 0
        self.transfer_read = 0
        self.bit_ack = 0
        self.busy = 0
        self.i2c_al_value = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        async_reset = not (i.get('nReset', 1) & 1)
        state = 'IDLE' if async_reset else self.state
        sr = 0 if async_reset else self.sr
        dcnt = 0 if async_reset else self.dcnt
        cmd = 'NOP' if async_reset else self.core_cmd_value
        cmd_ack = 0 if async_reset else self.cmd_ack
        ack_out = 0 if async_reset else self.ack_out
        bit_ack = 0 if async_reset else self.bit_ack
        busy = 0 if async_reset else self.busy
        transfer_read = 0 if async_reset else self.transfer_read
        requests = bool((i.get('read', 0) | i.get('write', 0) | i.get('stop', 0)) & 1)
        go = requests and not bool(cmd_ack)
        cnt_done = dcnt == 0
        shift = (state == 'READ' and bool(bit_ack)) or (state == 'WRITE' and bool(bit_ack) and not cnt_done)

        self.st_idle = state == 'IDLE'
        self.st_start = state == 'START'
        self.st_read = state == 'READ'
        self.st_write = state == 'WRITE'
        self.st_ack = state == 'ACK'
        self.st_stop = state == 'STOP'
        self.go = bool(go)
        self.ld = bool(state == 'IDLE' and go)
        self.shift = bool(shift)
        self.cnt_nonzero = dcnt != 0
        self.cnt_done = bool(cnt_done)
        self.core_ack = bool(bit_ack)
        self.core_rxd = bool(i.get('sda_i', 1) & 1)
        self.core_txd = bool((i.get('ack_in', 0) & 1) if state == 'ACK' and transfer_read else ((sr >> 7) & 1))
        self.i2c_cmd_start = cmd == 'START'
        self.i2c_cmd_stop = cmd == 'STOP'
        self.i2c_cmd_read = cmd == 'READ'
        self.i2c_cmd_write = cmd == 'WRITE'
        self.core_cmd_is_nop = cmd == 'NOP'
        self.bit_controller = True
        self.i2c_master_bit_ctrl = True
        self.core_cmd = True
        self.contentreference = True

        o['cmd_ack'] = int(bool(cmd_ack))
        o['ack_out'] = int(bool(ack_out))
        o['dout'] = self.mask(sr, 8)
        o['i2c_busy'] = int(bool(busy))
        o['i2c_al'] = int(bool(0 if async_reset else self.i2c_al_value))
        o['scl_o'] = 0
        o['scl_oen'] = 1
        o['sda_o'] = 0
        o['sda_oen'] = 1
        return o

    def advance(self, i):
        if not (i.get('nReset', 1) & 1):
            self.reset()
            return
        if (i.get('rst', 0) & 1) or self.i2c_al_value:
            self.reset()
            return

        read = i.get('read', 0) & 1
        write = i.get('write', 0) & 1
        stop = i.get('stop', 0) & 1
        start = i.get('start', 0) & 1
        core_ack = self.bit_ack
        core_rxd = i.get('sda_i', 1) & 1
        go = bool((read | write | stop) & (not self.cmd_ack))

        next_state = self.state
        next_cmd = self.core_cmd_value
        next_cmd_ack = 0
        next_ack_out = self.ack_out
        next_transfer_read = self.transfer_read
        next_sr = self.sr
        next_dcnt = self.dcnt
        next_busy = self.busy

        if self.state == 'IDLE':
            next_cmd = 'NOP'
            if go:
                next_sr = self.mask(i.get('din', 0), 8)
                next_dcnt = 7
                next_transfer_read = 0
                if start:
                    next_state = 'START'
                    next_cmd = 'START'
                elif read:
                    next_state = 'READ'
                    next_cmd = 'READ'
                    next_transfer_read = 1
                elif write:
                    next_state = 'WRITE'
                    next_cmd = 'WRITE'
                else:
                    next_state = 'STOP'
                    next_cmd = 'STOP'

        elif self.state == 'START':
            next_cmd = 'START'
            if core_ack:
                if read:
                    next_state = 'READ'
                    next_cmd = 'READ'
                    next_transfer_read = 1
                else:
                    next_state = 'WRITE'
                    next_cmd = 'WRITE'
                    next_transfer_read = 0

        elif self.state == 'WRITE':
            next_cmd = 'WRITE'
            if core_ack:
                if self.dcnt == 0:
                    next_state = 'ACK'
                    next_cmd = 'READ'
                else:
                    next_sr = self.mask((self.sr << 1) | core_rxd, 8)
                    next_dcnt = self.mask(self.dcnt - 1, 3)

        elif self.state == 'READ':
            next_cmd = 'READ'
            if core_ack:
                next_sr = self.mask((self.sr << 1) | core_rxd, 8)
                next_dcnt = self.mask(self.dcnt - 1, 3)
                if self.dcnt == 0:
                    next_state = 'ACK'
                    next_cmd = 'WRITE'

        elif self.state == 'ACK':
            if core_ack:
                if not self.transfer_read:
                    next_ack_out = core_rxd
                if stop:
                    next_state = 'STOP'
                    next_cmd = 'STOP'
                else:
                    next_state = 'IDLE'
                    next_cmd = 'NOP'
                    next_cmd_ack = 1

        elif self.state == 'STOP':
            next_cmd = 'STOP'
            if core_ack:
                next_state = 'IDLE'
                next_cmd = 'NOP'
                next_cmd_ack = 1

        if core_ack and self.core_cmd_value == 'START':
            next_busy = 1
        elif core_ack and self.core_cmd_value == 'STOP':
            next_busy = 0

        if core_ack:
            next_bit_ack = 0
        elif self.core_cmd_value != 'NOP' and (i.get('ena', 0) & 1):
            next_bit_ack = 1
        else:
            next_bit_ack = 0

        self.state = next_state
        self.core_cmd_value = next_cmd
        self.cmd_ack = next_cmd_ack
        self.ack_out = self.mask(next_ack_out, 1)
        self.transfer_read = next_transfer_read
        self.sr = self.mask(next_sr, 8)
        self.dcnt = self.mask(next_dcnt, 3)
        self.busy = self.mask(next_busy, 1)
        self.bit_ack = self.mask(next_bit_ack, 1)
