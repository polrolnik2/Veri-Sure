"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['dcsb_dat_o', 'dcsb_ack_o', 'dcsb_err_o', 'sbbiu_dat_o', 'sbbiu_adr_o', 'sbbiu_cyc_o', 'sbbiu_stb_o', 'sbbiu_we_o', 'sbbiu_sel_o', 'sbbiu_cab_o']
    PROBE_PORTS = ['fifo_dat_i', 'fifo_dat_o', 'fifo_wr', 'fifo_rd', 'fifo_full', 'fifo_empty', 'sel_sb', 'outstanding_store', 'fifo_wr_ack', 'or1200_sb_fifo']
    PROBE_WIDTHS = {'fifo_dat_i': 68, 'fifo_dat_o': 68, 'fifo_wr': 1, 'fifo_rd': 1, 'fifo_full': 1, 'fifo_empty': 1, 'sel_sb': 1, 'outstanding_store': 1, 'fifo_wr_ack': 1, 'or1200_sb_fifo': 1}
    LATENCY_CYCLES = 1

    def reset(self):
        self._fifo_depth = 4
        self._fifo = []
        self._outstanding_store = False
        self._fifo_wr_ack = False


    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        enabled = bool(getattr(self, "OR1200_SB_IMPLEMENTED", True))

        if not enabled:
            self.fifo_dat_i = 0
            self.fifo_dat_o = 0
            self.fifo_wr = False
            self.fifo_rd = False
            self.fifo_full = False
            self.fifo_empty = False
            self.sel_sb = False
            self.outstanding_store = False
            self.fifo_wr_ack = False
            self.or1200_sb_fifo = False

            o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)
            o['dcsb_ack_o'] = int(i['sbbiu_ack_i']) & 1
            o['dcsb_err_o'] = int(i['sbbiu_err_i']) & 1
            o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
            o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
            o['sbbiu_cyc_o'] = int(i['dcsb_cyc_i']) & 1
            o['sbbiu_stb_o'] = int(i['dcsb_stb_i']) & 1
            o['sbbiu_we_o'] = int(i['dcsb_we_i']) & 1
            o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
            o['sbbiu_cab_o'] = int(i['dcsb_cab_i']) & 1
            return o

        fifo_empty = not self._fifo
        fifo_full = len(self._fifo) >= self._fifo_depth
        outstanding = bool(self._outstanding_store)
        sel_sb = (not fifo_empty) or (fifo_empty and outstanding)
        fifo_rd = not outstanding
        fifo_wr = (
            bool(int(i['dcsb_cyc_i']) & 1)
            and bool(int(i['dcsb_stb_i']) & 1)
            and bool(int(i['dcsb_we_i']) & 1)
            and not fifo_full
            and not self._fifo_wr_ack
        )
        fifo_dat_i = (
            (self.mask(i['dcsb_sel_i'], 4) << 64)
            | (self.mask(i['dcsb_dat_i'], 32) << 32)
            | self.mask(i['dcsb_adr_i'], 32)
        )
        fifo_dat_o = self._fifo[0] if self._fifo else 0
        valid_pop = bool(fifo_rd and not fifo_empty)

        self.fifo_dat_i = self.mask(fifo_dat_i, 68)
        self.fifo_dat_o = self.mask(fifo_dat_o, 68)
        self.fifo_wr = bool(fifo_wr)
        self.fifo_rd = bool(fifo_rd)
        self.fifo_full = bool(fifo_full)
        self.fifo_empty = bool(fifo_empty)
        self.sel_sb = bool(sel_sb)
        self.outstanding_store = outstanding
        self.fifo_wr_ack = bool(self._fifo_wr_ack)
        self.or1200_sb_fifo = valid_pop

        o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)
        o['dcsb_ack_o'] = int(self._fifo_wr_ack) if sel_sb else (int(i['sbbiu_ack_i']) & 1)
        o['dcsb_err_o'] = 0 if sel_sb else (int(i['sbbiu_err_i']) & 1)

        if sel_sb:
            o['sbbiu_dat_o'] = self.mask(fifo_dat_o >> 32, 32)
            o['sbbiu_adr_o'] = self.mask(fifo_dat_o, 32)
            o['sbbiu_cyc_o'] = 1
            o['sbbiu_stb_o'] = 1
            o['sbbiu_we_o'] = 1
            o['sbbiu_sel_o'] = self.mask(fifo_dat_o >> 64, 4)
            o['sbbiu_cab_o'] = 0
        else:
            o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
            o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
            o['sbbiu_cyc_o'] = int(i['dcsb_cyc_i']) & 1
            o['sbbiu_stb_o'] = int(i['dcsb_stb_i']) & 1
            o['sbbiu_we_o'] = int(i['dcsb_we_i']) & 1
            o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
            o['sbbiu_cab_o'] = int(i['dcsb_cab_i']) & 1
        return o


    def advance(self, i):
        enabled = bool(getattr(self, "OR1200_SB_IMPLEMENTED", True))

        # Reset is modeled as active-high and synchronous to this edge.
        if int(i['rst']) & 1:
            self._fifo = []
            self._outstanding_store = False
            self._fifo_wr_ack = False
            return
        if not enabled:
            return

        fifo_empty = not self._fifo
        fifo_full = len(self._fifo) >= self._fifo_depth
        outstanding = bool(self._outstanding_store)
        sel_sb = (not fifo_empty) or (fifo_empty and outstanding)
        fifo_rd = not outstanding
        fifo_wr = (
            bool(int(i['dcsb_cyc_i']) & 1)
            and bool(int(i['dcsb_stb_i']) & 1)
            and bool(int(i['dcsb_we_i']) & 1)
            and not fifo_full
            and not self._fifo_wr_ack
        )
        valid_pop = bool(fifo_rd and not fifo_empty)
        fifo_dat_i = (
            (self.mask(i['dcsb_sel_i'], 4) << 64)
            | (self.mask(i['dcsb_dat_i'], 32) << 32)
            | self.mask(i['dcsb_adr_i'], 32)
        )

        if valid_pop:
            self._fifo.pop(0)
        if fifo_wr:
            self._fifo.append(self.mask(fifo_dat_i, 68))

        if (int(i['sbbiu_ack_i']) & 1):
            self._outstanding_store = False
        elif sel_sb or fifo_wr:
            self._outstanding_store = True

        self._fifo_wr_ack = bool(fifo_wr)
