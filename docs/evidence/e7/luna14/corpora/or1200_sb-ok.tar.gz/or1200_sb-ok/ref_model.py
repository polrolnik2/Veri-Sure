"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['dcsb_dat_o', 'dcsb_ack_o', 'dcsb_err_o', 'sbbiu_dat_o', 'sbbiu_adr_o', 'sbbiu_cyc_o', 'sbbiu_stb_o', 'sbbiu_we_o', 'sbbiu_sel_o', 'sbbiu_cab_o']
    PROBE_PORTS = ['fifo_dat_i', 'fifo_dat_o', 'fifo_wr', 'fifo_rd', 'fifo_full', 'fifo_empty', 'sel_sb', 'outstanding_store', 'fifo_wr_ack', 'or1200_sb_fifo']
    PROBE_WIDTHS = {'fifo_dat_i': 68, 'fifo_dat_o': 68, 'fifo_wr': 1, 'fifo_rd': 1, 'fifo_full': 1, 'fifo_empty': 1, 'sel_sb': 1, 'outstanding_store': 1, 'fifo_wr_ack': 1, 'or1200_sb_fifo': 1}
    LATENCY_CYCLES = 1

    def reset(self):
        self.sb_implemented = bool(getattr(self, "OR1200_SB_IMPLEMENTED", 1))
        self.fifo_depth = 4
        self._fifo = []
        self._outstanding_store = False
        self._fifo_wr_ack = False
        self._active_payload = None

    def _signals(self, i):
        if not self.sb_implemented:
            return {
                "fifo_dat_i": 0,
                "fifo_dat_o": 0,
                "fifo_wr": False,
                "fifo_rd": False,
                "fifo_full": False,
                "fifo_empty": True,
                "sel_sb": False,
                "pop": False,
            }

        adr = self.mask(i["dcsb_adr_i"], 32)
        dat = self.mask(i["dcsb_dat_i"], 32)
        sel = self.mask(i["dcsb_sel_i"], 4)
        fifo_dat_i = self.mask((sel << 64) | (dat << 32) | adr, 68)
        fifo_empty = not self._fifo
        fifo_full = len(self._fifo) >= self.fifo_depth
        fifo_wr = bool(
            self.mask(i["dcsb_cyc_i"], 1)
            and self.mask(i["dcsb_stb_i"], 1)
            and self.mask(i["dcsb_we_i"], 1)
            and not fifo_full
            and not self._fifo_wr_ack
        )
        fifo_rd = not self._outstanding_store
        sel_sb = (not fifo_empty) or self._outstanding_store
        pop = fifo_rd and not fifo_empty

        if self._active_payload is not None:
            fifo_dat_o = self._active_payload
        elif self._fifo:
            fifo_dat_o = self._fifo[0]
        else:
            fifo_dat_o = 0

        return {
            "fifo_dat_i": fifo_dat_i,
            "fifo_dat_o": self.mask(fifo_dat_o, 68),
            "fifo_wr": fifo_wr,
            "fifo_rd": fifo_rd,
            "fifo_full": fifo_full,
            "fifo_empty": fifo_empty,
            "sel_sb": sel_sb,
            "pop": pop,
        }

    def outputs(self, i):
        c = self._signals(i)

        self.fifo_dat_i = self.mask(c["fifo_dat_i"], 68)
        self.fifo_dat_o = self.mask(c["fifo_dat_o"], 68)
        self.fifo_wr = bool(c["fifo_wr"])
        self.fifo_rd = bool(c["fifo_rd"])
        self.fifo_full = bool(c["fifo_full"])
        self.fifo_empty = bool(c["fifo_empty"])
        self.sel_sb = bool(c["sel_sb"])
        self.outstanding_store = bool(self._outstanding_store)
        self.fifo_wr_ack = bool(self._fifo_wr_ack)
        self.or1200_sb_fifo = bool(c["pop"])

        o = {p: None for p in self.OUTPUT_PORTS}
        o["dcsb_dat_o"] = self.mask(i["sbbiu_dat_i"], 32)

        if not self.sb_implemented:
            o["dcsb_ack_o"] = self.mask(i["sbbiu_ack_i"], 1)
            o["dcsb_err_o"] = self.mask(i["sbbiu_err_i"], 1)
            o["sbbiu_dat_o"] = self.mask(i["dcsb_dat_i"], 32)
            o["sbbiu_adr_o"] = self.mask(i["dcsb_adr_i"], 32)
            o["sbbiu_cyc_o"] = self.mask(i["dcsb_cyc_i"], 1)
            o["sbbiu_stb_o"] = self.mask(i["dcsb_stb_i"], 1)
            o["sbbiu_we_o"] = self.mask(i["dcsb_we_i"], 1)
            o["sbbiu_sel_o"] = self.mask(i["dcsb_sel_i"], 4)
            o["sbbiu_cab_o"] = self.mask(i["dcsb_cab_i"], 1)
            return o

        if c["sel_sb"]:
            payload = c["fifo_dat_o"]
            o["sbbiu_dat_o"] = self.mask(payload >> 32, 32)
            o["sbbiu_adr_o"] = self.mask(payload, 32)
            o["sbbiu_cyc_o"] = 1
            o["sbbiu_stb_o"] = 1
            o["sbbiu_we_o"] = 1
            o["sbbiu_sel_o"] = self.mask(payload >> 64, 4)
            o["sbbiu_cab_o"] = 0
            o["dcsb_ack_o"] = int(self._fifo_wr_ack)
            o["dcsb_err_o"] = 0
        else:
            o["sbbiu_dat_o"] = self.mask(i["dcsb_dat_i"], 32)
            o["sbbiu_adr_o"] = self.mask(i["dcsb_adr_i"], 32)
            o["sbbiu_cyc_o"] = self.mask(i["dcsb_cyc_i"], 1)
            o["sbbiu_stb_o"] = self.mask(i["dcsb_stb_i"], 1)
            o["sbbiu_we_o"] = self.mask(i["dcsb_we_i"], 1)
            o["sbbiu_sel_o"] = self.mask(i["dcsb_sel_i"], 4)
            o["sbbiu_cab_o"] = self.mask(i["dcsb_cab_i"], 1)
            o["dcsb_ack_o"] = self.mask(i["sbbiu_ack_i"], 1)
            o["dcsb_err_o"] = self.mask(i["sbbiu_err_i"], 1)
        return o

    def advance(self, i):
        if self.mask(i["rst"], 1):
            self._fifo = []
            self._outstanding_store = False
            self._fifo_wr_ack = False
            self._active_payload = None
            return

        if not self.sb_implemented:
            return

        c = self._signals(i)
        old_head = self._fifo[0] if c["pop"] else None
        if c["pop"]:
            next_fifo = self._fifo[1:]
        else:
            next_fifo = self._fifo[:]
        if c["fifo_wr"]:
            next_fifo.append(c["fifo_dat_i"])
        self._fifo = next_fifo

        if self.mask(i["sbbiu_ack_i"], 1):
            self._outstanding_store = False
            self._active_payload = None
        else:
            if c["pop"]:
                self._active_payload = old_head
            elif not self._outstanding_store:
                self._active_payload = None
            if c["sel_sb"] or c["fifo_wr"]:
                self._outstanding_store = True

        self._fifo_wr_ack = bool(c["fifo_wr"])
