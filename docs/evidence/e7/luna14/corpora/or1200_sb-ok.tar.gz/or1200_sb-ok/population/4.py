"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['dcsb_dat_o', 'dcsb_ack_o', 'dcsb_err_o', 'sbbiu_dat_o', 'sbbiu_adr_o', 'sbbiu_cyc_o', 'sbbiu_stb_o', 'sbbiu_we_o', 'sbbiu_sel_o', 'sbbiu_cab_o']
    PROBE_PORTS = ['fifo_dat_i', 'fifo_dat_o', 'fifo_wr', 'fifo_rd', 'fifo_full', 'fifo_empty', 'sel_sb', 'outstanding_store', 'fifo_wr_ack', 'or1200_sb_fifo']
    PROBE_WIDTHS = {'fifo_dat_i': 68, 'fifo_dat_o': 68, 'fifo_wr': 1, 'fifo_rd': 1, 'fifo_full': 1, 'fifo_empty': 1, 'sel_sb': 1, 'outstanding_store': 1, 'fifo_wr_ack': 1, 'or1200_sb_fifo': 1}
    LATENCY_CYCLES = 1

    def reset(self):
        self._implemented = bool(getattr(self, "OR1200_SB_IMPLEMENTED", True))
        self._fifo_depth = 4
        self._fifo = []
        self._active_data = 0
        self._outstanding = False
        self._fifo_wr_ack = False
        self.fifo_dat_i = 0
        self.fifo_dat_o = 0
        self.fifo_wr = False
        self.fifo_rd = False
        self.fifo_full = False
        self.fifo_empty = True
        self.sel_sb = False
        self.outstanding_store = False
        self.fifo_wr_ack = False
        self.or1200_sb_fifo = False

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        dat_i = self.mask(i['dcsb_dat_i'], 32)
        adr_i = self.mask(i['dcsb_adr_i'], 32)
        sel_i = self.mask(i['dcsb_sel_i'], 4)
        dat_biu_i = self.mask(i['sbbiu_dat_i'], 32)

        if not self._implemented:
            self.fifo_dat_i = 0
            self.fifo_dat_o = 0
            self.fifo_wr = False
            self.fifo_rd = False
            self.fifo_full = False
            self.fifo_empty = True
            self.sel_sb = False
            self.outstanding_store = False
            self.fifo_wr_ack = False
            self.or1200_sb_fifo = False
            o['dcsb_dat_o'] = dat_biu_i
            o['dcsb_ack_o'] = int(bool(i['sbbiu_ack_i'] & 1))
            o['dcsb_err_o'] = int(bool(i['sbbiu_err_i'] & 1))
            o['sbbiu_dat_o'] = dat_i
            o['sbbiu_adr_o'] = adr_i
            o['sbbiu_cyc_o'] = i['dcsb_cyc_i'] & 1
            o['sbbiu_stb_o'] = i['dcsb_stb_i'] & 1
            o['sbbiu_we_o'] = i['dcsb_we_i'] & 1
            o['sbbiu_sel_o'] = sel_i
            o['sbbiu_cab_o'] = i['dcsb_cab_i'] & 1
            return o

        fifo_empty = len(self._fifo) == 0
        fifo_full = len(self._fifo) >= self._fifo_depth
        sel_sb = (not fifo_empty) or self._outstanding
        fifo_wr = bool((i['dcsb_cyc_i'] & 1) and (i['dcsb_stb_i'] & 1) and
                       (i['dcsb_we_i'] & 1) and not fifo_full and
                       not self._fifo_wr_ack)
        fifo_rd = not self._outstanding
        fifo_dat_i = ((sel_i << 64) | (dat_i << 32) | adr_i)

        if self._outstanding:
            fifo_dat_o = self._active_data
        elif self._fifo:
            fifo_dat_o = self._fifo[0]
        else:
            fifo_dat_o = 0

        self.fifo_dat_i = self.mask(fifo_dat_i, 68)
        self.fifo_dat_o = self.mask(fifo_dat_o, 68)
        self.fifo_wr = bool(fifo_wr)
        self.fifo_rd = bool(fifo_rd)
        self.fifo_full = bool(fifo_full)
        self.fifo_empty = bool(fifo_empty)
        self.sel_sb = bool(sel_sb)
        self.outstanding_store = bool(self._outstanding)
        self.fifo_wr_ack = bool(self._fifo_wr_ack)
        self.or1200_sb_fifo = bool(fifo_rd and not fifo_empty)

        o['dcsb_dat_o'] = dat_biu_i
        o['dcsb_ack_o'] = int(self._fifo_wr_ack if sel_sb else bool(i['sbbiu_ack_i'] & 1))
        o['dcsb_err_o'] = 0 if sel_sb else (i['sbbiu_err_i'] & 1)
        if sel_sb:
            fifo_value = self.mask(fifo_dat_o, 68)
            o['sbbiu_dat_o'] = (fifo_value >> 32) & self.mask(0xffffffff, 32)
            o['sbbiu_adr_o'] = fifo_value & self.mask(0xffffffff, 32)
            o['sbbiu_cyc_o'] = 1
            o['sbbiu_stb_o'] = 1
            o['sbbiu_we_o'] = 1
            o['sbbiu_sel_o'] = (fifo_value >> 64) & 0xf
            o['sbbiu_cab_o'] = 0
        else:
            o['sbbiu_dat_o'] = dat_i
            o['sbbiu_adr_o'] = adr_i
            o['sbbiu_cyc_o'] = i['dcsb_cyc_i'] & 1
            o['sbbiu_stb_o'] = i['dcsb_stb_i'] & 1
            o['sbbiu_we_o'] = i['dcsb_we_i'] & 1
            o['sbbiu_sel_o'] = sel_i
            o['sbbiu_cab_o'] = i['dcsb_cab_i'] & 1
        return o

    def advance(self, i):
        if not self._implemented:
            return
        if i['rst'] & 1:
            self._fifo = []
            self._active_data = 0
            self._outstanding = False
            self._fifo_wr_ack = False
            return

        old_outstanding = self._outstanding
        old_empty = len(self._fifo) == 0
        old_full = len(self._fifo) >= self._fifo_depth
        old_sel_sb = (not old_empty) or old_outstanding
        fifo_wr = bool((i['dcsb_cyc_i'] & 1) and (i['dcsb_stb_i'] & 1) and
                       (i['dcsb_we_i'] & 1) and not old_full and
                       not self._fifo_wr_ack)
        biu_ack = bool(i['sbbiu_ack_i'] & 1)
        payload = ((self.mask(i['dcsb_sel_i'], 4) << 64) |
                   (self.mask(i['dcsb_dat_i'], 32) << 32) |
                   self.mask(i['dcsb_adr_i'], 32))

        working_fifo = list(self._fifo)
        if fifo_wr:
            working_fifo.append(self.mask(payload, 68))

        active_data = self._active_data
        if not old_outstanding:
            if not old_empty:
                popped = working_fifo.pop(0)
                active_data = 0 if biu_ack else popped
            elif fifo_wr:
                if biu_ack:
                    active_data = 0
                else:
                    # The newly accepted entry becomes the active Store Buffer request.
                    working_fifo.pop(0)
                    active_data = self.mask(payload, 68)
            else:
                active_data = 0
        elif biu_ack:
            active_data = 0

        if biu_ack:
            outstanding = False
        elif old_sel_sb or fifo_wr:
            outstanding = True
        else:
            outstanding = False

        self._fifo = working_fifo
        self._active_data = self.mask(active_data, 68)
        self._outstanding = bool(outstanding)
        self._fifo_wr_ack = bool(fifo_wr)
