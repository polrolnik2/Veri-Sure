"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['dcsb_dat_o', 'dcsb_ack_o', 'dcsb_err_o', 'sbbiu_dat_o', 'sbbiu_adr_o', 'sbbiu_cyc_o', 'sbbiu_stb_o', 'sbbiu_we_o', 'sbbiu_sel_o', 'sbbiu_cab_o']
    PROBE_PORTS = ['fifo_dat_i', 'fifo_dat_o', 'fifo_wr', 'fifo_rd', 'fifo_full', 'fifo_empty', 'sel_sb', 'outstanding_store', 'fifo_wr_ack', 'or1200_sb_fifo']
    PROBE_WIDTHS = {'fifo_dat_i': 68, 'fifo_dat_o': 68, 'fifo_wr': 1, 'fifo_rd': 1, 'fifo_full': 1, 'fifo_empty': 1, 'sel_sb': 1, 'outstanding_store': 1, 'fifo_wr_ack': 1, 'or1200_sb_fifo': 1}
    LATENCY_CYCLES = 1

    FIFO_DEPTH = 4
    IMPLEMENTED = True

    def reset(self):
        self.implemented = bool(getattr(self, "IMPLEMENTED", True))
        self.fifo = []
        self.outstanding_store = False
        self.fifo_wr_ack = False

    def _comb(self, i):
        d_dat = self.mask(i["dcsb_dat_i"], 32)
        d_adr = self.mask(i["dcsb_adr_i"], 32)
        d_cyc = self.mask(i["dcsb_cyc_i"], 1)
        d_stb = self.mask(i["dcsb_stb_i"], 1)
        d_we = self.mask(i["dcsb_we_i"], 1)
        d_sel = self.mask(i["dcsb_sel_i"], 4)
        d_cab = self.mask(i["dcsb_cab_i"], 1)
        biu_dat = self.mask(i["sbbiu_dat_i"], 32)
        biu_ack = self.mask(i["sbbiu_ack_i"], 1)
        biu_err = self.mask(i["sbbiu_err_i"], 1)

        if not self.implemented:
            return {
                "d_dat": d_dat, "d_adr": d_adr, "d_cyc": d_cyc,
                "d_stb": d_stb, "d_we": d_we, "d_sel": d_sel,
                "d_cab": d_cab, "biu_dat": biu_dat, "biu_ack": biu_ack,
                "biu_err": biu_err, "fifo_dat_i": 0, "fifo_dat_o": 0,
                "fifo_wr": False, "fifo_rd": False, "fifo_full": False,
                "fifo_empty": True, "sel_sb": False,
                "outstanding_store": False, "fifo_wr_ack": False,
                "or1200_sb_fifo": False
            }

        fifo_empty = len(self.fifo) == 0
        fifo_full = len(self.fifo) >= self.FIFO_DEPTH
        fifo_dat_i = self.mask((d_sel << 64) | (d_dat << 32) | d_adr, 68)
        fifo_dat_o = self.fifo[0] if not fifo_empty else 0
        fifo_wr = bool(d_cyc and d_stb and d_we and not fifo_full and not self.fifo_wr_ack)
        fifo_rd = not self.outstanding_store
        sel_sb = (not fifo_empty) or self.outstanding_store
        return {
            "d_dat": d_dat, "d_adr": d_adr, "d_cyc": d_cyc,
            "d_stb": d_stb, "d_we": d_we, "d_sel": d_sel,
            "d_cab": d_cab, "biu_dat": biu_dat, "biu_ack": biu_ack,
            "biu_err": biu_err, "fifo_dat_i": fifo_dat_i,
            "fifo_dat_o": self.mask(fifo_dat_o, 68), "fifo_wr": fifo_wr,
            "fifo_rd": fifo_rd, "fifo_full": fifo_full,
            "fifo_empty": fifo_empty, "sel_sb": sel_sb,
            "outstanding_store": bool(self.outstanding_store),
            "fifo_wr_ack": bool(self.fifo_wr_ack),
            "or1200_sb_fifo": bool(fifo_rd and not fifo_empty)
        }

    def outputs(self, i):
        c = self._comb(i)
        self.fifo_dat_i = c["fifo_dat_i"]
        self.fifo_dat_o = c["fifo_dat_o"]
        self.fifo_wr = c["fifo_wr"]
        self.fifo_rd = c["fifo_rd"]
        self.fifo_full = c["fifo_full"]
        self.fifo_empty = c["fifo_empty"]
        self.sel_sb = c["sel_sb"]
        self.outstanding_store = c["outstanding_store"]
        self.fifo_wr_ack = c["fifo_wr_ack"]
        self.or1200_sb_fifo = c["or1200_sb_fifo"]

        o = {p: None for p in self.OUTPUT_PORTS}
        o["dcsb_dat_o"] = c["biu_dat"]
        if not self.implemented:
            o["dcsb_ack_o"] = c["biu_ack"]
            o["dcsb_err_o"] = c["biu_err"]
            o["sbbiu_dat_o"] = c["d_dat"]
            o["sbbiu_adr_o"] = c["d_adr"]
            o["sbbiu_cyc_o"] = c["d_cyc"]
            o["sbbiu_stb_o"] = c["d_stb"]
            o["sbbiu_we_o"] = c["d_we"]
            o["sbbiu_sel_o"] = c["d_sel"]
            o["sbbiu_cab_o"] = c["d_cab"]
        elif c["sel_sb"]:
            fifo_word = c["fifo_dat_o"]
            o["dcsb_ack_o"] = int(c["fifo_wr_ack"])
            o["dcsb_err_o"] = 0
            o["sbbiu_dat_o"] = (fifo_word >> 32) & 0xffffffff
            o["sbbiu_adr_o"] = fifo_word & 0xffffffff
            o["sbbiu_cyc_o"] = 1
            o["sbbiu_stb_o"] = 1
            o["sbbiu_we_o"] = 1
            o["sbbiu_sel_o"] = (fifo_word >> 64) & 0xf
            o["sbbiu_cab_o"] = 0
        else:
            o["dcsb_ack_o"] = c["biu_ack"]
            o["dcsb_err_o"] = c["biu_err"]
            o["sbbiu_dat_o"] = c["d_dat"]
            o["sbbiu_adr_o"] = c["d_adr"]
            o["sbbiu_cyc_o"] = c["d_cyc"]
            o["sbbiu_stb_o"] = c["d_stb"]
            o["sbbiu_we_o"] = c["d_we"]
            o["sbbiu_sel_o"] = c["d_sel"]
            o["sbbiu_cab_o"] = c["d_cab"]
        return o

    def advance(self, i):
        if self.mask(i["rst"], 1):
            self.fifo = []
            self.outstanding_store = False
            self.fifo_wr_ack = False
            return
        if not self.implemented:
            return

        c = self._comb(i)
        if c["or1200_sb_fifo"]:
            self.fifo.pop(0)
        if c["fifo_wr"]:
            self.fifo.append(c["fifo_dat_i"])

        self.fifo_wr_ack = bool(c["fifo_wr"])
        if c["biu_ack"]:
            self.outstanding_store = False
        else:
            self.outstanding_store = bool(c["sel_sb"] or c["fifo_wr"])
