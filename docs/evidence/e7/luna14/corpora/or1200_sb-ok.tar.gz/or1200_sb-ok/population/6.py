"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['dcsb_dat_o', 'dcsb_ack_o', 'dcsb_err_o', 'sbbiu_dat_o', 'sbbiu_adr_o', 'sbbiu_cyc_o', 'sbbiu_stb_o', 'sbbiu_we_o', 'sbbiu_sel_o', 'sbbiu_cab_o']
    PROBE_PORTS = ['fifo_dat_i', 'fifo_dat_o', 'fifo_wr', 'fifo_rd', 'fifo_full', 'fifo_empty', 'sel_sb', 'outstanding_store', 'fifo_wr_ack', 'or1200_sb_fifo']
    PROBE_WIDTHS = {'fifo_dat_i': 68, 'fifo_dat_o': 68, 'fifo_wr': 1, 'fifo_rd': 1, 'fifo_full': 1, 'fifo_empty': 1, 'sel_sb': 1, 'outstanding_store': 1, 'fifo_wr_ack': 1, 'or1200_sb_fifo': 1}
    LATENCY_CYCLES = 1

    def reset(self):
        self.sb_implemented = bool(getattr(self, 'OR1200_SB_IMPLEMENTED', True))
        self.queue = []
        self.active = None
        self.outstanding_store = False
        self.fifo_wr_ack = False
        self.fifo_dat_i = 0
        self.fifo_dat_o = 0
        self.fifo_wr = False
        self.fifo_rd = False
        self.fifo_full = False
        self.fifo_empty = True
        self.sel_sb = False
        self.or1200_sb_fifo = False

    def _pack(self, item):
        sel, data, adr = item
        return self.mask((self.mask(sel, 4) << 64) | (self.mask(data, 32) << 32) | self.mask(adr, 32), 68)

    def _comb(self, i):
        if not self.sb_implemented:
            return {
                'dcsb_dat_o': self.mask(i['sbbiu_dat_i'], 32),
                'dcsb_ack_o': int(bool(i['sbbiu_ack_i'])),
                'dcsb_err_o': int(bool(i['sbbiu_err_i'])),
                'sbbiu_dat_o': self.mask(i['dcsb_dat_i'], 32),
                'sbbiu_adr_o': self.mask(i['dcsb_adr_i'], 32),
                'sbbiu_cyc_o': int(bool(i['dcsb_cyc_i'])),
                'sbbiu_stb_o': int(bool(i['dcsb_stb_i'])),
                'sbbiu_we_o': int(bool(i['dcsb_we_i'])),
                'sbbiu_sel_o': self.mask(i['dcsb_sel_i'], 4),
                'sbbiu_cab_o': int(bool(i['dcsb_cab_i'])),
                'fifo_dat_i': 0,
                'fifo_dat_o': 0,
                'fifo_wr': False,
                'fifo_rd': False,
                'fifo_full': False,
                'fifo_empty': True,
                'sel_sb': False,
                'outstanding_store': False,
                'fifo_wr_ack': False,
                'or1200_sb_fifo': False
            }

        empty = not self.queue
        full = len(self.queue) >= 4
        sel = (not empty) or (empty and self.outstanding_store)
        rd = not self.outstanding_store
        wr = bool(i['dcsb_cyc_i'] and i['dcsb_stb_i'] and i['dcsb_we_i'] and not full and not self.fifo_wr_ack)
        input_item = (self.mask(i['dcsb_sel_i'], 4), self.mask(i['dcsb_dat_i'], 32), self.mask(i['dcsb_adr_i'], 32))
        if self.outstanding_store and self.active is not None:
            output_item = self.active
        elif self.queue:
            output_item = self.queue[0]
        else:
            output_item = None
        output_word = self._pack(output_item) if output_item is not None else 0
        valid_pop = bool(rd and (not empty or wr))

        if sel:
            sb_dat = self.mask(output_item[1], 32) if output_item is not None else 0
            sb_adr = self.mask(output_item[2], 32) if output_item is not None else 0
            sb_sel = self.mask(output_item[0], 4) if output_item is not None else 0
            sb_cyc = 1
            sb_stb = 1
            sb_we = 1
            sb_cab = 0
            dc_ack = int(bool(self.fifo_wr_ack))
            dc_err = 0
        else:
            sb_dat = self.mask(i['dcsb_dat_i'], 32)
            sb_adr = self.mask(i['dcsb_adr_i'], 32)
            sb_sel = self.mask(i['dcsb_sel_i'], 4)
            sb_cyc = int(bool(i['dcsb_cyc_i']))
            sb_stb = int(bool(i['dcsb_stb_i']))
            sb_we = int(bool(i['dcsb_we_i']))
            sb_cab = int(bool(i['dcsb_cab_i']))
            dc_ack = int(bool(i['sbbiu_ack_i']))
            dc_err = int(bool(i['sbbiu_err_i']))

        return {
            'dcsb_dat_o': self.mask(i['sbbiu_dat_i'], 32),
            'dcsb_ack_o': dc_ack,
            'dcsb_err_o': dc_err,
            'sbbiu_dat_o': sb_dat,
            'sbbiu_adr_o': sb_adr,
            'sbbiu_cyc_o': sb_cyc,
            'sbbiu_stb_o': sb_stb,
            'sbbiu_we_o': sb_we,
            'sbbiu_sel_o': sb_sel,
            'sbbiu_cab_o': sb_cab,
            'fifo_dat_i': self._pack(input_item),
            'fifo_dat_o': output_word,
            'fifo_wr': wr,
            'fifo_rd': rd,
            'fifo_full': full,
            'fifo_empty': empty,
            'sel_sb': bool(sel),
            'outstanding_store': bool(self.outstanding_store),
            'fifo_wr_ack': bool(self.fifo_wr_ack),
            'or1200_sb_fifo': valid_pop
        }

    def outputs(self, i):
        c = self._comb(i)
        self.fifo_dat_i = c['fifo_dat_i']
        self.fifo_dat_o = c['fifo_dat_o']
        self.fifo_wr = bool(c['fifo_wr'])
        self.fifo_rd = bool(c['fifo_rd'])
        self.fifo_full = bool(c['fifo_full'])
        self.fifo_empty = bool(c['fifo_empty'])
        self.sel_sb = bool(c['sel_sb'])
        self.outstanding_store = bool(c['outstanding_store'])
        self.fifo_wr_ack = bool(c['fifo_wr_ack'])
        self.or1200_sb_fifo = bool(c['or1200_sb_fifo'])
        o = {p: None for p in self.OUTPUT_PORTS}
        o['dcsb_dat_o'] = c['dcsb_dat_o']
        o['dcsb_ack_o'] = c['dcsb_ack_o']
        o['dcsb_err_o'] = c['dcsb_err_o']
        o['sbbiu_dat_o'] = c['sbbiu_dat_o']
        o['sbbiu_adr_o'] = c['sbbiu_adr_o']
        o['sbbiu_cyc_o'] = c['sbbiu_cyc_o']
        o['sbbiu_stb_o'] = c['sbbiu_stb_o']
        o['sbbiu_we_o'] = c['sbbiu_we_o']
        o['sbbiu_sel_o'] = c['sbbiu_sel_o']
        o['sbbiu_cab_o'] = c['sbbiu_cab_o']
        return o

    def advance(self, i):
        if not self.sb_implemented:
            return
        if i['rst']:
            self.queue = []
            self.active = None
            self.outstanding_store = False
            self.fifo_wr_ack = False
            return

        c = self._comb(i)
        accepted = bool(c['fifo_wr'])
        pending = list(self.queue)
        popped_item = None
        if c['fifo_rd'] and pending:
            popped_item = pending.pop(0)
            if accepted:
                pending.append((self.mask(i['dcsb_sel_i'], 4), self.mask(i['dcsb_dat_i'], 32), self.mask(i['dcsb_adr_i'], 32)))
        elif c['fifo_rd'] and accepted:
            # Chosen FIFO interpretation: an enabled read can consume a write
            # accepted into an otherwise empty FIFO on this edge.
            popped_item = (self.mask(i['dcsb_sel_i'], 4), self.mask(i['dcsb_dat_i'], 32), self.mask(i['dcsb_adr_i'], 32))
        elif accepted:
            pending.append((self.mask(i['dcsb_sel_i'], 4), self.mask(i['dcsb_dat_i'], 32), self.mask(i['dcsb_adr_i'], 32)))

        if i['sbbiu_ack_i']:
            self.outstanding_store = False
            self.active = None
        else:
            if popped_item is not None:
                self.active = popped_item
            elif not self.outstanding_store:
                self.active = None
            if c['sel_sb'] or accepted:
                self.outstanding_store = True

        self.queue = pending
        self.fifo_wr_ack = accepted
