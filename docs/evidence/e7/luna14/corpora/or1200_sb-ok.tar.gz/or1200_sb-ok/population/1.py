"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['dcsb_dat_o', 'dcsb_ack_o', 'dcsb_err_o', 'sbbiu_dat_o', 'sbbiu_adr_o', 'sbbiu_cyc_o', 'sbbiu_stb_o', 'sbbiu_we_o', 'sbbiu_sel_o', 'sbbiu_cab_o']
    PROBE_PORTS = ['fifo_dat_i', 'fifo_dat_o', 'fifo_wr', 'fifo_rd', 'fifo_full', 'fifo_empty', 'sel_sb', 'outstanding_store', 'fifo_wr_ack', 'or1200_sb_fifo']
    PROBE_WIDTHS = {'fifo_dat_i': 68, 'fifo_dat_o': 68, 'fifo_wr': 1, 'fifo_rd': 1, 'fifo_full': 1, 'fifo_empty': 1, 'sel_sb': 1, 'outstanding_store': 1, 'fifo_wr_ack': 1, 'or1200_sb_fifo': 1}
    LATENCY_CYCLES = 1

    def reset(self):
        self._sb_implemented = bool(getattr(self, "OR1200_SB_IMPLEMENTED", True))
        self._sb_fifo_capacity = 4
        self._sb_fifo = []
        self.outstanding_store = 0
        self.fifo_wr_ack = 0
        self._sb_active_valid = False
        self._sb_active_data = 0
        self._sb_fifo_last = 0

    def _signals(self, i):
        d = self.mask(i["dcsb_dat_i"], 32)
        a = self.mask(i["dcsb_adr_i"], 32)
        s = self.mask(i["dcsb_sel_i"], 4)
        payload = (s << 64) | (d << 32) | a

        if not self._sb_implemented:
            o = {
                "dcsb_dat_o": self.mask(i["sbbiu_dat_i"], 32),
                "dcsb_ack_o": self.mask(i["sbbiu_ack_i"], 1),
                "dcsb_err_o": self.mask(i["sbbiu_err_i"], 1),
                "sbbiu_dat_o": d,
                "sbbiu_adr_o": a,
                "sbbiu_cyc_o": self.mask(i["dcsb_cyc_i"], 1),
                "sbbiu_stb_o": self.mask(i["dcsb_stb_i"], 1),
                "sbbiu_we_o": self.mask(i["dcsb_we_i"], 1),
                "sbbiu_sel_o": s,
                "sbbiu_cab_o": self.mask(i["dcsb_cab_i"], 1),
            }
            p = {
                "fifo_dat_i": 0,
                "fifo_dat_o": 0,
                "fifo_wr": False,
                "fifo_rd": False,
                "fifo_full": False,
                "fifo_empty": True,
                "sel_sb": False,
                "outstanding_store": False,
                "fifo_wr_ack": False,
                "or1200_sb_fifo": False,
            }
            return o, p

        empty = len(self._sb_fifo) == 0
        full = len(self._sb_fifo) >= self._sb_fifo_capacity
        outstanding = bool(self.outstanding_store)
        sel_sb = (not empty) or outstanding
        fifo_wr = bool(
            self.mask(i["dcsb_cyc_i"], 1)
            and self.mask(i["dcsb_stb_i"], 1)
            and self.mask(i["dcsb_we_i"], 1)
            and not full
            and not self.fifo_wr_ack
        )
        fifo_rd = not outstanding
        valid_pop = fifo_rd and not empty

        if self._sb_active_valid and outstanding:
            fifo_data = self._sb_active_data
        elif not empty:
            fifo_data = self._sb_fifo[0]
        else:
            fifo_data = self._sb_fifo_last
        fifo_data = self.mask(fifo_data, 68)

        if sel_sb:
            biu_data = (fifo_data >> 32) & 0xffffffff
            biu_addr = fifo_data & 0xffffffff
            biu_sel = (fifo_data >> 64) & 0xf
            biu_cyc = 1
            biu_stb = 1
            biu_we = 1
            biu_cab = 0
            dc_ack = int(bool(self.fifo_wr_ack))
            dc_err = 0
        else:
            biu_data = d
            biu_addr = a
            biu_sel = s
            biu_cyc = self.mask(i["dcsb_cyc_i"], 1)
            biu_stb = self.mask(i["dcsb_stb_i"], 1)
            biu_we = self.mask(i["dcsb_we_i"], 1)
            biu_cab = self.mask(i["dcsb_cab_i"], 1)
            dc_ack = self.mask(i["sbbiu_ack_i"], 1)
            dc_err = self.mask(i["sbbiu_err_i"], 1)

        o = {
            "dcsb_dat_o": self.mask(i["sbbiu_dat_i"], 32),
            "dcsb_ack_o": dc_ack,
            "dcsb_err_o": dc_err,
            "sbbiu_dat_o": self.mask(biu_data, 32),
            "sbbiu_adr_o": self.mask(biu_addr, 32),
            "sbbiu_cyc_o": self.mask(biu_cyc, 1),
            "sbbiu_stb_o": self.mask(biu_stb, 1),
            "sbbiu_we_o": self.mask(biu_we, 1),
            "sbbiu_sel_o": self.mask(biu_sel, 4),
            "sbbiu_cab_o": self.mask(biu_cab, 1),
        }
        p = {
            "fifo_dat_i": self.mask(payload, 68),
            "fifo_dat_o": fifo_data,
            "fifo_wr": fifo_wr,
            "fifo_rd": fifo_rd,
            "fifo_full": full,
            "fifo_empty": empty,
            "sel_sb": sel_sb,
            "outstanding_store": outstanding,
            "fifo_wr_ack": bool(self.fifo_wr_ack),
            "or1200_sb_fifo": valid_pop,
        }
        return o, p

    def outputs(self, i):
        o, p = self._signals(i)
        for name, value in p.items():
            setattr(self, name, value)
        return o

    def advance(self, i):
        if self.mask(i["rst"], 1):
            self._sb_fifo = []
            self.outstanding_store = 0
            self.fifo_wr_ack = 0
            self._sb_active_valid = False
            self._sb_active_data = 0
            self._sb_fifo_last = 0
            return

        if not self._sb_implemented:
            return

        _, p = self._signals(i)
        old_outstanding = bool(self.outstanding_store)
        ack = bool(self.mask(i["sbbiu_ack_i"], 1))
        do_write = bool(p["fifo_wr"])
        do_pop = bool(p["or1200_sb_fifo"])
        popped = None

        if do_pop:
            popped = self._sb_fifo.pop(0)
            self._sb_fifo_last = self.mask(popped, 68)
        if do_write:
            self._sb_fifo.append(self.mask(p["fifo_dat_i"], 68))

        if old_outstanding:
            if ack:
                self.outstanding_store = 0
                self._sb_active_valid = False
            else:
                self.outstanding_store = 1
        else:
            if do_pop and not ack:
                self._sb_active_data = self.mask(popped, 68)
                self._sb_active_valid = True
            else:
                self._sb_active_valid = False
            if ack:
                self.outstanding_store = 0
            elif p["sel_sb"] or do_write:
                self.outstanding_store = 1
            else:
                self.outstanding_store = 0

        self.fifo_wr_ack = int(do_write)
