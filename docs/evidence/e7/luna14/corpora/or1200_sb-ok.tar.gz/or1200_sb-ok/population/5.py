"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['dcsb_dat_o', 'dcsb_ack_o', 'dcsb_err_o', 'sbbiu_dat_o', 'sbbiu_adr_o', 'sbbiu_cyc_o', 'sbbiu_stb_o', 'sbbiu_we_o', 'sbbiu_sel_o', 'sbbiu_cab_o']
    PROBE_PORTS = ['fifo_dat_i', 'fifo_dat_o', 'fifo_wr', 'fifo_rd', 'fifo_full', 'fifo_empty', 'sel_sb', 'outstanding_store', 'fifo_wr_ack', 'or1200_sb_fifo']
    PROBE_WIDTHS = {'fifo_dat_i': 68, 'fifo_dat_o': 68, 'fifo_wr': 1, 'fifo_rd': 1, 'fifo_full': 1, 'fifo_empty': 1, 'sel_sb': 1, 'outstanding_store': 1, 'fifo_wr_ack': 1, 'or1200_sb_fifo': 1}
    LATENCY_CYCLES = 1

    def reset(self):
        if not hasattr(self, 'sb_implemented'):
            self.sb_implemented = True
        self._fifo_depth = 4
        self.fifo = []
        self.fifo_qout = 0
        self.outstanding_store = False
        self.fifo_wr_ack = False

    def _signals(self, i):
        if not self.sb_implemented:
            return {
                'fifo_dat_i': 0,
                'fifo_dat_o': 0,
                'fifo_wr': False,
                'fifo_rd': False,
                'fifo_full': False,
                'fifo_empty': False,
                'sel_sb': False,
                'outstanding_store': False,
                'fifo_wr_ack': False,
                'or1200_sb_fifo': False,
            }

        fifo_empty = len(self.fifo) == 0
        fifo_full = len(self.fifo) >= self._fifo_depth
        outstanding = bool(self.outstanding_store)
        fifo_wr_ack = bool(self.fifo_wr_ack)
        sel_sb = bool((not fifo_empty) or outstanding)
        fifo_wr = bool(
            i['dcsb_cyc_i'] and i['dcsb_stb_i'] and i['dcsb_we_i']
            and not fifo_full and not fifo_wr_ack
        )
        fifo_rd = not outstanding

        # Model the FIFO's empty protection, with write-through on a simultaneous
        # accepted write and read when the queue was empty.
        valid_pop = bool(fifo_rd and ((not fifo_empty) or fifo_wr))

        fifo_dat_i = self.mask(
            ((self.mask(i['dcsb_sel_i'], 4) << 64)
             | (self.mask(i['dcsb_dat_i'], 32) << 32)
             | self.mask(i['dcsb_adr_i'], 32)),
            68,
        )
        if outstanding:
            fifo_dat_o = self.fifo_qout
        elif self.fifo:
            fifo_dat_o = self.fifo[0]
        else:
            fifo_dat_o = self.fifo_qout

        return {
            'fifo_dat_i': fifo_dat_i,
            'fifo_dat_o': self.mask(fifo_dat_o, 68),
            'fifo_wr': fifo_wr,
            'fifo_rd': fifo_rd,
            'fifo_full': fifo_full,
            'fifo_empty': fifo_empty,
            'sel_sb': sel_sb,
            'outstanding_store': outstanding,
            'fifo_wr_ack': fifo_wr_ack,
            'or1200_sb_fifo': valid_pop,
        }

    def outputs(self, i):
        s = self._signals(i)
        self.fifo_dat_i = s['fifo_dat_i']
        self.fifo_dat_o = s['fifo_dat_o']
        self.fifo_wr = bool(s['fifo_wr'])
        self.fifo_rd = bool(s['fifo_rd'])
        self.fifo_full = bool(s['fifo_full'])
        self.fifo_empty = bool(s['fifo_empty'])
        self.sel_sb = bool(s['sel_sb'])
        self.outstanding_store = bool(s['outstanding_store'])
        self.fifo_wr_ack = bool(s['fifo_wr_ack'])
        self.or1200_sb_fifo = bool(s['or1200_sb_fifo'])

        o = {p: None for p in self.OUTPUT_PORTS}
        o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)

        if not self.sb_implemented:
            o['dcsb_ack_o'] = int(bool(i['sbbiu_ack_i']))
            o['dcsb_err_o'] = int(bool(i['sbbiu_err_i']))
            o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
            o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
            o['sbbiu_cyc_o'] = int(bool(i['dcsb_cyc_i']))
            o['sbbiu_stb_o'] = int(bool(i['dcsb_stb_i']))
            o['sbbiu_we_o'] = int(bool(i['dcsb_we_i']))
            o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
            o['sbbiu_cab_o'] = int(bool(i['dcsb_cab_i']))
            return o

        if s['sel_sb']:
            fifo_dat_o = s['fifo_dat_o']
            o['dcsb_ack_o'] = int(bool(s['fifo_wr_ack']))
            o['dcsb_err_o'] = 0
            o['sbbiu_dat_o'] = self.mask(fifo_dat_o >> 32, 32)
            o['sbbiu_adr_o'] = self.mask(fifo_dat_o, 32)
            o['sbbiu_cyc_o'] = 1
            o['sbbiu_stb_o'] = 1
            o['sbbiu_we_o'] = 1
            o['sbbiu_sel_o'] = self.mask(fifo_dat_o >> 64, 4)
            o['sbbiu_cab_o'] = 0
        else:
            o['dcsb_ack_o'] = int(bool(i['sbbiu_ack_i']))
            o['dcsb_err_o'] = int(bool(i['sbbiu_err_i']))
            o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
            o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
            o['sbbiu_cyc_o'] = int(bool(i['dcsb_cyc_i']))
            o['sbbiu_stb_o'] = int(bool(i['dcsb_stb_i']))
            o['sbbiu_we_o'] = int(bool(i['dcsb_we_i']))
            o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
            o['sbbiu_cab_o'] = int(bool(i['dcsb_cab_i']))
        return o

    def advance(self, i):
        if not self.sb_implemented:
            return
        if i['rst']:
            self.fifo = []
            self.fifo_qout = 0
            self.outstanding_store = False
            self.fifo_wr_ack = False
            return

        s = self._signals(i)
        fifo_wr = bool(s['fifo_wr'])
        valid_pop = bool(s['or1200_sb_fifo'])
        payload = s['fifo_dat_i']
        consumed_write = False

        if valid_pop:
            if self.fifo:
                self.fifo_qout = self.fifo.pop(0)
            elif fifo_wr:
                # Empty-FIFO write-through: the accepted entry is also the entry
                # made available by this enabled read.
                self.fifo_qout = payload
                consumed_write = True

        if fifo_wr and not consumed_write:
            self.fifo.append(payload)

        self.fifo_wr_ack = fifo_wr
        if i['sbbiu_ack_i']:
            self.outstanding_store = False
        elif s['sel_sb'] or fifo_wr:
            self.outstanding_store = True
