"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        self.out = 0
        self.ex_enable = 0
        self.underflow = 0
        self.overflow = 0
        self.inexact = 0
        self.exception = 0
        self.invalid = 0
        for name in (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger'
        ):
            setattr(self, name, 0)
        for name in (
            'nan_output_0', 'nan_output', 'inf_round_down', 'out_inf',
            'out_0', 'out_1', 'out_2'
        ):
            setattr(self, name, 0)

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self.out
        o['ex_enable'] = self.ex_enable
        o['underflow'] = self.underflow
        o['overflow'] = self.overflow
        o['inexact'] = self.inexact
        o['exception'] = self.exception
        o['invalid'] = self.invalid
        for name in (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger'
        ):
            setattr(self, name, int(bool(getattr(self, name))))
        o['in_et_zero'] = self.in_et_zero
        o['opa_et_zero'] = self.opa_et_zero
        o['opb_et_zero'] = self.opb_et_zero
        o['input_et_zero'] = self.input_et_zero
        o['add'] = self.add
        o['subtract'] = self.subtract
        o['multiply'] = self.multiply
        o['divide'] = self.divide
        o['opa_qnan'] = self.opa_qnan
        o['opb_qnan'] = self.opb_qnan
        o['opa_snan'] = self.opa_snan
        o['opb_snan'] = self.opb_snan
        o['opa_pos_inf'] = self.opa_pos_inf
        o['opb_pos_inf'] = self.opb_pos_inf
        o['opa_neg_inf'] = self.opa_neg_inf
        o['opb_neg_inf'] = self.opb_neg_inf
        o['opa_inf'] = self.opa_inf
        o['opb_inf'] = self.opb_inf
        o['nan_input'] = self.nan_input
        o['snan_input'] = self.snan_input
        o['a_nan'] = self.a_nan
        o['div_by_0'] = self.div_by_0
        o['div_0_by_0'] = self.div_0_by_0
        o['div_inf_by_inf'] = self.div_inf_by_inf
        o['div_by_inf'] = self.div_by_inf
        o['mul_0_by_inf'] = self.mul_0_by_inf
        o['mul_inf'] = self.mul_inf
        o['div_inf'] = self.div_inf
        o['add_inf'] = self.add_inf
        o['sub_inf'] = self.sub_inf
        o['addsub_inf_invalid'] = self.addsub_inf_invalid
        o['addsub_inf'] = self.addsub_inf
        o['out_inf_trigger'] = self.out_inf_trigger
        o['out_pos_inf'] = self.out_pos_inf
        o['out_neg_inf'] = self.out_neg_inf
        o['round_nearest'] = self.round_nearest
        o['round_to_zero'] = self.round_to_zero
        o['round_to_pos_inf'] = self.round_to_pos_inf
        o['round_to_neg_inf'] = self.round_to_neg_inf
        o['inf_round_down_trigger'] = self.inf_round_down_trigger
        o['mul_uf'] = self.mul_uf
        o['div_uf'] = self.div_uf
        o['underflow_trigger'] = self.underflow_trigger
        o['invalid_trigger'] = self.invalid_trigger
        o['overflow_trigger'] = self.overflow_trigger
        o['inexact_trigger'] = self.inexact_trigger
        o['except_trigger'] = self.except_trigger
        o['enable_trigger'] = self.enable_trigger
        o['nan_out_trigger'] = self.nan_out_trigger
        o['snan_trigger'] = self.snan_trigger
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1
        o['exp_2047'] = self.exp_2047
        o['exp_2046'] = self.exp_2046
        o['mantissa_max'] = self.mantissa_max
        o['nan_output_0'] = self.nan_output_0
        o['nan_output'] = self.nan_output
        o['inf_round_down'] = self.inf_round_down
        o['out_inf'] = self.out_inf
        o['out_0'] = self.out_0
        o['out_1'] = self.out_1
        o['out_2'] = self.out_2
        return o

    def _derive(self, i):
        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        normal = self.mask(i['in_except'], 64)
        exponent_in = self.mask(i['exponent_in'], 12)
        mantissa_in = self.mask(i['mantissa_in'], 2)
        fpu_op = self.mask(i['fpu_op'], 3)
        rmode = self.mask(i['rmode'], 2)
        fraction_mask = (1 << 52) - 1
        magnitude_mask = (1 << 63) - 1

        opa_exp = (opa >> 52) & 0x7ff
        opb_exp = (opb >> 52) & 0x7ff
        opa_frac = opa & fraction_mask
        opb_frac = opb & fraction_mask
        opa_zero = (opa & magnitude_mask) == 0
        opb_zero = (opb & magnitude_mask) == 0
        opa_inf = opa_exp == 0x7ff and opa_frac == 0
        opb_inf = opb_exp == 0x7ff and opb_frac == 0
        opa_nan = opa_exp == 0x7ff and opa_frac != 0
        opb_nan = opb_exp == 0x7ff and opb_frac != 0
        opa_qnan = opa_nan and bool(opa_frac & (1 << 51))
        opb_qnan = opb_nan and bool(opb_frac & (1 << 51))
        opa_snan = opa_nan and not bool(opa_frac & (1 << 51))
        opb_snan = opb_nan and not bool(opb_frac & (1 << 51))
        nan_input = opa_nan or opb_nan
        snan_input = opa_snan or opb_snan

        add = fpu_op == 0
        subtract = fpu_op == 1
        multiply = fpu_op == 2
        divide = fpu_op == 3
        opa_pos_inf = opa_inf and not bool(opa >> 63)
        opb_pos_inf = opb_inf and not bool(opb >> 63)
        opa_neg_inf = opa_inf and bool(opa >> 63)
        opb_neg_inf = opb_inf and bool(opb >> 63)
        addsub_inf_invalid = (
            (add and opa_inf and opb_inf and (bool(opa >> 63) != bool(opb >> 63)))
            or (subtract and opa_inf and opb_inf and (bool(opa >> 63) == bool(opb >> 63)))
        )
        add_inf = add and (opa_inf or opb_inf) and not addsub_inf_invalid and not nan_input
        sub_inf = subtract and (opa_inf or opb_inf) and not addsub_inf_invalid and not nan_input
        addsub_inf = add_inf or sub_inf
        mul_0_by_inf = multiply and ((opa_zero and opb_inf) or (opb_zero and opa_inf))
        mul_inf = multiply and (opa_inf or opb_inf) and not mul_0_by_inf and not nan_input
        div_0_by_0 = divide and opa_zero and opb_zero
        div_inf_by_inf = divide and opa_inf and opb_inf
        div_by_inf = divide and opb_inf
        div_by_0 = divide and opb_zero and not opa_zero and not opa_inf and not opa_nan
        div_inf = divide and opa_inf and not opb_inf and not nan_input

        out_inf_trigger = bool(addsub_inf or mul_inf or div_inf or div_by_0 or exponent_in > 2046)
        sign = (normal >> 63) & 1
        out_pos_inf = out_inf_trigger and sign == 0
        out_neg_inf = out_inf_trigger and sign == 1
        round_nearest = rmode == 0
        round_to_zero = rmode == 1
        round_to_pos_inf = rmode == 2
        round_to_neg_inf = rmode == 3
        inf_round_down_trigger = out_inf_trigger and (
            (out_pos_inf and (round_to_zero or round_to_neg_inf))
            or (out_neg_inf and (round_to_zero or round_to_pos_inf))
        )

        input_zero = (normal & magnitude_mask) == 0
        mul_uf = multiply and not opa_zero and not opb_zero and input_zero
        finite_div_by_inf = div_by_inf and not opa_inf and not opa_nan
        div_uf = divide and (
            finite_div_by_inf or (not opa_zero and not opb_zero and input_zero)
        )
        underflow_trigger = bool(mul_uf or div_uf)
        invalid_trigger = bool(
            snan_input or addsub_inf_invalid or mul_0_by_inf
            or div_0_by_0 or div_inf_by_inf
        )
        overflow_trigger = out_inf_trigger and not nan_input
        inexact_trigger = (
            (mantissa_in != 0 or out_inf_trigger or underflow_trigger)
            and not nan_input
        )
        except_trigger = bool(
            invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger
        )
        nan_out_trigger = bool(nan_input or invalid_trigger)
        enable_trigger = bool(
            nan_out_trigger or out_inf_trigger or underflow_trigger or inexact_trigger
        )

        if nan_input:
            selected_fraction = opa_frac if opa_nan else opb_frac
        else:
            selected_fraction = opa_frac
        nan_fraction = (selected_fraction | (1 << 51)) & fraction_mask
        nan_magnitude = (0x7ff << 52) | nan_fraction
        infinity_magnitude = 0x7ff << 52
        max_finite_magnitude = (0x7fe << 52) | fraction_mask
        signed_zero = sign << 63

        out_0 = signed_zero if underflow_trigger else normal
        if out_inf_trigger:
            out_1 = signed_zero | (
                max_finite_magnitude if inf_round_down_trigger else infinity_magnitude
            )
        else:
            out_1 = out_0
        out_2 = (signed_zero | nan_magnitude) if nan_out_trigger else out_1

        return {
            'in_et_zero': int(input_zero), 'input_et_zero': int(input_zero),
            'opa_et_zero': int(opa_zero), 'opb_et_zero': int(opb_zero),
            'add': int(add), 'subtract': int(subtract),
            'multiply': int(multiply), 'divide': int(divide),
            'opa_qnan': int(opa_qnan), 'opb_qnan': int(opb_qnan),
            'opa_snan': int(opa_snan), 'opb_snan': int(opb_snan),
            'opa_pos_inf': int(opa_pos_inf), 'opb_pos_inf': int(opb_pos_inf),
            'opa_neg_inf': int(opa_neg_inf), 'opb_neg_inf': int(opb_neg_inf),
            'opa_inf': int(opa_inf), 'opb_inf': int(opb_inf),
            'nan_input': int(nan_input), 'snan_input': int(snan_input),
            'a_nan': int(opa_nan), 'div_by_0': int(div_by_0),
            'div_0_by_0': int(div_0_by_0), 'div_inf_by_inf': int(div_inf_by_inf),
            'div_by_inf': int(div_by_inf), 'mul_0_by_inf': int(mul_0_by_inf),
            'mul_inf': int(mul_inf), 'div_inf': int(div_inf),
            'add_inf': int(add_inf), 'sub_inf': int(sub_inf),
            'addsub_inf_invalid': int(addsub_inf_invalid), 'addsub_inf': int(addsub_inf),
            'out_inf_trigger': int(out_inf_trigger),
            'out_pos_inf': int(out_pos_inf), 'out_neg_inf': int(out_neg_inf),
            'round_nearest': int(round_nearest), 'round_to_zero': int(round_to_zero),
            'round_to_pos_inf': int(round_to_pos_inf),
            'round_to_neg_inf': int(round_to_neg_inf),
            'inf_round_down_trigger': int(inf_round_down_trigger),
            'mul_uf': int(mul_uf), 'div_uf': int(div_uf),
            'underflow_trigger': int(underflow_trigger),
            'invalid_trigger': int(invalid_trigger),
            'overflow_trigger': int(overflow_trigger),
            'inexact_trigger': int(inexact_trigger), 'except_trigger': int(except_trigger),
            'enable_trigger': int(enable_trigger), 'nan_out_trigger': int(nan_out_trigger),
            'snan_trigger': int(snan_input),
            'nan_output_0': self.mask(nan_magnitude, 63),
            'nan_output': self.mask(nan_magnitude, 63),
            'inf_round_down': self.mask(max_finite_magnitude if inf_round_down_trigger else 0, 63),
            'out_inf': self.mask(infinity_magnitude if out_inf_trigger else 0, 63),
            'out_0': self.mask(out_0, 64), 'out_1': self.mask(out_1, 64),
            'out_2': self.mask(out_2, 64),
            'out': self.mask(out_2, 64),
            'underflow': int(underflow_trigger), 'overflow': int(overflow_trigger),
            'inexact': int(inexact_trigger), 'invalid': int(invalid_trigger),
            'exception': int(except_trigger), 'ex_enable': int(enable_trigger)
        }

    def advance(self, i):
        if i['rst']:
            self.reset()
        elif i['enable']:
            d = self._derive(i)
            for name in (
                'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
                'add', 'subtract', 'multiply', 'divide',
                'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
                'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
                'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
                'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
                'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
                'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
                'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
                'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
                'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
                'overflow_trigger', 'inexact_trigger', 'except_trigger',
                'enable_trigger', 'nan_out_trigger', 'snan_trigger',
                'nan_output_0', 'nan_output', 'inf_round_down', 'out_inf',
                'out_0', 'out_1', 'out_2', 'out', 'ex_enable', 'underflow',
                'overflow', 'inexact', 'exception', 'invalid'
            ):
                setattr(self, name, d[name])
