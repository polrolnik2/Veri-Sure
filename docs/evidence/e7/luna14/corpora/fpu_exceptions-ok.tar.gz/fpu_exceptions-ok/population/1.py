"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        self._BOOLEAN_PROBES = (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan',
            'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf',
            'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input',
            'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf',
            'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf',
            'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger'
        )
        self._VALUE_PROBES = (
            'nan_output_0', 'nan_output', 'inf_round_down', 'out_inf',
            'out_0', 'out_1', 'out_2'
        )
        self._regs = dict.fromkeys(tuple(self.OUTPUT_PORTS) + self._BOOLEAN_PROBES + self._VALUE_PROBES, 0)
        for name in self._BOOLEAN_PROBES:
            setattr(self, name, False)
        for name in self._VALUE_PROBES:
            setattr(self, name, 0)
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1

    def _logic(self, i):
        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        candidate = self.mask(i['in_except'], 64)
        exponent = self.mask(i['exponent_in'], 12)
        mantissa = self.mask(i['mantissa_in'], 2)
        op = self.mask(i['fpu_op'], 3)
        mode = self.mask(i['rmode'], 2)

        frac_mask = (1 << 52) - 1
        quiet_bit = 1 << 51
        abs_mask = (1 << 63) - 1
        opa_frac = opa & frac_mask
        opb_frac = opb & frac_mask
        opa_exp = (opa >> 52) & 0x7ff
        opb_exp = (opb >> 52) & 0x7ff

        opa_zero = (opa & abs_mask) == 0
        opb_zero = (opb & abs_mask) == 0
        candidate_zero = (candidate & abs_mask) == 0

        opa_nan = opa_exp == 0x7ff and opa_frac != 0
        opb_nan = opb_exp == 0x7ff and opb_frac != 0
        opa_qnan = opa_nan and bool(opa_frac & quiet_bit)
        opb_qnan = opb_nan and bool(opb_frac & quiet_bit)
        opa_snan = opa_nan and not bool(opa_frac & quiet_bit)
        opb_snan = opb_nan and not bool(opb_frac & quiet_bit)
        opa_inf = opa_exp == 0x7ff and opa_frac == 0
        opb_inf = opb_exp == 0x7ff and opb_frac == 0
        opa_pos_inf = opa_inf and not bool(opa >> 63)
        opb_pos_inf = opb_inf and not bool(opb >> 63)
        opa_neg_inf = opa_inf and bool(opa >> 63)
        opb_neg_inf = opb_inf and bool(opb >> 63)
        nan_input = opa_nan or opb_nan
        snan_input = opa_snan or opb_snan

        add = op == 0
        subtract = op == 1
        multiply = op == 2
        divide = op == 3

        add_invalid = add and ((opa_pos_inf and opb_neg_inf) or (opa_neg_inf and opb_pos_inf))
        sub_invalid = subtract and ((opa_pos_inf and opb_pos_inf) or (opa_neg_inf and opb_neg_inf))
        addsub_inf_invalid = add_invalid or sub_invalid
        add_inf = add and (opa_inf or opb_inf) and not add_invalid
        sub_inf = subtract and (opa_inf or opb_inf) and not sub_invalid
        addsub_inf = add_inf or sub_inf

        div_0_by_0 = divide and opa_zero and opb_zero
        div_inf_by_inf = divide and opa_inf and opb_inf
        div_by_0 = divide and opb_zero and not opa_zero and not opa_nan
        div_by_inf = divide and opb_inf
        mul_0_by_inf = multiply and ((opa_zero and opb_inf) or (opb_zero and opa_inf))
        mul_inf = multiply and (opa_inf or opb_inf) and not mul_0_by_inf
        div_inf = divide and ((opa_inf and not opb_inf) or div_by_0)

        invalid_trigger = bool(snan_input or addsub_inf_invalid or mul_0_by_inf or div_0_by_0 or div_inf_by_inf)
        nan_out_trigger = nan_input or invalid_trigger
        out_inf_trigger = bool(mul_inf or div_inf or addsub_inf or div_by_0 or exponent > 2046)

        sign = (candidate >> 63) & 1
        out_pos_inf = out_inf_trigger and sign == 0
        out_neg_inf = out_inf_trigger and sign == 1
        round_nearest = mode == 0
        round_to_zero = mode == 1
        round_to_pos_inf = mode == 2
        round_to_neg_inf = mode == 3
        inf_round_down_trigger = out_inf_trigger and (
            (out_pos_inf and (round_to_zero or round_to_neg_inf)) or
            (out_neg_inf and (round_to_zero or round_to_pos_inf))
        )

        finite_a = not opa_nan and not opa_inf
        finite_b = not opb_nan and not opb_inf
        mul_uf = bool(multiply and not opa_zero and not opb_zero and candidate_zero and finite_a and finite_b)
        div_uf = bool(divide and not opa_zero and not opb_zero and candidate_zero and finite_a and finite_b)
        div_inf_underflow = bool(div_by_inf and finite_a)
        underflow_trigger = mul_uf or div_uf or div_inf_underflow

        overflow_trigger = out_inf_trigger and not nan_input
        inexact_trigger = bool((mantissa != 0 or out_inf_trigger or underflow_trigger) and not nan_input)
        except_trigger = bool(invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger)
        enable_trigger = bool(nan_out_trigger or out_inf_trigger or underflow_trigger or inexact_trigger)

        signed_zero = sign << 63
        out_0 = signed_zero if underflow_trigger else candidate
        infinity_magnitude = 2047 << 52
        maximum_magnitude = (2046 << 52) | frac_mask
        inf_round_down = maximum_magnitude if inf_round_down_trigger else 0
        out_inf = infinity_magnitude if out_inf_trigger else 0
        if out_inf_trigger:
            magnitude = maximum_magnitude if inf_round_down_trigger else infinity_magnitude
            out_1 = (sign << 63) | magnitude
        else:
            out_1 = out_0

        if nan_input:
            payload = opa_frac if opa_nan else opb_frac
        else:
            payload = opa_frac
        payload |= quiet_bit
        nan_low = (2047 << 52) | payload
        nan_output = nan_low if nan_out_trigger else 0
        nan_output_0 = nan_output
        nan_result = (sign << 63) | nan_low
        out_2 = nan_result if nan_out_trigger else out_1

        return {
            'in_et_zero': bool(candidate_zero),
            'opa_et_zero': bool(opa_zero),
            'opb_et_zero': bool(opb_zero),
            'input_et_zero': bool(candidate_zero),
            'add': bool(add),
            'subtract': bool(subtract),
            'multiply': bool(multiply),
            'divide': bool(divide),
            'opa_qnan': bool(opa_qnan),
            'opb_qnan': bool(opb_qnan),
            'opa_snan': bool(opa_snan),
            'opb_snan': bool(opb_snan),
            'opa_pos_inf': bool(opa_pos_inf),
            'opb_pos_inf': bool(opb_pos_inf),
            'opa_neg_inf': bool(opa_neg_inf),
            'opb_neg_inf': bool(opb_neg_inf),
            'opa_inf': bool(opa_inf),
            'opb_inf': bool(opb_inf),
            'nan_input': bool(nan_input),
            'snan_input': bool(snan_input),
            'a_nan': bool(opa_nan),
            'div_by_0': bool(div_by_0),
            'div_0_by_0': bool(div_0_by_0),
            'div_inf_by_inf': bool(div_inf_by_inf),
            'div_by_inf': bool(div_by_inf),
            'mul_0_by_inf': bool(mul_0_by_inf),
            'mul_inf': bool(mul_inf),
            'div_inf': bool(div_inf),
            'add_inf': bool(add_inf),
            'sub_inf': bool(sub_inf),
            'addsub_inf_invalid': bool(addsub_inf_invalid),
            'addsub_inf': bool(addsub_inf),
            'out_inf_trigger': bool(out_inf_trigger),
            'out_pos_inf': bool(out_pos_inf),
            'out_neg_inf': bool(out_neg_inf),
            'round_nearest': bool(round_nearest),
            'round_to_zero': bool(round_to_zero),
            'round_to_pos_inf': bool(round_to_pos_inf),
            'round_to_neg_inf': bool(round_to_neg_inf),
            'inf_round_down_trigger': bool(inf_round_down_trigger),
            'mul_uf': bool(mul_uf),
            'div_uf': bool(div_uf),
            'underflow_trigger': bool(underflow_trigger),
            'invalid_trigger': bool(invalid_trigger),
            'overflow_trigger': bool(overflow_trigger),
            'inexact_trigger': bool(inexact_trigger),
            'except_trigger': bool(except_trigger),
            'enable_trigger': bool(enable_trigger),
            'nan_out_trigger': bool(nan_out_trigger),
            'snan_trigger': bool(snan_input),
            'nan_output_0': self.mask(nan_output_0, 63),
            'nan_output': self.mask(nan_output, 63),
            'inf_round_down': self.mask(inf_round_down, 63),
            'out_inf': self.mask(out_inf, 63),
            'out_0': self.mask(out_0, 64),
            'out_1': self.mask(out_1, 64),
            'out_2': self.mask(out_2, 64),
            'out': self.mask(out_2, 64),
            'ex_enable': int(enable_trigger),
            'underflow': int(underflow_trigger),
            'overflow': int(overflow_trigger),
            'inexact': int(inexact_trigger),
            'exception': int(except_trigger),
            'invalid': int(invalid_trigger),
        }

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        for name in self._BOOLEAN_PROBES:
            setattr(self, name, bool(self._regs[name]))
        for name in self._VALUE_PROBES:
            setattr(self, name, self._regs[name])
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1
        o['out'] = self.mask(self._regs['out'], 64)
        o['ex_enable'] = self.mask(self._regs['ex_enable'], 1)
        o['underflow'] = self.mask(self._regs['underflow'], 1)
        o['overflow'] = self.mask(self._regs['overflow'], 1)
        o['inexact'] = self.mask(self._regs['inexact'], 1)
        o['exception'] = self.mask(self._regs['exception'], 1)
        o['invalid'] = self.mask(self._regs['invalid'], 1)
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
        elif i['enable']:
            self._regs = self._logic(i)
