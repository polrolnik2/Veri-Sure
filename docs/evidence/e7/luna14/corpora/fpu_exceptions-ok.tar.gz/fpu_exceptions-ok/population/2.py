"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        self._probe_names = (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan',
            'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf',
            'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input',
            'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf',
            'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf',
            'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047',
            'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max',
            'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2'
        )
        self._p = {name: 0 for name in self._probe_names}
        self._p['exp_2047'] = 2047
        self._p['exp_2046'] = 2046
        self._p['mantissa_max'] = (1 << 52) - 1
        self.out = 0
        self.ex_enable = 0
        self.underflow = 0
        self.overflow = 0
        self.inexact = 0
        self.exception = 0
        self.invalid = 0


    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        for name in self._probe_names:
            setattr(self, name, self._p[name])
        o['out'] = self.out
        o['ex_enable'] = self.ex_enable
        o['underflow'] = self.underflow
        o['overflow'] = self.overflow
        o['inexact'] = self.inexact
        o['exception'] = self.exception
        o['invalid'] = self.invalid
        return o


    def _compute(self, i):
        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        result = self.mask(i['in_except'], 64)
        exponent = self.mask(i['exponent_in'], 12)
        mantissa = self.mask(i['mantissa_in'], 2)
        op = self.mask(i['fpu_op'], 3)
        mode = self.mask(i['rmode'], 2)

        sign_a = (opa >> 63) & 1
        sign_b = (opb >> 63) & 1
        result_sign = (result >> 63) & 1
        frac_mask = (1 << 52) - 1
        magnitude_mask = (1 << 63) - 1
        exp_a = (opa >> 52) & 0x7ff
        exp_b = (opb >> 52) & 0x7ff
        frac_a = opa & frac_mask
        frac_b = opb & frac_mask

        az = int((opa & magnitude_mask) == 0)
        bz = int((opb & magnitude_mask) == 0)
        rz = int((result & magnitude_mask) == 0)
        a_nan = int(exp_a == 2047 and frac_a != 0)
        b_nan = int(exp_b == 2047 and frac_b != 0)
        aq = int(a_nan and ((frac_a >> 51) & 1))
        bq = int(b_nan and ((frac_b >> 51) & 1))
        ass = int(a_nan and not ((frac_a >> 51) & 1))
        bss = int(b_nan and not ((frac_b >> 51) & 1))
        ai = int(exp_a == 2047 and frac_a == 0)
        bi = int(exp_b == 2047 and frac_b == 0)
        ap = int(ai and not sign_a)
        bp = int(bi and not sign_b)
        an = int(ai and sign_a)
        bn = int(bi and sign_b)

        add = int(op == 0)
        sub = int(op == 1)
        mul = int(op == 2)
        div = int(op == 3)
        nan_input = int(a_nan or b_nan)
        snan_input = int(ass or bss)

        div_00 = int(div and az and bz)
        div_ii = int(div and ai and bi)
        div_by_0 = int(div and bz and not az)
        div_by_inf = int(div and bi)
        mul_0_inf = int(mul and ((az and bi) or (ai and bz)))

        add_invalid = int(add and ((ap and bn) or (an and bp)))
        sub_invalid = int(sub and ((ap and bp) or (an and bn)))
        addsub_invalid = int(add_invalid or sub_invalid)
        invalid = int(snan_input or addsub_invalid or mul_0_inf or div_00 or div_ii)

        add_inf = int(add and (ai or bi) and not add_invalid)
        sub_inf = int(sub and (ai or bi) and not sub_invalid)
        addsub_inf = int(add_inf or sub_inf)
        mul_inf = int(mul and (ai or bi) and not mul_0_inf)
        div_inf = int(div and ai and not bi)

        out_inf_trigger = int(add_inf or sub_inf or mul_inf or div_inf or div_by_0 or exponent > 2046)
        overflow = int(out_inf_trigger and not nan_input)

        finite_a = not (ai or a_nan)
        finite_b = not (bi or b_nan)
        mul_uf = int(mul and not az and not bz and rz and finite_a and finite_b)
        div_uf_by_inf = int(div_by_inf and finite_a)
        div_uf_zero_result = int(div and not az and not bz and rz and finite_a and finite_b)
        div_uf = int(div_uf_by_inf or div_uf_zero_result)
        underflow = int((mul_uf or div_uf) and not nan_input)

        inexact = int(((mantissa != 0) or out_inf_trigger or underflow) and not nan_input)
        exception = int(invalid or overflow or underflow or inexact)
        nan_out = int(nan_input or invalid)
        ex_enable = int(nan_out or exception)

        sign_bit = result_sign << 63
        infinity_magnitude = 2047 << 52
        max_finite_magnitude = (2046 << 52) | frac_mask
        round_down = int(
            out_inf_trigger and (
                (not result_sign and mode in (1, 3)) or
                (result_sign and mode in (1, 2))
            )
        )
        out_inf_value = sign_bit | infinity_magnitude
        out_0 = (sign_bit if underflow else result)
        out_1 = out_0
        if out_inf_trigger:
            out_1 = sign_bit | (max_finite_magnitude if round_down else infinity_magnitude)

        if nan_input:
            selected_fraction = frac_a if a_nan else frac_b
        else:
            selected_fraction = frac_a
        nan_magnitude = (2047 << 52) | (selected_fraction | (1 << 51))
        nan_value = sign_bit | nan_magnitude
        out_2 = nan_value if nan_out else out_1

        p = {name: 0 for name in self._probe_names}
        p.update({
            'in_et_zero': rz,
            'opa_et_zero': az,
            'opb_et_zero': bz,
            'input_et_zero': int(az or bz),
            'add': add,
            'subtract': sub,
            'multiply': mul,
            'divide': div,
            'opa_qnan': aq,
            'opb_qnan': bq,
            'opa_snan': ass,
            'opb_snan': bss,
            'opa_pos_inf': ap,
            'opb_pos_inf': bp,
            'opa_neg_inf': an,
            'opb_neg_inf': bn,
            'opa_inf': ai,
            'opb_inf': bi,
            'nan_input': nan_input,
            'snan_input': snan_input,
            'a_nan': a_nan,
            'div_by_0': div_by_0,
            'div_0_by_0': div_00,
            'div_inf_by_inf': div_ii,
            'div_by_inf': div_by_inf,
            'mul_0_by_inf': mul_0_inf,
            'mul_inf': mul_inf,
            'div_inf': div_inf,
            'add_inf': add_inf,
            'sub_inf': sub_inf,
            'addsub_inf_invalid': addsub_invalid,
            'addsub_inf': addsub_inf,
            'out_inf_trigger': out_inf_trigger,
            'out_pos_inf': int(out_inf_trigger and not result_sign),
            'out_neg_inf': int(out_inf_trigger and result_sign),
            'round_nearest': int(mode == 0),
            'round_to_zero': int(mode == 1),
            'round_to_pos_inf': int(mode == 2),
            'round_to_neg_inf': int(mode == 3),
            'inf_round_down_trigger': round_down,
            'mul_uf': mul_uf,
            'div_uf': div_uf,
            'underflow_trigger': underflow,
            'invalid_trigger': invalid,
            'overflow_trigger': overflow,
            'inexact_trigger': inexact,
            'except_trigger': exception,
            'enable_trigger': ex_enable,
            'nan_out_trigger': nan_out,
            'snan_trigger': snan_input,
            'exp_2047': 2047,
            'exp_2046': 2046,
            'nan_output_0': nan_magnitude if nan_out else 0,
            'nan_output': nan_magnitude if nan_out else 0,
            'mantissa_max': frac_mask,
            'inf_round_down': max_finite_magnitude,
            'out_inf': infinity_magnitude,
            'out_0': self.mask(out_0, 64),
            'out_1': self.mask(out_1, 64),
            'out_2': self.mask(out_2, 64)
        })
        return {
            'p': p,
            'out': self.mask(out_2, 64),
            'ex_enable': ex_enable,
            'underflow': underflow,
            'overflow': overflow,
            'inexact': inexact,
            'exception': exception,
            'invalid': invalid
        }


    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not i['enable']:
            return
        d = self._compute(i)
        self._p = d['p']
        self.out = d['out']
        self.ex_enable = d['ex_enable']
        self.underflow = d['underflow']
        self.overflow = d['overflow']
        self.inexact = d['inexact']
        self.exception = d['exception']
        self.invalid = d['invalid']
