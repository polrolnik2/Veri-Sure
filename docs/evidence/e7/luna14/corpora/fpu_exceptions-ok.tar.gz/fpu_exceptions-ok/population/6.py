"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        self.out = 0
        self.ex_enable = 0
        self.underflow = 0
        self.overflow = 0
        self.inexact = 0
        self.exception = 0
        self.invalid = 0
        self._probe_state = {name: 0 for name in (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger',
            'nan_output_0', 'nan_output', 'inf_round_down', 'out_inf',
            'out_0', 'out_1', 'out_2'
        )}

    def _compute(self, i):
        a = self.mask(i['opa'], 64)
        b = self.mask(i['opb'], 64)
        candidate = self.mask(i['in_except'], 64)
        exponent_in = self.mask(i['exponent_in'], 12)
        mantissa_in = self.mask(i['mantissa_in'], 2)
        op = self.mask(i['fpu_op'], 3)
        mode = self.mask(i['rmode'], 2)

        frac_mask = (1 << 52) - 1
        low63_mask = (1 << 63) - 1
        sign_mask = 1 << 63
        a_exp = (a >> 52) & 0x7ff
        b_exp = (b >> 52) & 0x7ff
        a_frac = a & frac_mask
        b_frac = b & frac_mask
        a_zero = (a & low63_mask) == 0
        b_zero = (b & low63_mask) == 0
        candidate_zero = (candidate & low63_mask) == 0

        a_nan = a_exp == 0x7ff and a_frac != 0
        b_nan = b_exp == 0x7ff and b_frac != 0
        a_qnan = a_nan and bool(a_frac & (1 << 51))
        b_qnan = b_nan and bool(b_frac & (1 << 51))
        a_snan = a_nan and not a_qnan
        b_snan = b_nan and not b_qnan
        a_inf = a_exp == 0x7ff and a_frac == 0
        b_inf = b_exp == 0x7ff and b_frac == 0
        a_sign = (a >> 63) & 1
        b_sign = (b >> 63) & 1
        candidate_sign = (candidate >> 63) & 1

        add = op == 0
        subtract = op == 1
        multiply = op == 2
        divide = op == 3
        nan_input = a_nan or b_nan
        snan_input = a_snan or b_snan

        div_0_by_0 = divide and a_zero and b_zero
        div_inf_by_inf = divide and a_inf and b_inf
        div_by_0 = divide and b_zero and not a_zero
        div_by_inf = divide and b_inf

        mul_0_by_inf = multiply and ((a_zero and b_inf) or (b_zero and a_inf))
        mul_inf = multiply and (a_inf or b_inf) and not mul_0_by_inf
        div_inf = divide and ((a_inf and not b_inf) or div_by_0)

        add_invalid = add and ((a_sign == 0 and b_sign == 1 and a_inf and b_inf) or
                               (a_sign == 1 and b_sign == 0 and a_inf and b_inf))
        sub_invalid = subtract and ((a_sign == 0 and b_sign == 0 and a_inf and b_inf) or
                                    (a_sign == 1 and b_sign == 1 and a_inf and b_inf))
        addsub_inf_invalid = add_invalid or sub_invalid
        addsub_inf = (add or subtract) and (a_inf or b_inf) and not addsub_inf_invalid
        add_inf = add and addsub_inf
        sub_inf = subtract and addsub_inf

        out_inf_trigger = bool(mul_inf or div_inf or add_inf or sub_inf or
                               div_by_0 or exponent_in > 2046)
        out_pos_inf = out_inf_trigger and candidate_sign == 0
        out_neg_inf = out_inf_trigger and candidate_sign == 1
        round_nearest = mode == 0
        round_to_zero = mode == 1
        round_to_pos_inf = mode == 2
        round_to_neg_inf = mode == 3
        inf_round_down_trigger = out_inf_trigger and (
            (candidate_sign == 0 and (round_to_zero or round_to_neg_inf)) or
            (candidate_sign == 1 and (round_to_zero or round_to_pos_inf))
        )

        a_finite = a_exp != 0x7ff
        b_finite = b_exp != 0x7ff
        mul_uf = multiply and candidate_zero and not a_zero and not b_zero and a_finite and b_finite
        div_uf = divide and (
            (b_inf and a_finite) or
            (candidate_zero and not a_zero and not b_zero and a_finite and b_finite)
        )
        underflow_trigger = bool(mul_uf or div_uf)
        invalid_trigger = bool(snan_input or addsub_inf_invalid or mul_0_by_inf or
                               div_0_by_0 or div_inf_by_inf)
        overflow_trigger = bool(out_inf_trigger and not nan_input)
        inexact_trigger = bool((mantissa_in != 0 or out_inf_trigger or underflow_trigger)
                               and not nan_input)
        except_trigger = bool(invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger)
        nan_out_trigger = bool(nan_input or invalid_trigger)

        max_finite = (2046 << 52) | frac_mask
        infinity_magnitude = 2047 << 52
        inf_round_down = max_finite
        out_inf = infinity_magnitude

        out_0 = candidate
        if underflow_trigger:
            out_0 = candidate_sign << 63
        out_1 = out_0
        if out_inf_trigger:
            magnitude = max_finite if inf_round_down_trigger else infinity_magnitude
            out_1 = (candidate_sign << 63) | magnitude

        if a_nan:
            payload = a_frac
        elif b_nan:
            payload = b_frac
        else:
            payload = a_frac
        payload = (payload | (1 << 51)) & frac_mask
        nan_lower = (2047 << 52) | payload
        nan_output_0 = nan_lower if nan_out_trigger else 0
        nan_output = nan_lower if nan_out_trigger else 0
        out_2 = out_1
        if nan_out_trigger:
            out_2 = (candidate_sign << 63) | nan_output
        final_out = self.mask(out_2, 64)

        probes = {
            'in_et_zero': int(candidate_zero),
            'opa_et_zero': int(a_zero),
            'opb_et_zero': int(b_zero),
            'input_et_zero': int(candidate_zero),
            'add': int(add),
            'subtract': int(subtract),
            'multiply': int(multiply),
            'divide': int(divide),
            'opa_qnan': int(a_qnan),
            'opb_qnan': int(b_qnan),
            'opa_snan': int(a_snan),
            'opb_snan': int(b_snan),
            'opa_pos_inf': int(a_inf and a_sign == 0),
            'opb_pos_inf': int(b_inf and b_sign == 0),
            'opa_neg_inf': int(a_inf and a_sign == 1),
            'opb_neg_inf': int(b_inf and b_sign == 1),
            'opa_inf': int(a_inf),
            'opb_inf': int(b_inf),
            'nan_input': int(nan_input),
            'snan_input': int(snan_input),
            'a_nan': int(a_nan),
            'div_by_0': int(div_by_0),
            'div_0_by_0': int(div_0_by_0),
            'div_inf_by_inf': int(div_inf_by_inf),
            'div_by_inf': int(div_by_inf),
            'mul_0_by_inf': int(mul_0_by_inf),
            'mul_inf': int(mul_inf),
            'div_inf': int(div_inf),
            'add_inf': int(add_inf),
            'sub_inf': int(sub_inf),
            'addsub_inf_invalid': int(addsub_inf_invalid),
            'addsub_inf': int(addsub_inf),
            'out_inf_trigger': int(out_inf_trigger),
            'out_pos_inf': int(out_pos_inf),
            'out_neg_inf': int(out_neg_inf),
            'round_nearest': int(round_nearest),
            'round_to_zero': int(round_to_zero),
            'round_to_pos_inf': int(round_to_pos_inf),
            'round_to_neg_inf': int(round_to_neg_inf),
            'inf_round_down_trigger': int(inf_round_down_trigger),
            'mul_uf': int(mul_uf),
            'div_uf': int(div_uf),
            'underflow_trigger': int(underflow_trigger),
            'invalid_trigger': int(invalid_trigger),
            'overflow_trigger': int(overflow_trigger),
            'inexact_trigger': int(inexact_trigger),
            'except_trigger': int(except_trigger),
            'enable_trigger': 1,
            'nan_out_trigger': int(nan_out_trigger),
            'snan_trigger': int(snan_input),
            'nan_output_0': self.mask(nan_output_0, 63),
            'nan_output': self.mask(nan_output, 63),
            'inf_round_down': self.mask(inf_round_down, 63),
            'out_inf': self.mask(out_inf, 63),
            'out_0': self.mask(out_0, 64),
            'out_1': self.mask(out_1, 64),
            'out_2': self.mask(out_2, 64)
        }
        return {
            'out': final_out,
            'ex_enable': int(nan_out_trigger or except_trigger),
            'underflow': int(underflow_trigger),
            'overflow': int(overflow_trigger),
            'inexact': int(inexact_trigger),
            'exception': int(except_trigger),
            'invalid': int(invalid_trigger),
            'probes': probes
        }

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self.out
        o['ex_enable'] = self.ex_enable
        o['underflow'] = self.underflow
        o['overflow'] = self.overflow
        o['inexact'] = self.inexact
        o['exception'] = self.exception
        o['invalid'] = self.invalid
        for name, value in self._probe_state.items():
            setattr(self, name, value)
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
        elif i['enable']:
            values = self._compute(i)
            self.out = self.mask(values['out'], 64)
            self.ex_enable = values['ex_enable']
            self.underflow = values['underflow']
            self.overflow = values['overflow']
            self.inexact = values['inexact']
            self.exception = values['exception']
            self.invalid = values['invalid']
            self._probe_state = values['probes']
