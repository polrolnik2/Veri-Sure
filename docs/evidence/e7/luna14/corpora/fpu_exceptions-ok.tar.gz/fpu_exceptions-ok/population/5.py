"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    _BOOLEAN_PROBES = (
        'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
        'add', 'subtract', 'multiply', 'divide',
        'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
        'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
        'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
        'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
        'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
        'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
        'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
        'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
        'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
        'overflow_trigger', 'inexact_trigger', 'except_trigger',
        'enable_trigger', 'nan_out_trigger', 'snan_trigger'
    )

    _VALUE_PROBES = (
        'nan_output_0', 'nan_output', 'inf_round_down', 'out_inf',
        'out_0', 'out_1', 'out_2'
    )

    def reset(self):
        self._probes = {name: False for name in self._BOOLEAN_PROBES}
        for name in self._VALUE_PROBES:
            self._probes[name] = 0
        for name, value in self._probes.items():
            setattr(self, name, value)
        self._out = 0
        self._ex_enable = 0
        self._underflow = 0
        self._overflow = 0
        self._inexact = 0
        self._exception = 0
        self._invalid = 0
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1

    def _no_requirement(self):
        return None

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self._out
        o['ex_enable'] = self._ex_enable
        o['underflow'] = self._underflow
        o['overflow'] = self._overflow
        o['inexact'] = self._inexact
        o['exception'] = self._exception
        o['invalid'] = self._invalid
        for name, value in self._probes.items():
            setattr(self, name, value)
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1
        return o

    def _compute(self, i):
        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        candidate = self.mask(i['in_except'], 64)
        exponent = self.mask(i['exponent_in'], 12)
        remainder = self.mask(i['mantissa_in'], 2)
        op = self.mask(i['fpu_op'], 3)
        mode = self.mask(i['rmode'], 2)

        sign_bit = (candidate >> 63) & 1
        sign = sign_bit << 63
        frac_mask = (1 << 52) - 1
        magnitude_mask = (1 << 63) - 1
        quiet_bit = 1 << 51

        a_exp = (opa >> 52) & 0x7ff
        b_exp = (opb >> 52) & 0x7ff
        a_frac = opa & frac_mask
        b_frac = opb & frac_mask
        a_zero = (opa & magnitude_mask) == 0
        b_zero = (opb & magnitude_mask) == 0
        result_zero = (candidate & magnitude_mask) == 0
        a_nan = a_exp == 0x7ff and a_frac != 0
        b_nan = b_exp == 0x7ff and b_frac != 0
        a_qnan = a_nan and bool(a_frac & quiet_bit)
        b_qnan = b_nan and bool(b_frac & quiet_bit)
        a_snan = a_nan and not bool(a_frac & quiet_bit)
        b_snan = b_nan and not bool(b_frac & quiet_bit)
        a_inf = a_exp == 0x7ff and a_frac == 0
        b_inf = b_exp == 0x7ff and b_frac == 0
        a_pos_inf = a_inf and not bool((opa >> 63) & 1)
        b_pos_inf = b_inf and not bool((opb >> 63) & 1)
        a_neg_inf = a_inf and bool((opa >> 63) & 1)
        b_neg_inf = b_inf and bool((opb >> 63) & 1)

        is_add = op == 0
        is_sub = op == 1
        is_mul = op == 2
        is_div = op == 3
        nan_input = a_nan or b_nan
        snan_input = a_snan or b_snan

        add_invalid = is_add and ((a_pos_inf and b_neg_inf) or (a_neg_inf and b_pos_inf))
        sub_invalid = is_sub and ((a_pos_inf and b_pos_inf) or (a_neg_inf and b_neg_inf))
        addsub_invalid = add_invalid or sub_invalid
        mul_zero_inf = is_mul and ((a_zero and b_inf) or (b_zero and a_inf))
        div_zero_zero = is_div and a_zero and b_zero
        div_inf_inf = is_div and a_inf and b_inf

        div_by_zero = is_div and b_zero and not a_zero and not a_inf and not nan_input
        div_by_inf = is_div and b_inf
        mul_inf = is_mul and (a_inf or b_inf) and not mul_zero_inf and not nan_input
        div_inf = is_div and a_inf and not b_inf and not nan_input
        add_inf = is_add and (a_inf or b_inf) and not add_invalid and not nan_input
        sub_inf = is_sub and (a_inf or b_inf) and not sub_invalid and not nan_input
        addsub_inf = add_inf or sub_inf

        out_inf_trigger = bool(
            mul_inf or div_inf or addsub_inf or div_by_zero or exponent > 2046
        )

        mul_uf = bool(
            is_mul and result_zero and not a_zero and not b_zero
            and not a_inf and not b_inf and not nan_input
        )
        div_uf_by_inf = is_div and b_inf and not a_inf and not nan_input
        div_uf_zero_result = bool(
            is_div and result_zero and not a_zero and not b_zero
            and not a_inf and not b_inf and not nan_input
        )
        div_uf = bool(div_uf_by_inf or div_uf_zero_result)
        underflow_trigger = bool(mul_uf or div_uf)

        invalid_trigger = bool(
            snan_input or addsub_invalid or mul_zero_inf or div_zero_zero or div_inf_inf
        )
        overflow_trigger = bool(out_inf_trigger and not nan_input)
        inexact_trigger = bool(
            (remainder != 0 or out_inf_trigger or underflow_trigger) and not nan_input
        )
        except_trigger = bool(
            invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger
        )
        nan_out_trigger = bool(nan_input or invalid_trigger)
        enable_trigger = bool(nan_out_trigger or except_trigger)

        round_nearest = mode == 0
        round_to_zero = mode == 1
        round_to_pos_inf = mode == 2
        round_to_neg_inf = mode == 3
        out_pos_inf = out_inf_trigger and sign_bit == 0
        out_neg_inf = out_inf_trigger and sign_bit == 1
        round_down = bool(
            (out_pos_inf and (round_to_zero or round_to_neg_inf))
            or (out_neg_inf and (round_to_zero or round_to_pos_inf))
        )

        infinity_magnitude = 0x7ff << 52
        max_finite_magnitude = (0x7fe << 52) | frac_mask
        out_inf_value = infinity_magnitude if out_inf_trigger else 0
        inf_round_down = max_finite_magnitude if round_down else 0

        out_0 = sign if underflow_trigger else candidate
        out_1 = out_0
        if out_inf_trigger:
            out_1 = sign | (max_finite_magnitude if round_down else infinity_magnitude)

        if nan_input:
            nan_fraction = a_frac if a_nan else b_frac
        else:
            nan_fraction = a_frac
        nan_fraction = (nan_fraction | quiet_bit) & frac_mask
        nan_magnitude = (0x7ff << 52) | nan_fraction
        nan_output = nan_magnitude if nan_out_trigger else 0
        nan_result = sign | nan_output if nan_out_trigger else out_1
        out_2 = self.mask(nan_result, 64)

        p = {
            'in_et_zero': bool(result_zero),
            'opa_et_zero': bool(a_zero),
            'opb_et_zero': bool(b_zero),
            'input_et_zero': bool(a_zero or b_zero),
            'add': bool(is_add),
            'subtract': bool(is_sub),
            'multiply': bool(is_mul),
            'divide': bool(is_div),
            'opa_qnan': bool(a_qnan),
            'opb_qnan': bool(b_qnan),
            'opa_snan': bool(a_snan),
            'opb_snan': bool(b_snan),
            'opa_pos_inf': bool(a_pos_inf),
            'opb_pos_inf': bool(b_pos_inf),
            'opa_neg_inf': bool(a_neg_inf),
            'opb_neg_inf': bool(b_neg_inf),
            'opa_inf': bool(a_inf),
            'opb_inf': bool(b_inf),
            'nan_input': bool(nan_input),
            'snan_input': bool(snan_input),
            'a_nan': bool(a_nan),
            'div_by_0': bool(div_by_zero),
            'div_0_by_0': bool(div_zero_zero),
            'div_inf_by_inf': bool(div_inf_inf),
            'div_by_inf': bool(div_by_inf),
            'mul_0_by_inf': bool(mul_zero_inf),
            'mul_inf': bool(mul_inf),
            'div_inf': bool(div_inf),
            'add_inf': bool(add_inf),
            'sub_inf': bool(sub_inf),
            'addsub_inf_invalid': bool(addsub_invalid),
            'addsub_inf': bool(addsub_inf),
            'out_inf_trigger': bool(out_inf_trigger),
            'out_pos_inf': bool(out_pos_inf),
            'out_neg_inf': bool(out_neg_inf),
            'round_nearest': bool(round_nearest),
            'round_to_zero': bool(round_to_zero),
            'round_to_pos_inf': bool(round_to_pos_inf),
            'round_to_neg_inf': bool(round_to_neg_inf),
            'inf_round_down_trigger': bool(round_down),
            'mul_uf': bool(mul_uf),
            'div_uf': bool(div_uf),
            'underflow_trigger': bool(underflow_trigger),
            'invalid_trigger': bool(invalid_trigger),
            'overflow_trigger': bool(overflow_trigger),
            'inexact_trigger': bool(inexact_trigger),
            'except_trigger': bool(except_trigger),
            'enable_trigger': bool(enable_trigger),
            'nan_out_trigger': bool(nan_out_trigger),
            'snan_trigger': bool(snan_input),
            'nan_output_0': self.mask(nan_output, 63),
            'nan_output': self.mask(nan_output, 63),
            'inf_round_down': self.mask(inf_round_down, 63),
            'out_inf': self.mask(out_inf_value, 63),
            'out_0': self.mask(out_0, 64),
            'out_1': self.mask(out_1, 64),
            'out_2': self.mask(out_2, 64)
        }
        return {
            'probes': p,
            'out': self.mask(out_2, 64),
            'ex_enable': int(enable_trigger),
            'underflow': int(underflow_trigger),
            'overflow': int(overflow_trigger),
            'inexact': int(inexact_trigger),
            'exception': int(except_trigger),
            'invalid': int(invalid_trigger)
        }

    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not i['enable']:
            return
        result = self._compute(i)
        self._probes = result['probes']
        for name, value in self._probes.items():
            setattr(self, name, value)
        self._out = result['out']
        self._ex_enable = result['ex_enable']
        self._underflow = result['underflow']
        self._overflow = result['overflow']
        self._inexact = result['inexact']
        self._exception = result['exception']
        self._invalid = result['invalid']
