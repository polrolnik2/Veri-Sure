"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        self._registered_outputs = {
            'out': 0,
            'ex_enable': 0,
            'underflow': 0,
            'overflow': 0,
            'inexact': 0,
            'exception': 0,
            'invalid': 0,
        }
        boolean_probes = (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger',
        )
        self._probe_values = {name: False for name in boolean_probes}
        self._probe_values.update({
            'exp_2047': 2047,
            'exp_2046': 2046,
            'nan_output_0': 0,
            'nan_output': 0,
            'mantissa_max': (1 << 52) - 1,
            'inf_round_down': 0,
            'out_inf': 0,
            'out_0': 0,
            'out_1': 0,
            'out_2': 0,
        })

    def _documentary_noop(self):
        return None

    def _calculate(self, i):
        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        candidate = self.mask(i['in_except'], 64)
        exponent_in = self.mask(i['exponent_in'], 12)
        mantissa_in = self.mask(i['mantissa_in'], 2)
        fpu_op = self.mask(i['fpu_op'], 3)
        rmode = self.mask(i['rmode'], 2)

        fraction_mask = (1 << 52) - 1
        magnitude_mask = (1 << 63) - 1
        a_exp = (opa >> 52) & 0x7ff
        b_exp = (opb >> 52) & 0x7ff
        a_fraction = opa & fraction_mask
        b_fraction = opb & fraction_mask
        a_sign = (opa >> 63) & 1
        b_sign = (opb >> 63) & 1
        result_sign = (candidate >> 63) & 1

        a_zero = (opa & magnitude_mask) == 0
        b_zero = (opb & magnitude_mask) == 0
        result_zero = (candidate & magnitude_mask) == 0
        a_nan = a_exp == 0x7ff and a_fraction != 0
        b_nan = b_exp == 0x7ff and b_fraction != 0
        a_qnan = a_nan and bool(a_fraction & (1 << 51))
        b_qnan = b_nan and bool(b_fraction & (1 << 51))
        a_snan = a_nan and not bool(a_fraction & (1 << 51))
        b_snan = b_nan and not bool(b_fraction & (1 << 51))
        a_inf = a_exp == 0x7ff and a_fraction == 0
        b_inf = b_exp == 0x7ff and b_fraction == 0
        a_pos_inf = a_inf and a_sign == 0
        b_pos_inf = b_inf and b_sign == 0
        a_neg_inf = a_inf and a_sign == 1
        b_neg_inf = b_inf and b_sign == 1

        add = fpu_op == 0
        subtract = fpu_op == 1
        multiply = fpu_op == 2
        divide = fpu_op == 3
        nan_input = a_nan or b_nan
        snan_input = a_snan or b_snan

        div_by_0 = divide and b_zero
        div_0_by_0 = divide and a_zero and b_zero
        div_inf_by_inf = divide and a_inf and b_inf
        div_by_inf = divide and b_inf
        mul_0_by_inf = multiply and ((a_zero and b_inf) or (b_zero and a_inf))
        mul_inf = multiply and (a_inf or b_inf) and not mul_0_by_inf
        div_inf = divide and a_inf and not b_inf

        addsub_inf_invalid = (
            (add and a_inf and b_inf and a_sign != b_sign)
            or (subtract and a_inf and b_inf and a_sign == b_sign)
        )
        add_inf = add and (a_inf or b_inf) and not addsub_inf_invalid
        sub_inf = subtract and (a_inf or b_inf) and not addsub_inf_invalid
        addsub_inf = add_inf or sub_inf

        invalid_trigger = bool(
            snan_input or addsub_inf_invalid or mul_0_by_inf
            or div_0_by_0 or div_inf_by_inf
        )
        exponent_overflow = exponent_in > 2046
        out_inf_trigger = bool(
            mul_inf or div_inf or add_inf or sub_inf or div_by_0
            or exponent_overflow
        )
        out_pos_inf = out_inf_trigger and result_sign == 0
        out_neg_inf = out_inf_trigger and result_sign == 1

        round_nearest = rmode == 0
        round_to_zero = rmode == 1
        round_to_pos_inf = rmode == 2
        round_to_neg_inf = rmode == 3
        inf_round_down_trigger = out_inf_trigger and (
            (result_sign == 0 and (round_to_zero or round_to_neg_inf))
            or (result_sign == 1 and (round_to_zero or round_to_pos_inf))
        )

        finite_div_by_inf = (
            divide and b_inf and not a_inf and not nan_input
        )
        mul_uf = bool(
            multiply and not a_zero and not b_zero and result_zero
            and not a_inf and not b_inf and not nan_input
        )
        div_uf = bool(
            finite_div_by_inf
            or (
                divide and not a_zero and not b_zero and result_zero
                and not a_inf and not b_inf and not nan_input
            )
        )
        underflow_trigger = bool(mul_uf or div_uf)
        overflow_trigger = bool(out_inf_trigger and not nan_input)
        inexact_trigger = bool(
            not nan_input
            and (mantissa_in != 0 or out_inf_trigger or underflow_trigger)
        )
        except_trigger = bool(
            invalid_trigger or overflow_trigger or underflow_trigger
            or inexact_trigger
        )
        nan_out_trigger = bool(nan_input or invalid_trigger)
        enable_trigger = bool(nan_out_trigger or except_trigger)

        if nan_input:
            selected_fraction = a_fraction if a_nan else b_fraction
        else:
            selected_fraction = a_fraction
        selected_fraction |= 1 << 51
        nan_magnitude = (2047 << 52) | (selected_fraction & fraction_mask)

        infinity_magnitude = 2047 << 52
        max_finite_magnitude = (2046 << 52) | fraction_mask
        if underflow_trigger:
            out_0 = result_sign << 63
        else:
            out_0 = candidate
        if out_inf_trigger:
            chosen_magnitude = (
                max_finite_magnitude if inf_round_down_trigger
                else infinity_magnitude
            )
            out_1 = (result_sign << 63) | chosen_magnitude
        else:
            out_1 = out_0
        if nan_out_trigger:
            out_2 = (result_sign << 63) | nan_magnitude
        else:
            out_2 = out_1

        probes = {
            'in_et_zero': bool(result_zero),
            'opa_et_zero': bool(a_zero),
            'opb_et_zero': bool(b_zero),
            'input_et_zero': bool(result_zero),
            'add': bool(add),
            'subtract': bool(subtract),
            'multiply': bool(multiply),
            'divide': bool(divide),
            'opa_qnan': bool(a_qnan),
            'opb_qnan': bool(b_qnan),
            'opa_snan': bool(a_snan),
            'opb_snan': bool(b_snan),
            'opa_pos_inf': bool(a_pos_inf),
            'opb_pos_inf': bool(b_pos_inf),
            'opa_neg_inf': bool(a_neg_inf),
            'opb_neg_inf': bool(b_neg_inf),
            'opa_inf': bool(a_inf),
            'opb_inf': bool(b_inf),
            'nan_input': bool(nan_input),
            'snan_input': bool(snan_input),
            'a_nan': bool(a_nan),
            'div_by_0': bool(div_by_0),
            'div_0_by_0': bool(div_0_by_0),
            'div_inf_by_inf': bool(div_inf_by_inf),
            'div_by_inf': bool(div_by_inf),
            'mul_0_by_inf': bool(mul_0_by_inf),
            'mul_inf': bool(mul_inf),
            'div_inf': bool(div_inf),
            'add_inf': bool(add_inf),
            'sub_inf': bool(sub_inf),
            'addsub_inf_invalid': bool(addsub_inf_invalid),
            'addsub_inf': bool(addsub_inf),
            'out_inf_trigger': bool(out_inf_trigger),
            'out_pos_inf': bool(out_pos_inf),
            'out_neg_inf': bool(out_neg_inf),
            'round_nearest': bool(round_nearest),
            'round_to_zero': bool(round_to_zero),
            'round_to_pos_inf': bool(round_to_pos_inf),
            'round_to_neg_inf': bool(round_to_neg_inf),
            'inf_round_down_trigger': bool(inf_round_down_trigger),
            'mul_uf': bool(mul_uf),
            'div_uf': bool(div_uf),
            'underflow_trigger': bool(underflow_trigger),
            'invalid_trigger': bool(invalid_trigger),
            'overflow_trigger': bool(overflow_trigger),
            'inexact_trigger': bool(inexact_trigger),
            'except_trigger': bool(except_trigger),
            'enable_trigger': bool(enable_trigger),
            'nan_out_trigger': bool(nan_out_trigger),
            'snan_trigger': bool(snan_input),
            'exp_2047': 2047,
            'exp_2046': 2046,
            'nan_output_0': self.mask(nan_magnitude, 63),
            'nan_output': self.mask(nan_magnitude, 63),
            'mantissa_max': fraction_mask,
            'inf_round_down': max_finite_magnitude if inf_round_down_trigger else 0,
            'out_inf': infinity_magnitude if out_inf_trigger else 0,
            'out_0': self.mask(out_0, 64),
            'out_1': self.mask(out_1, 64),
            'out_2': self.mask(out_2, 64),
        }
        outputs = {
            'out': self.mask(out_2, 64),
            'ex_enable': int(enable_trigger),
            'underflow': int(underflow_trigger),
            'overflow': int(overflow_trigger),
            'inexact': int(inexact_trigger),
            'exception': int(except_trigger),
            'invalid': int(invalid_trigger),
        }
        return probes, outputs

    def outputs(self, i):
        for name, value in self._probe_values.items():
            setattr(self, name, value)
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self._registered_outputs['out']
        o['ex_enable'] = self._registered_outputs['ex_enable']
        o['underflow'] = self._registered_outputs['underflow']
        o['overflow'] = self._registered_outputs['overflow']
        o['inexact'] = self._registered_outputs['inexact']
        o['exception'] = self._registered_outputs['exception']
        o['invalid'] = self._registered_outputs['invalid']
        return o

    def advance(self, i):
        if i['rst'] & 1:
            self.reset()
        elif i['enable'] & 1:
            probes, result = self._calculate(i)
            self._probe_values = probes
            self._registered_outputs = result
