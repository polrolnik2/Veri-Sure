"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        self._out = 0
        self._flags = {
            'ex_enable': 0,
            'underflow': 0,
            'overflow': 0,
            'inexact': 0,
            'exception': 0,
            'invalid': 0,
        }
        self._probe_state = {
            'in_et_zero': 0,
            'opa_et_zero': 0,
            'opb_et_zero': 0,
            'input_et_zero': 0,
            'add': 0,
            'subtract': 0,
            'multiply': 0,
            'divide': 0,
            'opa_qnan': 0,
            'opb_qnan': 0,
            'opa_snan': 0,
            'opb_snan': 0,
            'opa_pos_inf': 0,
            'opb_pos_inf': 0,
            'opa_neg_inf': 0,
            'opb_neg_inf': 0,
            'opa_inf': 0,
            'opb_inf': 0,
            'nan_input': 0,
            'snan_input': 0,
            'a_nan': 0,
            'div_by_0': 0,
            'div_0_by_0': 0,
            'div_inf_by_inf': 0,
            'div_by_inf': 0,
            'mul_0_by_inf': 0,
            'mul_inf': 0,
            'div_inf': 0,
            'add_inf': 0,
            'sub_inf': 0,
            'addsub_inf_invalid': 0,
            'addsub_inf': 0,
            'out_inf_trigger': 0,
            'out_pos_inf': 0,
            'out_neg_inf': 0,
            'round_nearest': 0,
            'round_to_zero': 0,
            'round_to_pos_inf': 0,
            'round_to_neg_inf': 0,
            'inf_round_down_trigger': 0,
            'mul_uf': 0,
            'div_uf': 0,
            'underflow_trigger': 0,
            'invalid_trigger': 0,
            'overflow_trigger': 0,
            'inexact_trigger': 0,
            'except_trigger': 0,
            'enable_trigger': 0,
            'nan_out_trigger': 0,
            'snan_trigger': 0,
            'nan_output_0': 0,
            'nan_output': 0,
            'inf_round_down': 0,
            'out_inf': 0,
            'out_0': 0,
            'out_1': 0,
            'out_2': 0,
        }

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self.mask(self._out, 64)
        o['ex_enable'] = self._flags['ex_enable']
        o['underflow'] = self._flags['underflow']
        o['overflow'] = self._flags['overflow']
        o['inexact'] = self._flags['inexact']
        o['exception'] = self._flags['exception']
        o['invalid'] = self._flags['invalid']
        for name, value in self._probe_state.items():
            setattr(self, name, value)
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not i['enable']:
            return
        result = self._compute(i)
        self._out = self.mask(result['out'], 64)
        self._flags = result['flags']
        self._probe_state = result['probes']

    def _compute(self, i):
        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        normal = self.mask(i['in_except'], 64)
        exponent = self.mask(i['exponent_in'], 12)
        mantissa = self.mask(i['mantissa_in'], 2)
        fpu_op = self.mask(i['fpu_op'], 3)
        rmode = self.mask(i['rmode'], 2)

        frac_mask = (1 << 52) - 1
        magnitude_mask = (1 << 63) - 1
        opa_frac = opa & frac_mask
        opb_frac = opb & frac_mask
        opa_exp = (opa >> 52) & 0x7ff
        opb_exp = (opb >> 52) & 0x7ff
        opa_zero = int((opa & magnitude_mask) == 0)
        opb_zero = int((opb & magnitude_mask) == 0)
        opa_nan = int(opa_exp == 0x7ff and opa_frac != 0)
        opb_nan = int(opb_exp == 0x7ff and opb_frac != 0)
        opa_qnan = int(bool(opa_nan) and bool(opa_frac & (1 << 51)))
        opb_qnan = int(bool(opb_nan) and bool(opb_frac & (1 << 51)))
        opa_snan = int(bool(opa_nan) and not bool(opa_qnan))
        opb_snan = int(bool(opb_nan) and not bool(opb_qnan))
        opa_inf = int(opa_exp == 0x7ff and opa_frac == 0)
        opb_inf = int(opb_exp == 0x7ff and opb_frac == 0)
        opa_sign = (opa >> 63) & 1
        opb_sign = (opb >> 63) & 1
        sign = (normal >> 63) & 1

        add = int(fpu_op == 0)
        subtract = int(fpu_op == 1)
        multiply = int(fpu_op == 2)
        divide = int(fpu_op == 3)
        nan_input = int(bool(opa_nan) or bool(opb_nan))
        snan_input = int(bool(opa_snan) or bool(opb_snan))
        any_inf = bool(opa_inf) or bool(opb_inf)

        addsub_inf_invalid = int(
            (bool(add) and ((bool(opa_inf) and bool(opb_inf) and opa_sign != opb_sign)))
            or (bool(subtract) and bool(opa_inf) and bool(opb_inf) and opa_sign == opb_sign)
        )
        addsub_inf = int(bool(add or subtract) and any_inf and not bool(addsub_inf_invalid) and not bool(nan_input))
        add_inf = int(bool(add) and any_inf and not bool(addsub_inf_invalid) and not bool(nan_input))
        sub_inf = int(bool(subtract) and any_inf and not bool(addsub_inf_invalid) and not bool(nan_input))

        mul_0_by_inf = int(bool(multiply) and ((bool(opa_zero) and bool(opb_inf)) or (bool(opb_zero) and bool(opa_inf))))
        mul_inf = int(bool(multiply) and any_inf and not bool(mul_0_by_inf) and not bool(nan_input))

        div_0_by_0 = int(bool(divide) and bool(opa_zero) and bool(opb_zero))
        div_inf_by_inf = int(bool(divide) and bool(opa_inf) and bool(opb_inf))
        div_by_0 = int(bool(divide) and bool(opb_zero) and not bool(opa_zero))
        div_by_inf = int(bool(divide) and bool(opb_inf) and not bool(opa_inf) and not bool(opa_nan))
        div_inf = int(bool(divide) and bool(opa_inf) and not bool(opb_inf) and not bool(opb_nan))

        result_zero = int((normal & magnitude_mask) == 0)
        mul_uf = int(
            bool(multiply) and bool(result_zero) and not bool(opa_zero) and not bool(opb_zero)
            and not bool(opa_inf) and not bool(opb_inf) and not bool(nan_input)
        )
        div_uf = int(
            bool(divide) and (
                bool(div_by_inf)
                or (
                    bool(result_zero) and not bool(opa_zero) and not bool(opb_zero)
                    and not bool(opa_inf) and not bool(opb_inf) and not bool(nan_input)
                )
            )
        )
        underflow_trigger = int(bool(mul_uf) or bool(div_uf))
        invalid_trigger = int(
            bool(snan_input) or bool(addsub_inf_invalid) or bool(mul_0_by_inf)
            or bool(div_0_by_0) or bool(div_inf_by_inf)
        )

        out_inf_trigger = int(
            bool(addsub_inf) or bool(mul_inf) or bool(div_inf) or bool(div_by_0) or exponent > 2046
        )
        round_nearest = int(rmode == 0)
        round_to_zero = int(rmode == 1)
        round_to_pos_inf = int(rmode == 2)
        round_to_neg_inf = int(rmode == 3)
        inf_round_down_trigger = int(
            bool(out_inf_trigger)
            and ((not bool(sign) and bool(round_to_zero or round_to_neg_inf))
                 or (bool(sign) and bool(round_to_zero or round_to_pos_inf)))
        )
        overflow_trigger = int(bool(out_inf_trigger) and not bool(nan_input))
        inexact_trigger = int(
            (bool(mantissa) or bool(out_inf_trigger) or bool(underflow_trigger)) and not bool(nan_input)
        )
        nan_out_trigger = int(bool(nan_input) or bool(invalid_trigger))
        except_trigger = int(
            bool(invalid_trigger) or bool(overflow_trigger) or bool(underflow_trigger) or bool(inexact_trigger)
        )
        enable_trigger = int(
            bool(nan_out_trigger) or bool(out_inf_trigger) or bool(underflow_trigger)
            or bool(inexact_trigger) or bool(invalid_trigger)
        )

        max_finite = (2046 << 52) | frac_mask
        infinity = 2047 << 52
        selected_infinity_magnitude = max_finite if inf_round_down_trigger else infinity
        inf_round_down = max_finite if inf_round_down_trigger else 0
        out_inf = selected_infinity_magnitude if out_inf_trigger else 0
        out_pos_inf = int(bool(out_inf_trigger) and not bool(sign))
        out_neg_inf = int(bool(out_inf_trigger) and bool(sign))

        if nan_input:
            payload = opa_frac if opa_nan else opb_frac
        else:
            payload = opa_frac
        payload |= 1 << 51
        nan_magnitude = (2047 << 52) | (payload & frac_mask)
        nan_magnitude = self.mask(nan_magnitude, 63)

        stage0 = ((sign << 63) if underflow_trigger else normal)
        stage0 = self.mask(stage0, 64)
        infinity_value = (sign << 63) | selected_infinity_magnitude
        stage1 = self.mask(infinity_value if out_inf_trigger else stage0, 64)
        nan_value = (sign << 63) | nan_magnitude
        stage2 = self.mask(nan_value if nan_out_trigger else stage1, 64)

        flags = {
            'ex_enable': enable_trigger,
            'underflow': underflow_trigger,
            'overflow': overflow_trigger,
            'inexact': inexact_trigger,
            'exception': except_trigger,
            'invalid': invalid_trigger,
        }
        probes = {
            'in_et_zero': result_zero,
            'opa_et_zero': opa_zero,
            'opb_et_zero': opb_zero,
            'input_et_zero': int(bool(opa_zero) or bool(opb_zero)),
            'add': add,
            'subtract': subtract,
            'multiply': multiply,
            'divide': divide,
            'opa_qnan': opa_qnan,
            'opb_qnan': opb_qnan,
            'opa_snan': opa_snan,
            'opb_snan': opb_snan,
            'opa_pos_inf': int(bool(opa_inf) and not bool(opa_sign)),
            'opb_pos_inf': int(bool(opb_inf) and not bool(opb_sign)),
            'opa_neg_inf': int(bool(opa_inf) and bool(opa_sign)),
            'opb_neg_inf': int(bool(opb_inf) and bool(opb_sign)),
            'opa_inf': opa_inf,
            'opb_inf': opb_inf,
            'nan_input': nan_input,
            'snan_input': snan_input,
            'a_nan': nan_out_trigger,
            'div_by_0': div_by_0,
            'div_0_by_0': div_0_by_0,
            'div_inf_by_inf': div_inf_by_inf,
            'div_by_inf': div_by_inf,
            'mul_0_by_inf': mul_0_by_inf,
            'mul_inf': mul_inf,
            'div_inf': div_inf,
            'add_inf': add_inf,
            'sub_inf': sub_inf,
            'addsub_inf_invalid': addsub_inf_invalid,
            'addsub_inf': addsub_inf,
            'out_inf_trigger': out_inf_trigger,
            'out_pos_inf': out_pos_inf,
            'out_neg_inf': out_neg_inf,
            'round_nearest': round_nearest,
            'round_to_zero': round_to_zero,
            'round_to_pos_inf': round_to_pos_inf,
            'round_to_neg_inf': round_to_neg_inf,
            'inf_round_down_trigger': inf_round_down_trigger,
            'mul_uf': mul_uf,
            'div_uf': div_uf,
            'underflow_trigger': underflow_trigger,
            'invalid_trigger': invalid_trigger,
            'overflow_trigger': overflow_trigger,
            'inexact_trigger': inexact_trigger,
            'except_trigger': except_trigger,
            'enable_trigger': enable_trigger,
            'nan_out_trigger': nan_out_trigger,
            'snan_trigger': snan_input,
            'nan_output_0': nan_magnitude,
            'nan_output': nan_magnitude,
            'inf_round_down': inf_round_down,
            'out_inf': out_inf,
            'out_0': stage0,
            'out_1': stage1,
            'out_2': stage2,
        }
        return {'out': stage2, 'flags': flags, 'probes': probes}
