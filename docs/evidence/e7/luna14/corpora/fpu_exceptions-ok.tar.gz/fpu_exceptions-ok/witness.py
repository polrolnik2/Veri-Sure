"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        self.out = 0
        self.ex_enable = 0
        self.underflow = 0
        self.overflow = 0
        self.inexact = 0
        self.exception = 0
        self.invalid = 0
        for name in (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger'
        ):
            setattr(self, name, False)
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1
        self.nan_output_0 = 0
        self.nan_output = 0
        self.inf_round_down = 0
        self.out_inf = 0
        self.out_0 = 0
        self.out_1 = 0
        self.out_2 = 0
        self._stage0_inf_trigger = False
        self._stage0_inf_value = 0
        self._stage0_nan_trigger = False
        self._stage0_nan_sign = 0
        self._stage1_nan_trigger = False
        self._stage1_nan_sign = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self.mask(self.out, 64)
        o['ex_enable'] = int(bool(self.ex_enable))
        o['underflow'] = int(bool(self.underflow))
        o['overflow'] = int(bool(self.overflow))
        o['inexact'] = int(bool(self.inexact))
        o['exception'] = int(bool(self.exception))
        o['invalid'] = int(bool(self.invalid))
        for name in (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger'
        ):
            setattr(self, name, bool(getattr(self, name)))
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1
        for name, width in (
            ('nan_output_0', 63), ('nan_output', 63),
            ('inf_round_down', 63), ('out_inf', 63),
            ('out_0', 64), ('out_1', 64), ('out_2', 64)
        ):
            setattr(self, name, self.mask(getattr(self, name), width))
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not i['enable']:
            return

        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        normal = self.mask(i['in_except'], 64)
        exponent = self.mask(i['exponent_in'], 12)
        mantissa = self.mask(i['mantissa_in'], 2)
        op = self.mask(i['fpu_op'], 3)
        rmode = self.mask(i['rmode'], 2)

        afrac = opa & ((1 << 52) - 1)
        bfrac = opb & ((1 << 52) - 1)
        aexp = (opa >> 52) & 0x7ff
        bexp = (opb >> 52) & 0x7ff
        asign = (opa >> 63) & 1
        bsign = (opb >> 63) & 1
        result_sign = (normal >> 63) & 1

        azero = (opa & ((1 << 63) - 1)) == 0
        bzero = (opb & ((1 << 63) - 1)) == 0
        result_zero = (normal & ((1 << 63) - 1)) == 0
        anan = aexp == 0x7ff and afrac != 0
        bnan = bexp == 0x7ff and bfrac != 0
        aqnan = anan and bool(afrac & (1 << 51))
        bqnan = bnan and bool(bfrac & (1 << 51))
        asnan = anan and not aqnan
        bsnan = bnan and not bqnan
        ainf = aexp == 0x7ff and afrac == 0
        binf = bexp == 0x7ff and bfrac == 0
        aposinf = ainf and asign == 0
        aneginf = ainf and asign == 1
        bposinf = binf and bsign == 0
        bneginf = binf and bsign == 1

        add = op == 0
        subtract = op == 1
        multiply = op == 2
        divide = op == 3
        nan_input = anan or bnan
        snan_input = asnan or bsnan
        div_0_by_0 = divide and azero and bzero
        div_inf_by_inf = divide and ainf and binf
        div_by_0 = divide and bzero and not azero
        div_by_inf = divide and binf and not ainf
        mul_0_by_inf = multiply and ((azero and binf) or (bzero and ainf))
        mul_inf = multiply and (ainf or binf) and not mul_0_by_inf

        addsub_inf_invalid = (
            (add and ((aposinf and bneginf) or (aneginf and bposinf))) or
            (subtract and ((aposinf and bposinf) or (aneginf and bneginf)))
        )
        addsub_inf = (add or subtract) and (ainf or binf)
        add_inf = add and (ainf or binf)
        sub_inf = subtract and (ainf or binf)

        invalid_trigger = bool(
            snan_input or addsub_inf_invalid or mul_0_by_inf or
            div_0_by_0 or div_inf_by_inf
        )
        valid_addsub_inf = addsub_inf and not addsub_inf_invalid
        out_inf_trigger = bool(
            mul_inf or (divide and ainf and not binf) or div_by_0 or
            valid_addsub_inf or exponent > 2046
        )

        round_down = bool(
            out_inf_trigger and (
                (result_sign == 0 and rmode in (1, 3)) or
                (result_sign == 1 and rmode in (1, 2))
            )
        )
        infinity_magnitude = 2047 << 52
        max_finite_magnitude = (2046 << 52) | ((1 << 52) - 1)
        selected_inf_magnitude = max_finite_magnitude if round_down else infinity_magnitude
        selected_inf_value = (result_sign << 63) | selected_inf_magnitude

        finite_div_by_inf = div_by_inf and not anan
        mul_uf = bool(
            multiply and not azero and not bzero and result_zero and
            not nan_input and not ainf and not binf
        )
        div_uf = bool(
            finite_div_by_inf or
            (divide and not azero and not bzero and result_zero and
             not nan_input and not ainf and not binf)
        )
        underflow_trigger = bool(mul_uf or div_uf)
        overflow_trigger = bool(out_inf_trigger and not nan_input)
        inexact_trigger = bool(
            not nan_input and (mantissa != 0 or out_inf_trigger or underflow_trigger)
        )
        except_trigger = bool(
            invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger
        )

        nan_out_trigger = bool(nan_input or invalid_trigger)
        if anan:
            nan_payload = afrac
        elif bnan:
            nan_payload = bfrac
        else:
            nan_payload = afrac
        nan_payload = self.mask(nan_payload | (1 << 51), 52)
        nan_magnitude = (2047 << 52) | nan_payload
        enable_trigger = bool(
            nan_out_trigger or invalid_trigger or overflow_trigger or
            underflow_trigger or inexact_trigger
        )

        # Advance the explicitly named output-selection stages using their old state.
        old_out_0 = self.out_0
        old_out_1 = self.out_1
        old_out_2 = self.out_2
        old_stage0_inf_trigger = self._stage0_inf_trigger
        old_stage0_inf_value = self._stage0_inf_value
        old_stage0_nan_trigger = self._stage0_nan_trigger
        old_stage0_nan_sign = self._stage0_nan_sign
        old_stage1_nan_trigger = self._stage1_nan_trigger
        old_stage1_nan_sign = self._stage1_nan_sign
        old_nan_output_0 = self.nan_output_0
        old_nan_output = self.nan_output

        next_out_1 = old_stage0_inf_value if old_stage0_inf_trigger else old_out_0
        next_out_2 = (
            ((old_stage1_nan_sign & 1) << 63) | old_nan_output
            if old_stage1_nan_trigger else old_out_1
        )
        next_out = old_out_2
        next_out_0 = ((result_sign << 63) if underflow_trigger else normal)
        next_nan_payload = nan_magnitude & ((1 << 63) - 1)

        self.in_et_zero = bool(result_zero)
        self.opa_et_zero = bool(azero)
        self.opb_et_zero = bool(bzero)
        self.input_et_zero = bool(result_zero)
        self.add = bool(add)
        self.subtract = bool(subtract)
        self.multiply = bool(multiply)
        self.divide = bool(divide)
        self.opa_qnan = bool(aqnan)
        self.opb_qnan = bool(bqnan)
        self.opa_snan = bool(asnan)
        self.opb_snan = bool(bsnan)
        self.opa_pos_inf = bool(aposinf)
        self.opb_pos_inf = bool(bposinf)
        self.opa_neg_inf = bool(aneginf)
        self.opb_neg_inf = bool(bneginf)
        self.opa_inf = bool(ainf)
        self.opb_inf = bool(binf)
        self.nan_input = bool(nan_input)
        self.snan_input = bool(snan_input)
        self.a_nan = bool(anan)
        self.div_by_0 = bool(div_by_0)
        self.div_0_by_0 = bool(div_0_by_0)
        self.div_inf_by_inf = bool(div_inf_by_inf)
        self.div_by_inf = bool(div_by_inf)
        self.mul_0_by_inf = bool(mul_0_by_inf)
        self.mul_inf = bool(mul_inf)
        self.div_inf = bool(divide and ainf and not binf)
        self.add_inf = bool(add_inf)
        self.sub_inf = bool(sub_inf)
        self.addsub_inf_invalid = bool(addsub_inf_invalid)
        self.addsub_inf = bool(addsub_inf)
        self.out_inf_trigger = bool(out_inf_trigger)
        self.out_pos_inf = bool(out_inf_trigger and result_sign == 0)
        self.out_neg_inf = bool(out_inf_trigger and result_sign == 1)
        self.round_nearest = bool(rmode == 0)
        self.round_to_zero = bool(rmode == 1)
        self.round_to_pos_inf = bool(rmode == 2)
        self.round_to_neg_inf = bool(rmode == 3)
        self.inf_round_down_trigger = bool(round_down)
        self.mul_uf = bool(mul_uf)
        self.div_uf = bool(div_uf)
        self.underflow_trigger = bool(underflow_trigger)
        self.invalid_trigger = bool(invalid_trigger)
        self.overflow_trigger = bool(overflow_trigger)
        self.inexact_trigger = bool(inexact_trigger)
        self.except_trigger = bool(except_trigger)
        self.enable_trigger = bool(enable_trigger)
        self.nan_out_trigger = bool(nan_out_trigger)
        self.snan_trigger = bool(snan_input)

        self.out_inf = infinity_magnitude if out_inf_trigger else 0
        self.inf_round_down = max_finite_magnitude if round_down else 0
        self.nan_output_0 = next_nan_payload
        self.nan_output = old_nan_output_0
        self.out_0 = self.mask(next_out_0, 64)
        self.out_1 = self.mask(next_out_1, 64)
        self.out_2 = self.mask(next_out_2, 64)
        self.out = self.mask(next_out, 64)

        self._stage0_inf_trigger = bool(out_inf_trigger)
        self._stage0_inf_value = self.mask(selected_inf_value, 64)
        self._stage0_nan_trigger = bool(nan_out_trigger)
        self._stage0_nan_sign = result_sign
        self._stage1_nan_trigger = bool(old_stage0_nan_trigger)
        self._stage1_nan_sign = old_stage0_nan_sign

        self.underflow = int(bool(underflow_trigger))
        self.overflow = int(bool(overflow_trigger))
        self.inexact = int(bool(inexact_trigger))
        self.invalid = int(bool(invalid_trigger))
        self.exception = int(bool(except_trigger))
        self.ex_enable = int(bool(enable_trigger))
