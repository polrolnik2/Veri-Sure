"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    _BOOL_PROBES = (
        "in_et_zero", "opa_et_zero", "opb_et_zero", "input_et_zero",
        "add", "subtract", "multiply", "divide",
        "opa_qnan", "opb_qnan", "opa_snan", "opb_snan",
        "opa_pos_inf", "opb_pos_inf", "opa_neg_inf", "opb_neg_inf",
        "opa_inf", "opb_inf", "nan_input", "snan_input", "a_nan",
        "div_by_0", "div_0_by_0", "div_inf_by_inf", "div_by_inf",
        "mul_0_by_inf", "mul_inf", "div_inf", "add_inf", "sub_inf",
        "addsub_inf_invalid", "addsub_inf", "out_inf_trigger",
        "out_pos_inf", "out_neg_inf", "round_nearest", "round_to_zero",
        "round_to_pos_inf", "round_to_neg_inf", "inf_round_down_trigger",
        "mul_uf", "div_uf", "underflow_trigger", "invalid_trigger",
        "overflow_trigger", "inexact_trigger", "except_trigger",
        "enable_trigger", "nan_out_trigger", "snan_trigger"
    )

    _VALUE_PROBES = {
        "exp_2047": 11,
        "exp_2046": 11,
        "nan_output_0": 63,
        "nan_output": 63,
        "mantissa_max": 52,
        "inf_round_down": 63,
        "out_inf": 63,
        "out_0": 64,
        "out_1": 64,
        "out_2": 64
    }

    def _empty_state(self):
        q = {name: False for name in self._BOOL_PROBES}
        q.update({name: 0 for name in self._VALUE_PROBES})
        q["exp_2047"] = 2047
        q["exp_2046"] = 2046
        q["mantissa_max"] = (1 << 52) - 1
        q.update({
            "out": 0, "ex_enable": 0, "underflow": 0, "overflow": 0,
            "inexact": 0, "exception": 0, "invalid": 0
        })
        return q

    def _empty_stage(self):
        return {
            "base": 0,
            "inf_trigger": False,
            "inf_result": 0,
            "nan_trigger": False,
            "nan_full": 0,
            "nan_payload": 0,
            "out1": 0,
            "out2": 0,
            "ports": {
                "ex_enable": 0, "underflow": 0, "overflow": 0,
                "inexact": 0, "exception": 0, "invalid": 0
            }
        }

    def reset(self):
        self._q = self._empty_state()
        self._s0 = self._empty_stage()
        self._s1 = self._empty_stage()
        self._s2 = self._empty_stage()

    def outputs(self, i):
        q = self._q
        for name in self._BOOL_PROBES:
            setattr(self, name, bool(q[name]))
        for name, width in self._VALUE_PROBES.items():
            setattr(self, name, self.mask(q[name], width))

        o = {p: None for p in self.OUTPUT_PORTS}
        o["out"] = self.mask(q["out"], 64)
        o["ex_enable"] = int(bool(q["ex_enable"]))
        o["underflow"] = int(bool(q["underflow"]))
        o["overflow"] = int(bool(q["overflow"]))
        o["inexact"] = int(bool(q["inexact"]))
        o["exception"] = int(bool(q["exception"]))
        o["invalid"] = int(bool(q["invalid"]))
        return o

    def _compute(self, i):
        opa = self.mask(i["opa"], 64)
        opb = self.mask(i["opb"], 64)
        candidate = self.mask(i["in_except"], 64)
        exponent = self.mask(i["exponent_in"], 12)
        remainder = self.mask(i["mantissa_in"], 2)
        op = self.mask(i["fpu_op"], 3)
        mode = self.mask(i["rmode"], 2)

        frac_mask = (1 << 52) - 1
        zero_mask = (1 << 63) - 1
        sign = (candidate >> 63) & 1
        a_exp = (opa >> 52) & 0x7ff
        b_exp = (opb >> 52) & 0x7ff
        a_frac = opa & frac_mask
        b_frac = opb & frac_mask

        a_zero = (opa & zero_mask) == 0
        b_zero = (opb & zero_mask) == 0
        result_zero = (candidate & zero_mask) == 0
        a_nan = a_exp == 0x7ff and a_frac != 0
        b_nan = b_exp == 0x7ff and b_frac != 0
        a_qnan = a_nan and bool((a_frac >> 51) & 1)
        b_qnan = b_nan and bool((b_frac >> 51) & 1)
        a_snan = a_nan and not bool((a_frac >> 51) & 1)
        b_snan = b_nan and not bool((b_frac >> 51) & 1)
        a_inf = a_exp == 0x7ff and a_frac == 0
        b_inf = b_exp == 0x7ff and b_frac == 0
        a_pos_inf = a_inf and not bool((opa >> 63) & 1)
        b_pos_inf = b_inf and not bool((opb >> 63) & 1)
        a_neg_inf = a_inf and bool((opa >> 63) & 1)
        b_neg_inf = b_inf and bool((opb >> 63) & 1)

        add = op == 0
        subtract = op == 1
        multiply = op == 2
        divide = op == 3
        nan_input = a_nan or b_nan
        snan_input = a_snan or b_snan

        add_invalid = add and ((a_pos_inf and b_neg_inf) or (a_neg_inf and b_pos_inf))
        sub_invalid = subtract and ((a_pos_inf and b_pos_inf) or (a_neg_inf and b_neg_inf))
        addsub_invalid = add_invalid or sub_invalid
        mul_0_by_inf = multiply and ((a_zero and b_inf) or (b_zero and a_inf))
        div_0_by_0 = divide and a_zero and b_zero
        div_inf_by_inf = divide and a_inf and b_inf
        div_by_0 = divide and b_zero and not a_zero and not a_inf and not nan_input
        div_by_inf = divide and b_inf and not a_inf and not nan_input

        invalid_operation = addsub_invalid or mul_0_by_inf or div_0_by_0 or div_inf_by_inf
        invalid_trigger = snan_input or invalid_operation

        add_inf = add and (a_inf or b_inf) and not add_invalid and not nan_input
        sub_inf = subtract and (a_inf or b_inf) and not sub_invalid and not nan_input
        addsub_inf = add_inf or sub_inf
        mul_inf = multiply and (a_inf or b_inf) and not mul_0_by_inf and not nan_input
        div_inf = divide and a_inf and not b_inf and not nan_input
        out_inf_trigger = (
            addsub_inf or mul_inf or div_inf or div_by_0 or exponent > 2046
        )

        round_nearest = mode == 0
        round_to_zero = mode == 1
        round_to_pos_inf = mode == 2
        round_to_neg_inf = mode == 3
        round_down = out_inf_trigger and (
            (not sign and (round_to_zero or round_to_neg_inf)) or
            (sign and (round_to_zero or round_to_pos_inf))
        )

        mul_uf = (
            multiply and not a_zero and not b_zero and not a_inf and not b_inf
            and not nan_input and result_zero
        )
        div_uf = div_by_inf or (
            divide and not a_zero and not b_zero and not a_inf and not b_inf
            and not nan_input and result_zero
        )
        underflow_trigger = mul_uf or div_uf

        overflow_trigger = out_inf_trigger and not nan_input
        inexact_trigger = not nan_input and (
            remainder != 0 or out_inf_trigger or underflow_trigger
        )
        except_trigger = (
            invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger
        )

        nan_out_trigger = nan_input or invalid_operation
        if nan_input:
            nan_source = opa if a_nan else opb
            nan_fraction = (nan_source & frac_mask) | (1 << 51)
        else:
            nan_fraction = (a_frac & frac_mask) | (1 << 51)
        nan_payload = ((2047 << 52) | nan_fraction) if nan_out_trigger else 0
        nan_full = ((sign << 63) | nan_payload) if nan_out_trigger else 0
        a_nan_select = a_nan or (invalid_operation and not nan_input)

        underflow_base = (sign << 63) if underflow_trigger else candidate
        infinity_magnitude = (2047 << 52) if out_inf_trigger else 0
        max_finite_magnitude = (2046 << 52) | frac_mask
        round_down_magnitude = max_finite_magnitude if round_down else 0
        inf_result = (sign << 63) | (
            max_finite_magnitude if round_down else (2047 << 52)
        )

        overflow = int(bool(overflow_trigger))
        underflow = int(bool(underflow_trigger))
        inexact = int(bool(inexact_trigger))
        invalid = int(bool(invalid_trigger))
        exception = int(bool(invalid or overflow or underflow or inexact))
        ex_enable = int(bool(
            nan_out_trigger or out_inf_trigger or underflow_trigger or inexact_trigger
        ))

        probes = {
            "in_et_zero": bool(result_zero),
            "opa_et_zero": bool(a_zero),
            "opb_et_zero": bool(b_zero),
            "input_et_zero": bool(result_zero),
            "add": bool(add),
            "subtract": bool(subtract),
            "multiply": bool(multiply),
            "divide": bool(divide),
            "opa_qnan": bool(a_qnan),
            "opb_qnan": bool(b_qnan),
            "opa_snan": bool(a_snan),
            "opb_snan": bool(b_snan),
            "opa_pos_inf": bool(a_pos_inf),
            "opb_pos_inf": bool(b_pos_inf),
            "opa_neg_inf": bool(a_neg_inf),
            "opb_neg_inf": bool(b_neg_inf),
            "opa_inf": bool(a_inf),
            "opb_inf": bool(b_inf),
            "nan_input": bool(nan_input),
            "snan_input": bool(snan_input),
            "a_nan": bool(a_nan_select),
            "div_by_0": bool(div_by_0),
            "div_0_by_0": bool(div_0_by_0),
            "div_inf_by_inf": bool(div_inf_by_inf),
            "div_by_inf": bool(div_by_inf),
            "mul_0_by_inf": bool(mul_0_by_inf),
            "mul_inf": bool(mul_inf),
            "div_inf": bool(div_inf),
            "add_inf": bool(add_inf),
            "sub_inf": bool(sub_inf),
            "addsub_inf_invalid": bool(addsub_invalid),
            "addsub_inf": bool(addsub_inf),
            "out_inf_trigger": bool(out_inf_trigger),
            "out_pos_inf": bool(out_inf_trigger and not sign),
            "out_neg_inf": bool(out_inf_trigger and bool(sign)),
            "round_nearest": bool(round_nearest),
            "round_to_zero": bool(round_to_zero),
            "round_to_pos_inf": bool(round_to_pos_inf),
            "round_to_neg_inf": bool(round_to_neg_inf),
            "inf_round_down_trigger": bool(round_down),
            "mul_uf": bool(mul_uf),
            "div_uf": bool(div_uf),
            "underflow_trigger": bool(underflow_trigger),
            "invalid_trigger": bool(invalid_trigger),
            "overflow_trigger": bool(overflow_trigger),
            "inexact_trigger": bool(inexact_trigger),
            "except_trigger": bool(except_trigger),
            "enable_trigger": bool(ex_enable),
            "nan_out_trigger": bool(nan_out_trigger),
            "snan_trigger": bool(snan_input),
            "exp_2047": 2047,
            "exp_2046": 2046,
            "nan_output_0": nan_payload,
            "nan_output": 0,
            "mantissa_max": frac_mask,
            "inf_round_down": round_down_magnitude,
            "out_inf": infinity_magnitude,
            "out_0": underflow_base,
            "out_1": 0,
            "out_2": 0
        }
        ports = {
            "ex_enable": ex_enable,
            "underflow": underflow,
            "overflow": overflow,
            "inexact": inexact,
            "exception": exception,
            "invalid": invalid
        }
        return {
            "probes": probes,
            "base_out": underflow_base,
            "inf_trigger": bool(out_inf_trigger),
            "inf_result": inf_result,
            "nan_trigger": bool(nan_out_trigger),
            "nan_full": nan_full,
            "nan_payload": nan_payload,
            "ports": ports
        }

    def advance(self, i):
        if int(i["rst"]) & 1:
            self.reset()
            return
        if not (int(i["enable"]) & 1):
            return

        c = self._compute(i)
        old0 = self._s0
        old1 = self._s1
        old2 = self._s2

        out1 = old0["inf_result"] if old0["inf_trigger"] else old0["base"]
        out2 = old1["nan_full"] if old1["nan_trigger"] else old1["out1"]
        final_out = old2["out2"]

        new0 = {
            "base": c["base_out"],
            "inf_trigger": c["inf_trigger"],
            "inf_result": c["inf_result"],
            "nan_trigger": c["nan_trigger"],
            "nan_full": c["nan_full"],
            "nan_payload": c["nan_payload"],
            "out1": 0,
            "out2": 0,
            "ports": c["ports"]
        }
        new1 = {
            "base": 0,
            "inf_trigger": False,
            "inf_result": 0,
            "nan_trigger": old0["nan_trigger"],
            "nan_full": old0["nan_full"],
            "nan_payload": old0["nan_payload"],
            "out1": out1,
            "out2": 0,
            "ports": old0["ports"]
        }
        new2 = {
            "base": 0,
            "inf_trigger": False,
            "inf_result": 0,
            "nan_trigger": False,
            "nan_full": 0,
            "nan_payload": 0,
            "out1": 0,
            "out2": out2,
            "ports": old1["ports"]
        }

        q = dict(c["probes"])
        q["out_0"] = c["base_out"]
        q["out_1"] = out1
        q["out_2"] = out2
        q["nan_output_0"] = c["nan_payload"]
        q["nan_output"] = old0["nan_payload"]
        q["out"] = final_out
        for name in ("ex_enable", "underflow", "overflow", "inexact", "exception", "invalid"):
            q[name] = old2["ports"][name]

        self._q = q
        self._s0 = new0
        self._s1 = new1
        self._s2 = new2
