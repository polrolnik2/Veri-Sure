"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    STORE_REFILL_ENABLED = False

    def reset(self):
        self._state = 'IDLE'
        self._saved_addr = 0
        self._cnt = 0
        self._hitmiss_eval = False
        self._store = False
        self._load = False
        self._cache_inhibit = False
        self._store_refill_enabled = bool(self.STORE_REFILL_ENABLED)

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        reset_active = bool(i['rst'])
        state = 'IDLE' if reset_active else self._state
        saved_addr = 0 if reset_active else self._saved_addr
        hitmiss_eval = False if reset_active else self._hitmiss_eval
        store = False if reset_active else self._store
        load = False if reset_active else self._load
        cache_inhibit = False if reset_active else self._cache_inhibit
        cnt = 0 if reset_active else self._cnt

        ci_seen = bool(cache_inhibit or (
            state in ('CLOAD', 'CSTORE')
            and i['dcqmem_cycstb_i']
            and i['dcqmem_ci_i']
        ))

        biu_read = bool(load and (
            (hitmiss_eval and i['tagcomp_miss']) or not hitmiss_eval
        ))
        biu_write = bool(store)
        load_hit = bool(
            state == 'CLOAD'
            and load
            and hitmiss_eval
            and not i['tagcomp_miss']
            and not ci_seen
        )
        store_hit_ack = bool(
            state == 'CSTORE'
            and store
            and i['biudata_valid']
            and not i['tagcomp_miss']
            and not ci_seen
        )
        first_hit_ack = bool(load_hit or store_hit_ack)
        first_miss_ack = bool(
            state in ('CLOAD', 'CSTORE') and i['biudata_valid']
        )
        first_miss_err = bool(
            state in ('CLOAD', 'CSTORE') and i['biudata_error']
        )
        burst = bool(
            (state == 'CLOAD' and load and i['tagcomp_miss'] and not ci_seen)
            or state == 'LREFILL3'
            or (state == 'SREFILL4' and self._store_refill_enabled)
        )
        refill_we = bool(load and i['biudata_valid'] and not ci_seen)
        dcram_we = (15 if refill_we else 0) | (
            self.mask(i['dcqmem_sel_i'], 4) if store_hit_ack else 0
        )
        tag_we = bool(biu_read and i['biudata_valid'] and not ci_seen)
        transfer_active = bool(biu_read or biu_write)
        dc_addr = saved_addr if (not hitmiss_eval and transfer_active) else i['start_addr']

        o['saved_addr'] = self.mask(saved_addr, 32)
        o['dcram_we'] = self.mask(dcram_we, 4)
        o['biu_read'] = int(biu_read)
        o['biu_write'] = int(biu_write)
        o['first_hit_ack'] = int(first_hit_ack)
        o['first_miss_ack'] = int(first_miss_ack)
        o['first_miss_err'] = int(first_miss_err)
        o['burst'] = int(burst)
        o['tag_we'] = int(tag_we)
        o['dc_addr'] = self.mask(dc_addr, 32)

        self.idle = bool(state == 'IDLE')
        self.cload = bool(state == 'CLOAD')
        self.cstore = bool(state == 'CSTORE')
        self.lrefill3 = bool(state == 'LREFILL3')
        self.srefill4 = bool(state == 'SREFILL4')
        self.hitmiss_eval = bool(hitmiss_eval)
        self.store = bool(store)
        self.load = bool(load)
        self.cache_inhibit = bool(cache_inhibit)
        self.cnt_nonzero = bool(cnt != 0)
        self.first_store_hit_ack = bool(store_hit_ack)
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return

        if self._state == 'IDLE':
            if i['dc_en'] and i['dcqmem_cycstb_i']:
                self._saved_addr = self.mask(i['start_addr'], 32)
                self._hitmiss_eval = True
                self._cache_inhibit = False
                self._store = bool(i['dcqmem_we_i'])
                self._load = not bool(i['dcqmem_we_i'])
                self._state = 'CSTORE' if i['dcqmem_we_i'] else 'CLOAD'
            return

        if self._state == 'CLOAD':
            ci_observed = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            if ci_observed:
                self._cache_inhibit = True
            ci_seen = bool(self._cache_inhibit)

            if i['biudata_error'] or (
                self._hitmiss_eval and not i['dcqmem_cycstb_i']
            ):
                self._state = 'IDLE'
                self._hitmiss_eval = False
                self._load = False
                self._store = False
            elif ci_seen:
                self._hitmiss_eval = False
                if i['biudata_valid']:
                    self._state = 'IDLE'
                    self._load = False
                    self._store = False
            elif self._hitmiss_eval:
                if not i['tagcomp_miss']:
                    self._state = 'IDLE'
                    self._hitmiss_eval = False
                    self._load = False
                    self._store = False
                else:
                    self._hitmiss_eval = False
                    if i['biudata_valid']:
                        self._state = 'LREFILL3'
                        self._cnt = 2
                        word_offset = (((self._saved_addr >> 2) + 1) & 3)
                        self._saved_addr = self.mask(
                            (self._saved_addr & ~12) | (word_offset << 2), 32
                        )
            elif i['biudata_valid']:
                self._state = 'LREFILL3'
                self._cnt = 2
                word_offset = (((self._saved_addr >> 2) + 1) & 3)
                self._saved_addr = self.mask(
                    (self._saved_addr & ~12) | (word_offset << 2), 32
                )
            return

        if self._state == 'CSTORE':
            ci_observed = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            if ci_observed:
                self._cache_inhibit = True
            ci_seen = bool(self._cache_inhibit)

            if i['biudata_error'] or (
                self._hitmiss_eval and not i['dcqmem_cycstb_i']
            ):
                self._state = 'IDLE'
                self._hitmiss_eval = False
                self._store = False
                self._load = False
            elif ci_seen:
                self._hitmiss_eval = False
                if i['biudata_valid']:
                    self._state = 'IDLE'
                    self._store = False
                    self._load = False
            elif i['biudata_valid']:
                self._hitmiss_eval = False
                if i['tagcomp_miss'] and self._store_refill_enabled:
                    self._state = 'SREFILL4'
                    self._store = False
                    self._load = True
                    self._cnt = 3
                else:
                    self._state = 'IDLE'
                    self._store = False
                    self._load = False
            else:
                self._hitmiss_eval = False
            return

        if self._state == 'LREFILL3':
            if i['biudata_valid']:
                if self._cnt != 0:
                    self._cnt -= 1
                    word_offset = (((self._saved_addr >> 2) + 1) & 3)
                    self._saved_addr = self.mask(
                        (self._saved_addr & ~12) | (word_offset << 2), 32
                    )
                else:
                    self._state = 'IDLE'
                    self._load = False
                    self._store = False
                    self._hitmiss_eval = False
            return

        if self._state == 'SREFILL4':
            if i['biudata_valid']:
                if self._cnt != 0:
                    self._cnt -= 1
                    word_offset = (((self._saved_addr >> 2) + 1) & 3)
                    self._saved_addr = self.mask(
                        (self._saved_addr & ~12) | (word_offset << 2), 32
                    )
                else:
                    self._state = 'IDLE'
                    self._load = False
                    self._store = False
                    self._hitmiss_eval = False
