"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self._saved_addr = 0
        self._cnt = 0
        self._hitmiss_eval = 0
        self._store = 0
        self._load = 0
        self._cache_inhibit = 0
        self._store_refill = False
        self.idle = True
        self.cload = False
        self.cstore = False
        self.lrefill3 = False
        self.srefill4 = False
        self.hitmiss_eval = False
        self.store = False
        self.load = False
        self.cache_inhibit = False
        self.cnt_nonzero = False
        self.first_store_hit_ack = False

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        # An asynchronous reset presents the reset state immediately, even before
        # advance() records that state in the model.
        if i['rst']:
            self.idle = True
            self.cload = False
            self.cstore = False
            self.lrefill3 = False
            self.srefill4 = False
            self.hitmiss_eval = False
            self.store = False
            self.load = False
            self.cache_inhibit = False
            self.cnt_nonzero = False
            self.first_store_hit_ack = False
            o['saved_addr'] = 0
            o['dcram_we'] = 0
            o['biu_read'] = 0
            o['biu_write'] = 0
            o['first_hit_ack'] = 0
            o['first_miss_ack'] = 0
            o['first_miss_err'] = 0
            o['burst'] = 0
            o['tag_we'] = 0
            o['dc_addr'] = self.mask(i['start_addr'], 32)
            return o

        ci_input = bool(
            self.state in ('CLOAD', 'CSTORE')
            and i['dcqmem_cycstb_i']
            and i['dcqmem_ci_i']
        )
        ci_active = bool(self._cache_inhibit or ci_input)

        self.idle = self.state == 'IDLE'
        self.cload = self.state == 'CLOAD'
        self.cstore = self.state == 'CSTORE'
        self.lrefill3 = self.state == 'LREFILL3'
        self.srefill4 = self.state == 'SREFILL4'
        self.hitmiss_eval = bool(self._hitmiss_eval)
        self.store = bool(self._store)
        self.load = bool(self._load)
        self.cache_inhibit = bool(self._cache_inhibit)
        self.cnt_nonzero = bool(self._cnt != 0)

        effective_eval = bool(self._hitmiss_eval and not ci_active)
        first_store_hit = bool(
            self.state == 'CSTORE'
            and self._store
            and i['biudata_valid']
            and not i['tagcomp_miss']
            and not ci_active
        )
        self.first_store_hit_ack = first_store_hit

        biu_read = bool(
            (effective_eval and i['tagcomp_miss'])
            or (self._load and not effective_eval)
        )
        biu_write = bool(self._store)
        load_hit_ack = bool(
            self.state == 'CLOAD'
            and self._hitmiss_eval
            and not i['tagcomp_miss']
            and not ci_active
        )
        first_hit_ack = bool(load_hit_ack or first_store_hit)
        first_miss_ack = bool(
            self.state in ('CLOAD', 'CSTORE') and i['biudata_valid']
        )
        first_miss_err = bool(
            self.state in ('CLOAD', 'CSTORE') and i['biudata_error']
        )
        burst = bool(
            (self.state == 'CLOAD' and i['tagcomp_miss'] and not ci_active)
            or self.state == 'LREFILL3'
            or (self._store_refill and self.state == 'SREFILL4')
        )
        dcram_we = 0
        if self._load and i['biudata_valid'] and not ci_active:
            dcram_we = 0xF
        elif first_store_hit:
            dcram_we = self.mask(i['dcqmem_sel_i'], 4)
        tag_we = bool(biu_read and i['biudata_valid'] and not ci_active)

        transfer_active = bool(biu_read or biu_write)
        if not self._hitmiss_eval and transfer_active:
            dc_addr = self._saved_addr
        else:
            dc_addr = self.mask(i['start_addr'], 32)

        o['saved_addr'] = self.mask(self._saved_addr, 32)
        o['dcram_we'] = self.mask(dcram_we, 4)
        o['biu_read'] = int(biu_read)
        o['biu_write'] = int(biu_write)
        o['first_hit_ack'] = int(first_hit_ack)
        o['first_miss_ack'] = int(first_miss_ack)
        o['first_miss_err'] = int(first_miss_err)
        o['burst'] = int(burst)
        o['tag_we'] = int(tag_we)
        o['dc_addr'] = self.mask(dc_addr, 32)
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return

        if self.state == 'IDLE':
            if i['dc_en'] and i['dcqmem_cycstb_i']:
                self._saved_addr = self.mask(i['start_addr'], 32)
                self._hitmiss_eval = 1
                self._cache_inhibit = 0
                if i['dcqmem_we_i']:
                    self._store = 1
                    self._load = 0
                    self.state = 'CSTORE'
                else:
                    self._store = 0
                    self._load = 1
                    self.state = 'CLOAD'
            return

        if self.state == 'CLOAD':
            was_evaluating = bool(self._hitmiss_eval)
            ci_seen = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            if ci_seen:
                self._cache_inhibit = 1
            ci_active = bool(self._cache_inhibit)

            if was_evaluating and not i['dcqmem_cycstb_i']:
                self.state = 'IDLE'
                self._hitmiss_eval = 0
                self._load = 0
                self._store = 0
            elif i['biudata_error']:
                self.state = 'IDLE'
                self._hitmiss_eval = 0
                self._load = 0
                self._store = 0
            elif ci_active:
                self._hitmiss_eval = 0
                if i['biudata_valid']:
                    self.state = 'IDLE'
                    self._load = 0
                    self._store = 0
            elif was_evaluating and not i['tagcomp_miss']:
                self.state = 'IDLE'
                self._hitmiss_eval = 0
                self._load = 0
                self._store = 0
            elif i['tagcomp_miss'] and i['biudata_valid']:
                self.state = 'LREFILL3'
                self._hitmiss_eval = 0
                self._saved_addr = self.mask(
                    (self._saved_addr & 0xFFFFFFF3)
                    | ((((self._saved_addr >> 2) + 1) & 0x3) << 2),
                    32,
                )
                self._cnt = 2
            else:
                # The tag result has been sampled; the miss transfer continues
                # with load asserted and hit/miss evaluation no longer active.
                self._hitmiss_eval = 0
            return

        if self.state == 'LREFILL3':
            if i['biudata_valid']:
                if self._cnt != 0:
                    self._cnt -= 1
                    self._saved_addr = self.mask(
                        (self._saved_addr & 0xFFFFFFF3)
                        | ((((self._saved_addr >> 2) + 1) & 0x3) << 2),
                        32,
                    )
                else:
                    self.state = 'IDLE'
                    self._load = 0
                    self._hitmiss_eval = 0
            return

        if self.state == 'CSTORE':
            was_evaluating = bool(self._hitmiss_eval)
            ci_seen = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            if ci_seen:
                self._cache_inhibit = 1
            ci_active = bool(self._cache_inhibit)

            if was_evaluating and not i['dcqmem_cycstb_i']:
                self.state = 'IDLE'
                self._hitmiss_eval = 0
                self._store = 0
                self._load = 0
            elif i['biudata_error']:
                self.state = 'IDLE'
                self._hitmiss_eval = 0
                self._store = 0
                self._load = 0
            elif ci_active:
                self._hitmiss_eval = 0
                if i['biudata_valid']:
                    self.state = 'IDLE'
                    self._store = 0
                    self._load = 0
            elif i['biudata_valid']:
                self._hitmiss_eval = 0
                if i['tagcomp_miss'] and self._store_refill:
                    self.state = 'SREFILL4'
                    self._store = 0
                    self._load = 1
                    self._cnt = 3
                else:
                    self.state = 'IDLE'
                    self._store = 0
                    self._load = 0
            else:
                self._hitmiss_eval = 0
            return

        if self.state == 'SREFILL4':
            if i['biudata_valid']:
                if self._cnt != 0:
                    self._cnt -= 1
                    self._saved_addr = self.mask(
                        (self._saved_addr & 0xFFFFFFF3)
                        | ((((self._saved_addr >> 2) + 1) & 0x3) << 2),
                        32,
                    )
                else:
                    self.state = 'IDLE'
                    self._load = 0
                    self._hitmiss_eval = 0
            return

        self.reset()
