"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.saved_addr_r = 0
        self.cnt = 0
        self.hitmiss_eval_r = 0
        self.store_r = 0
        self.load_r = 0
        self.cache_inhibit_r = 0
        self.idle = True
        self.cload = False
        self.cstore = False
        self.lrefill3 = False
        self.srefill4 = False
        self.hitmiss_eval = False
        self.store = False
        self.load = False
        self.cache_inhibit = False
        self.cnt_nonzero = False
        self.first_store_hit_ack = False

    def _store_refill_enabled(self):
        return bool(getattr(self, 'OR1200_DC_STORE_REFILL', 0))

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        reset_view = bool(i['rst'])
        state = 'IDLE' if reset_view else self.state
        saved_addr = 0 if reset_view else self.saved_addr_r
        cnt = 0 if reset_view else self.cnt
        hitmiss_eval = False if reset_view else bool(self.hitmiss_eval_r)
        store = False if reset_view else bool(self.store_r)
        load = False if reset_view else bool(self.load_r)
        cache_inhibit = False if reset_view else bool(self.cache_inhibit_r)

        ci_seen = (state in ('CLOAD', 'CSTORE') and
                   bool(i['dcqmem_cycstb_i']) and bool(i['dcqmem_ci_i']))
        ci_active = cache_inhibit or ci_seen

        in_idle = state == 'IDLE'
        in_cload = state == 'CLOAD'
        in_cstore = state == 'CSTORE'
        in_lrefill3 = state == 'LREFILL3'
        in_srefill4 = state == 'SREFILL4'

        self.idle = bool(in_idle)
        self.cload = bool(in_cload)
        self.cstore = bool(in_cstore)
        self.lrefill3 = bool(in_lrefill3)
        self.srefill4 = bool(in_srefill4)
        self.hitmiss_eval = bool(hitmiss_eval)
        self.store = bool(store)
        self.load = bool(load)
        self.cache_inhibit = bool(cache_inhibit)
        self.cnt_nonzero = bool(cnt != 0)

        biu_read = bool((hitmiss_eval and bool(i['tagcomp_miss'])) or
                        ((not hitmiss_eval) and load))
        biu_write = bool(store)
        first_store_hit_ack = bool(in_cstore and store and
                                   bool(i['biudata_valid']) and
                                   not bool(i['tagcomp_miss']) and
                                   not ci_active)
        self.first_store_hit_ack = first_store_hit_ack

        load_hit_ack = bool(in_cload and load and
                            not bool(i['tagcomp_miss']) and not ci_active)
        first_hit_ack = bool(load_hit_ack or first_store_hit_ack)
        first_miss_ack = bool((in_cload or in_cstore) and
                              bool(i['biudata_valid']))
        first_miss_err = bool((in_cload or in_cstore) and
                              bool(i['biudata_error']))

        dcram_we = 0
        if load and bool(i['biudata_valid']) and not ci_active:
            dcram_we |= 0xF
        if first_store_hit_ack:
            dcram_we |= self.mask(i['dcqmem_sel_i'], 4)

        tag_we = bool(biu_read and bool(i['biudata_valid']) and not ci_active)
        burst = bool((in_cload and load and bool(i['tagcomp_miss']) and
                      not ci_active) or in_lrefill3 or
                     (in_srefill4 and self._store_refill_enabled()))

        transfer_active = bool(biu_read or biu_write)
        if not hitmiss_eval and transfer_active:
            dc_addr = saved_addr
        else:
            dc_addr = self.mask(i['start_addr'], 32)

        o['saved_addr'] = self.mask(saved_addr, 32)
        o['dcram_we'] = self.mask(dcram_we, 4)
        o['biu_read'] = int(biu_read)
        o['biu_write'] = int(biu_write)
        o['first_hit_ack'] = int(first_hit_ack)
        o['first_miss_ack'] = int(first_miss_ack)
        o['first_miss_err'] = int(first_miss_err)
        o['burst'] = int(burst)
        o['tag_we'] = int(tag_we)
        o['dc_addr'] = self.mask(dc_addr, 32)
        return o

    def advance(self, i):
        if bool(i['rst']):
            self.reset()
            return

        if self.state == 'IDLE':
            if bool(i['dc_en']) and bool(i['dcqmem_cycstb_i']):
                self.saved_addr_r = self.mask(i['start_addr'], 32)
                self.hitmiss_eval_r = 1
                self.cache_inhibit_r = 0
                if bool(i['dcqmem_we_i']):
                    self.store_r = 1
                    self.load_r = 0
                    self.state = 'CSTORE'
                else:
                    self.store_r = 0
                    self.load_r = 1
                    self.state = 'CLOAD'
            return

        if self.state == 'CLOAD':
            if self.hitmiss_eval_r and not bool(i['dcqmem_cycstb_i']):
                self.state = 'IDLE'
                self.hitmiss_eval_r = 0
                self.load_r = 0
                self.store_r = 0
                return
            if bool(i['biudata_error']):
                self.state = 'IDLE'
                self.hitmiss_eval_r = 0
                self.load_r = 0
                self.store_r = 0
                return

            ci_seen = bool(i['dcqmem_cycstb_i']) and bool(i['dcqmem_ci_i'])
            if ci_seen:
                self.cache_inhibit_r = 1
            ci_active = bool(self.cache_inhibit_r) or ci_seen

            if ci_active:
                self.hitmiss_eval_r = 0
                if bool(i['biudata_valid']):
                    self.state = 'IDLE'
                    self.load_r = 0
                    self.store_r = 0
                return

            if not bool(i['tagcomp_miss']):
                self.state = 'IDLE'
                self.hitmiss_eval_r = 0
                self.load_r = 0
                self.store_r = 0
            elif bool(i['biudata_valid']):
                self.state = 'LREFILL3'
                self.hitmiss_eval_r = 0
                self.saved_addr_r = self.mask(
                    (self.saved_addr_r & 0xFFFFFFF3) |
                    ((((self.saved_addr_r >> 2) + 1) & 0x3) << 2), 32)
                self.cnt = 2
            else:
                self.hitmiss_eval_r = 0
            return

        if self.state == 'CSTORE':
            if self.hitmiss_eval_r and not bool(i['dcqmem_cycstb_i']):
                self.state = 'IDLE'
                self.hitmiss_eval_r = 0
                self.store_r = 0
                self.load_r = 0
                return
            if bool(i['biudata_error']):
                self.state = 'IDLE'
                self.hitmiss_eval_r = 0
                self.store_r = 0
                self.load_r = 0
                return

            ci_seen = bool(i['dcqmem_cycstb_i']) and bool(i['dcqmem_ci_i'])
            if ci_seen:
                self.cache_inhibit_r = 1
            ci_active = bool(self.cache_inhibit_r) or ci_seen
            self.hitmiss_eval_r = 0

            if bool(i['biudata_valid']):
                if ci_active:
                    self.state = 'IDLE'
                    self.store_r = 0
                    self.load_r = 0
                elif bool(i['tagcomp_miss']):
                    if self._store_refill_enabled():
                        self.state = 'SREFILL4'
                        self.store_r = 0
                        self.load_r = 1
                        self.cnt = 3
                    else:
                        self.state = 'IDLE'
                        self.store_r = 0
                        self.load_r = 0
                else:
                    self.state = 'IDLE'
                    self.store_r = 0
                    self.load_r = 0
            return

        if self.state == 'LREFILL3':
            if bool(i['biudata_valid']):
                if self.cnt != 0:
                    self.cnt -= 1
                    self.saved_addr_r = self.mask(
                        (self.saved_addr_r & 0xFFFFFFF3) |
                        ((((self.saved_addr_r >> 2) + 1) & 0x3) << 2), 32)
                else:
                    self.state = 'IDLE'
                    self.load_r = 0
                    self.store_r = 0
            return

        if self.state == 'SREFILL4':
            if bool(i['biudata_valid']):
                if self.cnt != 0:
                    self.cnt -= 1
                    self.saved_addr_r = self.mask(
                        (self.saved_addr_r & 0xFFFFFFF3) |
                        ((((self.saved_addr_r >> 2) + 1) & 0x3) << 2), 32)
                else:
                    self.state = 'IDLE'
                    self.load_r = 0
                    self.store_r = 0
            return
