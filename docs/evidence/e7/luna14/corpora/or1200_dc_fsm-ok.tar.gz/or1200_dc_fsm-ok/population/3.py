"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.saved_addr_r = 0
        self.cnt = 0
        self.hitmiss_eval = False
        self.store = False
        self.load = False
        self.cache_inhibit = False
        self.store_refill_enabled = False
        self.idle = True
        self.cload = False
        self.cstore = False
        self.lrefill3 = False
        self.srefill4 = False
        self.cnt_nonzero = False
        self.first_store_hit_ack = False


    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        self.idle = (self.state == 'IDLE')
        self.cload = (self.state == 'CLOAD')
        self.cstore = (self.state == 'CSTORE')
        self.lrefill3 = (self.state == 'LREFILL3')
        self.srefill4 = (self.state == 'SREFILL4')
        self.cnt_nonzero = (self.cnt != 0)

        observed_ci = bool(
            self.state in ('CLOAD', 'CSTORE')
            and i['dcqmem_cycstb_i']
            and i['dcqmem_ci_i']
        )
        ci_now = bool(self.cache_inhibit or observed_ci)

        self.first_store_hit_ack = bool(
            self.state == 'CSTORE'
            and self.store
            and i['biudata_valid']
            and not i['tagcomp_miss']
            and not ci_now
        )

        biu_read = bool(
            self.load
            and (
                (self.hitmiss_eval and i['tagcomp_miss'])
                or not self.hitmiss_eval
                or ci_now
            )
        )
        biu_write = bool(self.store)
        first_hit_ack = bool(
            (self.state == 'CLOAD' and self.load and not i['tagcomp_miss'] and not ci_now)
            or self.first_store_hit_ack
        )

        o['saved_addr'] = self.mask(self.saved_addr_r, 32)
        o['biu_read'] = int(biu_read)
        o['biu_write'] = int(biu_write)
        o['first_hit_ack'] = int(first_hit_ack)
        o['first_miss_ack'] = int(
            self.state in ('CLOAD', 'CSTORE') and bool(i['biudata_valid'])
        )
        o['first_miss_err'] = int(
            self.state in ('CLOAD', 'CSTORE') and bool(i['biudata_error'])
        )
        o['burst'] = int(
            (self.state == 'CLOAD' and self.load and i['tagcomp_miss'] and not ci_now)
            or self.state == 'LREFILL3'
            or (self.store_refill_enabled and self.state == 'SREFILL4')
        )

        refill_write = bool(self.load and i['biudata_valid'] and not ci_now)
        store_write = bool(self.first_store_hit_ack)
        o['dcram_we'] = self.mask(
            (0xF if refill_write else 0)
            | (self.mask(i['dcqmem_sel_i'], 4) if store_write else 0),
            4
        )
        o['tag_we'] = int(bool(biu_read and i['biudata_valid'] and not ci_now))

        transfer_active = bool(biu_read or biu_write)
        if not self.hitmiss_eval and transfer_active:
            o['dc_addr'] = self.mask(self.saved_addr_r, 32)
        else:
            o['dc_addr'] = self.mask(i['start_addr'], 32)
        return o


    def advance(self, i):
        if i['rst']:
            self.reset()
            return

        if self.state == 'IDLE':
            if i['dc_en'] and i['dcqmem_cycstb_i']:
                self.saved_addr_r = self.mask(i['start_addr'], 32)
                self.hitmiss_eval = True
                self.store = bool(i['dcqmem_we_i'])
                self.load = not bool(i['dcqmem_we_i'])
                self.cache_inhibit = False
                self.cnt = 0
                if i['dcqmem_we_i']:
                    self.state = 'CSTORE'
                else:
                    self.state = 'CLOAD'
            return

        if self.state == 'CLOAD':
            if i['biudata_error']:
                self.state = 'IDLE'
                self.load = False
                self.hitmiss_eval = False
                return

            if self.hitmiss_eval and not i['dcqmem_cycstb_i']:
                self.state = 'IDLE'
                self.load = False
                self.hitmiss_eval = False
                return

            observed_ci = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            if observed_ci:
                self.cache_inhibit = True

            if self.cache_inhibit or observed_ci:
                self.hitmiss_eval = False
                if i['biudata_valid']:
                    self.state = 'IDLE'
                    self.load = False
                return

            if self.hitmiss_eval and not i['tagcomp_miss']:
                self.state = 'IDLE'
                self.load = False
                self.hitmiss_eval = False
                return

            if self.hitmiss_eval and i['tagcomp_miss'] and i['biudata_valid']:
                self.state = 'LREFILL3'
                self.hitmiss_eval = False
                self.saved_addr_r = self.mask(
                    (self.saved_addr_r & ~0xC)
                    | ((((self.saved_addr_r >> 2) + 1) & 0x3) << 2),
                    32
                )
                self.cnt = 2
            return

        if self.state == 'CSTORE':
            if i['biudata_error']:
                self.state = 'IDLE'
                self.store = False
                self.hitmiss_eval = False
                return

            if self.hitmiss_eval and not i['dcqmem_cycstb_i']:
                self.state = 'IDLE'
                self.store = False
                self.hitmiss_eval = False
                return

            observed_ci = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            if observed_ci:
                self.cache_inhibit = True
            if self.cache_inhibit or observed_ci:
                self.hitmiss_eval = False
                if i['biudata_valid']:
                    self.state = 'IDLE'
                    self.store = False
                return

            # Hit/miss evaluation is complete while the write-through response is pending.
            self.hitmiss_eval = False
            if i['biudata_valid']:
                if i['tagcomp_miss'] and self.store_refill_enabled:
                    self.state = 'SREFILL4'
                    self.store = False
                    self.load = True
                    self.hitmiss_eval = False
                    self.cnt = 3
                else:
                    self.state = 'IDLE'
                    self.store = False
                    self.load = False
            return

        if self.state == 'LREFILL3' or self.state == 'SREFILL4':
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    self.saved_addr_r = self.mask(
                        (self.saved_addr_r & ~0xC)
                        | ((((self.saved_addr_r >> 2) + 1) & 0x3) << 2),
                        32
                    )
                else:
                    self.state = 'IDLE'
                    self.load = False
            return
