"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self._state = 'IDLE'
        self._saved_addr = 0
        self._cnt = 0
        self._hitmiss_eval = 0
        self._store = 0
        self._load = 0
        self._cache_inhibit = 0
        self._store_refill = False
        self.idle = False
        self.cload = False
        self.cstore = False
        self.lrefill3 = False
        self.srefill4 = False
        self.hitmiss_eval = False
        self.store = False
        self.load = False
        self.cache_inhibit = False
        self.cnt_nonzero = False
        self.first_store_hit_ack = False

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        if i['rst']:
            state = 'IDLE'
            saved_addr = 0
            cnt = 0
            hitmiss_eval = 0
            store = 0
            load = 0
            cache_inhibit = 0
        else:
            state = self._state
            saved_addr = self._saved_addr
            cnt = self._cnt
            hitmiss_eval = self._hitmiss_eval
            store = self._store
            load = self._load
            cache_inhibit = self._cache_inhibit

        in_cload = state == 'CLOAD'
        in_cstore = state == 'CSTORE'
        ci_now = bool(cache_inhibit or ((in_cload or in_cstore) and i['dcqmem_cycstb_i'] and i['dcqmem_ci_i']))

        biu_read = int((in_cload and hitmiss_eval and i['tagcomp_miss'] and not ci_now) or (not hitmiss_eval and load))
        biu_write = int(bool(store))
        first_store_hit_ack = bool(in_cstore and i['biudata_valid'] and not i['tagcomp_miss'] and not ci_now)
        load_hit_ack = bool(in_cload and hitmiss_eval and not i['tagcomp_miss'] and not ci_now)
        first_hit_ack = int(load_hit_ack or first_store_hit_ack)
        first_miss_ack = int((in_cload or in_cstore) and bool(i['biudata_valid']))
        first_miss_err = int((in_cload or in_cstore) and bool(i['biudata_error']))

        dcram_we = 0
        if load and i['biudata_valid'] and not ci_now:
            dcram_we |= 15
        if first_store_hit_ack:
            dcram_we |= self.mask(i['dcqmem_sel_i'], 4)

        burst = int((in_cload and i['tagcomp_miss'] and not ci_now) or state == 'LREFILL3' or (self._store_refill and state == 'SREFILL4'))
        tag_we = int(bool(biu_read and i['biudata_valid'] and not ci_now))
        transfer_active = bool(biu_read or biu_write)
        if hitmiss_eval or not transfer_active:
            dc_addr = i['start_addr']
        else:
            dc_addr = saved_addr

        o['saved_addr'] = self.mask(saved_addr, 32)
        o['dcram_we'] = self.mask(dcram_we, 4)
        o['biu_read'] = biu_read
        o['biu_write'] = biu_write
        o['first_hit_ack'] = first_hit_ack
        o['first_miss_ack'] = first_miss_ack
        o['first_miss_err'] = first_miss_err
        o['burst'] = burst
        o['tag_we'] = tag_we
        o['dc_addr'] = self.mask(dc_addr, 32)

        self.idle = state == 'IDLE'
        self.cload = in_cload
        self.cstore = in_cstore
        self.lrefill3 = state == 'LREFILL3'
        self.srefill4 = state == 'SREFILL4'
        self.hitmiss_eval = bool(hitmiss_eval)
        self.store = bool(store)
        self.load = bool(load)
        self.cache_inhibit = bool(cache_inhibit)
        self.cnt_nonzero = bool(cnt != 0)
        self.first_store_hit_ack = first_store_hit_ack
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return

        if self._state == 'IDLE':
            if i['dc_en'] and i['dcqmem_cycstb_i']:
                self._saved_addr = self.mask(i['start_addr'], 32)
                self._hitmiss_eval = 1
                self._cache_inhibit = 0
                if i['dcqmem_we_i']:
                    self._state = 'CSTORE'
                    self._store = 1
                    self._load = 0
                else:
                    self._state = 'CLOAD'
                    self._store = 0
                    self._load = 1
            return

        if self._state == 'CLOAD':
            ci_seen = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            ci_now = bool(self._cache_inhibit or ci_seen)
            if i['biudata_error'] or (self._hitmiss_eval and not i['dcqmem_cycstb_i']):
                self._state = 'IDLE'
                self._hitmiss_eval = 0
                self._store = 0
                self._load = 0
                self._cache_inhibit = 0
            else:
                if ci_seen:
                    self._cache_inhibit = 1
                if ci_now:
                    self._hitmiss_eval = 0
                    if i['biudata_valid']:
                        self._state = 'IDLE'
                        self._store = 0
                        self._load = 0
                        self._cache_inhibit = 0
                elif self._hitmiss_eval and not i['tagcomp_miss']:
                    self._state = 'IDLE'
                    self._hitmiss_eval = 0
                    self._store = 0
                    self._load = 0
                    self._cache_inhibit = 0
                elif self._hitmiss_eval:
                    self._hitmiss_eval = 0
                    if i['biudata_valid']:
                        self._state = 'LREFILL3'
                        self._cnt = 2
                        self._saved_addr = self.mask((self._saved_addr & ~12) | ((((self._saved_addr >> 2) + 1) & 3) << 2), 32)
                elif i['biudata_valid']:
                    self._state = 'LREFILL3'
                    self._cnt = 2
                    self._saved_addr = self.mask((self._saved_addr & ~12) | ((((self._saved_addr >> 2) + 1) & 3) << 2), 32)
            return

        if self._state == 'CSTORE':
            ci_seen = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            ci_now = bool(self._cache_inhibit or ci_seen)
            if i['biudata_error'] or (self._hitmiss_eval and not i['dcqmem_cycstb_i']):
                self._state = 'IDLE'
                self._hitmiss_eval = 0
                self._store = 0
                self._load = 0
                self._cache_inhibit = 0
            else:
                if ci_seen:
                    self._cache_inhibit = 1
                if ci_now:
                    self._hitmiss_eval = 0
                    if i['biudata_valid']:
                        self._state = 'IDLE'
                        self._store = 0
                        self._load = 0
                        self._cache_inhibit = 0
                else:
                    self._hitmiss_eval = 0
                    if i['biudata_valid']:
                        if i['tagcomp_miss'] and self._store_refill:
                            self._state = 'SREFILL4'
                            self._store = 0
                            self._load = 1
                            self._cnt = 3
                        else:
                            self._state = 'IDLE'
                            self._store = 0
                            self._load = 0
                            self._cache_inhibit = 0
            return

        if self._state == 'LREFILL3' or self._state == 'SREFILL4':
            if i['biudata_valid']:
                if self._cnt != 0:
                    self._cnt -= 1
                    self._saved_addr = self.mask((self._saved_addr & ~12) | ((((self._saved_addr >> 2) + 1) & 3) << 2), 32)
                else:
                    self._state = 'IDLE'
                    self._hitmiss_eval = 0
                    self._store = 0
                    self._load = 0
                    self._cache_inhibit = 0
            return
