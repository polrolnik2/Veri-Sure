"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.saved_addr_r = 0
        self.cnt = 0
        self.hitmiss_eval_r = 0
        self.store_r = 0
        self.load_r = 0
        self.cache_inhibit_r = 0
        self.store_refill = False
        self.idle = True
        self.cload = False
        self.cstore = False
        self.lrefill3 = False
        self.srefill4 = False
        self.hitmiss_eval = False
        self.store = False
        self.load = False
        self.cache_inhibit = False
        self.cnt_nonzero = False
        self.first_store_hit_ack = False

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        if i['rst']:
            state = 'IDLE'
            saved_addr = 0
            cnt = 0
            hitmiss_eval = 0
            store = 0
            load = 0
            cache_inhibit = 0
        else:
            state = self.state
            saved_addr = self.saved_addr_r
            cnt = self.cnt
            hitmiss_eval = self.hitmiss_eval_r
            store = self.store_r
            load = self.load_r
            cache_inhibit = self.cache_inhibit_r

        ci_now = bool(cache_inhibit or (
            state in ('CLOAD', 'CSTORE')
            and i['dcqmem_cycstb_i']
            and i['dcqmem_ci_i']
        ))
        first_store_hit_ack = bool(
            state == 'CSTORE'
            and store
            and i['biudata_valid']
            and not i['tagcomp_miss']
            and not ci_now
        )
        biu_read = bool(
            (state == 'CLOAD' and hitmiss_eval and i['tagcomp_miss'])
            or (not hitmiss_eval and load)
        )
        biu_write = bool(store)

        self.idle = state == 'IDLE'
        self.cload = state == 'CLOAD'
        self.cstore = state == 'CSTORE'
        self.lrefill3 = state == 'LREFILL3'
        self.srefill4 = state == 'SREFILL4'
        self.hitmiss_eval = bool(hitmiss_eval)
        self.store = bool(store)
        self.load = bool(load)
        self.cache_inhibit = bool(cache_inhibit)
        self.cnt_nonzero = bool(cnt > 0)
        self.first_store_hit_ack = first_store_hit_ack

        load_hit_ack = bool(
            state == 'CLOAD'
            and load
            and not i['tagcomp_miss']
            and not ci_now
        )
        dcram_we = 0
        if load and i['biudata_valid'] and not ci_now:
            dcram_we = 0xF
        if first_store_hit_ack:
            dcram_we |= self.mask(i['dcqmem_sel_i'], 4)

        burst = bool(
            (state == 'CLOAD' and load and i['tagcomp_miss'] and not ci_now)
            or state == 'LREFILL3'
            or (state == 'SREFILL4' and self.store_refill)
        )

        transfer_active = bool(biu_read or biu_write)
        if not hitmiss_eval and transfer_active:
            dc_addr = saved_addr
        else:
            dc_addr = i['start_addr']

        o['saved_addr'] = self.mask(saved_addr, 32)
        o['dcram_we'] = self.mask(dcram_we, 4)
        o['biu_read'] = int(biu_read)
        o['biu_write'] = int(biu_write)
        o['first_hit_ack'] = int(bool(load_hit_ack or first_store_hit_ack))
        o['first_miss_ack'] = int(bool(
            state in ('CLOAD', 'CSTORE') and i['biudata_valid']
        ))
        o['first_miss_err'] = int(bool(
            state in ('CLOAD', 'CSTORE') and i['biudata_error']
        ))
        o['burst'] = int(burst)
        o['tag_we'] = int(bool(biu_read and i['biudata_valid'] and not ci_now))
        o['dc_addr'] = self.mask(dc_addr, 32)
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return

        if self.state == 'IDLE':
            if i['dc_en'] and i['dcqmem_cycstb_i']:
                self.saved_addr_r = self.mask(i['start_addr'], 32)
                self.hitmiss_eval_r = 1
                self.cache_inhibit_r = 0
                if i['dcqmem_we_i']:
                    self.state = 'CSTORE'
                    self.store_r = 1
                    self.load_r = 0
                else:
                    self.state = 'CLOAD'
                    self.store_r = 0
                    self.load_r = 1
            return

        if self.state == 'CLOAD':
            eval_active = bool(self.hitmiss_eval_r)
            ci_now = bool(
                self.cache_inhibit_r
                or (i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            )
            if i['dcqmem_cycstb_i'] and i['dcqmem_ci_i']:
                self.cache_inhibit_r = 1
            self.hitmiss_eval_r = 0

            if (eval_active and not i['dcqmem_cycstb_i']) or i['biudata_error']:
                self.state = 'IDLE'
                self.load_r = 0
                self.store_r = 0
                self.cache_inhibit_r = 0
            elif ci_now:
                if i['biudata_valid']:
                    self.state = 'IDLE'
                    self.load_r = 0
                    self.store_r = 0
                    self.cache_inhibit_r = 0
            elif not i['tagcomp_miss']:
                self.state = 'IDLE'
                self.load_r = 0
                self.store_r = 0
                self.cache_inhibit_r = 0
            elif i['biudata_valid']:
                self.state = 'LREFILL3'
                self.saved_addr_r = self.mask(
                    (self.saved_addr_r & 0xFFFFFFF3)
                    | ((((self.saved_addr_r >> 2) + 1) & 0x3) << 2),
                    32
                )
                self.cnt = 2
            return

        if self.state == 'CSTORE':
            eval_active = bool(self.hitmiss_eval_r)
            ci_now = bool(
                self.cache_inhibit_r
                or (i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            )
            if i['dcqmem_cycstb_i'] and i['dcqmem_ci_i']:
                self.cache_inhibit_r = 1
            self.hitmiss_eval_r = 0

            if (eval_active and not i['dcqmem_cycstb_i']) or i['biudata_error']:
                self.state = 'IDLE'
                self.store_r = 0
                self.load_r = 0
                self.cache_inhibit_r = 0
            elif ci_now:
                if i['biudata_valid']:
                    self.state = 'IDLE'
                    self.store_r = 0
                    self.load_r = 0
                    self.cache_inhibit_r = 0
            elif i['biudata_valid']:
                if i['tagcomp_miss'] and self.store_refill:
                    self.state = 'SREFILL4'
                    self.store_r = 0
                    self.load_r = 1
                    self.cnt = 3
                else:
                    self.state = 'IDLE'
                    self.store_r = 0
                    self.load_r = 0
                    self.cache_inhibit_r = 0
            return

        if self.state == 'LREFILL3' or self.state == 'SREFILL4':
            if i['biudata_valid']:
                if self.cnt > 0:
                    self.cnt -= 1
                    self.saved_addr_r = self.mask(
                        (self.saved_addr_r & 0xFFFFFFF3)
                        | ((((self.saved_addr_r >> 2) + 1) & 0x3) << 2),
                        32
                    )
                else:
                    self.state = 'IDLE'
                    self.load_r = 0
                    self.store_r = 0
                    self.cache_inhibit_r = 0
            return
