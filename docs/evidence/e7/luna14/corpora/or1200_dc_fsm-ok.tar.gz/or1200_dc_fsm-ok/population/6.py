"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.saved_addr_r = 0
        self.cnt = 0
        self.hitmiss_eval_r = 0
        self.store_r = 0
        self.load_r = 0
        self.cache_inhibit_r = 0
        self.store_refill_enabled = False
        self.idle = True
        self.cload = False
        self.cstore = False
        self.lrefill3 = False
        self.srefill4 = False
        self.hitmiss_eval = False
        self.store = False
        self.load = False
        self.cache_inhibit = False
        self.cnt_nonzero = False
        self.first_store_hit_ack = False

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        reset_active = bool(i['rst'])
        if reset_active:
            state = 'IDLE'
            saved_addr = 0
            cnt = 0
            hitmiss_eval = 0
            store = 0
            load = 0
            cache_inhibit = 0
        else:
            state = self.state
            saved_addr = self.saved_addr_r
            cnt = self.cnt
            hitmiss_eval = self.hitmiss_eval_r
            store = self.store_r
            load = self.load_r
            cache_inhibit = self.cache_inhibit_r

        observed_ci = (
            state in ('CLOAD', 'CSTORE')
            and bool(i['dcqmem_cycstb_i'])
            and bool(i['dcqmem_ci_i'])
        )
        ci_active = bool(cache_inhibit or observed_ci)

        load_hit_ack = (
            state == 'CLOAD'
            and bool(load)
            and bool(hitmiss_eval)
            and not bool(i['tagcomp_miss'])
            and not ci_active
        )
        first_store_hit_ack = (
            state == 'CSTORE'
            and bool(store)
            and bool(i['biudata_valid'])
            and not bool(i['tagcomp_miss'])
            and not ci_active
        )
        first_hit_ack = bool(load_hit_ack or first_store_hit_ack)

        biu_read = bool(
            load
            and (
                (bool(hitmiss_eval) and bool(i['tagcomp_miss']))
                or not bool(hitmiss_eval)
            )
        )
        biu_write = bool(store)

        if not bool(hitmiss_eval) and (biu_read or biu_write):
            dc_addr = saved_addr
        else:
            dc_addr = i['start_addr']

        if load and bool(i['biudata_valid']) and not ci_active:
            dcram_we = 0xF
        elif first_store_hit_ack:
            dcram_we = self.mask(i['dcqmem_sel_i'], 4)
        else:
            dcram_we = 0

        first_access_state = state in ('CLOAD', 'CSTORE')
        burst = bool(
            (state == 'CLOAD' and bool(i['tagcomp_miss']) and not ci_active)
            or state == 'LREFILL3'
            or (state == 'SREFILL4' and self.store_refill_enabled)
        )

        o['saved_addr'] = self.mask(saved_addr, 32)
        o['dcram_we'] = self.mask(dcram_we, 4)
        o['biu_read'] = int(biu_read)
        o['biu_write'] = int(biu_write)
        o['first_hit_ack'] = int(first_hit_ack)
        o['first_miss_ack'] = int(first_access_state and bool(i['biudata_valid']))
        o['first_miss_err'] = int(first_access_state and bool(i['biudata_error']))
        o['burst'] = int(burst)
        o['tag_we'] = int(biu_read and bool(i['biudata_valid']) and not ci_active)
        o['dc_addr'] = self.mask(dc_addr, 32)

        self.idle = bool(state == 'IDLE')
        self.cload = bool(state == 'CLOAD')
        self.cstore = bool(state == 'CSTORE')
        self.lrefill3 = bool(state == 'LREFILL3')
        self.srefill4 = bool(state == 'SREFILL4')
        self.hitmiss_eval = bool(hitmiss_eval)
        self.store = bool(store)
        self.load = bool(load)
        self.cache_inhibit = bool(cache_inhibit)
        self.cnt_nonzero = bool(cnt != 0)
        self.first_store_hit_ack = bool(first_store_hit_ack)

        return o

    def advance(self, i):
        if bool(i['rst']):
            self.reset()
            return

        state = self.state

        if state == 'IDLE':
            if bool(i['dc_en']) and bool(i['dcqmem_cycstb_i']):
                self.saved_addr_r = self.mask(i['start_addr'], 32)
                self.hitmiss_eval_r = 1
                self.cache_inhibit_r = 0
                if bool(i['dcqmem_we_i']):
                    self.store_r = 1
                    self.load_r = 0
                    self.state = 'CSTORE'
                else:
                    self.store_r = 0
                    self.load_r = 1
                    self.state = 'CLOAD'
            return

        if state in ('CLOAD', 'CSTORE'):
            observed_ci = bool(i['dcqmem_cycstb_i']) and bool(i['dcqmem_ci_i'])
            if observed_ci:
                self.cache_inhibit_r = 1
            ci_active = bool(self.cache_inhibit_r or observed_ci)

            if self.hitmiss_eval_r and not bool(i['dcqmem_cycstb_i']):
                self.state = 'IDLE'
                self.hitmiss_eval_r = 0
                self.store_r = 0
                self.load_r = 0
                return

            if bool(i['biudata_error']):
                self.state = 'IDLE'
                self.hitmiss_eval_r = 0
                self.store_r = 0
                self.load_r = 0
                return

            if state == 'CLOAD':
                evaluating = bool(self.hitmiss_eval_r)
                if evaluating:
                    self.hitmiss_eval_r = 0
                    if not ci_active and not bool(i['tagcomp_miss']):
                        self.state = 'IDLE'
                        self.store_r = 0
                        self.load_r = 0
                        return

                if ci_active:
                    if bool(i['biudata_valid']):
                        self.state = 'IDLE'
                        self.hitmiss_eval_r = 0
                        self.store_r = 0
                        self.load_r = 0
                    return

                if bool(i['biudata_valid']):
                    self.state = 'LREFILL3'
                    self.saved_addr_r = self.mask(
                        (self.saved_addr_r & ~0xC)
                        | ((((self.saved_addr_r >> 2) + 1) & 0x3) << 2),
                        32,
                    )
                    self.cnt = 2
                return

            if self.hitmiss_eval_r:
                self.hitmiss_eval_r = 0

            if ci_active and bool(i['biudata_valid']):
                self.state = 'IDLE'
                self.hitmiss_eval_r = 0
                self.store_r = 0
                self.load_r = 0
                return

            if bool(i['biudata_valid']):
                if bool(i['tagcomp_miss']) and self.store_refill_enabled:
                    self.state = 'SREFILL4'
                    self.store_r = 0
                    self.load_r = 1
                    self.cnt = 3
                else:
                    self.state = 'IDLE'
                    self.hitmiss_eval_r = 0
                    self.store_r = 0
                    self.load_r = 0
                return

            return

        if state == 'LREFILL3':
            if bool(i['biudata_valid']):
                if self.cnt != 0:
                    self.cnt -= 1
                    self.saved_addr_r = self.mask(
                        (self.saved_addr_r & ~0xC)
                        | ((((self.saved_addr_r >> 2) + 1) & 0x3) << 2),
                        32,
                    )
                else:
                    self.state = 'IDLE'
                    self.load_r = 0
            return

        if state == 'SREFILL4':
            if bool(i['biudata_valid']):
                if self.cnt != 0:
                    self.cnt -= 1
                    self.saved_addr_r = self.mask(
                        (self.saved_addr_r & ~0xC)
                        | ((((self.saved_addr_r >> 2) + 1) & 0x3) << 2),
                        32,
                    )
                else:
                    self.state = 'IDLE'
                    self.load_r = 0
            return
