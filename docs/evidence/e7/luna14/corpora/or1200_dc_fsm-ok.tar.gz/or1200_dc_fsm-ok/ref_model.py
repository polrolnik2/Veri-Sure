"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.saved_addr_r = 0
        self.cnt = 0
        self.hitmiss_eval = False
        self.store = False
        self.load = False
        self.cache_inhibit = False
        self.store_refill = False
        self.idle = True
        self.cload = False
        self.cstore = False
        self.lrefill3 = False
        self.srefill4 = False
        self.cnt_nonzero = False
        self.first_store_hit_ack = False

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        state = self.state
        in_cload = state == 'CLOAD'
        in_cstore = state == 'CSTORE'
        in_lrefill3 = state == 'LREFILL3'
        in_srefill4 = state == 'SREFILL4'
        live_cache_inhibit = bool(self.cache_inhibit)
        if (in_cload or in_cstore) and i['dcqmem_cycstb_i'] and i['dcqmem_ci_i']:
            live_cache_inhibit = True

        self.idle = state == 'IDLE'
        self.cload = in_cload
        self.cstore = in_cstore
        self.lrefill3 = in_lrefill3
        self.srefill4 = in_srefill4
        self.hitmiss_eval = bool(self.hitmiss_eval)
        self.store = bool(self.store)
        self.load = bool(self.load)
        self.cache_inhibit = bool(self.cache_inhibit)
        self.cnt_nonzero = bool(self.cnt != 0)

        biu_read = bool(
            self.load and (
                (self.hitmiss_eval and i['tagcomp_miss'])
                or not self.hitmiss_eval
                or (in_cload and live_cache_inhibit)
            )
        )
        if in_srefill4 and not self.store_refill:
            biu_read = False
        biu_write = bool(self.store)

        self.first_store_hit_ack = bool(
            in_cstore
            and self.store
            and i['biudata_valid']
            and not i['tagcomp_miss']
            and not live_cache_inhibit
        )
        load_hit_ack = bool(
            in_cload
            and self.load
            and not i['tagcomp_miss']
            and not live_cache_inhibit
        )
        first_hit_ack = bool(load_hit_ack or self.first_store_hit_ack)
        first_miss_ack = bool(
            (in_cload or in_cstore) and i['biudata_valid']
        )
        first_miss_err = bool(
            (in_cload or in_cstore) and i['biudata_error']
        )

        burst = bool(
            (in_cload and self.load and i['tagcomp_miss'] and not live_cache_inhibit)
            or in_lrefill3
            or (in_srefill4 and self.store_refill)
        )
        if self.load and i['biudata_valid'] and not live_cache_inhibit and biu_read:
            dcram_we = 0xF
        elif self.first_store_hit_ack:
            dcram_we = self.mask(i['dcqmem_sel_i'], 4)
        else:
            dcram_we = 0

        tag_we = bool(biu_read and i['biudata_valid'] and not live_cache_inhibit)
        post_eval_transfer = bool(biu_read or biu_write)
        if self.hitmiss_eval or not post_eval_transfer:
            dc_addr = self.mask(i['start_addr'], 32)
        else:
            dc_addr = self.mask(self.saved_addr_r, 32)

        o['saved_addr'] = self.mask(self.saved_addr_r, 32)
        o['dcram_we'] = self.mask(dcram_we, 4)
        o['biu_read'] = int(biu_read)
        o['biu_write'] = int(biu_write)
        o['first_hit_ack'] = int(first_hit_ack)
        o['first_miss_ack'] = int(first_miss_ack)
        o['first_miss_err'] = int(first_miss_err)
        o['burst'] = int(burst)
        o['tag_we'] = int(tag_we)
        o['dc_addr'] = self.mask(dc_addr, 32)
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return

        if self.state == 'IDLE':
            if i['dc_en'] and i['dcqmem_cycstb_i']:
                self.saved_addr_r = self.mask(i['start_addr'], 32)
                self.hitmiss_eval = True
                self.store = bool(i['dcqmem_we_i'])
                self.load = not bool(i['dcqmem_we_i'])
                self.cache_inhibit = False
                self.cnt = 0
                self.state = 'CSTORE' if i['dcqmem_we_i'] else 'CLOAD'
            return

        if self.state == 'CLOAD':
            eval_active = bool(self.hitmiss_eval)
            live_cache_inhibit = bool(self.cache_inhibit)
            if i['dcqmem_cycstb_i'] and i['dcqmem_ci_i']:
                live_cache_inhibit = True
                self.cache_inhibit = True

            if eval_active and not i['dcqmem_cycstb_i']:
                self.state = 'IDLE'
                self.load = False
                self.hitmiss_eval = False
            elif i['biudata_error']:
                self.state = 'IDLE'
                self.load = False
                self.hitmiss_eval = False
            elif live_cache_inhibit and i['biudata_valid']:
                self.state = 'IDLE'
                self.load = False
                self.hitmiss_eval = False
            elif not live_cache_inhibit and not i['tagcomp_miss']:
                self.state = 'IDLE'
                self.load = False
                self.hitmiss_eval = False
            elif not live_cache_inhibit and i['tagcomp_miss'] and i['biudata_valid']:
                self.state = 'LREFILL3'
                self.hitmiss_eval = False
                self.saved_addr_r = self.mask(
                    (self.saved_addr_r & 0xFFFFFFF3)
                    | ((((self.saved_addr_r >> 2) + 1) & 0x3) << 2),
                    32,
                )
                self.cnt = 2
            else:
                self.hitmiss_eval = False
            return

        if self.state == 'CSTORE':
            eval_active = bool(self.hitmiss_eval)
            live_cache_inhibit = bool(self.cache_inhibit)
            if i['dcqmem_cycstb_i'] and i['dcqmem_ci_i']:
                live_cache_inhibit = True
                self.cache_inhibit = True

            if eval_active and not i['dcqmem_cycstb_i']:
                self.state = 'IDLE'
                self.store = False
                self.hitmiss_eval = False
            elif i['biudata_error']:
                self.state = 'IDLE'
                self.store = False
                self.load = False
                self.hitmiss_eval = False
            elif live_cache_inhibit and i['biudata_valid']:
                self.state = 'IDLE'
                self.store = False
                self.hitmiss_eval = False
            elif i['biudata_valid']:
                self.hitmiss_eval = False
                if i['tagcomp_miss'] and self.store_refill:
                    self.state = 'SREFILL4'
                    self.store = False
                    self.load = True
                    self.cnt = 3
                else:
                    self.state = 'IDLE'
                    self.store = False
                    self.load = False
            else:
                self.hitmiss_eval = False
            return

        if self.state == 'LREFILL3':
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    self.saved_addr_r = self.mask(
                        (self.saved_addr_r & 0xFFFFFFF3)
                        | ((((self.saved_addr_r >> 2) + 1) & 0x3) << 2),
                        32,
                    )
                else:
                    self.state = 'IDLE'
                    self.load = False
            return

        if self.state == 'SREFILL4':
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    self.saved_addr_r = self.mask(
                        (self.saved_addr_r & 0xFFFFFFF3)
                        | ((((self.saved_addr_r >> 2) + 1) & 0x3) << 2),
                        32,
                    )
                else:
                    self.state = 'IDLE'
                    self.load = False
            return
