"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.saved_addr_r = 0
        self.cnt = 0
        self.hitmiss_eval = 0
        self.store = 0
        self.load = 0
        self.cache_inhibit = 0
        self.store_refill = False
        self.idle = True
        self.cload = False
        self.cstore = False
        self.lrefill3 = False
        self.srefill4 = False
        self.cnt_nonzero = False
        self.first_store_hit_ack = False

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        # An asserted asynchronous reset is already observable at this sample.
        resetting = bool(i['rst'])
        state = 'IDLE' if resetting else self.state
        saved_addr = 0 if resetting else self.saved_addr_r
        hitmiss_eval = 0 if resetting else self.hitmiss_eval
        store = 0 if resetting else self.store
        load = 0 if resetting else self.load
        cache_inhibit = 0 if resetting else self.cache_inhibit
        cnt = 0 if resetting else self.cnt

        ci_seen_now = bool(
            not resetting
            and state in ('CLOAD', 'CSTORE')
            and i['dcqmem_cycstb_i']
            and i['dcqmem_ci_i']
        )
        effective_ci = bool(cache_inhibit or ci_seen_now)
        tag_miss = bool(i['tagcomp_miss'])
        data_valid = bool(i['biudata_valid'])

        biu_read = bool((hitmiss_eval and tag_miss) or ((not hitmiss_eval) and load))
        biu_write = bool(store)
        first_store_hit_ack = bool(
            state == 'CSTORE'
            and data_valid
            and not tag_miss
            and not effective_ci
        )
        first_hit_ack = bool(
            (state == 'CLOAD' and not tag_miss and not effective_ci)
            or first_store_hit_ack
        )
        first_miss_ack = bool(state in ('CLOAD', 'CSTORE') and data_valid)
        first_miss_err = bool(
            state in ('CLOAD', 'CSTORE') and i['biudata_error']
        )

        dcram_we = 0
        if load and data_valid and not effective_ci:
            dcram_we |= 0xF
        if first_store_hit_ack:
            dcram_we |= self.mask(i['dcqmem_sel_i'], 4)

        tag_we = bool(biu_read and data_valid and not effective_ci)
        burst = bool(
            (state == 'CLOAD' and load and tag_miss and not effective_ci)
            or state == 'LREFILL3'
            or (state == 'SREFILL4' and self.store_refill)
        )

        post_evaluation_transfer = bool(
            not hitmiss_eval and (biu_read or biu_write)
        )
        dc_addr = saved_addr if post_evaluation_transfer else i['start_addr']

        o['saved_addr'] = self.mask(saved_addr, 32)
        o['dcram_we'] = self.mask(dcram_we, 4)
        o['biu_read'] = int(biu_read)
        o['biu_write'] = int(biu_write)
        o['first_hit_ack'] = int(first_hit_ack)
        o['first_miss_ack'] = int(first_miss_ack)
        o['first_miss_err'] = int(first_miss_err)
        o['burst'] = int(burst)
        o['tag_we'] = int(tag_we)
        o['dc_addr'] = self.mask(dc_addr, 32)

        # These are the observation attributes declared as probes by the contract.
        self.idle = bool(state == 'IDLE')
        self.cload = bool(state == 'CLOAD')
        self.cstore = bool(state == 'CSTORE')
        self.lrefill3 = bool(state == 'LREFILL3')
        self.srefill4 = bool(state == 'SREFILL4')
        self.hitmiss_eval = bool(hitmiss_eval)
        self.store = bool(store)
        self.load = bool(load)
        self.cache_inhibit = bool(cache_inhibit)
        self.cnt_nonzero = bool(cnt != 0)
        self.first_store_hit_ack = bool(first_store_hit_ack)
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return

        state = self.state
        if state == 'IDLE':
            if i['dc_en'] and i['dcqmem_cycstb_i']:
                self.saved_addr_r = self.mask(i['start_addr'], 32)
                self.hitmiss_eval = 1
                self.cache_inhibit = 0
                self.cnt = 0
                if i['dcqmem_we_i']:
                    self.state = 'CSTORE'
                    self.store = 1
                    self.load = 0
                else:
                    self.state = 'CLOAD'
                    self.store = 0
                    self.load = 1
            return

        if state == 'CLOAD':
            if self.hitmiss_eval and not i['dcqmem_cycstb_i']:
                self.state = 'IDLE'
                self.hitmiss_eval = 0
                self.load = 0
                self.store = 0
                self.cache_inhibit = 0
                return
            if i['biudata_error']:
                self.state = 'IDLE'
                self.hitmiss_eval = 0
                self.load = 0
                self.store = 0
                self.cache_inhibit = 0
                return

            ci_seen = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            if ci_seen:
                self.cache_inhibit = 1
            if self.cache_inhibit or ci_seen:
                self.hitmiss_eval = 0
                if i['biudata_valid']:
                    self.state = 'IDLE'
                    self.load = 0
                    self.store = 0
                    self.cache_inhibit = 0
                return

            if self.hitmiss_eval and not i['tagcomp_miss']:
                self.state = 'IDLE'
                self.hitmiss_eval = 0
                self.load = 0
                self.store = 0
                self.cache_inhibit = 0
                return

            # A miss has been evaluated. Keep the request active while the BIU
            # supplies its first word, then enter the remaining-word refill state.
            self.hitmiss_eval = 0
            if i['biudata_valid']:
                self.state = 'LREFILL3'
                self.saved_addr_r = self.mask(
                    (self.saved_addr_r & 0xFFFFFFF3)
                    | ((((self.saved_addr_r >> 2) + 1) & 0x3) << 2),
                    32,
                )
                self.cnt = 2
            return

        if state == 'CSTORE':
            if self.hitmiss_eval and not i['dcqmem_cycstb_i']:
                self.state = 'IDLE'
                self.hitmiss_eval = 0
                self.store = 0
                self.load = 0
                self.cache_inhibit = 0
                return
            if i['biudata_error']:
                self.state = 'IDLE'
                self.hitmiss_eval = 0
                self.store = 0
                self.load = 0
                self.cache_inhibit = 0
                return

            ci_seen = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            if ci_seen:
                self.cache_inhibit = 1
            if self.hitmiss_eval:
                self.hitmiss_eval = 0

            if i['biudata_valid']:
                if self.cache_inhibit or ci_seen:
                    self.state = 'IDLE'
                    self.store = 0
                    self.load = 0
                    self.hitmiss_eval = 0
                    self.cache_inhibit = 0
                elif i['tagcomp_miss'] and self.store_refill:
                    self.state = 'SREFILL4'
                    self.store = 0
                    self.load = 1
                    self.hitmiss_eval = 0
                    self.cnt = 3
                    # Store refill deliberately starts at the current word offset.
                else:
                    self.state = 'IDLE'
                    self.store = 0
                    self.load = 0
                    self.hitmiss_eval = 0
                    self.cache_inhibit = 0
            return

        if state == 'LREFILL3':
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    self.saved_addr_r = self.mask(
                        (self.saved_addr_r & 0xFFFFFFF3)
                        | ((((self.saved_addr_r >> 2) + 1) & 0x3) << 2),
                        32,
                    )
                else:
                    self.state = 'IDLE'
                    self.load = 0
                    self.store = 0
                    self.hitmiss_eval = 0
                    self.cache_inhibit = 0
            return

        if state == 'SREFILL4':
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    self.saved_addr_r = self.mask(
                        (self.saved_addr_r & 0xFFFFFFF3)
                        | ((((self.saved_addr_r >> 2) + 1) & 0x3) << 2),
                        32,
                    )
                else:
                    self.state = 'IDLE'
                    self.load = 0
                    self.store = 0
                    self.hitmiss_eval = 0
                    self.cache_inhibit = 0
            return
