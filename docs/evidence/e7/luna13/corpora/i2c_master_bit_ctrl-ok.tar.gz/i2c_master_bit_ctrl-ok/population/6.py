"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence', 'write_stable_high_phase', 'read_sample_window', 'cscl', 'csda', 'filter_cnt_expired', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'sscl_rise', 'sta_condition', 'sto_condition', 'slave_wait', 'scl_sync', 'cnt_zero', 'clk_en', 'sda_chk']
    PROBE_WIDTHS = {'idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1, 'write_stable_high_phase': 1, 'read_sample_window': 1, 'cscl': 1, 'csda': 1, 'filter_cnt_expired': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'sscl_rise': 1, 'sta_condition': 1, 'sto_condition': 1, 'slave_wait': 1, 'scl_sync': 1, 'cnt_zero': 1, 'clk_en': 1, 'sda_chk': 1}
    LATENCY_CYCLES = 0

    def _reset_state(self):
        self.state = 'IDLE'
        self.op = None
        self.cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0
        self.scl_oen = 1
        self.sda_oen = 1
        self.cSCL_meta = 1
        self.cSCL = 1
        self.cSDA_meta = 1
        self.cSDA = 1
        self.fSCL = 7
        self.fSDA = 7
        self.dSCL = 1
        self.dSDA = 1
        self.filter_cnt = 0
        self.cnt = 0
        self.clk_en = 1

    def reset(self):
        self._reset_state()

    def _majority3(self, value):
        return int((((value >> 0) & 1) + ((value >> 1) & 1) + ((value >> 2) & 1)) >= 2)

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        async_reset = not (i['nReset'] & 1)

        if async_reset:
            state = 'IDLE'
            ack = 0
            busy = 0
            al = 0
            dout = 0
            scl_oen = 1
            sda_oen = 1
            fscl = 7
            fsda = 7
            sscl = 1
            ssda = 1
            dscl = 1
            dsda = 1
            cscl = 1
            csda = 1
            cnt = 0
            clk_en = 1
            filter_expired = 0
        else:
            state = self.state
            ack = self.cmd_ack
            busy = self.busy
            al = self.al
            dout = self.dout
            scl_oen = self.scl_oen
            sda_oen = self.sda_oen
            fscl = self.fSCL & 7
            fsda = self.fSDA & 7
            sscl = self._majority3(fscl)
            ssda = self._majority3(fsda)
            dscl = self.dSCL & 1
            dsda = self.dSDA & 1
            cscl = self.cSCL & 1
            csda = self.cSDA & 1
            cnt = self.cnt & 65535
            clk_en = self.clk_en & 1
            filter_expired = bool(self.filter_cnt == 0 and (i['ena'] & 1))

        sscl_rise = bool(sscl and not dscl)
        sta_condition = bool((not ssda) and dsda and sscl)
        sto_condition = bool(ssda and (not dsda) and sscl)
        slave_wait = bool(scl_oen and (not sscl))
        scl_sync = bool(scl_oen and dscl and (not sscl))
        sda_chk = bool(state == 'WRITE_HIGH')

        self.idle = bool(state == 'IDLE')
        self.fsm_active = bool(state != 'IDLE')
        self.in_start_sequence = bool(state in ('START_RELEASE', 'START_SDA_LOW'))
        self.in_stop_sequence = bool(state in ('STOP_SDA_LOW', 'STOP_SCL_HIGH', 'STOP_SDA_HIGH'))
        self.in_read_sequence = bool(state in ('READ_SETUP', 'READ_HIGH', 'READ_LOW'))
        self.in_write_sequence = bool(state in ('WRITE_SETUP', 'WRITE_HIGH', 'WRITE_LOW'))
        self.write_stable_high_phase = bool(state == 'WRITE_HIGH')
        self.read_sample_window = bool(state == 'READ_HIGH')
        self.cscl = cscl
        self.csda = csda
        self.filter_cnt_expired = bool(filter_expired)
        self.fscl = fscl
        self.fsda = fsda
        self.sscl = sscl
        self.ssda = ssda
        self.dscl = dscl
        self.dsda = dsda
        self.sscl_rise = sscl_rise
        self.sta_condition = sta_condition
        self.sto_condition = sto_condition
        self.slave_wait = slave_wait
        self.scl_sync = scl_sync
        self.cnt_zero = bool(cnt == 0)
        self.clk_en = bool(clk_en)
        self.sda_chk = sda_chk

        o['cmd_ack'] = ack
        o['busy'] = busy
        o['al'] = al
        o['dout'] = dout
        o['scl_o'] = 0
        o['scl_oen'] = scl_oen
        o['sda_o'] = 0
        o['sda_oen'] = sda_oen
        return o

    def advance(self, i):
        if not (i['nReset'] & 1):
            self._reset_state()
            return
        if i['rst'] & 1:
            self._reset_state()
            return

        ena = i['ena'] & 1
        clk_cnt = self.mask(i['clk_cnt'], 16)
        old_state = self.state
        old_op = self.op
        old_clk_en = self.clk_en & 1
        old_filter_cnt = self.filter_cnt
        old_cSCL = self.cSCL
        old_cSDA = self.cSDA
        sscl = self._majority3(self.fSCL)
        ssda = self._majority3(self.fSDA)
        dscl = self.dSCL & 1
        dsda = self.dSDA & 1
        sscl_rise = bool(sscl and not dscl)
        sta_condition = bool((not ssda) and dsda and sscl)
        sto_condition = bool(ssda and (not dsda) and sscl)
        slave_wait = bool(self.scl_oen and (not sscl))
        scl_sync = bool(self.scl_oen and dscl and (not sscl))
        sda_chk = bool(old_state == 'WRITE_HIGH')

        arbitration_lost = bool(
            (sda_chk and self.sda_oen and (not ssda)) or
            (sto_condition and old_state != 'IDLE' and old_op != 'STOP')
        )

        self.cmd_ack = 0

        if sta_condition:
            self.busy = 1
        elif sto_condition:
            self.busy = 0

        if sscl_rise:
            self.dout = ssda

        self.dSCL = sscl
        self.dSDA = ssda

        self.cSCL_meta = i['scl_i'] & 1
        self.cSCL = old_cSCL if False else old_cSCL
        self.cSDA_meta = i['sda_i'] & 1
        self.cSDA = old_cSDA

        if not ena:
            self.filter_cnt = 0
        elif old_filter_cnt == 0:
            self.filter_cnt = self.mask(clk_cnt >> 2, 16)
            self.fSCL = self.mask(((self.fSCL << 1) | old_cSCL), 3)
            self.fSDA = self.mask(((self.fSDA << 1) | old_cSDA), 3)
        else:
            self.filter_cnt = self.mask(old_filter_cnt - 1, 16)

        if not ena:
            self.cnt = clk_cnt
            self.clk_en = 1
        elif scl_sync:
            self.cnt = clk_cnt
            self.clk_en = 1
        elif slave_wait:
            self.cnt = self.mask(self.cnt, 16)
            self.clk_en = 0
        elif self.cnt == 0:
            self.cnt = clk_cnt
            self.clk_en = 1
        else:
            self.cnt = self.mask(self.cnt - 1, 16)
            self.clk_en = 0

        if arbitration_lost:
            self.al = 1
            self.state = 'IDLE'
            self.op = None
            self.scl_oen = 1
            self.sda_oen = 1
        elif ena and old_clk_en and not slave_wait:
            if old_state == 'IDLE':
                cmd = i['cmd'] & 15
                if cmd == 1:
                    self.state = 'START_RELEASE'
                    self.op = 'START'
                    self.scl_oen = 1
                    self.sda_oen = 1
                elif cmd == 2:
                    self.state = 'STOP_SDA_LOW'
                    self.op = 'STOP'
                    self.scl_oen = 0
                    self.sda_oen = 0
                elif cmd == 4:
                    self.state = 'WRITE_SETUP'
                    self.op = 'WRITE'
                    self.scl_oen = 0
                    self.sda_oen = 1 if (i['din'] & 1) else 0
                elif cmd == 8:
                    self.state = 'READ_SETUP'
                    self.op = 'READ'
                    self.scl_oen = 0
                    self.sda_oen = 1
            elif old_state == 'START_RELEASE':
                self.state = 'START_SDA_LOW'
                self.sda_oen = 0
            elif old_state == 'START_SDA_LOW':
                self.state = 'IDLE'
                self.op = None
                self.scl_oen = 0
                self.cmd_ack = 1
            elif old_state == 'STOP_SDA_LOW':
                self.state = 'STOP_SCL_HIGH'
                self.scl_oen = 1
            elif old_state == 'STOP_SCL_HIGH':
                self.state = 'STOP_SDA_HIGH'
                self.sda_oen = 1
            elif old_state == 'STOP_SDA_HIGH':
                self.state = 'IDLE'
                self.op = None
                self.cmd_ack = 1
            elif old_state == 'READ_SETUP':
                self.state = 'READ_HIGH'
                self.scl_oen = 1
                self.sda_oen = 1
            elif old_state == 'READ_HIGH':
                self.state = 'READ_LOW'
                self.scl_oen = 0
            elif old_state == 'READ_LOW':
                self.state = 'IDLE'
                self.op = None
                self.cmd_ack = 1
            elif old_state == 'WRITE_SETUP':
                self.state = 'WRITE_HIGH'
                self.scl_oen = 1
            elif old_state == 'WRITE_HIGH':
                self.state = 'WRITE_LOW'
                self.scl_oen = 0
            elif old_state == 'WRITE_LOW':
                self.state = 'IDLE'
                self.op = None
                self.cmd_ack = 1
