"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence', 'write_stable_high_phase', 'read_sample_window', 'cscl', 'csda', 'filter_cnt_expired', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'sscl_rise', 'sta_condition', 'sto_condition', 'slave_wait', 'scl_sync', 'cnt_zero', 'clk_en', 'sda_chk']
    PROBE_WIDTHS = {'idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1, 'write_stable_high_phase': 1, 'read_sample_window': 1, 'cscl': 1, 'csda': 1, 'filter_cnt_expired': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'sscl_rise': 1, 'sta_condition': 1, 'sto_condition': 1, 'slave_wait': 1, 'scl_sync': 1, 'cnt_zero': 1, 'clk_en': 1, 'sda_chk': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'idle'
        self.cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0
        self.scl_oen = 1
        self.sda_oen = 1
        self._cnt = 0
        self._clk_en = 1
        self._filter_cnt = 0
        self._sync_scl_1 = 1
        self._sync_scl_2 = 1
        self._sync_sda_1 = 1
        self._sync_sda_2 = 1
        self._fscl = 7
        self._fsda = 7
        self._dscl = 1
        self._dsda = 1

    def _majority(self, value):
        return int(((value >> 2) & 1) + ((value >> 1) & 1) + (value & 1) >= 2)

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        reset_view = (i['nReset'] == 0)

        if reset_view:
            state = 'idle'
            cmd_ack = 0
            busy = 0
            al = 0
            dout = 0
            scl_oen = 1
            sda_oen = 1
            cnt = 0
            clk_en = 1
            filter_cnt = 0
            sync_scl_2 = 1
            sync_sda_2 = 1
            fscl = 7
            fsda = 7
            dscl = 1
            dsda = 1
        else:
            state = self.state
            cmd_ack = self.cmd_ack
            busy = self.busy
            al = self.al
            dout = self.dout
            scl_oen = self.scl_oen
            sda_oen = self.sda_oen
            cnt = self._cnt
            clk_en = self._clk_en
            filter_cnt = self._filter_cnt
            sync_scl_2 = self._sync_scl_2
            sync_sda_2 = self._sync_sda_2
            fscl = self._fscl
            fsda = self._fsda
            dscl = self._dscl
            dsda = self._dsda

        sscl = self._majority(fscl)
        ssda = self._majority(fsda)
        sscl_rise = bool(sscl and not dscl)
        sta_condition = bool((not ssda) and dsda and sscl)
        sto_condition = bool(ssda and (not dsda) and sscl)
        slave_wait = bool((not reset_view) and scl_oen and not sscl)
        scl_sync = bool((not reset_view) and scl_oen and dscl and not sscl)
        filter_cnt_expired = bool((not reset_view) and i['ena'] and filter_cnt == 0)
        sda_chk = bool(state == 'wr_c')

        self.idle = (state == 'idle')
        self.fsm_active = (state != 'idle')
        self.in_start_sequence = state in ('start_a', 'start_b', 'start_c')
        self.in_stop_sequence = state in ('stop_a', 'stop_b', 'stop_c')
        self.in_read_sequence = state in ('rd_a', 'rd_b', 'rd_c', 'rd_d')
        self.in_write_sequence = state in ('wr_a', 'wr_b', 'wr_c', 'wr_d')
        self.write_stable_high_phase = bool(state == 'wr_c' and scl_oen)
        self.read_sample_window = bool(state in ('rd_c', 'rd_d') and scl_oen)
        self.cscl = bool(sync_scl_2)
        self.csda = bool(sync_sda_2)
        self.filter_cnt_expired = filter_cnt_expired
        self.fscl = fscl & 7
        self.fsda = fsda & 7
        self.sscl = bool(sscl)
        self.ssda = bool(ssda)
        self.dscl = bool(dscl)
        self.dsda = bool(dsda)
        self.sscl_rise = sscl_rise
        self.sta_condition = sta_condition
        self.sto_condition = sto_condition
        self.slave_wait = slave_wait
        self.scl_sync = scl_sync
        self.cnt_zero = bool(cnt == 0)
        self.clk_en = bool(clk_en)
        self.sda_chk = sda_chk

        o['cmd_ack'] = int(cmd_ack)
        o['busy'] = int(busy)
        o['al'] = int(al)
        o['dout'] = int(dout)
        o['scl_o'] = 0
        o['scl_oen'] = int(scl_oen)
        o['sda_o'] = 0
        o['sda_oen'] = int(sda_oen)
        return o

    def advance(self, i):
        if i['nReset'] == 0 or i['rst'] != 0:
            self.reset()
            return

        state = self.state
        sscl = self._majority(self._fscl)
        ssda = self._majority(self._fsda)
        sscl_rise = bool(sscl and not self._dscl)
        sta_condition = bool((not ssda) and self._dsda and sscl)
        sto_condition = bool(ssda and (not self._dsda) and sscl)
        slave_wait = bool(self.scl_oen and not sscl)
        scl_sync = bool(self.scl_oen and self._dscl and not sscl)
        sda_chk = (state == 'wr_c')
        unexpected_stop = bool(sto_condition and state != 'idle' and state not in ('stop_a', 'stop_b', 'stop_c'))
        arbitration_lost = bool((sda_chk and self.sda_oen and not ssda) or unexpected_stop)
        old_al = self.al
        old_tick = self._clk_en
        old_sync_scl_2 = self._sync_scl_2
        old_sync_sda_2 = self._sync_sda_2
        old_cnt = self._cnt

        self.cmd_ack = 0
        if sta_condition:
            self.busy = 1
        elif sto_condition:
            self.busy = 0
        if sscl_rise:
            self.dout = int(ssda)

        self._dscl = int(sscl)
        self._dsda = int(ssda)
        self._sync_scl_1 = int(i['scl_i']) & 1
        self._sync_scl_2 = old_sync_scl_2 if False else int(self._sync_scl_1 if False else old_sync_scl_2)
        self._sync_scl_2 = int(self._sync_scl_1 if False else old_sync_scl_2)
        self._sync_sda_1 = int(i['sda_i']) & 1
        self._sync_sda_2 = old_sync_sda_2

        if not i['ena']:
            self._filter_cnt = 0
        elif self._filter_cnt == 0:
            self._filter_cnt = self.mask(i['clk_cnt'] >> 2, 16)
            self._fscl = self.mask((self._fscl << 1) | old_sync_scl_2, 3)
            self._fsda = self.mask((self._fsda << 1) | old_sync_sda_2, 3)
        else:
            self._filter_cnt = self.mask(self._filter_cnt - 1, 16)

        if not i['ena'] or scl_sync:
            self._cnt = self.mask(i['clk_cnt'], 16)
            self._clk_en = 1
        elif slave_wait:
            self._cnt = old_cnt
            self._clk_en = 0
        elif old_cnt == 0:
            self._cnt = self.mask(i['clk_cnt'], 16)
            self._clk_en = 1
        else:
            self._cnt = self.mask(old_cnt - 1, 16)
            self._clk_en = 0

        if arbitration_lost:
            self.al = 1
            self.state = 'idle'
            self.scl_oen = 1
            self.sda_oen = 1
        elif old_tick and i['ena'] and not slave_wait and not old_al:
            if state == 'idle':
                command = self.mask(i['cmd'], 4)
                if command == 1:
                    self.state = 'start_a'
                elif command == 2:
                    self.state = 'stop_a'
                elif command == 4:
                    self.state = 'wr_a'
                elif command == 8:
                    self.state = 'rd_a'
            elif state == 'start_a':
                self.scl_oen = 1
                self.sda_oen = 1
                self.state = 'start_b'
            elif state == 'start_b':
                self.sda_oen = 0
                self.state = 'start_c'
            elif state == 'start_c':
                self.scl_oen = 0
                self.state = 'idle'
                self.cmd_ack = 1
            elif state == 'stop_a':
                self.scl_oen = 0
                self.sda_oen = 0
                self.state = 'stop_b'
            elif state == 'stop_b':
                self.scl_oen = 1
                self.state = 'stop_c'
            elif state == 'stop_c':
                self.sda_oen = 1
                self.state = 'idle'
                self.cmd_ack = 1
            elif state == 'rd_a':
                self.scl_oen = 0
                self.sda_oen = 1
                self.state = 'rd_b'
            elif state == 'rd_b':
                self.scl_oen = 1
                self.state = 'rd_c'
            elif state == 'rd_c':
                self.state = 'rd_d'
            elif state == 'rd_d':
                self.scl_oen = 0
                self.state = 'idle'
                self.cmd_ack = 1
            elif state == 'wr_a':
                self.scl_oen = 0
                self.sda_oen = int(i['din']) & 1
                self.state = 'wr_b'
            elif state == 'wr_b':
                self.scl_oen = 1
                self.sda_oen = int(i['din']) & 1
                self.state = 'wr_c'
            elif state == 'wr_c':
                self.sda_oen = int(i['din']) & 1
                self.state = 'wr_d'
            elif state == 'wr_d':
                self.scl_oen = 0
                self.sda_oen = int(i['din']) & 1
                self.state = 'idle'
                self.cmd_ack = 1
