"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence', 'write_stable_high_phase', 'read_sample_window', 'cscl', 'csda', 'filter_cnt_expired', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'sscl_rise', 'sta_condition', 'sto_condition', 'slave_wait', 'scl_sync', 'cnt_zero', 'clk_en', 'sda_chk']
    PROBE_WIDTHS = {'idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1, 'write_stable_high_phase': 1, 'read_sample_window': 1, 'cscl': 1, 'csda': 1, 'filter_cnt_expired': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'sscl_rise': 1, 'sta_condition': 1, 'sto_condition': 1, 'slave_wait': 1, 'scl_sync': 1, 'cnt_zero': 1, 'clk_en': 1, 'sda_chk': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'idle'
        self.active_cmd = 0
        self.write_bit = 0
        self.cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0
        self.scl_oen_reg = 1
        self.sda_oen_reg = 1
        self.cnt = 0
        self.clk_en = 1
        self.filter_cnt = 0
        self._sync_scl = 1
        self._sync_sda = 1
        self.cSCL = 1
        self.cSDA = 1
        self.fscl_reg = 7
        self.fsda_reg = 7
        self.dSCL = 1
        self.dSDA = 1

    def _phase_lines(self, state):
        if state == 'sta_release':
            return (1, 1)
        if state == 'sta_sda_low':
            return (1, 0)
        if state == 'sta_scl_low':
            return (0, 0)
        if state == 'sto_sda_low':
            return (0, 0)
        if state == 'sto_scl_high':
            return (1, 0)
        if state == 'sto_sda_high':
            return (1, 1)
        if state == 'read_prepare':
            return (0, 1)
        if state == 'read_high':
            return (1, 1)
        if state == 'read_low':
            return (0, 1)
        if state == 'write_prepare':
            return (0, 1 - self.write_bit)
        if state == 'write_high':
            return (1, 1 - self.write_bit)
        if state == 'write_low':
            return (0, 1 - self.write_bit)
        return None

    def _set_phase(self, state):
        self.state = state
        lines = self._phase_lines(state)
        if lines is not None:
            self.scl_oen_reg, self.sda_oen_reg = lines

    def _signals(self, i):
        fscl = self.fscl_reg
        fsda = self.fsda_reg
        sscl = int(((fscl & 1) + ((fscl >> 1) & 1) + ((fscl >> 2) & 1)) >= 2)
        ssda = int(((fsda & 1) + ((fsda >> 1) & 1) + ((fsda >> 2) & 1)) >= 2)
        scl_oen = int(self.scl_oen_reg)
        sda_oen = int(self.sda_oen_reg)
        state = self.state
        sta = int((not ssda) and self.dSDA and sscl)
        sto = int(ssda and (not self.dSDA) and sscl)
        scl_sync = int(scl_oen and self.dSCL and (not sscl))
        slave_wait = int(scl_oen and (not sscl))
        p = {
            'idle': int(state == 'idle'),
            'fsm_active': int(state != 'idle'),
            'in_start_sequence': int(state in ('sta_release', 'sta_sda_low', 'sta_scl_low')),
            'in_stop_sequence': int(state in ('sto_sda_low', 'sto_scl_high', 'sto_sda_high')),
            'in_read_sequence': int(state in ('read_prepare', 'read_high', 'read_low')),
            'in_write_sequence': int(state in ('write_prepare', 'write_high', 'write_low')),
            'write_stable_high_phase': int(state == 'write_high'),
            'read_sample_window': int(state == 'read_high'),
            'cscl': int(self.cSCL),
            'csda': int(self.cSDA),
            'filter_cnt_expired': int(bool(i['ena']) and self.filter_cnt == 0),
            'fscl': fscl,
            'fsda': fsda,
            'sscl': sscl,
            'ssda': ssda,
            'dscl': int(self.dSCL),
            'dsda': int(self.dSDA),
            'sscl_rise': int(sscl and (not self.dSCL)),
            'sta_condition': sta,
            'sto_condition': sto,
            'slave_wait': slave_wait,
            'scl_sync': scl_sync,
            'cnt_zero': int(self.cnt == 0),
            'clk_en': int(self.clk_en),
            'sda_chk': int(state == 'write_high')
        }
        return p

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        if not i['nReset']:
            o['cmd_ack'] = 0
            o['busy'] = 0
            o['al'] = 0
            o['dout'] = 0
            o['scl_o'] = 0
            o['scl_oen'] = 1
            o['sda_o'] = 0
            o['sda_oen'] = 1
            p = {
                'idle': 1, 'fsm_active': 0,
                'in_start_sequence': 0, 'in_stop_sequence': 0,
                'in_read_sequence': 0, 'in_write_sequence': 0,
                'write_stable_high_phase': 0, 'read_sample_window': 0,
                'cscl': 1, 'csda': 1, 'filter_cnt_expired': 0,
                'fscl': 7, 'fsda': 7, 'sscl': 1, 'ssda': 1,
                'dscl': 1, 'dsda': 1, 'sscl_rise': 0,
                'sta_condition': 0, 'sto_condition': 0,
                'slave_wait': 0, 'scl_sync': 0, 'cnt_zero': 1,
                'clk_en': 1, 'sda_chk': 0
            }
        else:
            o['cmd_ack'] = int(self.cmd_ack)
            o['busy'] = int(self.busy)
            o['al'] = int(self.al)
            o['dout'] = int(self.dout)
            o['scl_o'] = 0
            o['scl_oen'] = int(self.scl_oen_reg)
            o['sda_o'] = 0
            o['sda_oen'] = int(self.sda_oen_reg)
            p = self._signals(i)
        for name, value in p.items():
            setattr(self, name, value)
        return o

    def advance(self, i):
        if (not i['nReset']) or i['rst']:
            self.reset()
            return

        sig = self._signals(i)
        old_cSCL = self.cSCL
        old_cSDA = self.cSDA
        self.cSCL = int(self._sync_scl)
        self.cSDA = int(self._sync_sda)
        self._sync_scl = self.mask(i['scl_i'], 1)
        self._sync_sda = self.mask(i['sda_i'], 1)

        if i['ena']:
            if self.filter_cnt == 0:
                self.filter_cnt = self.mask(self.mask(i['clk_cnt'], 16) >> 2, 16)
                self.fscl_reg = self.mask(((self.fscl_reg & 3) << 1) | old_cSCL, 3)
                self.fsda_reg = self.mask(((self.fsda_reg & 3) << 1) | old_cSDA, 3)
            else:
                self.filter_cnt = self.mask(self.filter_cnt - 1, 16)
        else:
            self.filter_cnt = 0

        if sig['sscl_rise']:
            self.dout = int(sig['ssda'])
        self.dSCL = int(sig['sscl'])
        self.dSDA = int(sig['ssda'])

        self.busy = int(self.busy)
        if sig['sta_condition']:
            self.busy = 1
        elif sig['sto_condition']:
            self.busy = 0

        self.cmd_ack = 0
        self.al = 0
        arbitration_loss = bool(sig['fsm_active']) and (
            (bool(sig['sda_chk']) and bool(sig['sda_oen']) and not bool(sig['ssda'])) or
            (bool(sig['sto_condition']) and self.active_cmd != 2)
        )
        if arbitration_loss:
            self.state = 'idle'
            self.active_cmd = 0
            self.scl_oen_reg = 1
            self.sda_oen_reg = 1
            self.al = 1
        elif i['ena'] and sig['clk_en'] and not sig['slave_wait']:
            if self.state == 'idle':
                command = self.mask(i['cmd'], 4)
                if command == 1:
                    self.active_cmd = command
                    self._set_phase('sta_release')
                elif command == 2:
                    self.active_cmd = command
                    self._set_phase('sto_sda_low')
                elif command == 8:
                    self.active_cmd = command
                    self._set_phase('read_prepare')
                elif command == 4:
                    self.active_cmd = command
                    self.write_bit = self.mask(i['din'], 1)
                    self._set_phase('write_prepare')
            elif self.state == 'sta_release':
                self._set_phase('sta_sda_low')
            elif self.state == 'sta_sda_low':
                self._set_phase('sta_scl_low')
            elif self.state == 'sta_scl_low':
                self.state = 'idle'
                self.active_cmd = 0
                self.cmd_ack = 1
            elif self.state == 'sto_sda_low':
                self._set_phase('sto_scl_high')
            elif self.state == 'sto_scl_high':
                self._set_phase('sto_sda_high')
            elif self.state == 'sto_sda_high':
                self.state = 'idle'
                self.active_cmd = 0
                self.cmd_ack = 1
            elif self.state == 'read_prepare':
                self._set_phase('read_high')
            elif self.state == 'read_high':
                self._set_phase('read_low')
            elif self.state == 'read_low':
                self.state = 'idle'
                self.active_cmd = 0
                self.cmd_ack = 1
            elif self.state == 'write_prepare':
                self._set_phase('write_high')
            elif self.state == 'write_high':
                self._set_phase('write_low')
            elif self.state == 'write_low':
                self.state = 'idle'
                self.active_cmd = 0
                self.cmd_ack = 1

        if not i['ena']:
            self.cnt = self.mask(i['clk_cnt'], 16)
            self.clk_en = 1
        elif sig['scl_sync']:
            self.cnt = self.mask(i['clk_cnt'], 16)
            self.clk_en = 1
        elif sig['slave_wait']:
            self.clk_en = 0
        elif self.cnt == 0:
            self.cnt = self.mask(i['clk_cnt'], 16)
            self.clk_en = 1
        else:
            self.cnt = self.mask(self.cnt - 1, 16)
            self.clk_en = 0
