"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence', 'write_stable_high_phase', 'read_sample_window', 'cscl', 'csda', 'filter_cnt_expired', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'sscl_rise', 'sta_condition', 'sto_condition', 'slave_wait', 'scl_sync', 'cnt_zero', 'clk_en', 'sda_chk']
    PROBE_WIDTHS = {'idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1, 'write_stable_high_phase': 1, 'read_sample_window': 1, 'cscl': 1, 'csda': 1, 'filter_cnt_expired': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'sscl_rise': 1, 'sta_condition': 1, 'sto_condition': 1, 'slave_wait': 1, 'scl_sync': 1, 'cnt_zero': 1, 'clk_en': 1, 'sda_chk': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self._state = 'idle'
        self._cmd_ack = 0
        self._busy = 0
        self._al = 0
        self._dout = 0
        self._scl_oen = 1
        self._sda_oen = 1
        self._sda_chk = 0
        self._cnt = 0
        self._clk_en = 1
        self._filter_cnt = 0
        self._meta_scl = 0
        self._meta_sda = 0
        self._cscl = 0
        self._csda = 0
        self._fscl = 7
        self._fsda = 7
        self._dscl = 1
        self._dsda = 1
        self.idle = True
        self.fsm_active = False
        self.in_start_sequence = False
        self.in_stop_sequence = False
        self.in_read_sequence = False
        self.in_write_sequence = False
        self.write_stable_high_phase = False
        self.read_sample_window = False
        self.cscl = 0
        self.csda = 0
        self.filter_cnt_expired = False
        self.fscl = 7
        self.fsda = 7
        self.sscl = 1
        self.ssda = 1
        self.dscl = 1
        self.dsda = 1
        self.sscl_rise = False
        self.sta_condition = False
        self.sto_condition = False
        self.slave_wait = False
        self.scl_sync = False
        self.cnt_zero = True
        self.clk_en = True
        self.sda_chk = False

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        o['scl_o'] = 0
        o['sda_o'] = 0
        if (i['nReset'] & 1) == 0:
            o['cmd_ack'] = 0
            o['busy'] = 0
            o['al'] = 0
            o['dout'] = 0
            o['scl_oen'] = 1
            o['sda_oen'] = 1
            self.idle = True
            self.fsm_active = False
            self.in_start_sequence = False
            self.in_stop_sequence = False
            self.in_read_sequence = False
            self.in_write_sequence = False
            self.write_stable_high_phase = False
            self.read_sample_window = False
            self.cscl = 0
            self.csda = 0
            self.filter_cnt_expired = False
            self.fscl = 7
            self.fsda = 7
            self.sscl = 1
            self.ssda = 1
            self.dscl = 1
            self.dsda = 1
            self.sscl_rise = False
            self.sta_condition = False
            self.sto_condition = False
            self.slave_wait = False
            self.scl_sync = False
            self.cnt_zero = True
            self.clk_en = True
            self.sda_chk = False
            return o

        sscl = int((((self._fscl >> 0) & 1) + ((self._fscl >> 1) & 1) + ((self._fscl >> 2) & 1)) >= 2)
        ssda = int((((self._fsda >> 0) & 1) + ((self._fsda >> 1) & 1) + ((self._fsda >> 2) & 1)) >= 2)
        sscl_rise = bool(sscl and not self._dscl)
        sta = bool((not ssda) and self._dsda and sscl)
        sto = bool(ssda and (not self._dsda) and sscl)
        slave_wait = bool(self._scl_oen and not sscl)
        scl_sync = bool(self._scl_oen and self._dscl and not sscl)

        o['cmd_ack'] = self._cmd_ack
        o['busy'] = self._busy
        o['al'] = self._al
        o['dout'] = self._dout
        o['scl_oen'] = self._scl_oen
        o['sda_oen'] = self._sda_oen

        self.idle = self._state == 'idle'
        self.fsm_active = self._state != 'idle'
        self.in_start_sequence = self._state.startswith('start_')
        self.in_stop_sequence = self._state.startswith('stop_')
        self.in_read_sequence = self._state.startswith('read_')
        self.in_write_sequence = self._state.startswith('write_')
        self.write_stable_high_phase = self._state == 'write_high'
        self.read_sample_window = self._state == 'read_sample'
        self.cscl = self._cscl
        self.csda = self._csda
        self.filter_cnt_expired = bool((i['ena'] & 1) and self._filter_cnt == 0)
        self.fscl = self._fscl
        self.fsda = self._fsda
        self.sscl = sscl
        self.ssda = ssda
        self.dscl = self._dscl
        self.dsda = self._dsda
        self.sscl_rise = sscl_rise
        self.sta_condition = sta
        self.sto_condition = sto
        self.slave_wait = slave_wait
        self.scl_sync = scl_sync
        self.cnt_zero = self._cnt == 0
        self.clk_en = bool(self._clk_en)
        self.sda_chk = bool(self._sda_chk)
        return o

    def advance(self, i):
        if (i['nReset'] & 1) == 0:
            self.reset()
            return
        if i['rst'] & 1:
            self.reset()
            return

        ena = i['ena'] & 1
        clk_cnt = self.mask(i['clk_cnt'], 16)
        tick = bool(self._clk_en)
        old_state = self._state

        sscl = int((((self._fscl >> 0) & 1) + ((self._fscl >> 1) & 1) + ((self._fscl >> 2) & 1)) >= 2)
        ssda = int((((self._fsda >> 0) & 1) + ((self._fsda >> 1) & 1) + ((self._fsda >> 2) & 1)) >= 2)
        sscl_rise = bool(sscl and not self._dscl)
        sta = bool((not ssda) and self._dsda and sscl)
        sto = bool(ssda and (not self._dsda) and sscl)
        slave_wait = bool(self._scl_oen and not sscl)
        scl_sync = bool(self._scl_oen and self._dscl and not sscl)

        if sta:
            self._busy = 1
        elif sto:
            self._busy = 0

        if sscl_rise:
            self._dout = ssda

        self._dscl = sscl
        self._dsda = ssda

        filter_expired = bool(ena and self._filter_cnt == 0)
        old_cscl = self._cscl
        old_csda = self._csda
        if filter_expired:
            self._fscl = ((self._fscl << 1) & 7) | old_cscl
            self._fsda = ((self._fsda << 1) & 7) | old_csda

        old_meta_scl = self._meta_scl
        old_meta_sda = self._meta_sda
        self._cscl = old_meta_scl
        self._csda = old_meta_sda
        self._meta_scl = i['scl_i'] & 1
        self._meta_sda = i['sda_i'] & 1

        if not ena:
            self._filter_cnt = 0
        elif self._filter_cnt == 0:
            self._filter_cnt = (clk_cnt >> 2) & 0x3fff
        else:
            self._filter_cnt = (self._filter_cnt - 1) & 0x3fff

        self._cmd_ack = 0
        arbitration_lost_now = bool((self._sda_chk and self._sda_oen and not ssda) or (sto and old_state != 'idle' and not old_state.startswith('stop_')))
        if self._al:
            self._state = 'idle'
            self._scl_oen = 1
            self._sda_oen = 1
            self._sda_chk = 0
        elif arbitration_lost_now:
            self._al = 1
            self._state = 'idle'
            self._scl_oen = 1
            self._sda_oen = 1
            self._sda_chk = 0
        elif ena and tick and not slave_wait:
            state = self._state
            if state == 'idle':
                cmd = i['cmd'] & 0xf
                if cmd == 1:
                    self._state = 'start_release'
                    self._scl_oen = 1
                    self._sda_oen = 1
                    self._sda_chk = 0
                elif cmd == 2:
                    self._state = 'stop_drive_sda'
                    self._sda_oen = 0
                    self._sda_chk = 0
                elif cmd == 8:
                    self._state = 'read_release_sda'
                    self._sda_oen = 1
                    self._sda_chk = 0
                elif cmd == 4:
                    self._state = 'write_data'
                    self._sda_chk = 0
            elif state == 'start_release':
                self._state = 'start_sda_low'
                self._scl_oen = 1
                self._sda_oen = 0
            elif state == 'start_sda_low':
                self._state = 'start_scl_low'
                self._scl_oen = 0
                self._sda_oen = 0
            elif state == 'start_scl_low':
                self._state = 'idle'
                self._cmd_ack = 1
            elif state == 'stop_drive_sda':
                self._state = 'stop_release_scl'
                self._scl_oen = 1
                self._sda_oen = 0
            elif state == 'stop_release_scl':
                self._state = 'stop_release_sda'
                self._scl_oen = 1
                self._sda_oen = 1
            elif state == 'stop_release_sda':
                self._state = 'idle'
                self._cmd_ack = 1
            elif state == 'read_release_sda':
                self._state = 'read_release_scl'
                self._sda_oen = 1
            elif state == 'read_release_scl':
                self._state = 'read_sample'
                self._scl_oen = 1
            elif state == 'read_sample':
                self._state = 'read_pull_scl'
                self._scl_oen = 0
            elif state == 'read_pull_scl':
                self._state = 'idle'
                self._cmd_ack = 1
            elif state == 'write_data':
                self._state = 'write_release_scl'
                self._sda_oen = i['din'] & 1
            elif state == 'write_release_scl':
                self._state = 'write_high'
                self._scl_oen = 1
                self._sda_chk = 1
            elif state == 'write_high':
                self._state = 'write_pull_scl'
                self._scl_oen = 0
                self._sda_chk = 0
            elif state == 'write_pull_scl':
                self._state = 'idle'
                self._cmd_ack = 1

        if not ena:
            self._cnt = clk_cnt
            self._clk_en = 1
        elif scl_sync:
            self._cnt = clk_cnt
            self._clk_en = 1
        elif slave_wait:
            self._clk_en = 0
        elif self._cnt == 0:
            self._cnt = clk_cnt
            self._clk_en = 1
        else:
            self._cnt = (self._cnt - 1) & 0xffff
            self._clk_en = 0
