"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence', 'write_stable_high_phase', 'read_sample_window', 'cscl', 'csda', 'filter_cnt_expired', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'sscl_rise', 'sta_condition', 'sto_condition', 'slave_wait', 'scl_sync', 'cnt_zero', 'clk_en', 'sda_chk']
    PROBE_WIDTHS = {'idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1, 'write_stable_high_phase': 1, 'read_sample_window': 1, 'cscl': 1, 'csda': 1, 'filter_cnt_expired': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'sscl_rise': 1, 'sta_condition': 1, 'sto_condition': 1, 'slave_wait': 1, 'scl_sync': 1, 'cnt_zero': 1, 'clk_en': 1, 'sda_chk': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self._reset_state()

    def _reset_state(self):
        self.state = 'idle'
        self.scl_oen = 1
        self.sda_oen = 1
        self.cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0
        self.write_bit = 0
        self.cSCL1 = 1
        self.cSDA1 = 1
        self.cSCL = 1
        self.cSDA = 1
        self.fscl = 7
        self.fsda = 7
        self.filter_cnt = 0
        self.dSCL = 1
        self.dSDA = 1
        self.cnt = 0
        self.clk_en = 0

    def _majority(self, history):
        return int(((history >> 0) & 1) + ((history >> 1) & 1) + ((history >> 2) & 1) >= 2)

    def _view(self, i):
        resetting = not (i['nReset'] & 1)
        if resetting:
            state = 'idle'
            scl_oen = 1
            sda_oen = 1
            cmd_ack = 0
            busy = 0
            al = 0
            dout = 0
            cscl = 1
            csda = 1
            fscl = 7
            fsda = 7
            filter_cnt = 0
            dscl = 1
            dsda = 1
            cnt = 0
            clk_en = 0
        else:
            state = self.state
            scl_oen = self.scl_oen
            sda_oen = self.sda_oen
            cmd_ack = self.cmd_ack
            busy = self.busy
            al = self.al
            dout = self.dout
            cscl = self.cSCL
            csda = self.cSDA
            fscl = self.fscl
            fsda = self.fsda
            filter_cnt = self.filter_cnt
            dscl = self.dSCL
            dsda = self.dSDA
            cnt = self.cnt
            clk_en = self.clk_en

        sscl = self._majority(fscl)
        ssda = self._majority(fsda)
        sscl_rise = int(bool(sscl) and not bool(dscl))
        sta_condition = int(not ssda and dsda and sscl)
        sto_condition = int(ssda and not dsda and sscl)
        slave_wait = int(bool(scl_oen) and not bool(sscl))
        scl_sync = int(bool(scl_oen) and bool(dscl) and not bool(sscl))
        filter_cnt_expired = int(not resetting and bool(i['ena'] & 1) and filter_cnt == 0)

        return {
            'state': state,
            'scl_oen': scl_oen,
            'sda_oen': sda_oen,
            'cmd_ack': cmd_ack,
            'busy': busy,
            'al': al,
            'dout': dout,
            'cscl': cscl,
            'csda': csda,
            'filter_cnt_expired': filter_cnt_expired,
            'fscl': fscl,
            'fsda': fsda,
            'sscl': sscl,
            'ssda': ssda,
            'dscl': dscl,
            'dsda': dsda,
            'sscl_rise': sscl_rise,
            'sta_condition': sta_condition,
            'sto_condition': sto_condition,
            'slave_wait': 0 if resetting else slave_wait,
            'scl_sync': 0 if resetting else scl_sync,
            'cnt_zero': int(cnt == 0),
            'clk_en': clk_en,
            'sda_chk': int(not resetting and state == 'write_stable'),
            'idle': int(state == 'idle'),
            'fsm_active': int(state != 'idle'),
            'in_start_sequence': int(state.startswith('start_')),
            'in_stop_sequence': int(state.startswith('stop_')),
            'in_read_sequence': int(state.startswith('read_')),
            'in_write_sequence': int(state.startswith('write_')),
            'write_stable_high_phase': int(state == 'write_stable'),
            'read_sample_window': int(state == 'read_high')
        }

    def outputs(self, i):
        v = self._view(i)
        self.idle = v['idle']
        self.fsm_active = v['fsm_active']
        self.in_start_sequence = v['in_start_sequence']
        self.in_stop_sequence = v['in_stop_sequence']
        self.in_read_sequence = v['in_read_sequence']
        self.in_write_sequence = v['in_write_sequence']
        self.write_stable_high_phase = v['write_stable_high_phase']
        self.read_sample_window = v['read_sample_window']
        self.cscl = v['cscl']
        self.csda = v['csda']
        self.filter_cnt_expired = v['filter_cnt_expired']
        self.fscl = v['fscl']
        self.fsda = v['fsda']
        self.sscl = v['sscl']
        self.ssda = v['ssda']
        self.dscl = v['dscl']
        self.dsda = v['dsda']
        self.sscl_rise = v['sscl_rise']
        self.sta_condition = v['sta_condition']
        self.sto_condition = v['sto_condition']
        self.slave_wait = v['slave_wait']
        self.scl_sync = v['scl_sync']
        self.cnt_zero = v['cnt_zero']
        self.clk_en = v['clk_en']
        self.sda_chk = v['sda_chk']

        o = {p: None for p in self.OUTPUT_PORTS}
        o['cmd_ack'] = v['cmd_ack']
        o['busy'] = v['busy']
        o['al'] = v['al']
        o['dout'] = v['dout']
        o['scl_o'] = 0
        o['scl_oen'] = v['scl_oen']
        o['sda_o'] = 0
        o['sda_oen'] = v['sda_oen']
        return o

    def advance(self, i):
        if not (i['nReset'] & 1) or (i['rst'] & 1):
            self._reset_state()
            return

        v = self._view(i)
        old_cSCL1 = self.cSCL1
        old_cSDA1 = self.cSDA1
        sample_scl = self.cSCL
        sample_sda = self.cSDA

        self.cSCL = old_cSCL1
        self.cSDA = old_cSDA1
        self.cSCL1 = i['scl_i'] & 1
        self.cSDA1 = i['sda_i'] & 1

        interval = ((i['clk_cnt'] & 65535) >> 2) & 16383
        if i['ena'] & 1:
            if self.filter_cnt == 0:
                self.fscl = self.mask((self.fscl << 1) | sample_scl, 3)
                self.fsda = self.mask((self.fsda << 1) | sample_sda, 3)
                self.filter_cnt = interval
            else:
                self.filter_cnt = self.mask(self.filter_cnt - 1, 14)
        else:
            self.filter_cnt = 0

        self.dSCL = v['sscl']
        self.dSDA = v['ssda']
        if v['sscl_rise']:
            self.dout = v['ssda']

        if v['sta_condition']:
            self.busy = 1
        if v['sto_condition']:
            self.busy = 0

        arbitration_loss = bool(v['sda_chk'] and v['sda_oen'] and not v['ssda'])
        unexpected_stop = bool(v['sto_condition'] and v['fsm_active'] and not v['state'].startswith('stop_'))
        lost_now = arbitration_loss or unexpected_stop
        self.al = int(bool(self.al) or lost_now)
        self.cmd_ack = 0

        if lost_now:
            self.state = 'idle'
            self.scl_oen = 1
            self.sda_oen = 1
        elif self.clk_en and (i['ena'] & 1) and not v['slave_wait']:
            if self.state == 'idle':
                cmd = i['cmd'] & 15
                if cmd == 1:
                    self.state = 'start_release'
                    self.scl_oen = 1
                    self.sda_oen = 1
                elif cmd == 2:
                    self.state = 'stop_low'
                    self.sda_oen = 0
                elif cmd == 8:
                    self.state = 'read_data'
                    self.scl_oen = 0
                    self.sda_oen = 1
                elif cmd == 4:
                    self.state = 'write_data'
                    self.write_bit = i['din'] & 1
                    self.scl_oen = 0
                    self.sda_oen = 1 - self.write_bit
            elif self.state == 'start_release':
                self.state = 'start_sda_low'
            elif self.state == 'start_sda_low':
                self.sda_oen = 0
                self.state = 'start_scl_low'
            elif self.state == 'start_scl_low':
                self.scl_oen = 0
                self.state = 'idle'
                self.cmd_ack = 1
            elif self.state == 'stop_low':
                self.scl_oen = 1
                self.state = 'stop_scl_high'
            elif self.state == 'stop_scl_high':
                self.sda_oen = 1
                self.state = 'stop_sda_high'
            elif self.state == 'stop_sda_high':
                self.state = 'idle'
                self.cmd_ack = 1
            elif self.state == 'read_data':
                self.scl_oen = 1
                self.state = 'read_high'
            elif self.state == 'read_high':
                self.scl_oen = 0
                self.state = 'read_low'
            elif self.state == 'read_low':
                self.state = 'idle'
                self.cmd_ack = 1
            elif self.state == 'write_data':
                self.scl_oen = 1
                self.state = 'write_high'
            elif self.state == 'write_high':
                self.state = 'write_stable'
            elif self.state == 'write_stable':
                self.scl_oen = 0
                self.state = 'write_low'
            elif self.state == 'write_low':
                self.state = 'idle'
                self.cmd_ack = 1

        if v['scl_sync']:
            self.cnt = self.mask(i['clk_cnt'], 16)
            self.clk_en = 1
        elif v['slave_wait']:
            self.clk_en = 0
        elif not (i['ena'] & 1):
            self.cnt = self.mask(i['clk_cnt'], 16)
            self.clk_en = 1
        elif self.cnt == 0:
            self.cnt = self.mask(i['clk_cnt'], 16)
            self.clk_en = 1
        else:
            self.cnt = self.mask(self.cnt - 1, 16)
            self.clk_en = 0
