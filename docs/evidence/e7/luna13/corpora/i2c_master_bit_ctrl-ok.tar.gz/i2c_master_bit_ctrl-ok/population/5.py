"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence', 'write_stable_high_phase', 'read_sample_window', 'cscl', 'csda', 'filter_cnt_expired', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'sscl_rise', 'sta_condition', 'sto_condition', 'slave_wait', 'scl_sync', 'cnt_zero', 'clk_en', 'sda_chk']
    PROBE_WIDTHS = {'idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1, 'write_stable_high_phase': 1, 'read_sample_window': 1, 'cscl': 1, 'csda': 1, 'filter_cnt_expired': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'sscl_rise': 1, 'sta_condition': 1, 'sto_condition': 1, 'slave_wait': 1, 'scl_sync': 1, 'cnt_zero': 1, 'clk_en': 1, 'sda_chk': 1}
    LATENCY_CYCLES = 0

    def _reset_state(self, reload=0):
        self.state = 'IDLE'
        self.cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0
        self.scl_oen = 1
        self.sda_oen = 1
        self.cSCL0 = 1
        self.cSCL1 = 1
        self.cSDA0 = 1
        self.cSDA1 = 1
        self.fscl = 7
        self.fsda = 7
        self.filter_cnt = 0
        self.dscl = 1
        self.dsda = 1
        self.cnt = self.mask(reload, 16)
        self.clk_en = 1

    def reset(self):
        self._reset_state(0)

    def _majority(self, value):
        ones = (value & 1) + ((value >> 1) & 1) + ((value >> 2) & 1)
        return int(ones >= 2)

    def _signals(self, i):
        sscl = self._majority(self.fscl)
        ssda = self._majority(self.fsda)
        sscl_rise = int(bool(sscl) and not bool(self.dscl))
        sta_condition = int((not bool(ssda)) and bool(self.dsda) and bool(sscl))
        sto_condition = int(bool(ssda) and (not bool(self.dsda)) and bool(sscl))
        slave_wait = int(bool(self.scl_oen) and not bool(sscl))
        scl_sync = int(bool(self.scl_oen) and bool(self.dscl) and not bool(sscl))
        return {
            'sscl': sscl,
            'ssda': ssda,
            'sscl_rise': sscl_rise,
            'sta_condition': sta_condition,
            'sto_condition': sto_condition,
            'slave_wait': slave_wait,
            'scl_sync': scl_sync,
            'filter_cnt_expired': int(bool(i['ena']) and self.filter_cnt == 0),
            'clk_en': int(bool(self.clk_en) and not bool(slave_wait)),
            'cnt_zero': int(self.cnt == 0),
            'sda_chk': int(self.state == 'WRITE_C')
        }

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        if not i['nReset']:
            o['cmd_ack'] = 0
            o['busy'] = 0
            o['al'] = 0
            o['dout'] = 0
            o['scl_o'] = 0
            o['scl_oen'] = 1
            o['sda_o'] = 0
            o['sda_oen'] = 1
            values = {
                'idle': 1, 'fsm_active': 0,
                'in_start_sequence': 0, 'in_stop_sequence': 0,
                'in_read_sequence': 0, 'in_write_sequence': 0,
                'write_stable_high_phase': 0, 'read_sample_window': 0,
                'cscl': 1, 'csda': 1, 'filter_cnt_expired': 0,
                'fscl': 7, 'fsda': 7, 'sscl': 1, 'ssda': 1,
                'dscl': 1, 'dsda': 1, 'sscl_rise': 0,
                'sta_condition': 0, 'sto_condition': 0,
                'slave_wait': 0, 'scl_sync': 0,
                'cnt_zero': int((self.mask(i['clk_cnt'], 16)) == 0),
                'clk_en': 1, 'sda_chk': 0
            }
        else:
            o['cmd_ack'] = self.cmd_ack
            o['busy'] = self.busy
            o['al'] = self.al
            o['dout'] = self.dout
            o['scl_o'] = 0
            o['scl_oen'] = self.scl_oen
            o['sda_o'] = 0
            o['sda_oen'] = self.sda_oen
            sig = self._signals(i)
            values = {
                'idle': int(self.state == 'IDLE'),
                'fsm_active': int(self.state != 'IDLE'),
                'in_start_sequence': int(self.state.startswith('START_')),
                'in_stop_sequence': int(self.state.startswith('STOP_')),
                'in_read_sequence': int(self.state.startswith('READ_')),
                'in_write_sequence': int(self.state.startswith('WRITE_')),
                'write_stable_high_phase': int(self.state == 'WRITE_C'),
                'read_sample_window': int(self.state == 'READ_C'),
                'cscl': self.cSCL1,
                'csda': self.cSDA1,
                'filter_cnt_expired': sig['filter_cnt_expired'],
                'fscl': self.mask(self.fscl, 3),
                'fsda': self.mask(self.fsda, 3),
                'sscl': sig['sscl'],
                'ssda': sig['ssda'],
                'dscl': self.dscl,
                'dsda': self.dsda,
                'sscl_rise': sig['sscl_rise'],
                'sta_condition': sig['sta_condition'],
                'sto_condition': sig['sto_condition'],
                'slave_wait': sig['slave_wait'],
                'scl_sync': sig['scl_sync'],
                'cnt_zero': sig['cnt_zero'],
                'clk_en': sig['clk_en'],
                'sda_chk': sig['sda_chk']
            }
        for name, value in values.items():
            setattr(self, name, value)
        return o

    def advance(self, i):
        clk_cnt = self.mask(i['clk_cnt'], 16)
        if not i['nReset'] or i['rst']:
            self._reset_state(clk_cnt)
            return

        sig = self._signals(i)
        old_cSCL0 = self.cSCL0
        old_cSDA0 = self.cSDA0

        self.cmd_ack = 0
        if sig['sscl_rise']:
            self.dout = sig['ssda']
        if sig['sta_condition']:
            self.busy = 1
        elif sig['sto_condition']:
            self.busy = 0

        self.cSCL0 = int(bool(i['scl_i']))
        self.cSCL1 = old_cSCL0
        self.cSDA0 = int(bool(i['sda_i']))
        self.cSDA1 = old_cSDA0
        self.dscl = sig['sscl']
        self.dsda = sig['ssda']

        if not i['ena']:
            self.filter_cnt = 0
        elif self.filter_cnt == 0:
            self.filter_cnt = (clk_cnt >> 2) & 0xFFFF
            self.fscl = self.mask((self.fscl << 1) | self.cSCL1, 3)
            self.fsda = self.mask((self.fsda << 1) | self.cSDA1, 3)
        else:
            self.filter_cnt = self.mask(self.filter_cnt - 1, 16)

        arbitration_loss = bool(sig['sda_chk'] and self.sda_oen and not sig['ssda'])
        unexpected_stop = bool(sig['sto_condition'] and self.state != 'IDLE' and not self.state.startswith('STOP_'))
        if self.al or arbitration_loss or unexpected_stop:
            if arbitration_loss or unexpected_stop:
                self.al = 1
            self.state = 'IDLE'
            self.scl_oen = 1
            self.sda_oen = 1
        elif i['ena'] and self.clk_en and not sig['slave_wait']:
            if self.state == 'IDLE':
                command = self.mask(i['cmd'], 4)
                if command == 1:
                    self.state = 'START_A'
                elif command == 2:
                    self.state = 'STOP_A'
                elif command == 4:
                    self.state = 'WRITE_A'
                elif command == 8:
                    self.state = 'READ_A'
            elif self.state == 'START_A':
                self.scl_oen = 1
                self.sda_oen = 1
                self.state = 'START_B'
            elif self.state == 'START_B':
                self.sda_oen = 0
                self.state = 'START_C'
            elif self.state == 'START_C':
                self.scl_oen = 0
                self.state = 'IDLE'
                self.cmd_ack = 1
            elif self.state == 'STOP_A':
                self.scl_oen = 0
                self.sda_oen = 0
                self.state = 'STOP_B'
            elif self.state == 'STOP_B':
                self.scl_oen = 1
                self.state = 'STOP_C'
            elif self.state == 'STOP_C':
                self.sda_oen = 1
                self.state = 'IDLE'
                self.cmd_ack = 1
            elif self.state == 'READ_A':
                self.sda_oen = 1
                self.state = 'READ_B'
            elif self.state == 'READ_B':
                self.scl_oen = 1
                self.state = 'READ_C'
            elif self.state == 'READ_C':
                self.scl_oen = 0
                self.state = 'IDLE'
                self.cmd_ack = 1
            elif self.state == 'WRITE_A':
                self.sda_oen = int(bool(i['din']))
                self.state = 'WRITE_B'
            elif self.state == 'WRITE_B':
                self.scl_oen = 1
                self.state = 'WRITE_C'
            elif self.state == 'WRITE_C':
                self.scl_oen = 0
                self.state = 'IDLE'
                self.cmd_ack = 1

        if not i['ena']:
            self.cnt = clk_cnt
            self.clk_en = 1
        elif sig['slave_wait']:
            self.clk_en = 0
        elif self.cnt == 0 or sig['scl_sync']:
            self.cnt = clk_cnt
            self.clk_en = 1
        else:
            self.cnt = self.mask(self.cnt - 1, 16)
            self.clk_en = 0
