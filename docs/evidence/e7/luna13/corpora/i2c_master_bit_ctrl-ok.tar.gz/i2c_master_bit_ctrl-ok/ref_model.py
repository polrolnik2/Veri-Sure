"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence', 'write_stable_high_phase', 'read_sample_window', 'cscl', 'csda', 'filter_cnt_expired', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'sscl_rise', 'sta_condition', 'sto_condition', 'slave_wait', 'scl_sync', 'cnt_zero', 'clk_en', 'sda_chk']
    PROBE_WIDTHS = {'idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1, 'write_stable_high_phase': 1, 'read_sample_window': 1, 'cscl': 1, 'csda': 1, 'filter_cnt_expired': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'sscl_rise': 1, 'sta_condition': 1, 'sto_condition': 1, 'slave_wait': 1, 'scl_sync': 1, 'cnt_zero': 1, 'clk_en': 1, 'sda_chk': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'idle'
        self.scl_oen = 1
        self.sda_oen = 1
        self.cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0
        self.cSCL_meta = 1
        self.cscl = 1
        self.cSDA_meta = 1
        self.csda = 1
        self.fscl = 7
        self.fsda = 7
        self.dscl = 1
        self.dsda = 1
        self.filter_cnt = 0
        self.cnt = 0
        self.clk_en = 1
        self.write_bit = 0

    def _signals(self, i):
        if i['nReset'] == 0:
            state = 'idle'
            scl_oen = 1
            sda_oen = 1
            cmd_ack = 0
            busy = 0
            al = 0
            dout = 0
            cscl = 1
            csda = 1
            fscl = 7
            fsda = 7
            dscl = 1
            dsda = 1
            filter_cnt = 0
            cnt = 0
            clk_en = 1
            write_bit = 0
        else:
            state = self.state
            scl_oen = self.scl_oen
            sda_oen = self.sda_oen
            cmd_ack = self.cmd_ack
            busy = self.busy
            al = self.al
            dout = self.dout
            cscl = self.cscl
            csda = self.csda
            fscl = self.fscl
            fsda = self.fsda
            dscl = self.dscl
            dsda = self.dsda
            filter_cnt = self.filter_cnt
            cnt = self.cnt
            clk_en = self.clk_en
            write_bit = self.write_bit

        sscl = int(((fscl & 1) + ((fscl >> 1) & 1) + ((fscl >> 2) & 1)) >= 2)
        ssda = int(((fsda & 1) + ((fsda >> 1) & 1) + ((fsda >> 2) & 1)) >= 2)
        sscl_rise = int(bool(sscl and not dscl))
        sta_condition = int(bool((not ssda) and dsda and sscl))
        sto_condition = int(bool(ssda and (not dsda) and sscl))
        slave_wait = int(bool(scl_oen and (not sscl)))
        scl_sync = int(bool(dscl and (not sscl) and scl_oen))
        sda_chk = int(state == 'write_c')
        filter_cnt_expired = int(bool(i['nReset'] and i['ena'] and filter_cnt == 0))

        return {
            'state': state,
            'scl_oen': scl_oen,
            'sda_oen': sda_oen,
            'cmd_ack': cmd_ack,
            'busy': busy,
            'al': al,
            'dout': dout,
            'cscl': cscl,
            'csda': csda,
            'fscl': fscl,
            'fsda': fsda,
            'sscl': sscl,
            'ssda': ssda,
            'dscl': dscl,
            'dsda': dsda,
            'sscl_rise': sscl_rise,
            'sta_condition': sta_condition,
            'sto_condition': sto_condition,
            'slave_wait': slave_wait,
            'scl_sync': scl_sync,
            'cnt_zero': int(cnt == 0),
            'clk_en': clk_en,
            'sda_chk': sda_chk,
            'filter_cnt_expired': filter_cnt_expired,
            'write_bit': write_bit,
        }

    def outputs(self, i):
        s = self._signals(i)
        state = s['state']

        self.idle = (state == 'idle')
        self.fsm_active = (state != 'idle')
        self.in_start_sequence = state.startswith('start_')
        self.in_stop_sequence = state.startswith('stop_')
        self.in_read_sequence = state.startswith('read_')
        self.in_write_sequence = state.startswith('write_')
        self.write_stable_high_phase = (state == 'write_c')
        self.read_sample_window = (state == 'read_c')
        self.cscl = s['cscl']
        self.csda = s['csda']
        self.filter_cnt_expired = bool(s['filter_cnt_expired'])
        self.fscl = s['fscl']
        self.fsda = s['fsda']
        self.sscl = s['sscl']
        self.ssda = s['ssda']
        self.dscl = s['dscl']
        self.dsda = s['dsda']
        self.sscl_rise = bool(s['sscl_rise'])
        self.sta_condition = bool(s['sta_condition'])
        self.sto_condition = bool(s['sto_condition'])
        self.slave_wait = bool(s['slave_wait'])
        self.scl_sync = bool(s['scl_sync'])
        self.cnt_zero = bool(s['cnt_zero'])
        self.clk_en = bool(s['clk_en'])
        self.sda_chk = bool(s['sda_chk'])

        o = {p: None for p in self.OUTPUT_PORTS}
        o['cmd_ack'] = int(s['cmd_ack'])
        o['busy'] = int(s['busy'])
        o['al'] = int(s['al'])
        o['dout'] = int(s['dout'])
        o['scl_o'] = 0
        o['scl_oen'] = int(s['scl_oen'])
        o['sda_o'] = 0
        o['sda_oen'] = int(s['sda_oen'])
        return o

    def advance(self, i):
        if i['nReset'] == 0:
            self.reset()
            return
        if i['rst']:
            self.reset()
            self.cnt = self.mask(i['clk_cnt'], 16)
            self.clk_en = 1
            return

        s = self._signals(i)
        old_cscl = self.cscl
        old_csda = self.csda
        state = self.state

        # Two synchronizer stages; filtering consumes the old second stage.
        self.cscl = self.cSCL_meta
        self.cSCL_meta = int(bool(i['scl_i']))
        self.csda = self.cSDA_meta
        self.cSDA_meta = int(bool(i['sda_i']))

        # The input filter is disabled, and its counter cleared, when ena is low.
        if not i['ena']:
            self.filter_cnt = 0
        elif s['filter_cnt_expired']:
            self.fscl = self.mask((self.fscl << 1) | s['cscl'], 3)
            self.fsda = self.mask((self.fsda << 1) | s['csda'], 3)
            self.filter_cnt = self.mask(i['clk_cnt'] >> 2, 14)
        else:
            self.filter_cnt = self.mask(self.filter_cnt - 1, 14)

        # Delayed filtered samples and read data use values from before this edge.
        self.dscl = s['sscl']
        self.dsda = s['ssda']
        if s['sscl_rise']:
            self.dout = s['ssda']

        if s['sta_condition']:
            self.busy = 1
        elif s['sto_condition']:
            self.busy = 0

        # The divider produces a timing tick. ena separately gates FSM progress.
        if not i['ena']:
            self.cnt = self.mask(i['clk_cnt'], 16)
            self.clk_en = 1
        elif s['scl_sync'] or s['cnt_zero']:
            self.cnt = self.mask(i['clk_cnt'], 16)
            self.clk_en = 1
        elif s['slave_wait']:
            self.clk_en = 0
        else:
            self.cnt = self.mask(self.cnt - 1, 16)
            self.clk_en = 0

        self.cmd_ack = 0
        arbitration_lost = bool(
            (s['sda_chk'] and s['write_bit'] and not s['ssda']) or
            (s['sto_condition'] and state != 'idle' and not state.startswith('stop_'))
        )

        if arbitration_lost:
            self.al = 1
            self.state = 'idle'
            self.scl_oen = 1
            self.sda_oen = 1
            self.write_bit = 0
            return

        if not (i['ena'] and s['clk_en'] and not s['slave_wait']):
            return

        if state == 'idle':
            command = i['cmd'] & 15
            if command == 1:
                self.state = 'start_a'
            elif command == 2:
                self.state = 'stop_a'
            elif command == 4:
                self.state = 'write_a'
            elif command == 8:
                self.state = 'read_a'
        elif state == 'start_a':
            self.scl_oen = 1
            self.sda_oen = 1
            self.state = 'start_b'
        elif state == 'start_b':
            self.sda_oen = 0
            self.state = 'start_c'
        elif state == 'start_c':
            self.scl_oen = 0
            self.state = 'start_d'
        elif state == 'start_d':
            self.cmd_ack = 1
            self.state = 'idle'
        elif state == 'stop_a':
            self.scl_oen = 0
            self.sda_oen = 0
            self.state = 'stop_b'
        elif state == 'stop_b':
            self.scl_oen = 1
            self.state = 'stop_c'
        elif state == 'stop_c':
            self.sda_oen = 1
            self.state = 'stop_d'
        elif state == 'stop_d':
            self.cmd_ack = 1
            self.state = 'idle'
        elif state == 'read_a':
            self.scl_oen = 0
            self.sda_oen = 1
            self.state = 'read_b'
        elif state == 'read_b':
            self.scl_oen = 1
            self.state = 'read_c'
        elif state == 'read_c':
            self.state = 'read_d'
        elif state == 'read_d':
            self.scl_oen = 0
            self.state = 'read_e'
        elif state == 'read_e':
            self.cmd_ack = 1
            self.state = 'idle'
        elif state == 'write_a':
            self.scl_oen = 0
            self.write_bit = int(bool(i['din']))
            self.sda_oen = self.write_bit
            self.state = 'write_b'
        elif state == 'write_b':
            self.scl_oen = 1
            self.state = 'write_c'
        elif state == 'write_c':
            self.state = 'write_d'
        elif state == 'write_d':
            self.scl_oen = 0
            self.state = 'write_e'
        elif state == 'write_e':
            self.cmd_ack = 1
            self.state = 'idle'
        else:
            self.state = 'idle'
