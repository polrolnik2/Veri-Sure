"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        self._registers = {
            'out': 0,
            'ex_enable': 0,
            'underflow': 0,
            'overflow': 0,
            'inexact': 0,
            'exception': 0,
            'invalid': 0,
        }
        names = (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger',
            'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output',
            'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2'
        )
        self._probe_state = {name: 0 for name in names}
        self._probe_state.update({
            'exp_2047': 2047,
            'exp_2046': 2046,
            'mantissa_max': (1 << 52) - 1,
        })

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        for name, value in self._probe_state.items():
            setattr(self, name, value)
        for name in self.OUTPUT_PORTS:
            o[name] = self._registers[name]
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not i['enable']:
            return

        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        candidate = self.mask(i['in_except'], 64)
        exponent_in = self.mask(i['exponent_in'], 12)
        mantissa_in = self.mask(i['mantissa_in'], 2)
        fpu_op = self.mask(i['fpu_op'], 3)
        rmode = self.mask(i['rmode'], 2)

        fraction_mask = (1 << 52) - 1
        quiet_bit = 1 << 51
        exponent_a = (opa >> 52) & 0x7ff
        exponent_b = (opb >> 52) & 0x7ff
        fraction_a = opa & fraction_mask
        fraction_b = opb & fraction_mask
        sign_a = (opa >> 63) & 1
        sign_b = (opb >> 63) & 1
        sign = (candidate >> 63) & 1

        opa_zero = (opa & ((1 << 63) - 1)) == 0
        opb_zero = (opb & ((1 << 63) - 1)) == 0
        result_zero = (candidate & ((1 << 63) - 1)) == 0

        opa_nan = exponent_a == 0x7ff and fraction_a != 0
        opb_nan = exponent_b == 0x7ff and fraction_b != 0
        opa_qnan = opa_nan and bool(fraction_a & quiet_bit)
        opb_qnan = opb_nan and bool(fraction_b & quiet_bit)
        opa_snan = opa_nan and not bool(fraction_a & quiet_bit)
        opb_snan = opb_nan and not bool(fraction_b & quiet_bit)
        opa_inf = exponent_a == 0x7ff and fraction_a == 0
        opb_inf = exponent_b == 0x7ff and fraction_b == 0
        opa_pos_inf = opa_inf and sign_a == 0
        opb_pos_inf = opb_inf and sign_b == 0
        opa_neg_inf = opa_inf and sign_a == 1
        opb_neg_inf = opb_inf and sign_b == 1
        nan_input = opa_nan or opb_nan
        snan_input = opa_snan or opb_snan

        is_add = fpu_op == 0
        is_subtract = fpu_op == 1
        is_multiply = fpu_op == 2
        is_divide = fpu_op == 3

        addsub_invalid = (
            (is_add and ((opa_pos_inf and opb_neg_inf) or (opa_neg_inf and opb_pos_inf)))
            or (is_subtract and ((opa_pos_inf and opb_pos_inf) or (opa_neg_inf and opb_neg_inf)))
        )
        any_inf = opa_inf or opb_inf
        add_inf = is_add and any_inf
        sub_inf = is_subtract and any_inf
        addsub_inf = (is_add or is_subtract) and any_inf and not addsub_invalid and not nan_input

        div_0_by_0 = is_divide and opa_zero and opb_zero
        div_inf_by_inf = is_divide and opa_inf and opb_inf
        div_by_0 = is_divide and opb_zero and not opa_zero
        div_by_inf = is_divide and opb_inf and not opa_inf and not nan_input
        mul_0_by_inf = is_multiply and ((opa_zero and opb_inf) or (opb_zero and opa_inf))
        mul_inf = is_multiply and any_inf and not mul_0_by_inf and not nan_input
        div_inf = is_divide and opa_inf and not opb_inf and not nan_input

        invalid_trigger = bool(
            snan_input or addsub_invalid or mul_0_by_inf or div_0_by_0 or div_inf_by_inf
        )
        nan_out_trigger = bool(nan_input or invalid_trigger)
        snan_trigger = bool(snan_input)

        out_inf_trigger = bool(
            mul_inf or div_inf or addsub_inf or div_by_0 or exponent_in > 2046
        )
        round_nearest = rmode == 0
        round_to_zero = rmode == 1
        round_to_pos_inf = rmode == 2
        round_to_neg_inf = rmode == 3
        round_down = out_inf_trigger and (
            (sign == 0 and (round_to_zero or round_to_neg_inf))
            or (sign == 1 and (round_to_zero or round_to_pos_inf))
        )

        mul_uf = (
            is_multiply and result_zero and not opa_zero and not opb_zero
            and not opa_inf and not opb_inf and not nan_input
        )
        div_uf = bool(
            div_by_inf
            or (
                is_divide and result_zero and not opa_zero and not opb_zero
                and not opa_inf and not opb_inf and not nan_input
            )
        )
        underflow_trigger = bool(mul_uf or div_uf)
        overflow_trigger = bool(out_inf_trigger and not nan_input)
        inexact_trigger = bool(
            not nan_input and (mantissa_in != 0 or out_inf_trigger or underflow_trigger)
        )
        except_trigger = bool(
            invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger
        )
        enable_trigger = bool(
            nan_out_trigger or out_inf_trigger or underflow_trigger or inexact_trigger
        )

        if opa_nan:
            nan_fraction = fraction_a
        elif opb_nan:
            nan_fraction = fraction_b
        else:
            nan_fraction = fraction_a
        nan_magnitude = ((0x7ff << 52) | (nan_fraction | quiet_bit)) if nan_out_trigger else 0
        nan_magnitude = self.mask(nan_magnitude, 63)
        nan_result = self.mask((sign << 63) | nan_magnitude, 64)

        max_finite_magnitude = (2046 << 52) | fraction_mask
        infinity_magnitude = 2047 << 52
        signed_zero = sign << 63
        out_0 = signed_zero if underflow_trigger else candidate
        if out_inf_trigger:
            selected_magnitude = max_finite_magnitude if round_down else infinity_magnitude
            out_1 = self.mask((sign << 63) | selected_magnitude, 64)
        else:
            out_1 = out_0
        out_2 = nan_result if nan_out_trigger else out_1
        final_out = self.mask(out_2, 64)

        p = dict(self._probe_state)
        p.update({
            'in_et_zero': int(result_zero),
            'opa_et_zero': int(opa_zero),
            'opb_et_zero': int(opb_zero),
            'input_et_zero': int(opa_zero or opb_zero),
            'add': int(is_add),
            'subtract': int(is_subtract),
            'multiply': int(is_multiply),
            'divide': int(is_divide),
            'opa_qnan': int(opa_qnan),
            'opb_qnan': int(opb_qnan),
            'opa_snan': int(opa_snan),
            'opb_snan': int(opb_snan),
            'opa_pos_inf': int(opa_pos_inf),
            'opb_pos_inf': int(opb_pos_inf),
            'opa_neg_inf': int(opa_neg_inf),
            'opb_neg_inf': int(opb_neg_inf),
            'opa_inf': int(opa_inf),
            'opb_inf': int(opb_inf),
            'nan_input': int(nan_input),
            'snan_input': int(snan_input),
            'a_nan': int(nan_out_trigger and (opa_nan or not nan_input)),
            'div_by_0': int(div_by_0),
            'div_0_by_0': int(div_0_by_0),
            'div_inf_by_inf': int(div_inf_by_inf),
            'div_by_inf': int(div_by_inf),
            'mul_0_by_inf': int(mul_0_by_inf),
            'mul_inf': int(mul_inf),
            'div_inf': int(div_inf),
            'add_inf': int(add_inf),
            'sub_inf': int(sub_inf),
            'addsub_inf_invalid': int(addsub_invalid),
            'addsub_inf': int(addsub_inf),
            'out_inf_trigger': int(out_inf_trigger),
            'out_pos_inf': int(out_inf_trigger and sign == 0),
            'out_neg_inf': int(out_inf_trigger and sign == 1),
            'round_nearest': int(round_nearest),
            'round_to_zero': int(round_to_zero),
            'round_to_pos_inf': int(round_to_pos_inf),
            'round_to_neg_inf': int(round_to_neg_inf),
            'inf_round_down_trigger': int(round_down),
            'mul_uf': int(mul_uf),
            'div_uf': int(div_uf),
            'underflow_trigger': int(underflow_trigger),
            'invalid_trigger': int(invalid_trigger),
            'overflow_trigger': int(overflow_trigger),
            'inexact_trigger': int(inexact_trigger),
            'except_trigger': int(except_trigger),
            'enable_trigger': int(enable_trigger),
            'nan_out_trigger': int(nan_out_trigger),
            'snan_trigger': int(snan_trigger),
            'exp_2047': 2047,
            'exp_2046': 2046,
            'nan_output_0': nan_magnitude,
            'nan_output': nan_magnitude,
            'mantissa_max': fraction_mask,
            'inf_round_down': max_finite_magnitude if round_down else 0,
            'out_inf': infinity_magnitude if out_inf_trigger else 0,
            'out_0': self.mask(out_0, 64),
            'out_1': self.mask(out_1, 64),
            'out_2': self.mask(out_2, 64),
        })
        self._probe_state = p
        self._registers = {
            'out': final_out,
            'ex_enable': int(enable_trigger),
            'underflow': int(underflow_trigger),
            'overflow': int(overflow_trigger),
            'inexact': int(inexact_trigger),
            'exception': int(except_trigger),
            'invalid': int(invalid_trigger),
        }
