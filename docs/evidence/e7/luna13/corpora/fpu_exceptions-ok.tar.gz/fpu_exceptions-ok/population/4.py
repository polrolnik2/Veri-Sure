"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        names = (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger',
            'nan_output_0', 'nan_output', 'inf_round_down', 'out_inf',
            'out_0', 'out_1', 'out_2'
        )
        self._regs = {name: 0 for name in names}
        self._outputs = {p: 0 for p in self.OUTPUT_PORTS}
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        for p in self.OUTPUT_PORTS:
            o[p] = self._outputs[p]
        probe_names = (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger',
            'nan_output_0', 'nan_output', 'inf_round_down', 'out_inf',
            'out_0', 'out_1', 'out_2'
        )
        for name in probe_names:
            setattr(self, name, self._regs[name])
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1
        return o

    def _calculate(self, i):
        a = self.mask(i['opa'], 64)
        b = self.mask(i['opb'], 64)
        candidate = self.mask(i['in_except'], 64)
        exponent_in = self.mask(i['exponent_in'], 12)
        mantissa_in = self.mask(i['mantissa_in'], 2)
        fpu_op = self.mask(i['fpu_op'], 3)
        rmode = self.mask(i['rmode'], 2)

        fraction_mask = (1 << 52) - 1
        sign_mask = 1 << 63
        quiet_bit = 1 << 51
        exponent_a = (a >> 52) & 0x7ff
        exponent_b = (b >> 52) & 0x7ff
        fraction_a = a & fraction_mask
        fraction_b = b & fraction_mask

        a_zero = (a & ((1 << 63) - 1)) == 0
        b_zero = (b & ((1 << 63) - 1)) == 0
        a_nan = exponent_a == 0x7ff and fraction_a != 0
        b_nan = exponent_b == 0x7ff and fraction_b != 0
        a_qnan = a_nan and bool(fraction_a & quiet_bit)
        b_qnan = b_nan and bool(fraction_b & quiet_bit)
        a_snan = a_nan and not bool(fraction_a & quiet_bit)
        b_snan = b_nan and not bool(fraction_b & quiet_bit)
        a_inf = exponent_a == 0x7ff and fraction_a == 0
        b_inf = exponent_b == 0x7ff and fraction_b == 0
        a_pos_inf = a_inf and not bool(a & sign_mask)
        b_pos_inf = b_inf and not bool(b & sign_mask)
        a_neg_inf = a_inf and bool(a & sign_mask)
        b_neg_inf = b_inf and bool(b & sign_mask)
        nan_input = a_nan or b_nan
        snan_input = a_snan or b_snan

        add = fpu_op == 0
        subtract = fpu_op == 1
        multiply = fpu_op == 2
        divide = fpu_op == 3

        div_0_by_0 = divide and a_zero and b_zero
        div_inf_by_inf = divide and a_inf and b_inf
        div_by_0 = divide and b_zero and not a_zero
        div_by_inf = divide and b_inf and not a_inf
        mul_0_by_inf = multiply and ((a_zero and b_inf) or (b_zero and a_inf))
        mul_inf = multiply and (a_inf or b_inf) and not mul_0_by_inf
        div_inf = divide and a_inf and not b_inf
        add_inf = add and (a_inf or b_inf)
        sub_inf = subtract and (a_inf or b_inf)

        invalid_addsub = (
            (add and ((a_pos_inf and b_neg_inf) or (a_neg_inf and b_pos_inf)))
            or (subtract and ((a_pos_inf and b_pos_inf) or (a_neg_inf and b_neg_inf)))
        )
        addsub_inf_invalid = invalid_addsub
        addsub_inf = (add_inf or sub_inf) and not invalid_addsub
        invalid_trigger = (
            snan_input or invalid_addsub or mul_0_by_inf
            or div_0_by_0 or div_inf_by_inf
        )
        nan_out_trigger = nan_input or invalid_trigger

        out_inf_trigger = (
            mul_inf or div_inf or addsub_inf or div_by_0
            or exponent_in > 2046
        )
        candidate_zero = (candidate & ((1 << 63) - 1)) == 0
        finite_a_nonzero = not a_zero and not a_inf and not a_nan
        finite_b_nonzero = not b_zero and not b_inf and not b_nan
        mul_uf = multiply and finite_a_nonzero and finite_b_nonzero and candidate_zero
        div_uf = (
            (div_by_inf and finite_a_nonzero)
            or (divide and finite_a_nonzero and finite_b_nonzero and candidate_zero)
        )
        underflow_trigger = mul_uf or div_uf

        out_sign = 1 if candidate & sign_mask else 0
        out_pos_inf = out_inf_trigger and not out_sign
        out_neg_inf = out_inf_trigger and bool(out_sign)
        round_nearest = rmode == 0
        round_to_zero = rmode == 1
        round_to_pos_inf = rmode == 2
        round_to_neg_inf = rmode == 3
        inf_round_down_trigger = (
            (out_pos_inf and (round_to_zero or round_to_neg_inf))
            or (out_neg_inf and (round_to_zero or round_to_pos_inf))
        )

        overflow_trigger = out_inf_trigger and not nan_input
        inexact_trigger = (
            (mantissa_in != 0 or out_inf_trigger or underflow_trigger)
            and not nan_input
        )
        except_trigger = (
            invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger
        )
        enable_trigger = nan_out_trigger or except_trigger

        if a_nan:
            nan_source = a
        elif b_nan:
            nan_source = b
        else:
            nan_source = a
        nan_fraction = (nan_source & fraction_mask) | quiet_bit
        nan_value = self.mask((0x7ff << 52) | nan_fraction, 63)
        out_inf_value = self.mask(2047 << 52, 63)
        inf_round_down_value = self.mask((2046 << 52) | fraction_mask, 63)

        out_0 = (candidate & sign_mask) if underflow_trigger else candidate
        if out_inf_trigger:
            magnitude = inf_round_down_value if inf_round_down_trigger else out_inf_value
            out_1 = (out_sign << 63) | magnitude
        else:
            out_1 = out_0
        if nan_out_trigger:
            out_2 = (out_sign << 63) | nan_value
        else:
            out_2 = out_1
        out_2 = self.mask(out_2, 64)

        r = {name: 0 for name in self._regs}
        r.update({
            'in_et_zero': int(candidate_zero),
            'opa_et_zero': int(a_zero),
            'opb_et_zero': int(b_zero),
            'input_et_zero': int(candidate_zero),
            'add': int(add),
            'subtract': int(subtract),
            'multiply': int(multiply),
            'divide': int(divide),
            'opa_qnan': int(a_qnan),
            'opb_qnan': int(b_qnan),
            'opa_snan': int(a_snan),
            'opb_snan': int(b_snan),
            'opa_pos_inf': int(a_pos_inf),
            'opb_pos_inf': int(b_pos_inf),
            'opa_neg_inf': int(a_neg_inf),
            'opb_neg_inf': int(b_neg_inf),
            'opa_inf': int(a_inf),
            'opb_inf': int(b_inf),
            'nan_input': int(nan_input),
            'snan_input': int(snan_input),
            'a_nan': int(a_nan),
            'div_by_0': int(div_by_0),
            'div_0_by_0': int(div_0_by_0),
            'div_inf_by_inf': int(div_inf_by_inf),
            'div_by_inf': int(div_by_inf),
            'mul_0_by_inf': int(mul_0_by_inf),
            'mul_inf': int(mul_inf),
            'div_inf': int(div_inf),
            'add_inf': int(add_inf),
            'sub_inf': int(sub_inf),
            'addsub_inf_invalid': int(addsub_inf_invalid),
            'addsub_inf': int(addsub_inf),
            'out_inf_trigger': int(out_inf_trigger),
            'out_pos_inf': int(out_pos_inf),
            'out_neg_inf': int(out_neg_inf),
            'round_nearest': int(round_nearest),
            'round_to_zero': int(round_to_zero),
            'round_to_pos_inf': int(round_to_pos_inf),
            'round_to_neg_inf': int(round_to_neg_inf),
            'inf_round_down_trigger': int(inf_round_down_trigger),
            'mul_uf': int(mul_uf),
            'div_uf': int(div_uf),
            'underflow_trigger': int(underflow_trigger),
            'invalid_trigger': int(invalid_trigger),
            'overflow_trigger': int(overflow_trigger),
            'inexact_trigger': int(inexact_trigger),
            'except_trigger': int(except_trigger),
            'enable_trigger': int(enable_trigger),
            'nan_out_trigger': int(nan_out_trigger),
            'snan_trigger': int(snan_input),
            'nan_output_0': nan_value,
            'nan_output': nan_value,
            'inf_round_down': inf_round_down_value,
            'out_inf': out_inf_value,
            'out_0': self.mask(out_0, 64),
            'out_1': self.mask(out_1, 64),
            'out_2': out_2
        })
        outputs = {
            'out': out_2,
            'ex_enable': int(enable_trigger),
            'underflow': int(underflow_trigger),
            'overflow': int(overflow_trigger),
            'inexact': int(inexact_trigger),
            'exception': int(except_trigger),
            'invalid': int(invalid_trigger)
        }
        return r, outputs

    def advance(self, i):
        if self.mask(i['rst'], 1):
            self.reset()
            return
        if not self.mask(i['enable'], 1):
            return
        next_regs, next_outputs = self._calculate(i)
        self._regs = next_regs
        self._outputs = next_outputs
