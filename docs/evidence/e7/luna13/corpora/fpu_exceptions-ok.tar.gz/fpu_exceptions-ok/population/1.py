"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        self._o = {p: 0 for p in self.OUTPUT_PORTS}
        self._probes = {name: 0 for name in (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger',
            'nan_output_0', 'nan_output', 'inf_round_down', 'out_inf',
            'out_0', 'out_1', 'out_2'
        )}

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        for p in self.OUTPUT_PORTS:
            o[p] = self._o[p]
        for name, value in self._probes.items():
            setattr(self, name, value)
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1
        return o

    def advance(self, i):
        if self.mask(i['rst'], 1):
            self.reset()
            return
        if not self.mask(i['enable'], 1):
            return

        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        candidate = self.mask(i['in_except'], 64)
        exponent_in = self.mask(i['exponent_in'], 12)
        mantissa_in = self.mask(i['mantissa_in'], 2)
        fpu_op = self.mask(i['fpu_op'], 3)
        rmode = self.mask(i['rmode'], 2)

        fraction_mask = (1 << 52) - 1
        lower_63_mask = (1 << 63) - 1
        quiet_bit = 1 << 51
        opa_exp = (opa >> 52) & 0x7ff
        opb_exp = (opb >> 52) & 0x7ff
        opa_frac = opa & fraction_mask
        opb_frac = opb & fraction_mask
        opa_sign = (opa >> 63) & 1
        opb_sign = (opb >> 63) & 1
        result_sign = (candidate >> 63) & 1

        opa_zero = int((opa & lower_63_mask) == 0)
        opb_zero = int((opb & lower_63_mask) == 0)
        result_zero = int((candidate & lower_63_mask) == 0)
        opa_nan = int(opa_exp == 0x7ff and opa_frac != 0)
        opb_nan = int(opb_exp == 0x7ff and opb_frac != 0)
        opa_qnan = int(bool(opa_nan) and bool(opa_frac & quiet_bit))
        opb_qnan = int(bool(opb_nan) and bool(opb_frac & quiet_bit))
        opa_snan = int(bool(opa_nan) and not bool(opa_frac & quiet_bit))
        opb_snan = int(bool(opb_nan) and not bool(opb_frac & quiet_bit))
        opa_inf = int(opa_exp == 0x7ff and opa_frac == 0)
        opb_inf = int(opb_exp == 0x7ff and opb_frac == 0)
        opa_pos_inf = int(bool(opa_inf) and opa_sign == 0)
        opb_pos_inf = int(bool(opb_inf) and opb_sign == 0)
        opa_neg_inf = int(bool(opa_inf) and opa_sign == 1)
        opb_neg_inf = int(bool(opb_inf) and opb_sign == 1)
        nan_input = int(bool(opa_nan) or bool(opb_nan))
        snan_input = int(bool(opa_snan) or bool(opb_snan))

        add = int(fpu_op == 0)
        subtract = int(fpu_op == 1)
        multiply = int(fpu_op == 2)
        divide = int(fpu_op == 3)

        addsub_inf_invalid = int(
            (bool(add) and ((bool(opa_pos_inf) and bool(opb_neg_inf)) or
                            (bool(opa_neg_inf) and bool(opb_pos_inf)))) or
            (bool(subtract) and ((bool(opa_pos_inf) and bool(opb_pos_inf)) or
                                 (bool(opa_neg_inf) and bool(opb_neg_inf))))
        )
        div_0_by_0 = int(bool(divide) and bool(opa_zero) and bool(opb_zero))
        div_inf_by_inf = int(bool(divide) and bool(opa_inf) and bool(opb_inf))
        div_by_0 = int(bool(divide) and bool(opb_zero) and not bool(opa_zero)
                       and not bool(opa_inf) and not bool(nan_input))
        div_by_inf = int(bool(divide) and bool(opb_inf) and not bool(opa_inf)
                         and not bool(nan_input))
        mul_0_by_inf = int(bool(multiply) and
                           ((bool(opa_zero) and bool(opb_inf)) or
                            (bool(opb_zero) and bool(opa_inf))))
        mul_inf = int(bool(multiply) and (bool(opa_inf) or bool(opb_inf))
                      and not bool(mul_0_by_inf) and not bool(nan_input))
        div_inf = int(bool(divide) and bool(opa_inf) and not bool(opb_inf)
                      and not bool(nan_input))
        add_inf = int(bool(add) and (bool(opa_inf) or bool(opb_inf))
                      and not bool(addsub_inf_invalid) and not bool(nan_input))
        sub_inf = int(bool(subtract) and (bool(opa_inf) or bool(opb_inf))
                      and not bool(addsub_inf_invalid) and not bool(nan_input))
        addsub_inf = int(bool(add or subtract) and
                         (bool(opa_inf) or bool(opb_inf)))

        round_nearest = int(rmode == 0)
        round_to_zero = int(rmode == 1)
        round_to_pos_inf = int(rmode == 2)
        round_to_neg_inf = int(rmode == 3)

        valid_inf_result = bool(mul_inf or div_inf or add_inf or sub_inf)
        out_inf_trigger = int(valid_inf_result or bool(div_by_0) or exponent_in > 2046)
        round_down = bool(out_inf_trigger) and (
            (result_sign == 0 and (rmode == 1 or rmode == 3)) or
            (result_sign == 1 and (rmode == 1 or rmode == 2))
        )
        inf_round_down_trigger = int(round_down)
        out_pos_inf = int(bool(out_inf_trigger) and result_sign == 0)
        out_neg_inf = int(bool(out_inf_trigger) and result_sign == 1)

        mul_uf = int(bool(multiply) and not bool(opa_zero) and not bool(opb_zero)
                     and bool(result_zero))
        div_uf = int(bool(divide) and (bool(div_by_inf) or
                     (not bool(opa_zero) and not bool(opb_zero) and bool(result_zero))))
        underflow_trigger = int(bool(mul_uf) or bool(div_uf))
        invalid_trigger = int(bool(snan_input) or bool(addsub_inf_invalid) or
                              bool(mul_0_by_inf) or bool(div_0_by_0) or
                              bool(div_inf_by_inf))
        overflow_trigger = int(bool(out_inf_trigger) and not bool(nan_input))
        inexact_trigger = int(not bool(nan_input) and
                              (mantissa_in != 0 or bool(out_inf_trigger) or
                               bool(underflow_trigger)))
        except_trigger = int(bool(invalid_trigger) or bool(overflow_trigger) or
                             bool(underflow_trigger) or bool(inexact_trigger))
        nan_out_trigger = int(bool(nan_input) or bool(invalid_trigger))
        snan_trigger = int(bool(snan_input))
        enable_trigger = int(bool(nan_out_trigger) or bool(out_inf_trigger) or
                             bool(underflow_trigger) or bool(inexact_trigger))

        if opa_nan:
            selected_fraction = opa_frac
        elif opb_nan:
            selected_fraction = opb_frac
        else:
            selected_fraction = opa_frac
        nan_magnitude = ((0x7ff << 52) | (selected_fraction | quiet_bit)) & lower_63_mask
        nan_sign = result_sign << 63

        infinity_magnitude = 0x7ff << 52
        max_finite_magnitude = (0x7fe << 52) | fraction_mask
        signed_zero = result_sign << 63
        out_0 = signed_zero if underflow_trigger else candidate
        if out_inf_trigger:
            selected_magnitude = max_finite_magnitude if round_down else infinity_magnitude
            out_1 = (result_sign << 63) | selected_magnitude
        else:
            out_1 = out_0
        out_2 = (nan_sign | nan_magnitude) if nan_out_trigger else out_1

        self._o['out'] = self.mask(out_2, 64)
        self._o['ex_enable'] = enable_trigger
        self._o['underflow'] = underflow_trigger
        self._o['overflow'] = overflow_trigger
        self._o['inexact'] = inexact_trigger
        self._o['exception'] = except_trigger
        self._o['invalid'] = invalid_trigger

        self._probes.update({
            'in_et_zero': result_zero,
            'opa_et_zero': opa_zero,
            'opb_et_zero': opb_zero,
            'input_et_zero': result_zero,
            'add': add,
            'subtract': subtract,
            'multiply': multiply,
            'divide': divide,
            'opa_qnan': opa_qnan,
            'opb_qnan': opb_qnan,
            'opa_snan': opa_snan,
            'opb_snan': opb_snan,
            'opa_pos_inf': opa_pos_inf,
            'opb_pos_inf': opb_pos_inf,
            'opa_neg_inf': opa_neg_inf,
            'opb_neg_inf': opb_neg_inf,
            'opa_inf': opa_inf,
            'opb_inf': opb_inf,
            'nan_input': nan_input,
            'snan_input': snan_input,
            'a_nan': int(bool(opa_nan) or (bool(nan_out_trigger) and not bool(nan_input))),
            'div_by_0': div_by_0,
            'div_0_by_0': div_0_by_0,
            'div_inf_by_inf': div_inf_by_inf,
            'div_by_inf': div_by_inf,
            'mul_0_by_inf': mul_0_by_inf,
            'mul_inf': mul_inf,
            'div_inf': div_inf,
            'add_inf': add_inf,
            'sub_inf': sub_inf,
            'addsub_inf_invalid': addsub_inf_invalid,
            'addsub_inf': addsub_inf,
            'out_inf_trigger': out_inf_trigger,
            'out_pos_inf': out_pos_inf,
            'out_neg_inf': out_neg_inf,
            'round_nearest': round_nearest,
            'round_to_zero': round_to_zero,
            'round_to_pos_inf': round_to_pos_inf,
            'round_to_neg_inf': round_to_neg_inf,
            'inf_round_down_trigger': inf_round_down_trigger,
            'mul_uf': mul_uf,
            'div_uf': div_uf,
            'underflow_trigger': underflow_trigger,
            'invalid_trigger': invalid_trigger,
            'overflow_trigger': overflow_trigger,
            'inexact_trigger': inexact_trigger,
            'except_trigger': except_trigger,
            'enable_trigger': enable_trigger,
            'nan_out_trigger': nan_out_trigger,
            'snan_trigger': snan_trigger,
            'nan_output_0': nan_magnitude,
            'nan_output': nan_magnitude,
            'inf_round_down': max_finite_magnitude if round_down else 0,
            'out_inf': infinity_magnitude if out_inf_trigger else 0,
            'out_0': self.mask(out_0, 64),
            'out_1': self.mask(out_1, 64),
            'out_2': self.mask(out_2, 64)
        })
