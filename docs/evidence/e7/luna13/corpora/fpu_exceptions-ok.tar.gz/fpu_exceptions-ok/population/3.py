"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        self.out = 0
        self.ex_enable = 0
        self.underflow = 0
        self.overflow = 0
        self.inexact = 0
        self.exception = 0
        self.invalid = 0
        for name in (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger',
            'nan_output_0', 'nan_output', 'inf_round_down', 'out_inf',
            'out_0', 'out_1', 'out_2'
        ):
            setattr(self, name, 0)
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self.out
        o['ex_enable'] = self.ex_enable
        o['underflow'] = self.underflow
        o['overflow'] = self.overflow
        o['inexact'] = self.inexact
        o['exception'] = self.exception
        o['invalid'] = self.invalid
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1
        for name in (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger',
            'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output',
            'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2'
        ):
            setattr(self, name, getattr(self, name))
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not i['enable']:
            return

        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        candidate = self.mask(i['in_except'], 64)
        exponent = self.mask(i['exponent_in'], 12)
        remainder = self.mask(i['mantissa_in'], 2)
        op = self.mask(i['fpu_op'], 3)
        mode = self.mask(i['rmode'], 2)

        frac_mask = (1 << 52) - 1
        magnitude_mask = (1 << 63) - 1
        sign_mask = 1 << 63
        opa_exp = (opa >> 52) & 0x7ff
        opb_exp = (opb >> 52) & 0x7ff
        opa_frac = opa & frac_mask
        opb_frac = opb & frac_mask
        opa_zero = (opa & magnitude_mask) == 0
        opb_zero = (opb & magnitude_mask) == 0
        candidate_zero = (candidate & magnitude_mask) == 0
        opa_nan = opa_exp == 0x7ff and opa_frac != 0
        opb_nan = opb_exp == 0x7ff and opb_frac != 0
        opa_qnan = opa_nan and bool(opa_frac & (1 << 51))
        opb_qnan = opb_nan and bool(opb_frac & (1 << 51))
        opa_snan = opa_nan and not bool(opa_frac & (1 << 51))
        opb_snan = opb_nan and not bool(opb_frac & (1 << 51))
        opa_inf = opa_exp == 0x7ff and opa_frac == 0
        opb_inf = opb_exp == 0x7ff and opb_frac == 0
        opa_pos_inf = opa_inf and not bool(opa & sign_mask)
        opb_pos_inf = opb_inf and not bool(opb & sign_mask)
        opa_neg_inf = opa_inf and bool(opa & sign_mask)
        opb_neg_inf = opb_inf and bool(opb & sign_mask)

        add = op == 0
        subtract = op == 1
        multiply = op == 2
        divide = op == 3
        nan_input = opa_nan or opb_nan
        snan_input = opa_snan or opb_snan

        div_0_by_0 = divide and opa_zero and opb_zero
        div_inf_by_inf = divide and opa_inf and opb_inf
        div_by_0 = divide and opb_zero and not opa_zero
        div_by_inf = divide and opb_inf and not opa_inf and not opa_nan
        mul_0_by_inf = multiply and ((opa_zero and opb_inf) or (opb_zero and opa_inf))
        mul_inf = multiply and (opa_inf or opb_inf)
        div_inf = divide and (opa_inf or div_by_0)
        add_inf = add and (opa_inf or opb_inf)
        sub_inf = subtract and (opa_inf or opb_inf)

        add_invalid = add and ((opa_pos_inf and opb_neg_inf) or (opa_neg_inf and opb_pos_inf))
        sub_invalid = subtract and ((opa_pos_inf and opb_pos_inf) or (opa_neg_inf and opb_neg_inf))
        addsub_inf_invalid = add_invalid or sub_invalid
        addsub_inf = (add or subtract) and (opa_inf or opb_inf)
        invalid_trigger = (
            snan_input or addsub_inf_invalid or mul_0_by_inf or
            div_0_by_0 or div_inf_by_inf
        )

        valid_addsub_inf = addsub_inf and not addsub_inf_invalid
        valid_mul_inf = mul_inf and not mul_0_by_inf
        valid_div_inf = div_inf and not div_0_by_0 and not div_inf_by_inf
        out_inf_trigger = (
            valid_addsub_inf or valid_mul_inf or valid_div_inf or
            div_by_0 or exponent > 2046
        )

        round_nearest = mode == 0
        round_to_zero = mode == 1
        round_to_pos_inf = mode == 2
        round_to_neg_inf = mode == 3
        negative_result = bool(candidate & sign_mask)
        inf_round_down_trigger = out_inf_trigger and (
            (not negative_result and (round_to_zero or round_to_neg_inf)) or
            (negative_result and (round_to_zero or round_to_pos_inf))
        )

        mul_uf = (
            multiply and candidate_zero and not opa_zero and not opb_zero and
            not opa_inf and not opb_inf and not opa_nan and not opb_nan
        )
        div_uf = (
            divide and candidate_zero and not opa_zero and not opb_zero and
            not opa_inf and not opb_inf and not opa_nan and not opb_nan
        )
        underflow_trigger = div_by_inf or mul_uf or div_uf
        overflow_trigger = out_inf_trigger and not nan_input
        inexact_trigger = (
            not nan_input and
            (remainder != 0 or out_inf_trigger or underflow_trigger)
        )
        except_trigger = invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger
        nan_out_trigger = nan_input or invalid_trigger
        enable_trigger = (
            nan_out_trigger or out_inf_trigger or underflow_trigger or
            inexact_trigger or invalid_trigger
        )

        if opa_nan:
            selected_frac = opa_frac
        elif opb_nan:
            selected_frac = opb_frac
        else:
            selected_frac = opa_frac
        nan_magnitude = (0x7ff << 52) | (selected_frac | (1 << 51))
        nan_magnitude = self.mask(nan_magnitude, 63)

        infinity_magnitude = 2047 << 52
        max_finite_magnitude = (2046 << 52) | frac_mask
        selected_inf_magnitude = (
            max_finite_magnitude if inf_round_down_trigger else infinity_magnitude
        )
        sign = candidate & sign_mask
        stage0 = sign if underflow_trigger else candidate
        if out_inf_trigger:
            stage1 = sign | selected_inf_magnitude
        else:
            stage1 = stage0
        if nan_out_trigger:
            stage2 = sign | nan_magnitude
        else:
            stage2 = stage1

        self.in_et_zero = int(candidate_zero)
        self.opa_et_zero = int(opa_zero)
        self.opb_et_zero = int(opb_zero)
        self.input_et_zero = int(candidate_zero)
        self.add = int(add)
        self.subtract = int(subtract)
        self.multiply = int(multiply)
        self.divide = int(divide)
        self.opa_qnan = int(opa_qnan)
        self.opb_qnan = int(opb_qnan)
        self.opa_snan = int(opa_snan)
        self.opb_snan = int(opb_snan)
        self.opa_pos_inf = int(opa_pos_inf)
        self.opb_pos_inf = int(opb_pos_inf)
        self.opa_neg_inf = int(opa_neg_inf)
        self.opb_neg_inf = int(opb_neg_inf)
        self.opa_inf = int(opa_inf)
        self.opb_inf = int(opb_inf)
        self.nan_input = int(nan_input)
        self.snan_input = int(snan_input)
        self.a_nan = int(opa_nan)
        self.div_by_0 = int(div_by_0)
        self.div_0_by_0 = int(div_0_by_0)
        self.div_inf_by_inf = int(div_inf_by_inf)
        self.div_by_inf = int(div_by_inf)
        self.mul_0_by_inf = int(mul_0_by_inf)
        self.mul_inf = int(mul_inf)
        self.div_inf = int(div_inf)
        self.add_inf = int(add_inf)
        self.sub_inf = int(sub_inf)
        self.addsub_inf_invalid = int(addsub_inf_invalid)
        self.addsub_inf = int(addsub_inf)
        self.out_inf_trigger = int(out_inf_trigger)
        self.out_pos_inf = int(out_inf_trigger and not negative_result)
        self.out_neg_inf = int(out_inf_trigger and negative_result)
        self.round_nearest = int(round_nearest)
        self.round_to_zero = int(round_to_zero)
        self.round_to_pos_inf = int(round_to_pos_inf)
        self.round_to_neg_inf = int(round_to_neg_inf)
        self.inf_round_down_trigger = int(inf_round_down_trigger)
        self.mul_uf = int(mul_uf)
        self.div_uf = int(div_uf)
        self.underflow_trigger = int(underflow_trigger)
        self.invalid_trigger = int(invalid_trigger)
        self.overflow_trigger = int(overflow_trigger)
        self.inexact_trigger = int(inexact_trigger)
        self.except_trigger = int(except_trigger)
        self.enable_trigger = int(enable_trigger)
        self.nan_out_trigger = int(nan_out_trigger)
        self.snan_trigger = int(snan_input)

        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = frac_mask
        self.nan_output_0 = nan_magnitude
        self.nan_output = nan_magnitude
        self.inf_round_down = max_finite_magnitude
        self.out_inf = infinity_magnitude
        self.out_0 = self.mask(stage0, 64)
        self.out_1 = self.mask(stage1, 64)
        self.out_2 = self.mask(stage2, 64)
        self.out = self.mask(stage2, 64)

        self.invalid = int(invalid_trigger)
        self.overflow = int(overflow_trigger)
        self.underflow = int(underflow_trigger)
        self.inexact = int(inexact_trigger)
        self.exception = int(except_trigger)
        self.ex_enable = int(enable_trigger)
