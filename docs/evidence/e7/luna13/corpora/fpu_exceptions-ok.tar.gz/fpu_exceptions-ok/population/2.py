"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        self.out = 0
        self.ex_enable = 0
        self.underflow = 0
        self.overflow = 0
        self.inexact = 0
        self.exception = 0
        self.invalid = 0
        for name in (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger'
        ):
            setattr(self, name, 0)
        for name in ('nan_output_0', 'nan_output', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2'):
            setattr(self, name, 0)
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1
        self._s0_inf = 0
        self._s0_down = 0
        self._s0_sign = 0
        self._s0_nan = 0
        self._s0_nan_payload = 0
        self._s1_nan = 0
        self._s1_sign = 0
        self._s1_nan_payload = 0

    def outputs(self, i):
        for name in (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger'
        ):
            setattr(self, name, self.mask(getattr(self, name), 1))
        for name, width in (
            ('nan_output_0', 63), ('nan_output', 63),
            ('inf_round_down', 63), ('out_inf', 63),
            ('out_0', 64), ('out_1', 64), ('out_2', 64)
        ):
            setattr(self, name, self.mask(getattr(self, name), width))
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self.mask(self.out, 64)
        o['ex_enable'] = self.mask(self.ex_enable, 1)
        o['underflow'] = self.mask(self.underflow, 1)
        o['overflow'] = self.mask(self.overflow, 1)
        o['inexact'] = self.mask(self.inexact, 1)
        o['exception'] = self.mask(self.exception, 1)
        o['invalid'] = self.mask(self.invalid, 1)
        return o

    def _decode(self, i):
        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        result = self.mask(i['in_except'], 64)
        exponent = self.mask(i['exponent_in'], 12)
        mantissa = self.mask(i['mantissa_in'], 2)
        op = self.mask(i['fpu_op'], 3)
        rmode = self.mask(i['rmode'], 2)
        frac_mask = (1 << 52) - 1
        lower63 = (1 << 63) - 1
        a_exp = (opa >> 52) & 0x7ff
        b_exp = (opb >> 52) & 0x7ff
        a_frac = opa & frac_mask
        b_frac = opb & frac_mask
        a_zero = int((opa & lower63) == 0)
        b_zero = int((opb & lower63) == 0)
        a_nan = int(a_exp == 0x7ff and a_frac != 0)
        b_nan = int(b_exp == 0x7ff and b_frac != 0)
        a_qnan = int(a_nan and ((a_frac >> 51) & 1))
        b_qnan = int(b_nan and ((b_frac >> 51) & 1))
        a_snan = int(a_nan and not ((a_frac >> 51) & 1))
        b_snan = int(b_nan and not ((b_frac >> 51) & 1))
        a_inf = int(a_exp == 0x7ff and a_frac == 0)
        b_inf = int(b_exp == 0x7ff and b_frac == 0)
        a_pos_inf = int(a_inf and not ((opa >> 63) & 1))
        b_pos_inf = int(b_inf and not ((opb >> 63) & 1))
        a_neg_inf = int(a_inf and ((opa >> 63) & 1))
        b_neg_inf = int(b_inf and ((opb >> 63) & 1))
        is_add = int(op == 0)
        is_sub = int(op == 1)
        is_mul = int(op == 2)
        is_div = int(op == 3)
        nan_input = int(a_nan or b_nan)
        snan_input = int(a_snan or b_snan)
        div_0_by_0 = int(is_div and a_zero and b_zero)
        div_inf_by_inf = int(is_div and a_inf and b_inf)
        div_by_0 = int(is_div and b_zero and not a_zero and not a_inf and not nan_input)
        div_by_inf = int(is_div and b_inf and not a_inf and not nan_input)
        mul_0_by_inf = int(is_mul and ((a_zero and b_inf) or (b_zero and a_inf)))
        mul_inf = int(is_mul and (a_inf or b_inf) and not mul_0_by_inf)
        div_inf = int(is_div and a_inf and not b_inf)
        add_inf = int(is_add and (a_inf or b_inf))
        sub_inf = int(is_sub and (a_inf or b_inf))
        addsub_inf = int((is_add or is_sub) and (a_inf or b_inf))
        addsub_inf_invalid = int(
            (is_add and ((a_pos_inf and b_neg_inf) or (a_neg_inf and b_pos_inf))) or
            (is_sub and ((a_pos_inf and b_pos_inf) or (a_neg_inf and b_neg_inf)))
        )
        invalid_trigger = int(
            snan_input or addsub_inf_invalid or mul_0_by_inf or
            div_0_by_0 or div_inf_by_inf
        )
        in_zero = int((result & lower63) == 0)
        mul_uf = int(is_mul and in_zero and not a_zero and not b_zero)
        div_uf = int(
            div_by_inf or
            (is_div and in_zero and not a_zero and not b_zero)
        )
        underflow_trigger = int(mul_uf or div_uf)
        valid_addsub_inf = int(addsub_inf and not addsub_inf_invalid)
        out_inf_trigger = int(
            valid_addsub_inf or mul_inf or div_inf or div_by_0 or exponent > 2046
        )
        sign = (result >> 63) & 1
        out_pos_inf = int(out_inf_trigger and not sign)
        out_neg_inf = int(out_inf_trigger and sign)
        round_down = int(
            (out_pos_inf and rmode in (1, 3)) or
            (out_neg_inf and rmode in (1, 2))
        )
        overflow_trigger = int(out_inf_trigger and not nan_input)
        inexact_trigger = int(
            not nan_input and (mantissa != 0 or out_inf_trigger or underflow_trigger)
        )
        except_trigger = int(
            invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger
        )
        nan_out_trigger = int(nan_input or invalid_trigger)
        snan_trigger = snan_input
        a_nan_select = int(a_nan or not nan_input)
        if nan_input:
            selected = opa if a_nan else opb
            nan_payload = (selected & lower63) | (1 << 51)
        elif nan_out_trigger:
            nan_payload = (2047 << 52) | (1 << 51) | (opa & ((1 << 51) - 1))
        else:
            nan_payload = 0
        max_finite = (2046 << 52) | frac_mask
        infinity_magnitude = 2047 << 52
        return {
            'opa': opa,
            'opb': opb,
            'in_except': result,
            'in_et_zero': in_zero,
            'opa_et_zero': a_zero,
            'opb_et_zero': b_zero,
            'input_et_zero': in_zero,
            'add': is_add,
            'subtract': is_sub,
            'multiply': is_mul,
            'divide': is_div,
            'opa_qnan': a_qnan,
            'opb_qnan': b_qnan,
            'opa_snan': a_snan,
            'opb_snan': b_snan,
            'opa_pos_inf': a_pos_inf,
            'opb_pos_inf': b_pos_inf,
            'opa_neg_inf': a_neg_inf,
            'opb_neg_inf': b_neg_inf,
            'opa_inf': a_inf,
            'opb_inf': b_inf,
            'nan_input': nan_input,
            'snan_input': snan_input,
            'a_nan': a_nan_select,
            'div_by_0': div_by_0,
            'div_0_by_0': div_0_by_0,
            'div_inf_by_inf': div_inf_by_inf,
            'div_by_inf': div_by_inf,
            'mul_0_by_inf': mul_0_by_inf,
            'mul_inf': mul_inf,
            'div_inf': div_inf,
            'add_inf': add_inf,
            'sub_inf': sub_inf,
            'addsub_inf_invalid': addsub_inf_invalid,
            'addsub_inf': addsub_inf,
            'out_inf_trigger': out_inf_trigger,
            'out_pos_inf': out_pos_inf,
            'out_neg_inf': out_neg_inf,
            'round_nearest': int(rmode == 0),
            'round_to_zero': int(rmode == 1),
            'round_to_pos_inf': int(rmode == 2),
            'round_to_neg_inf': int(rmode == 3),
            'inf_round_down_trigger': round_down,
            'mul_uf': mul_uf,
            'div_uf': div_uf,
            'underflow_trigger': underflow_trigger,
            'invalid_trigger': invalid_trigger,
            'overflow_trigger': overflow_trigger,
            'inexact_trigger': inexact_trigger,
            'except_trigger': except_trigger,
            'enable_trigger': int(nan_out_trigger or out_inf_trigger or underflow_trigger or inexact_trigger),
            'nan_out_trigger': nan_out_trigger,
            'snan_trigger': snan_trigger,
            'nan_payload': self.mask(nan_payload, 63),
            'out_inf': infinity_magnitude if out_inf_trigger else 0,
            'inf_round_down': max_finite if round_down else 0
        }

    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not i['enable']:
            return
        d = self._decode(i)

        old_out_0 = self.out_0
        old_out_1 = self.out_1
        old_out_2 = self.out_2
        old_s0_inf = self._s0_inf
        old_s0_down = self._s0_down
        old_s0_sign = self._s0_sign
        old_s0_nan = self._s0_nan
        old_s0_payload = self._s0_nan_payload
        old_s1_nan = self._s1_nan
        old_s1_sign = self._s1_sign
        old_s1_payload = self._s1_nan_payload
        old_nan_output_0 = self.nan_output_0

        next_out_1 = old_out_0
        if old_s0_inf:
            magnitude = ((2046 << 52) | ((1 << 52) - 1)) if old_s0_down else (2047 << 52)
            next_out_1 = (old_s0_sign << 63) | magnitude
        next_out_2 = old_out_1
        if old_s1_nan:
            next_out_2 = (old_s1_sign << 63) | old_s1_payload

        for name in (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger'
        ):
            setattr(self, name, d[name])

        self.underflow = d['underflow_trigger']
        self.overflow = d['overflow_trigger']
        self.inexact = d['inexact_trigger']
        self.exception = d['except_trigger']
        self.invalid = d['invalid_trigger']
        self.ex_enable = d['enable_trigger']

        next_out_0 = ((d['in_except'] >> 63) << 63) if d['underflow_trigger'] else d['in_except']
        self.out = self.mask(old_out_2, 64)
        self.out_0 = self.mask(next_out_0, 64)
        self.out_1 = self.mask(next_out_1, 64)
        self.out_2 = self.mask(next_out_2, 64)

        self._s0_inf = d['out_inf_trigger']
        self._s0_down = d['inf_round_down_trigger']
        self._s0_sign = (d['in_except'] >> 63) & 1
        self._s0_nan = d['nan_out_trigger']
        self._s0_nan_payload = d['nan_payload']
        self._s1_nan = old_s0_nan
        self._s1_sign = old_s0_sign
        self._s1_nan_payload = old_s0_payload

        self.nan_output_0 = d['nan_payload']
        self.nan_output = self.mask(old_nan_output_0, 63)
        self.out_inf = self.mask(d['out_inf'], 63)
        self.inf_round_down = self.mask(d['inf_round_down'], 63)
