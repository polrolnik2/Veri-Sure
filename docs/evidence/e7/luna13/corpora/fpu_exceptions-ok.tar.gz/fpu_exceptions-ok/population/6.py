"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        self.out = 0
        self.ex_enable = 0
        self.underflow = 0
        self.overflow = 0
        self.inexact = 0
        self.exception = 0
        self.invalid = 0
        self._probe_state = dict.fromkeys((
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger',
            'nan_output_0', 'nan_output', 'inf_round_down', 'out_inf',
            'out_0', 'out_1', 'out_2'
        ), 0)

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self.mask(self.out, 64)
        o['ex_enable'] = self.mask(self.ex_enable, 1)
        o['underflow'] = self.mask(self.underflow, 1)
        o['overflow'] = self.mask(self.overflow, 1)
        o['inexact'] = self.mask(self.inexact, 1)
        o['exception'] = self.mask(self.exception, 1)
        o['invalid'] = self.mask(self.invalid, 1)
        for name, value in self._probe_state.items():
            setattr(self, name, value)
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not i['enable']:
            return

        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        candidate = self.mask(i['in_except'], 64)
        exponent_in = self.mask(i['exponent_in'], 12)
        mantissa_in = self.mask(i['mantissa_in'], 2)
        fpu_op = self.mask(i['fpu_op'], 3)
        rmode = self.mask(i['rmode'], 2)

        fraction_mask = (1 << 52) - 1
        low63_mask = (1 << 63) - 1
        opa_exp = (opa >> 52) & 0x7ff
        opb_exp = (opb >> 52) & 0x7ff
        opa_fraction = opa & fraction_mask
        opb_fraction = opb & fraction_mask

        opa_zero = int((opa & low63_mask) == 0)
        opb_zero = int((opb & low63_mask) == 0)
        input_zero = int((candidate & low63_mask) == 0)

        opa_nan = int(opa_exp == 0x7ff and opa_fraction != 0)
        opb_nan = int(opb_exp == 0x7ff and opb_fraction != 0)
        opa_qnan = int(opa_nan and ((opa_fraction >> 51) & 1))
        opb_qnan = int(opb_nan and ((opb_fraction >> 51) & 1))
        opa_snan = int(opa_nan and not opa_qnan)
        opb_snan = int(opb_nan and not opb_qnan)
        nan_input = int(opa_nan or opb_nan)
        snan_input = int(opa_snan or opb_snan)

        opa_inf = int(opa_exp == 0x7ff and opa_fraction == 0)
        opb_inf = int(opb_exp == 0x7ff and opb_fraction == 0)
        opa_pos_inf = int(opa_inf and ((opa >> 63) & 1) == 0)
        opb_pos_inf = int(opb_inf and ((opb >> 63) & 1) == 0)
        opa_neg_inf = int(opa_inf and ((opa >> 63) & 1) == 1)
        opb_neg_inf = int(opb_inf and ((opb >> 63) & 1) == 1)

        add = int(fpu_op == 0)
        subtract = int(fpu_op == 1)
        multiply = int(fpu_op == 2)
        divide = int(fpu_op == 3)

        div_0_by_0 = int(divide and opa_zero and opb_zero)
        div_inf_by_inf = int(divide and opa_inf and opb_inf)
        div_by_0 = int(divide and opb_zero and not opa_zero and not nan_input)
        div_by_inf = int(divide and opb_inf and not opa_inf and not nan_input)

        mul_0_by_inf = int(multiply and ((opa_zero and opb_inf) or (opb_zero and opa_inf)))
        mul_inf = int(multiply and (opa_inf or opb_inf) and not mul_0_by_inf and not nan_input)

        div_inf = int(divide and opa_inf and not opb_inf and not nan_input)
        add_inf = int(add and (opa_inf or opb_inf))
        sub_inf = int(subtract and (opa_inf or opb_inf))
        add_invalid = bool(add and ((opa_pos_inf and opb_neg_inf) or (opa_neg_inf and opb_pos_inf)))
        sub_invalid = bool(subtract and ((opa_pos_inf and opb_pos_inf) or (opa_neg_inf and opb_neg_inf)))
        addsub_inf_invalid = int(add_invalid or sub_invalid)
        addsub_inf = int((add_inf or sub_inf) and not addsub_inf_invalid and not nan_input)

        invalid_trigger = int(bool(snan_input or addsub_inf_invalid or mul_0_by_inf or div_0_by_0 or div_inf_by_inf))
        out_inf_trigger = int(bool(
            mul_inf or div_inf or addsub_inf or div_by_0 or exponent_in > 2046
        ))

        sign = (candidate >> 63) & 1
        out_pos_inf = int(out_inf_trigger and not sign)
        out_neg_inf = int(out_inf_trigger and sign)
        round_nearest = int(rmode == 0)
        round_to_zero = int(rmode == 1)
        round_to_pos_inf = int(rmode == 2)
        round_to_neg_inf = int(rmode == 3)
        inf_round_down_trigger = int(bool(
            (out_pos_inf and (round_to_zero or round_to_neg_inf)) or
            (out_neg_inf and (round_to_zero or round_to_pos_inf))
        ))

        mul_uf = int(bool(
            multiply and not opa_zero and not opb_zero and input_zero and not nan_input
        ))
        div_uf = int(bool(
            div_by_inf or
            (divide and not opa_zero and not opb_zero and input_zero and
             not opa_inf and not opb_inf and not nan_input)
        ))
        underflow_trigger = int(bool(mul_uf or div_uf))
        overflow_trigger = int(bool(out_inf_trigger and not nan_input))
        inexact_trigger = int(bool(
            not nan_input and (mantissa_in != 0 or out_inf_trigger or underflow_trigger)
        ))
        except_trigger = int(bool(
            invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger
        ))

        nan_out_trigger = int(bool(nan_input or invalid_trigger))
        a_nan = int(bool(opa_nan or (invalid_trigger and not nan_input)))
        snan_trigger = snan_input
        enable_trigger = int(bool(
            nan_out_trigger or out_inf_trigger or underflow_trigger or inexact_trigger
        ))

        if nan_input:
            selected_nan = opa if opa_nan else opb
            nan_magnitude = (selected_nan & low63_mask) | (1 << 51)
        elif invalid_trigger:
            nan_magnitude = (0x7ff << 52) | (1 << 51) | (opa & ((1 << 51) - 1))
        else:
            nan_magnitude = 0

        infinity_magnitude = 0x7ff << 52
        max_finite_magnitude = (0x7fe << 52) | fraction_mask
        if inf_round_down_trigger:
            special_infinity_magnitude = max_finite_magnitude
        else:
            special_infinity_magnitude = infinity_magnitude

        out_0 = ((sign << 63) if underflow_trigger else candidate)
        out_1 = ((sign << 63) | special_infinity_magnitude) if out_inf_trigger else out_0
        out_2 = ((sign << 63) | nan_magnitude) if nan_out_trigger else out_1

        self.out = self.mask(out_2, 64)
        self.ex_enable = enable_trigger
        self.underflow = underflow_trigger
        self.overflow = overflow_trigger
        self.inexact = inexact_trigger
        self.exception = except_trigger
        self.invalid = invalid_trigger

        self._probe_state.update({
            'in_et_zero': input_zero,
            'opa_et_zero': opa_zero,
            'opb_et_zero': opb_zero,
            'input_et_zero': input_zero,
            'add': add,
            'subtract': subtract,
            'multiply': multiply,
            'divide': divide,
            'opa_qnan': opa_qnan,
            'opb_qnan': opb_qnan,
            'opa_snan': opa_snan,
            'opb_snan': opb_snan,
            'opa_pos_inf': opa_pos_inf,
            'opb_pos_inf': opb_pos_inf,
            'opa_neg_inf': opa_neg_inf,
            'opb_neg_inf': opb_neg_inf,
            'opa_inf': opa_inf,
            'opb_inf': opb_inf,
            'nan_input': nan_input,
            'snan_input': snan_input,
            'a_nan': a_nan,
            'div_by_0': div_by_0,
            'div_0_by_0': div_0_by_0,
            'div_inf_by_inf': div_inf_by_inf,
            'div_by_inf': div_by_inf,
            'mul_0_by_inf': mul_0_by_inf,
            'mul_inf': mul_inf,
            'div_inf': div_inf,
            'add_inf': add_inf,
            'sub_inf': sub_inf,
            'addsub_inf_invalid': addsub_inf_invalid,
            'addsub_inf': addsub_inf,
            'out_inf_trigger': out_inf_trigger,
            'out_pos_inf': out_pos_inf,
            'out_neg_inf': out_neg_inf,
            'round_nearest': round_nearest,
            'round_to_zero': round_to_zero,
            'round_to_pos_inf': round_to_pos_inf,
            'round_to_neg_inf': round_to_neg_inf,
            'inf_round_down_trigger': inf_round_down_trigger,
            'mul_uf': mul_uf,
            'div_uf': div_uf,
            'underflow_trigger': underflow_trigger,
            'invalid_trigger': invalid_trigger,
            'overflow_trigger': overflow_trigger,
            'inexact_trigger': inexact_trigger,
            'except_trigger': except_trigger,
            'enable_trigger': enable_trigger,
            'nan_out_trigger': nan_out_trigger,
            'snan_trigger': snan_trigger,
            'nan_output_0': nan_magnitude,
            'nan_output': nan_magnitude,
            'inf_round_down': max_finite_magnitude if inf_round_down_trigger else 0,
            'out_inf': infinity_magnitude if out_inf_trigger else 0,
            'out_0': self.mask(out_0, 64),
            'out_1': self.mask(out_1, 64),
            'out_2': self.mask(out_2, 64)
        })
