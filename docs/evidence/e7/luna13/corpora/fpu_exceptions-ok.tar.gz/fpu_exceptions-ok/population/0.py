"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        self._out_reg = 0
        self._ex_enable_reg = 0
        self._underflow_reg = 0
        self._overflow_reg = 0
        self._inexact_reg = 0
        self._exception_reg = 0
        self._invalid_reg = 0
        self._probe_names = (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger',
            'nan_output_0', 'nan_output', 'inf_round_down', 'out_inf',
            'out_0', 'out_1', 'out_2'
        )
        self._probe_state = {name: 0 for name in self._probe_names}
        self._s0_inf_trigger = 0
        self._s0_inf_magnitude = 0
        self._s0_sign = 0
        self._s0_nan_trigger = 0
        self._s1_nan_trigger = 0
        self._s1_sign = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self._out_reg
        o['ex_enable'] = self._ex_enable_reg
        o['underflow'] = self._underflow_reg
        o['overflow'] = self._overflow_reg
        o['inexact'] = self._inexact_reg
        o['exception'] = self._exception_reg
        o['invalid'] = self._invalid_reg
        for name in self._probe_names:
            setattr(self, name, self._probe_state[name])
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1
        return o

    def _derive(self, i):
        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        candidate = self.mask(i['in_except'], 64)
        exponent = self.mask(i['exponent_in'], 12)
        mantissa = self.mask(i['mantissa_in'], 2)
        op = self.mask(i['fpu_op'], 3)
        mode = self.mask(i['rmode'], 2)

        fraction_mask = (1 << 52) - 1
        magnitude_mask = (1 << 63) - 1
        a_exp = (opa >> 52) & 0x7ff
        b_exp = (opb >> 52) & 0x7ff
        a_fraction = opa & fraction_mask
        b_fraction = opb & fraction_mask
        a_zero = int((opa & magnitude_mask) == 0)
        b_zero = int((opb & magnitude_mask) == 0)
        result_zero = int((candidate & magnitude_mask) == 0)
        a_nan = int(a_exp == 0x7ff and a_fraction != 0)
        b_nan = int(b_exp == 0x7ff and b_fraction != 0)
        a_qnan = int(a_nan and ((a_fraction >> 51) & 1) != 0)
        b_qnan = int(b_nan and ((b_fraction >> 51) & 1) != 0)
        a_snan = int(a_nan and not a_qnan)
        b_snan = int(b_nan and not b_qnan)
        a_inf = int(a_exp == 0x7ff and a_fraction == 0)
        b_inf = int(b_exp == 0x7ff and b_fraction == 0)
        a_sign = (opa >> 63) & 1
        b_sign = (opb >> 63) & 1
        result_sign = (candidate >> 63) & 1

        is_add = int(op == 0)
        is_subtract = int(op == 1)
        is_multiply = int(op == 2)
        is_divide = int(op == 3)
        a_pos_inf = int(a_inf and not a_sign)
        b_pos_inf = int(b_inf and not b_sign)
        a_neg_inf = int(a_inf and a_sign)
        b_neg_inf = int(b_inf and b_sign)
        nan_input = int(a_nan or b_nan)
        snan_input = int(a_snan or b_snan)

        div_0_by_0 = int(is_divide and a_zero and b_zero)
        div_inf_by_inf = int(is_divide and a_inf and b_inf)
        div_by_0 = int(is_divide and b_zero and not a_zero)
        div_by_inf = int(is_divide and b_inf and not a_inf)
        mul_0_by_inf = int(is_multiply and ((a_zero and b_inf) or (b_zero and a_inf)))
        mul_inf = int(is_multiply and (a_inf or b_inf) and not mul_0_by_inf)
        div_inf = int(is_divide and a_inf and not b_inf)
        add_inf = int(is_add and (a_inf or b_inf))
        sub_inf = int(is_subtract and (a_inf or b_inf))

        invalid_add = is_add and ((a_pos_inf and b_neg_inf) or (a_neg_inf and b_pos_inf))
        invalid_subtract = is_subtract and ((a_pos_inf and b_pos_inf) or (a_neg_inf and b_neg_inf))
        addsub_inf_invalid = int(invalid_add or invalid_subtract)
        addsub_inf = int(add_inf or sub_inf)
        invalid_trigger = int(
            snan_input or addsub_inf_invalid or mul_0_by_inf or
            div_0_by_0 or div_inf_by_inf
        )

        valid_addsub_inf = addsub_inf and not addsub_inf_invalid
        out_inf_trigger = int(
            mul_inf or div_inf or valid_addsub_inf or div_by_0 or exponent > 2046
        )
        round_nearest = int(mode == 0)
        round_to_zero = int(mode == 1)
        round_to_pos_inf = int(mode == 2)
        round_to_neg_inf = int(mode == 3)
        round_down = int(
            out_inf_trigger and (
                (not result_sign and (round_to_zero or round_to_neg_inf)) or
                (result_sign and (round_to_zero or round_to_pos_inf))
            )
        )

        mul_uf = int(is_multiply and not a_zero and not b_zero and result_zero)
        div_uf = int(
            div_by_inf or
            (is_divide and not a_zero and not b_zero and result_zero)
        )
        underflow_trigger = int(mul_uf or div_uf)
        overflow_trigger = int(out_inf_trigger and not nan_input)
        inexact_trigger = int(
            not nan_input and (mantissa != 0 or out_inf_trigger or underflow_trigger)
        )
        except_trigger = int(
            invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger
        )
        nan_out_trigger = int(nan_input or invalid_trigger)
        enable_trigger = except_trigger

        infinity_magnitude = 2047 << 52
        maximum_finite_magnitude = (2046 << 52) | fraction_mask
        inf_round_down = maximum_finite_magnitude if round_down else 0
        out_inf = infinity_magnitude if out_inf_trigger else 0

        if nan_input:
            selected_fraction = a_fraction if a_nan else b_fraction
        else:
            selected_fraction = a_fraction
        nan_magnitude = ((0x7ff << 52) | selected_fraction | (1 << 51)) if nan_out_trigger else 0

        return {
            'in_et_zero': result_zero,
            'opa_et_zero': a_zero,
            'opb_et_zero': b_zero,
            'input_et_zero': result_zero,
            'add': is_add,
            'subtract': is_subtract,
            'multiply': is_multiply,
            'divide': is_divide,
            'opa_qnan': a_qnan,
            'opb_qnan': b_qnan,
            'opa_snan': a_snan,
            'opb_snan': b_snan,
            'opa_pos_inf': a_pos_inf,
            'opb_pos_inf': b_pos_inf,
            'opa_neg_inf': a_neg_inf,
            'opb_neg_inf': b_neg_inf,
            'opa_inf': a_inf,
            'opb_inf': b_inf,
            'nan_input': nan_input,
            'snan_input': snan_input,
            'a_nan': int(a_nan),
            'div_by_0': div_by_0,
            'div_0_by_0': div_0_by_0,
            'div_inf_by_inf': div_inf_by_inf,
            'div_by_inf': div_by_inf,
            'mul_0_by_inf': mul_0_by_inf,
            'mul_inf': mul_inf,
            'div_inf': div_inf,
            'add_inf': int(add_inf),
            'sub_inf': int(sub_inf),
            'addsub_inf_invalid': addsub_inf_invalid,
            'addsub_inf': addsub_inf,
            'out_inf_trigger': out_inf_trigger,
            'out_pos_inf': int(out_inf_trigger and not result_sign),
            'out_neg_inf': int(out_inf_trigger and result_sign),
            'round_nearest': round_nearest,
            'round_to_zero': round_to_zero,
            'round_to_pos_inf': round_to_pos_inf,
            'round_to_neg_inf': round_to_neg_inf,
            'inf_round_down_trigger': round_down,
            'mul_uf': mul_uf,
            'div_uf': div_uf,
            'underflow_trigger': underflow_trigger,
            'invalid_trigger': invalid_trigger,
            'overflow_trigger': overflow_trigger,
            'inexact_trigger': inexact_trigger,
            'except_trigger': except_trigger,
            'enable_trigger': enable_trigger,
            'nan_out_trigger': nan_out_trigger,
            'snan_trigger': snan_input,
            'nan_output_0': nan_magnitude,
            'inf_round_down': inf_round_down,
            'out_inf': out_inf,
            'underflow': underflow_trigger,
            'overflow': overflow_trigger,
            'inexact': inexact_trigger,
            'exception': except_trigger,
            'invalid': invalid_trigger,
            'ex_enable': enable_trigger,
            'candidate': candidate,
            'result_sign': result_sign,
            'nan_magnitude': nan_magnitude,
            'selected_inf_magnitude': inf_round_down if round_down else out_inf
        }

    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not i['enable']:
            return

        d = self._derive(i)
        state = self._probe_state
        old_out_0 = state['out_0']
        old_out_1 = state['out_1']
        old_out_2 = state['out_2']
        old_nan_output_0 = state['nan_output_0']
        old_nan_output = state['nan_output']
        old_s0_inf_trigger = self._s0_inf_trigger
        old_s0_inf_magnitude = self._s0_inf_magnitude
        old_s0_sign = self._s0_sign
        old_s0_nan_trigger = self._s0_nan_trigger
        old_s1_nan_trigger = self._s1_nan_trigger
        old_s1_sign = self._s1_sign

        new_out_0 = ((d['result_sign'] << 63) if d['underflow'] else d['candidate'])
        new_out_1 = old_out_0
        if old_s0_inf_trigger:
            new_out_1 = (old_s0_sign << 63) | old_s0_inf_magnitude
        new_out_2 = old_out_1
        if old_s1_nan_trigger:
            new_out_2 = (old_s1_sign << 63) | old_nan_output
        new_out = old_out_2

        for name in d:
            if name in state:
                state[name] = d[name]
        state['nan_output_0'] = d['nan_output_0']
        state['nan_output'] = old_nan_output_0
        state['out_0'] = self.mask(new_out_0, 64)
        state['out_1'] = self.mask(new_out_1, 64)
        state['out_2'] = self.mask(new_out_2, 64)
        self._out_reg = self.mask(new_out, 64)

        self._s0_inf_trigger = d['out_inf_trigger']
        self._s0_inf_magnitude = d['selected_inf_magnitude']
        self._s0_sign = d['result_sign']
        self._s0_nan_trigger = d['nan_out_trigger']
        self._s1_nan_trigger = old_s0_nan_trigger
        self._s1_sign = old_s0_sign

        self._ex_enable_reg = d['ex_enable']
        self._underflow_reg = d['underflow']
        self._overflow_reg = d['overflow']
        self._inexact_reg = d['inexact']
        self._exception_reg = d['exception']
        self._invalid_reg = d['invalid']
