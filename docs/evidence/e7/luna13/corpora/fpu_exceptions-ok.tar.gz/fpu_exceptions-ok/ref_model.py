"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        self._p = {
            'in_et_zero': False, 'opa_et_zero': False, 'opb_et_zero': False,
            'input_et_zero': False, 'add': False, 'subtract': False,
            'multiply': False, 'divide': False, 'opa_qnan': False,
            'opb_qnan': False, 'opa_snan': False, 'opb_snan': False,
            'opa_pos_inf': False, 'opb_pos_inf': False,
            'opa_neg_inf': False, 'opb_neg_inf': False,
            'opa_inf': False, 'opb_inf': False, 'nan_input': False,
            'snan_input': False, 'a_nan': False, 'div_by_0': False,
            'div_0_by_0': False, 'div_inf_by_inf': False,
            'div_by_inf': False, 'mul_0_by_inf': False, 'mul_inf': False,
            'div_inf': False, 'add_inf': False, 'sub_inf': False,
            'addsub_inf_invalid': False, 'addsub_inf': False,
            'out_inf_trigger': False, 'out_pos_inf': False,
            'out_neg_inf': False, 'round_nearest': False,
            'round_to_zero': False, 'round_to_pos_inf': False,
            'round_to_neg_inf': False, 'inf_round_down_trigger': False,
            'mul_uf': False, 'div_uf': False, 'underflow_trigger': False,
            'invalid_trigger': False, 'overflow_trigger': False,
            'inexact_trigger': False, 'except_trigger': False,
            'enable_trigger': False, 'nan_out_trigger': False,
            'snan_trigger': False, 'exp_2047': 2047, 'exp_2046': 2046,
            'nan_output_0': 0, 'nan_output': 0,
            'mantissa_max': (1 << 52) - 1, 'inf_round_down': 0,
            'out_inf': 0, 'out_0': 0, 'out_1': 0, 'out_2': 0
        }
        for _name, _value in self._p.items():
            setattr(self, _name, _value)
        self.out = 0
        self.ex_enable = 0
        self.underflow = 0
        self.overflow = 0
        self.inexact = 0
        self.exception = 0
        self.invalid = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self.out
        o['ex_enable'] = self.ex_enable
        o['underflow'] = self.underflow
        o['overflow'] = self.overflow
        o['inexact'] = self.inexact
        o['exception'] = self.exception
        o['invalid'] = self.invalid
        for _name, _value in self._p.items():
            setattr(self, _name, _value)
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not i['enable']:
            return
        _p, _r = self._derive(i)
        self._p = _p
        for _name, _value in _r.items():
            setattr(self, _name, _value)

    def _derive(self, i):
        _opa = self.mask(i['opa'], 64)
        _opb = self.mask(i['opb'], 64)
        _candidate = self.mask(i['in_except'], 64)
        _exponent = self.mask(i['exponent_in'], 12)
        _mantissa = self.mask(i['mantissa_in'], 2)
        _op = self.mask(i['fpu_op'], 3)
        _mode = self.mask(i['rmode'], 2)
        _frac_mask = (1 << 52) - 1
        _mag_mask = (1 << 63) - 1
        _quiet_bit = 1 << 51
        _sign = _candidate & (1 << 63)
        _a_exp = (_opa >> 52) & 0x7ff
        _b_exp = (_opb >> 52) & 0x7ff
        _a_frac = _opa & _frac_mask
        _b_frac = _opb & _frac_mask
        _a_zero = (_opa & _mag_mask) == 0
        _b_zero = (_opb & _mag_mask) == 0
        _result_zero = (_candidate & _mag_mask) == 0
        _a_nan = _a_exp == 0x7ff and _a_frac != 0
        _b_nan = _b_exp == 0x7ff and _b_frac != 0
        _a_qnan = _a_nan and bool(_a_frac & _quiet_bit)
        _b_qnan = _b_nan and bool(_b_frac & _quiet_bit)
        _a_snan = _a_nan and not bool(_a_frac & _quiet_bit)
        _b_snan = _b_nan and not bool(_b_frac & _quiet_bit)
        _a_inf = _a_exp == 0x7ff and _a_frac == 0
        _b_inf = _b_exp == 0x7ff and _b_frac == 0
        _a_pos_inf = _a_inf and not bool(_opa >> 63)
        _b_pos_inf = _b_inf and not bool(_opb >> 63)
        _a_neg_inf = _a_inf and bool(_opa >> 63)
        _b_neg_inf = _b_inf and bool(_opb >> 63)
        _is_add = _op == 0
        _is_sub = _op == 1
        _is_mul = _op == 2
        _is_div = _op == 3
        _nan_input = _a_nan or _b_nan
        _snan_input = _a_snan or _b_snan
        _div_0_by_0 = _is_div and _a_zero and _b_zero
        _div_inf_by_inf = _is_div and _a_inf and _b_inf
        _div_by_0 = (_is_div and not _a_zero and not _a_inf and
                     not _a_nan and _b_zero)
        _div_by_inf = (_is_div and _b_inf and not _a_inf and
                       not _a_nan)
        _mul_0_by_inf = (_is_mul and ((_a_zero and _b_inf) or
                                      (_b_zero and _a_inf)))
        _addsub_invalid = (
            (_is_add and ((_a_pos_inf and _b_neg_inf) or
                          (_a_neg_inf and _b_pos_inf))) or
            (_is_sub and ((_a_pos_inf and _b_pos_inf) or
                          (_a_neg_inf and _b_neg_inf)))
        )
        _addsub_any_inf = (_is_add or _is_sub) and (_a_inf or _b_inf)
        _addsub_inf = _addsub_any_inf and not _addsub_invalid and not _nan_input
        _add_inf = _is_add and (_a_inf or _b_inf)
        _sub_inf = _is_sub and (_a_inf or _b_inf)
        _mul_inf = (_is_mul and (_a_inf or _b_inf) and
                    not _mul_0_by_inf and not _nan_input)
        _div_inf = (_is_div and _a_inf and not _b_inf and not _nan_input)
        _valid_inf = _addsub_inf or _mul_inf or _div_inf
        _out_inf_trigger = bool(_valid_inf or _div_by_0 or _exponent > 2046)
        _out_neg = bool(_sign)
        _out_pos_inf = _out_inf_trigger and not _out_neg
        _out_neg_inf = _out_inf_trigger and _out_neg
        _round_down = _out_inf_trigger and (
            (not _out_neg and _mode in (1, 3)) or
            (_out_neg and _mode in (1, 2))
        )
        _mul_uf = (_is_mul and not _a_zero and not _b_zero and
                   not _a_inf and not _b_inf and not _nan_input and
                   _result_zero)
        _div_uf = (_div_by_inf or
                   (_is_div and not _a_zero and not _b_zero and
                    not _a_inf and not _b_inf and not _nan_input and
                    _result_zero))
        _underflow = bool(_mul_uf or _div_uf)
        _invalid_ops = (_addsub_invalid or _mul_0_by_inf or
                        _div_0_by_0 or _div_inf_by_inf)
        _invalid = bool(_snan_input or _invalid_ops)
        _nan_out = bool(_nan_input or _invalid_ops)
        _overflow = bool(_out_inf_trigger and not _nan_input)
        _inexact = bool(not _nan_input and
                        (_mantissa != 0 or _out_inf_trigger or _underflow))
        _exception = bool(_invalid or _overflow or _underflow or _inexact)
        _enable_trigger = bool(_nan_out or _out_inf_trigger or _underflow or
                               _inexact or _invalid)
        _inf_mag = 0x7ff << 52
        _max_mag = (0x7fe << 52) | _frac_mask
        _inf_round_down = _max_mag if _round_down else 0
        _out_inf_value = _inf_mag if _out_inf_trigger else 0
        _out_0 = _sign if _underflow else _candidate
        _out_1 = (_sign | (_max_mag if _round_down else _inf_mag)
                  if _out_inf_trigger else _out_0)
        if _nan_input:
            _selected_frac = _a_frac if _a_nan else _b_frac
            _nan_frac = _selected_frac | _quiet_bit
        else:
            _nan_frac = _a_frac | _quiet_bit
        _nan_mag = (0x7ff << 52) | (_nan_frac & _frac_mask)
        _nan_value = (_sign | _nan_mag) if _nan_out else _out_1
        _nan_payload = _nan_mag & _mag_mask if _nan_out else 0
        _a_nan_select = _a_nan or (_invalid_ops and not _nan_input)
        _p = {
            'in_et_zero': bool(_result_zero),
            'opa_et_zero': bool(_a_zero),
            'opb_et_zero': bool(_b_zero),
            'input_et_zero': bool(_result_zero),
            'add': bool(_is_add), 'subtract': bool(_is_sub),
            'multiply': bool(_is_mul), 'divide': bool(_is_div),
            'opa_qnan': bool(_a_qnan), 'opb_qnan': bool(_b_qnan),
            'opa_snan': bool(_a_snan), 'opb_snan': bool(_b_snan),
            'opa_pos_inf': bool(_a_pos_inf), 'opb_pos_inf': bool(_b_pos_inf),
            'opa_neg_inf': bool(_a_neg_inf), 'opb_neg_inf': bool(_b_neg_inf),
            'opa_inf': bool(_a_inf), 'opb_inf': bool(_b_inf),
            'nan_input': bool(_nan_input), 'snan_input': bool(_snan_input),
            'a_nan': bool(_a_nan_select), 'div_by_0': bool(_div_by_0),
            'div_0_by_0': bool(_div_0_by_0),
            'div_inf_by_inf': bool(_div_inf_by_inf),
            'div_by_inf': bool(_div_by_inf),
            'mul_0_by_inf': bool(_mul_0_by_inf), 'mul_inf': bool(_mul_inf),
            'div_inf': bool(_div_inf), 'add_inf': bool(_add_inf),
            'sub_inf': bool(_sub_inf),
            'addsub_inf_invalid': bool(_addsub_invalid),
            'addsub_inf': bool(_addsub_inf),
            'out_inf_trigger': bool(_out_inf_trigger),
            'out_pos_inf': bool(_out_pos_inf), 'out_neg_inf': bool(_out_neg_inf),
            'round_nearest': bool(_mode == 0),
            'round_to_zero': bool(_mode == 1),
            'round_to_pos_inf': bool(_mode == 2),
            'round_to_neg_inf': bool(_mode == 3),
            'inf_round_down_trigger': bool(_round_down),
            'mul_uf': bool(_mul_uf), 'div_uf': bool(_div_uf),
            'underflow_trigger': bool(_underflow),
            'invalid_trigger': bool(_invalid),
            'overflow_trigger': bool(_overflow),
            'inexact_trigger': bool(_inexact),
            'except_trigger': bool(_exception),
            'enable_trigger': bool(_enable_trigger),
            'nan_out_trigger': bool(_nan_out),
            'snan_trigger': bool(_snan_input),
            'exp_2047': 2047, 'exp_2046': 2046,
            'nan_output_0': _nan_payload, 'nan_output': _nan_payload,
            'mantissa_max': _frac_mask,
            'inf_round_down': _inf_round_down, 'out_inf': _out_inf_value,
            'out_0': self.mask(_out_0, 64),
            'out_1': self.mask(_out_1, 64),
            'out_2': self.mask(_nan_value, 64)
        }
        _r = {
            'out': self.mask(_nan_value, 64),
            'ex_enable': int(_enable_trigger),
            'underflow': int(_underflow), 'overflow': int(_overflow),
            'inexact': int(_inexact), 'exception': int(_exception),
            'invalid': int(_invalid)
        }
        return _p, _r
