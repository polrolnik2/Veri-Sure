"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.saved_addr_r = 0
        self.cnt = 0
        self.hitmiss_eval = False
        self.store = False
        self.load = False
        self.cache_inhibit = False
        self.store_refill_enabled = True
        self.first_store_hit_ack = False
        self.idle = True
        self.cload = False
        self.cstore = False
        self.lrefill3 = False
        self.srefill4 = False
        self.cnt_nonzero = False

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        active_request_state = self.state in ('CLOAD', 'CSTORE')
        live_cache_inhibit = bool(
            self.cache_inhibit or
            (active_request_state and i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
        )
        load_hit_ack = bool(
            self.state == 'CLOAD' and
            not i['tagcomp_miss'] and
            not live_cache_inhibit
        )
        self.first_store_hit_ack = bool(
            self.state == 'CSTORE' and
            i['biudata_valid'] and
            not i['tagcomp_miss'] and
            not live_cache_inhibit
        )

        biu_read = bool(
            (self.state == 'CLOAD' and self.hitmiss_eval and i['tagcomp_miss']) or
            (not self.hitmiss_eval and self.load)
        )
        biu_write = bool(self.store)

        self.idle = self.state == 'IDLE'
        self.cload = self.state == 'CLOAD'
        self.cstore = self.state == 'CSTORE'
        self.lrefill3 = self.state == 'LREFILL3'
        self.srefill4 = self.state == 'SREFILL4'
        self.cnt_nonzero = bool(self.cnt != 0)

        burst = bool(
            (self.state == 'CLOAD' and i['tagcomp_miss'] and not live_cache_inhibit) or
            self.state == 'LREFILL3' or
            (self.store_refill_enabled and self.state == 'SREFILL4')
        )

        if self.load and i['biudata_valid'] and not live_cache_inhibit:
            dcram_we = 15
        elif self.first_store_hit_ack:
            dcram_we = self.mask(i['dcqmem_sel_i'], 4)
        else:
            dcram_we = 0

        first_miss_ack = bool(
            active_request_state and i['biudata_valid']
        )
        first_miss_err = bool(
            active_request_state and i['biudata_error']
        )
        tag_we = bool(biu_read and i['biudata_valid'] and not live_cache_inhibit)

        if self.hitmiss_eval or not (biu_read or biu_write):
            dc_addr = self.mask(i['start_addr'], 32)
        else:
            dc_addr = self.mask(self.saved_addr_r, 32)

        self.hitmiss_eval = bool(self.hitmiss_eval)
        self.store = bool(self.store)
        self.load = bool(self.load)
        self.cache_inhibit = bool(self.cache_inhibit)

        o['saved_addr'] = self.mask(self.saved_addr_r, 32)
        o['dcram_we'] = dcram_we
        o['biu_read'] = int(biu_read)
        o['biu_write'] = int(biu_write)
        o['first_hit_ack'] = int(bool(load_hit_ack or self.first_store_hit_ack))
        o['first_miss_ack'] = int(first_miss_ack)
        o['first_miss_err'] = int(first_miss_err)
        o['burst'] = int(burst)
        o['tag_we'] = int(tag_we)
        o['dc_addr'] = dc_addr
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return

        if self.state == 'IDLE':
            if i['dc_en'] and i['dcqmem_cycstb_i']:
                self.saved_addr_r = self.mask(i['start_addr'], 32)
                self.hitmiss_eval = True
                self.cache_inhibit = False
                if i['dcqmem_we_i']:
                    self.state = 'CSTORE'
                    self.store = True
                    self.load = False
                else:
                    self.state = 'CLOAD'
                    self.store = False
                    self.load = True
            return

        if self.state == 'CLOAD':
            live_cache_inhibit = bool(
                self.cache_inhibit or
                (i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            )
            if i['biudata_error'] or (self.hitmiss_eval and not i['dcqmem_cycstb_i']):
                self.state = 'IDLE'
                self.hitmiss_eval = False
                self.load = False
                self.store = False
                self.cache_inhibit = False
                return

            if i['dcqmem_cycstb_i'] and i['dcqmem_ci_i']:
                self.cache_inhibit = True
            self.hitmiss_eval = False

            if live_cache_inhibit:
                if i['biudata_valid']:
                    self.state = 'IDLE'
                    self.load = False
                    self.store = False
                    self.cache_inhibit = False
                return

            if not i['tagcomp_miss']:
                self.state = 'IDLE'
                self.load = False
                self.store = False
                self.cache_inhibit = False
                return

            if i['biudata_valid']:
                self.state = 'LREFILL3'
                self.saved_addr_r = self.mask(
                    (self.saved_addr_r & ~12) |
                    ((((self.saved_addr_r >> 2) + 1) & 3) << 2),
                    32
                )
                self.cnt = 2
            return

        if self.state == 'CSTORE':
            live_cache_inhibit = bool(
                self.cache_inhibit or
                (i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            )
            if i['biudata_error'] or (self.hitmiss_eval and not i['dcqmem_cycstb_i']):
                self.state = 'IDLE'
                self.hitmiss_eval = False
                self.store = False
                self.load = False
                self.cache_inhibit = False
                return

            if i['dcqmem_cycstb_i'] and i['dcqmem_ci_i']:
                self.cache_inhibit = True
            self.hitmiss_eval = False

            if i['biudata_valid']:
                if live_cache_inhibit:
                    self.state = 'IDLE'
                    self.store = False
                    self.load = False
                    self.cache_inhibit = False
                elif i['tagcomp_miss'] and self.store_refill_enabled:
                    self.state = 'SREFILL4'
                    self.store = False
                    self.load = True
                    self.cnt = 3
                else:
                    self.state = 'IDLE'
                    self.store = False
                    self.load = False
                    self.cache_inhibit = False
            return

        if self.state in ('LREFILL3', 'SREFILL4'):
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    self.saved_addr_r = self.mask(
                        (self.saved_addr_r & ~12) |
                        ((((self.saved_addr_r >> 2) + 1) & 3) << 2),
                        32
                    )
                else:
                    self.state = 'IDLE'
                    self.load = False
                    self.store = False
                    self.cache_inhibit = False
                    self.hitmiss_eval = False
