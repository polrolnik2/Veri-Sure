"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self._state = 'IDLE'
        self._saved_addr_r = 0
        self._cnt = 0
        self._hitmiss_eval = 0
        self._store = 0
        self._load = 0
        self._cache_inhibit = 0
        self._store_refill = True
        self.idle = False
        self.cload = False
        self.cstore = False
        self.lrefill3 = False
        self.srefill4 = False
        self.hitmiss_eval = False
        self.store = False
        self.load = False
        self.cache_inhibit = False
        self.cnt_nonzero = False
        self.first_store_hit_ack = False

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        # rst is asynchronous: present reset-state observations and outputs while
        # it is asserted, without changing state in this sampling method.
        reset_active = bool(i['rst'])
        state = 'IDLE' if reset_active else self._state
        saved_addr = 0 if reset_active else self._saved_addr_r
        cnt = 0 if reset_active else self._cnt
        hitmiss_eval = 0 if reset_active else self._hitmiss_eval
        store = 0 if reset_active else self._store
        load = 0 if reset_active else self._load
        cache_inhibit = 0 if reset_active else self._cache_inhibit

        ci_seen_now = bool(
            not reset_active
            and state in ('CLOAD', 'CSTORE')
            and i['dcqmem_cycstb_i']
            and i['dcqmem_ci_i']
        )
        ci_active = bool(cache_inhibit or ci_seen_now)

        self.idle = state == 'IDLE'
        self.cload = state == 'CLOAD'
        self.cstore = state == 'CSTORE'
        self.lrefill3 = state == 'LREFILL3'
        self.srefill4 = state == 'SREFILL4'
        self.hitmiss_eval = bool(hitmiss_eval)
        self.store = bool(store)
        self.load = bool(load)
        self.cache_inhibit = bool(cache_inhibit)
        self.cnt_nonzero = bool(cnt != 0)

        first_store_hit_ack = bool(
            state == 'CSTORE'
            and i['biudata_valid']
            and not i['tagcomp_miss']
            and not ci_active
            and not (hitmiss_eval and not i['dcqmem_cycstb_i'])
        )
        self.first_store_hit_ack = first_store_hit_ack

        biu_read = bool(
            (state == 'CLOAD' and (
                ci_active
                or (hitmiss_eval and i['tagcomp_miss'])
                or (not hitmiss_eval and load)
            ))
            or (state in ('LREFILL3', 'SREFILL4') and load and not ci_active)
        )
        biu_write = bool(store)
        load_hit_ack = bool(
            state == 'CLOAD'
            and hitmiss_eval
            and not i['tagcomp_miss']
            and not ci_active
            and i['dcqmem_cycstb_i']
        )
        first_hit_ack = bool(load_hit_ack or first_store_hit_ack)
        first_miss_ack = bool(
            state in ('CLOAD', 'CSTORE') and i['biudata_valid']
        )
        first_miss_err = bool(
            state in ('CLOAD', 'CSTORE') and i['biudata_error']
        )
        burst = bool(
            (state == 'CLOAD' and load and i['tagcomp_miss'] and not ci_active)
            or state == 'LREFILL3'
            or (state == 'SREFILL4' and self._store_refill)
        )

        if load and i['biudata_valid'] and not ci_active:
            dcram_we = 0xF
        elif first_store_hit_ack:
            dcram_we = self.mask(i['dcqmem_sel_i'], 4)
        else:
            dcram_we = 0

        tag_we = bool(biu_read and i['biudata_valid'] and not ci_active)
        post_eval_transfer = bool((biu_read or biu_write) and not hitmiss_eval)
        dc_addr = saved_addr if post_eval_transfer else self.mask(i['start_addr'], 32)

        o['saved_addr'] = self.mask(saved_addr, 32)
        o['dcram_we'] = self.mask(dcram_we, 4)
        o['biu_read'] = int(biu_read)
        o['biu_write'] = int(biu_write)
        o['first_hit_ack'] = int(first_hit_ack)
        o['first_miss_ack'] = int(first_miss_ack)
        o['first_miss_err'] = int(first_miss_err)
        o['burst'] = int(burst)
        o['tag_we'] = int(tag_we)
        o['dc_addr'] = self.mask(dc_addr, 32)
        return o

    def advance(self, i):
        if i['rst']:
            self._state = 'IDLE'
            self._saved_addr_r = 0
            self._cnt = 0
            self._hitmiss_eval = 0
            self._store = 0
            self._load = 0
            self._cache_inhibit = 0
            return

        if self._state == 'IDLE':
            if i['dc_en'] and i['dcqmem_cycstb_i']:
                self._saved_addr_r = self.mask(i['start_addr'], 32)
                self._hitmiss_eval = 1
                self._store = 1 if i['dcqmem_we_i'] else 0
                self._load = 0 if i['dcqmem_we_i'] else 1
                self._cache_inhibit = 0
                self._cnt = 0
                self._state = 'CSTORE' if i['dcqmem_we_i'] else 'CLOAD'
            return

        if self._state == 'CLOAD':
            ci_seen_now = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            if ci_seen_now:
                self._cache_inhibit = 1
            ci_active = bool(self._cache_inhibit or ci_seen_now)

            if self._hitmiss_eval and not i['dcqmem_cycstb_i']:
                self._state = 'IDLE'
                self._hitmiss_eval = 0
                self._load = 0
                self._store = 0
                self._cache_inhibit = 0
                self._cnt = 0
            elif i['biudata_error']:
                self._state = 'IDLE'
                self._hitmiss_eval = 0
                self._load = 0
                self._store = 0
                self._cache_inhibit = 0
                self._cnt = 0
            elif ci_active:
                self._hitmiss_eval = 0
                if i['biudata_valid']:
                    self._state = 'IDLE'
                    self._load = 0
                    self._store = 0
                    self._cache_inhibit = 0
                    self._cnt = 0
            elif self._hitmiss_eval and not i['tagcomp_miss']:
                self._state = 'IDLE'
                self._hitmiss_eval = 0
                self._load = 0
                self._store = 0
                self._cache_inhibit = 0
                self._cnt = 0
            else:
                self._hitmiss_eval = 0
                if i['biudata_valid']:
                    # The first missed word was returned at the original offset.
                    # Set the next word offset and count the remaining refill.
                    offset = (self._saved_addr_r >> 2) & 0x3
                    self._saved_addr_r = self.mask(
                        (self._saved_addr_r & ~0xC) | (((offset + 1) & 0x3) << 2),
                        32,
                    )
                    self._cnt = 2  # OR1200_DCLS - 2 for a four-word line.
                    self._state = 'LREFILL3'
            return

        if self._state == 'CSTORE':
            ci_seen_now = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            if ci_seen_now:
                self._cache_inhibit = 1
            ci_active = bool(self._cache_inhibit or ci_seen_now)

            if self._hitmiss_eval and not i['dcqmem_cycstb_i']:
                self._state = 'IDLE'
                self._hitmiss_eval = 0
                self._store = 0
                self._load = 0
                self._cache_inhibit = 0
                self._cnt = 0
            elif i['biudata_error']:
                self._state = 'IDLE'
                self._hitmiss_eval = 0
                self._store = 0
                self._load = 0
                self._cache_inhibit = 0
                self._cnt = 0
            elif ci_active:
                self._hitmiss_eval = 0
                if i['biudata_valid']:
                    self._state = 'IDLE'
                    self._store = 0
                    self._load = 0
                    self._cache_inhibit = 0
                    self._cnt = 0
            else:
                self._hitmiss_eval = 0
                if i['biudata_valid']:
                    if i['tagcomp_miss'] and self._store_refill:
                        self._state = 'SREFILL4'
                        self._store = 0
                        self._load = 1
                        self._cnt = 3  # OR1200_DCLS - 1 for a four-word line.
                        # Store refill starts at the current saved word offset.
                    else:
                        self._state = 'IDLE'
                        self._store = 0
                        self._load = 0
                        self._cache_inhibit = 0
                        self._cnt = 0
            return

        if self._state == 'LREFILL3':
            if i['biudata_valid']:
                if self._cnt != 0:
                    self._cnt -= 1
                    offset = (self._saved_addr_r >> 2) & 0x3
                    self._saved_addr_r = self.mask(
                        (self._saved_addr_r & ~0xC) | (((offset + 1) & 0x3) << 2),
                        32,
                    )
                else:
                    self._state = 'IDLE'
                    self._load = 0
                    self._store = 0
                    self._hitmiss_eval = 0
                    self._cache_inhibit = 0
            return

        if self._state == 'SREFILL4':
            if i['biudata_valid']:
                if self._cnt != 0:
                    self._cnt -= 1
                    offset = (self._saved_addr_r >> 2) & 0x3
                    self._saved_addr_r = self.mask(
                        (self._saved_addr_r & ~0xC) | (((offset + 1) & 0x3) << 2),
                        32,
                    )
                else:
                    self._state = 'IDLE'
                    self._load = 0
                    self._store = 0
                    self._hitmiss_eval = 0
                    self._cache_inhibit = 0
            return
