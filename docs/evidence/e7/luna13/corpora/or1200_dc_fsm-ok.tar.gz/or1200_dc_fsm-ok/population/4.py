"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.saved_addr_r = 0
        self.cnt = 0
        self._hitmiss_eval = 0
        self._store = 0
        self._load = 0
        self._cache_inhibit = 0
        self.store_refill_enabled = True
        self.idle = True
        self.cload = False
        self.cstore = False
        self.lrefill3 = False
        self.srefill4 = False
        self.hitmiss_eval = False
        self.store = False
        self.load = False
        self.cache_inhibit = False
        self.cnt_nonzero = False
        self.first_store_hit_ack = False

    def _finish(self):
        self.state = 'IDLE'
        self._hitmiss_eval = 0
        self._store = 0
        self._load = 0
        self._cache_inhibit = 0

    def _increment_word_offset(self):
        offset = ((self.saved_addr_r >> 2) + 1) & 3
        self.saved_addr_r = self.mask((self.saved_addr_r & 0xFFFFFFF3) | (offset << 2), 32)

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        reset_now = bool(i['rst'])
        state = 'IDLE' if reset_now else self.state
        saved_addr = 0 if reset_now else self.saved_addr_r
        hitmiss_eval = 0 if reset_now else self._hitmiss_eval
        store = 0 if reset_now else self._store
        load = 0 if reset_now else self._load
        cache_inhibit = 0 if reset_now else self._cache_inhibit
        cnt = 0 if reset_now else self.cnt

        ci_seen = bool(state in ('CLOAD', 'CSTORE') and i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
        effective_ci = bool(cache_inhibit or ci_seen)
        first_store_hit_ack = bool(
            state == 'CSTORE' and store and i['biudata_valid']
            and not i['tagcomp_miss'] and not effective_ci
        )
        biu_read = bool(
            (state == 'CLOAD' and hitmiss_eval and i['tagcomp_miss'])
            or (not hitmiss_eval and load)
        )
        biu_write = bool(store)
        first_hit_ack = bool(
            (state == 'CLOAD' and not i['tagcomp_miss'] and not effective_ci)
            or first_store_hit_ack
        )
        first_miss_ack = bool(state in ('CLOAD', 'CSTORE') and i['biudata_valid'])
        first_miss_err = bool(state in ('CLOAD', 'CSTORE') and i['biudata_error'])
        burst = bool(
            (state == 'CLOAD' and load and i['tagcomp_miss'] and not effective_ci)
            or state == 'LREFILL3'
            or (self.store_refill_enabled and state == 'SREFILL4')
        )
        dcram_we = 0
        if load and i['biudata_valid'] and not effective_ci:
            dcram_we = 15
        if first_store_hit_ack:
            dcram_we = self.mask(i['dcqmem_sel_i'], 4)
        tag_we = bool(biu_read and i['biudata_valid'] and not effective_ci)
        dc_addr = saved_addr if (not hitmiss_eval and (biu_read or biu_write)) else i['start_addr']

        self.idle = bool(state == 'IDLE')
        self.cload = bool(state == 'CLOAD')
        self.cstore = bool(state == 'CSTORE')
        self.lrefill3 = bool(state == 'LREFILL3')
        self.srefill4 = bool(state == 'SREFILL4')
        self.hitmiss_eval = bool(hitmiss_eval)
        self.store = bool(store)
        self.load = bool(load)
        self.cache_inhibit = bool(cache_inhibit)
        self.cnt_nonzero = bool(cnt != 0)
        self.first_store_hit_ack = first_store_hit_ack

        o['saved_addr'] = self.mask(saved_addr, 32)
        o['dcram_we'] = self.mask(dcram_we, 4)
        o['biu_read'] = int(biu_read)
        o['biu_write'] = int(biu_write)
        o['first_hit_ack'] = int(first_hit_ack)
        o['first_miss_ack'] = int(first_miss_ack)
        o['first_miss_err'] = int(first_miss_err)
        o['burst'] = int(burst)
        o['tag_we'] = int(tag_we)
        o['dc_addr'] = self.mask(dc_addr, 32)
        return o

    def advance(self, i):
        if i['rst']:
            self.state = 'IDLE'
            self.saved_addr_r = 0
            self.cnt = 0
            self._hitmiss_eval = 0
            self._store = 0
            self._load = 0
            self._cache_inhibit = 0
            return

        if self.state == 'IDLE':
            if i['dc_en'] and i['dcqmem_cycstb_i']:
                self.saved_addr_r = self.mask(i['start_addr'], 32)
                self._hitmiss_eval = 1
                self._cache_inhibit = 0
                if i['dcqmem_we_i']:
                    self.state = 'CSTORE'
                    self._store = 1
                    self._load = 0
                else:
                    self.state = 'CLOAD'
                    self._store = 0
                    self._load = 1
            return

        if self.state == 'CLOAD':
            if self._hitmiss_eval and not i['dcqmem_cycstb_i']:
                self._finish()
            elif i['biudata_error']:
                self._finish()
            elif self._cache_inhibit or (i['dcqmem_cycstb_i'] and i['dcqmem_ci_i']):
                self._cache_inhibit = 1
                self._hitmiss_eval = 0
                if i['biudata_valid']:
                    self._finish()
            elif self._hitmiss_eval:
                self._hitmiss_eval = 0
                if not i['tagcomp_miss']:
                    self._finish()
                elif i['biudata_valid']:
                    self.state = 'LREFILL3'
                    self.cnt = 2
                    self._increment_word_offset()
            elif i['biudata_valid']:
                self.state = 'LREFILL3'
                self.cnt = 2
                self._increment_word_offset()
            return

        if self.state == 'CSTORE':
            if self._hitmiss_eval and not i['dcqmem_cycstb_i']:
                self._finish()
            elif i['biudata_error']:
                self._finish()
            elif self._cache_inhibit or (i['dcqmem_cycstb_i'] and i['dcqmem_ci_i']):
                self._cache_inhibit = 1
                self._hitmiss_eval = 0
                if i['biudata_valid']:
                    self._finish()
            else:
                self._hitmiss_eval = 0
                if i['biudata_valid']:
                    if i['tagcomp_miss'] and self.store_refill_enabled:
                        self.state = 'SREFILL4'
                        self._store = 0
                        self._load = 1
                        self.cnt = 3
                    else:
                        self._finish()
            return

        if self.state == 'LREFILL3':
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    self._increment_word_offset()
                else:
                    self._finish()
            return

        if self.state == 'SREFILL4':
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    self._increment_word_offset()
                else:
                    self._finish()
            return
