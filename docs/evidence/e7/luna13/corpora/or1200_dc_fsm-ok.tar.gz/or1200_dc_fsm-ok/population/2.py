"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self._saved_addr_r = 0
        self._cnt = 0
        self._hitmiss_eval = False
        self._store = False
        self._load = False
        self._cache_inhibit = False
        self._store_refill = True
        self.idle = True
        self.cload = False
        self.cstore = False
        self.lrefill3 = False
        self.srefill4 = False
        self.hitmiss_eval = False
        self.store = False
        self.load = False
        self.cache_inhibit = False
        self.cnt_nonzero = False
        self.first_store_hit_ack = False

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        rst = bool(i['rst'])
        state = 'IDLE' if rst else self.state
        saved_addr = 0 if rst else self._saved_addr_r
        hitmiss_eval = False if rst else self._hitmiss_eval
        store = False if rst else self._store
        load = False if rst else self._load
        cache_inhibit = False if rst else self._cache_inhibit
        cnt = 0 if rst else self._cnt

        ci_seen_now = bool(
            not rst
            and state in ('CLOAD', 'CSTORE')
            and i['dcqmem_cycstb_i']
            and i['dcqmem_ci_i']
        )
        effective_ci = bool(cache_inhibit or ci_seen_now)

        biu_read = False
        if state == 'CLOAD':
            if effective_ci:
                biu_read = True
            elif hitmiss_eval:
                biu_read = bool(i['tagcomp_miss'])
            else:
                biu_read = bool(load)
        elif state in ('LREFILL3', 'SREFILL4'):
            biu_read = bool(load)

        biu_write = bool(store)
        first_store_hit_ack = bool(
            state == 'CSTORE'
            and store
            and i['biudata_valid']
            and not i['tagcomp_miss']
            and not effective_ci
        )
        first_hit_ack = bool(
            (state == 'CLOAD' and hitmiss_eval and not i['tagcomp_miss'] and not effective_ci)
            or first_store_hit_ack
        )
        first_miss_ack = bool(
            state in ('CLOAD', 'CSTORE') and i['biudata_valid']
        )
        first_miss_err = bool(
            state in ('CLOAD', 'CSTORE') and i['biudata_error']
        )

        refill_in_cload = bool(
            state == 'CLOAD'
            and load
            and not effective_ci
            and ((hitmiss_eval and i['tagcomp_miss']) or not hitmiss_eval)
        )
        burst = bool(
            (refill_in_cload and (not hitmiss_eval or i['tagcomp_miss']))
            or state == 'LREFILL3'
            or (self._store_refill and state == 'SREFILL4')
        )

        dcram_we = 0
        if load and i['biudata_valid'] and not effective_ci:
            dcram_we = 0xF
        elif first_store_hit_ack:
            dcram_we = self.mask(i['dcqmem_sel_i'], 4)

        tag_we = bool(biu_read and i['biudata_valid'] and not effective_ci)
        post_evaluation_transfer = bool(biu_read or biu_write)
        if hitmiss_eval or not post_evaluation_transfer:
            dc_addr = i['start_addr']
        else:
            dc_addr = saved_addr

        self.idle = bool(state == 'IDLE')
        self.cload = bool(state == 'CLOAD')
        self.cstore = bool(state == 'CSTORE')
        self.lrefill3 = bool(state == 'LREFILL3')
        self.srefill4 = bool(state == 'SREFILL4')
        self.hitmiss_eval = bool(hitmiss_eval)
        self.store = bool(store)
        self.load = bool(load)
        self.cache_inhibit = bool(cache_inhibit)
        self.cnt_nonzero = bool(cnt != 0)
        self.first_store_hit_ack = bool(first_store_hit_ack)

        o['saved_addr'] = self.mask(saved_addr, 32)
        o['dcram_we'] = self.mask(dcram_we, 4)
        o['biu_read'] = int(biu_read)
        o['biu_write'] = int(biu_write)
        o['first_hit_ack'] = int(first_hit_ack)
        o['first_miss_ack'] = int(first_miss_ack)
        o['first_miss_err'] = int(first_miss_err)
        o['burst'] = int(burst)
        o['tag_we'] = int(tag_we)
        o['dc_addr'] = self.mask(dc_addr, 32)
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return

        if self.state == 'IDLE':
            if i['dc_en'] and i['dcqmem_cycstb_i']:
                self._saved_addr_r = self.mask(i['start_addr'], 32)
                self._hitmiss_eval = True
                self._cache_inhibit = False
                if i['dcqmem_we_i']:
                    self.state = 'CSTORE'
                    self._store = True
                    self._load = False
                else:
                    self.state = 'CLOAD'
                    self._store = False
                    self._load = True
            return

        if self.state == 'CLOAD':
            ci_seen_now = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            if ci_seen_now:
                self._cache_inhibit = True

            if self._hitmiss_eval and not i['dcqmem_cycstb_i']:
                self.state = 'IDLE'
                self._hitmiss_eval = False
                self._load = False
                self._store = False
                self._cache_inhibit = False
                return
            if i['biudata_error']:
                self.state = 'IDLE'
                self._hitmiss_eval = False
                self._load = False
                self._store = False
                self._cache_inhibit = False
                return

            effective_ci = bool(self._cache_inhibit or ci_seen_now)
            if effective_ci:
                self._hitmiss_eval = False
                if i['biudata_valid']:
                    self.state = 'IDLE'
                    self._load = False
                    self._store = False
                    self._cache_inhibit = False
                return

            if self._hitmiss_eval:
                self._hitmiss_eval = False
                if not i['tagcomp_miss']:
                    self.state = 'IDLE'
                    self._load = False
                    self._store = False
                    self._cache_inhibit = False
                    return

            if i['biudata_valid']:
                self.state = 'LREFILL3'
                self._cnt = 2
                a = self._saved_addr_r
                self._saved_addr_r = self.mask(
                    (a & 0xFFFFFFF3) | (((((a >> 2) & 0x3) + 1) & 0x3) << 2), 32
                )
            return

        if self.state == 'CSTORE':
            ci_seen_now = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            if ci_seen_now:
                self._cache_inhibit = True

            if self._hitmiss_eval and not i['dcqmem_cycstb_i']:
                self.state = 'IDLE'
                self._hitmiss_eval = False
                self._store = False
                self._load = False
                self._cache_inhibit = False
                return
            if i['biudata_error']:
                self.state = 'IDLE'
                self._hitmiss_eval = False
                self._store = False
                self._load = False
                self._cache_inhibit = False
                return

            effective_ci = bool(self._cache_inhibit or ci_seen_now)
            if effective_ci:
                self._hitmiss_eval = False
                if i['biudata_valid']:
                    self.state = 'IDLE'
                    self._store = False
                    self._load = False
                    self._cache_inhibit = False
                return

            self._hitmiss_eval = False
            if i['biudata_valid']:
                if i['tagcomp_miss'] and self._store_refill:
                    self.state = 'SREFILL4'
                    self._store = False
                    self._load = True
                    self._cnt = 3
                else:
                    self.state = 'IDLE'
                    self._store = False
                    self._load = False
                    self._cache_inhibit = False
            return

        if self.state == 'LREFILL3':
            if i['biudata_valid']:
                if self._cnt != 0:
                    self._cnt -= 1
                    a = self._saved_addr_r
                    self._saved_addr_r = self.mask(
                        (a & 0xFFFFFFF3) | (((((a >> 2) & 0x3) + 1) & 0x3) << 2), 32
                    )
                else:
                    self.state = 'IDLE'
                    self._load = False
                    self._store = False
                    self._cache_inhibit = False
            return

        if self.state == 'SREFILL4':
            if i['biudata_valid']:
                if self._cnt != 0:
                    self._cnt -= 1
                    a = self._saved_addr_r
                    self._saved_addr_r = self.mask(
                        (a & 0xFFFFFFF3) | (((((a >> 2) & 0x3) + 1) & 0x3) << 2), 32
                    )
                else:
                    self.state = 'IDLE'
                    self._load = False
                    self._store = False
                    self._cache_inhibit = False
            return
