"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.saved_addr_r = 0
        self.cnt = 0
        self._hitmiss_eval = 0
        self._store = 0
        self._load = 0
        self._cache_inhibit = 0
        self.store_refill_enabled = True

        self.idle = True
        self.cload = False
        self.cstore = False
        self.lrefill3 = False
        self.srefill4 = False
        self.hitmiss_eval = False
        self.store = False
        self.load = False
        self.cache_inhibit = False
        self.cnt_nonzero = False
        self.first_store_hit_ack = False

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        cload = self.state == 'CLOAD'
        cstore = self.state == 'CSTORE'
        lrefill3 = self.state == 'LREFILL3'
        srefill4 = self.state == 'SREFILL4'
        ci_seen = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
        effective_ci = bool(self._cache_inhibit or ((cload or cstore) and ci_seen))

        first_store_hit_ack = bool(
            cstore and i['biudata_valid'] and not i['tagcomp_miss'] and not effective_ci
        )

        # These attributes are observation probes; registered state remains unchanged.
        self.idle = self.state == 'IDLE'
        self.cload = cload
        self.cstore = cstore
        self.lrefill3 = lrefill3
        self.srefill4 = srefill4
        self.hitmiss_eval = bool(self._hitmiss_eval)
        self.store = bool(self._store)
        self.load = bool(self._load)
        self.cache_inhibit = bool(self._cache_inhibit)
        self.cnt_nonzero = bool(self.cnt != 0)
        self.first_store_hit_ack = first_store_hit_ack

        evaluating_load_miss = bool(
            cload and self._hitmiss_eval and i['tagcomp_miss']
        )
        evaluating_ci_load = bool(cload and self._hitmiss_eval and effective_ci)
        post_eval_load_transfer = bool(
            self._load and not self._hitmiss_eval and (cload or lrefill3 or srefill4)
        )
        biu_read = bool(
            evaluating_load_miss or evaluating_ci_load or post_eval_load_transfer
        )
        biu_write = bool(self._store)

        load_hit_ack = bool(
            cload and self._hitmiss_eval and not i['tagcomp_miss'] and not effective_ci
        )
        first_hit_ack = bool(load_hit_ack or first_store_hit_ack)
        first_miss_ack = bool((cload or cstore) and i['biudata_valid'])
        first_miss_err = bool((cload or cstore) and i['biudata_error'])

        dcram_we = 0
        if self._load and i['biudata_valid'] and not effective_ci:
            dcram_we = 0xF
        if first_store_hit_ack:
            dcram_we = self.mask(i['dcqmem_sel_i'], 4)

        burst = bool(
            (cload and i['tagcomp_miss'] and not effective_ci)
            or lrefill3
            or (srefill4 and self.store_refill_enabled)
        )
        tag_we = bool(biu_read and i['biudata_valid'] and not effective_ci)

        if not self._hitmiss_eval and (biu_read or biu_write):
            dc_addr = self.saved_addr_r
        else:
            dc_addr = self.mask(i['start_addr'], 32)

        o['saved_addr'] = self.mask(self.saved_addr_r, 32)
        o['dcram_we'] = self.mask(dcram_we, 4)
        o['biu_read'] = int(biu_read)
        o['biu_write'] = int(biu_write)
        o['first_hit_ack'] = int(first_hit_ack)
        o['first_miss_ack'] = int(first_miss_ack)
        o['first_miss_err'] = int(first_miss_err)
        o['burst'] = int(burst)
        o['tag_we'] = int(tag_we)
        o['dc_addr'] = self.mask(dc_addr, 32)
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return

        state = self.state
        ci_seen = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
        effective_ci = bool(
            self._cache_inhibit
            or ((state == 'CLOAD' or state == 'CSTORE') and ci_seen)
        )

        if state == 'IDLE':
            if i['dc_en'] and i['dcqmem_cycstb_i']:
                self.saved_addr_r = self.mask(i['start_addr'], 32)
                self._hitmiss_eval = 1
                self._cache_inhibit = 0
                if i['dcqmem_we_i']:
                    self.state = 'CSTORE'
                    self._store = 1
                    self._load = 0
                else:
                    self.state = 'CLOAD'
                    self._store = 0
                    self._load = 1
            return

        if state == 'CLOAD':
            if i['biudata_error'] or (self._hitmiss_eval and not i['dcqmem_cycstb_i']):
                self.state = 'IDLE'
                self._hitmiss_eval = 0
                self._store = 0
                self._load = 0
                return

            if ci_seen:
                self._cache_inhibit = 1

            if self._hitmiss_eval:
                self._hitmiss_eval = 0
                if effective_ci:
                    if i['biudata_valid']:
                        self.state = 'IDLE'
                        self._store = 0
                        self._load = 0
                    return

                if not i['tagcomp_miss']:
                    self.state = 'IDLE'
                    self._store = 0
                    self._load = 0
                    return

                if i['biudata_valid']:
                    self.state = 'LREFILL3'
                    self.saved_addr_r = self.mask(
                        (self.saved_addr_r & ~0xC)
                        | (((((self.saved_addr_r >> 2) + 1) & 0x3) << 2)),
                        32
                    )
                    self.cnt = 2
                return

            if effective_ci:
                if i['biudata_valid']:
                    self.state = 'IDLE'
                    self._store = 0
                    self._load = 0
                return

            if i['biudata_valid']:
                self.state = 'LREFILL3'
                self.saved_addr_r = self.mask(
                    (self.saved_addr_r & ~0xC)
                    | (((((self.saved_addr_r >> 2) + 1) & 0x3) << 2)),
                    32
                )
                self.cnt = 2
            return

        if state == 'CSTORE':
            if i['biudata_error'] or (self._hitmiss_eval and not i['dcqmem_cycstb_i']):
                self.state = 'IDLE'
                self._hitmiss_eval = 0
                self._store = 0
                self._load = 0
                return

            if ci_seen:
                self._cache_inhibit = 1
            if self._hitmiss_eval:
                self._hitmiss_eval = 0

            if not i['biudata_valid']:
                return

            if effective_ci:
                self.state = 'IDLE'
                self._store = 0
                self._load = 0
                return

            if i['tagcomp_miss'] and self.store_refill_enabled:
                self.state = 'SREFILL4'
                self._store = 0
                self._load = 1
                self._hitmiss_eval = 0
                self.cnt = 3
                # Store refill begins at the current saved word offset.
                return

            self.state = 'IDLE'
            self._store = 0
            self._load = 0
            return

        if state == 'LREFILL3' or state == 'SREFILL4':
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    self.saved_addr_r = self.mask(
                        (self.saved_addr_r & ~0xC)
                        | (((((self.saved_addr_r >> 2) + 1) & 0x3) << 2)),
                        32
                    )
                else:
                    self.state = 'IDLE'
                    self._load = 0
                    self._store = 0
                    self._hitmiss_eval = 0
            return
