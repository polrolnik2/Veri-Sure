"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.saved_addr_r = 0
        self.cnt = 0
        self.hitmiss_eval = False
        self.store = False
        self.load = False
        self.cache_inhibit = False
        self.store_refill_enabled = True
        self.first_store_hit_ack = False
        self.cnt_nonzero = False
        self.idle = True
        self.cload = False
        self.cstore = False
        self.lrefill3 = False
        self.srefill4 = False

    def _increment_word_offset(self):
        offset = ((self.saved_addr_r >> 2) + 1) & 0x3
        self.saved_addr_r = self.mask((self.saved_addr_r & 0xFFFFFFF3) | (offset << 2), 32)

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        state = self.state
        ci_seen_now = bool(
            state in ('CLOAD', 'CSTORE')
            and i['dcqmem_cycstb_i']
            and i['dcqmem_ci_i']
        )
        ci_active = bool(self.cache_inhibit or ci_seen_now)

        self.idle = state == 'IDLE'
        self.cload = state == 'CLOAD'
        self.cstore = state == 'CSTORE'
        self.lrefill3 = state == 'LREFILL3'
        self.srefill4 = state == 'SREFILL4'
        self.cnt_nonzero = bool(self.cnt != 0)

        self.first_store_hit_ack = bool(
            state == 'CSTORE'
            and self.store
            and i['biudata_valid']
            and not i['tagcomp_miss']
            and not ci_active
        )

        biu_read = bool(
            (state == 'CLOAD' and self.hitmiss_eval and i['tagcomp_miss'])
            or ((not self.hitmiss_eval) and self.load)
        )
        biu_write = bool(self.store)
        first_hit_ack = bool(
            (state == 'CLOAD' and not i['tagcomp_miss'] and not ci_active)
            or self.first_store_hit_ack
        )
        first_miss_ack = bool(
            state in ('CLOAD', 'CSTORE') and i['biudata_valid']
        )
        first_miss_err = bool(
            state in ('CLOAD', 'CSTORE') and i['biudata_error']
        )
        burst = bool(
            (state == 'CLOAD' and i['tagcomp_miss'] and not ci_active)
            or state == 'LREFILL3'
            or state == 'SREFILL4'
        )

        if self.load and i['biudata_valid'] and not ci_active:
            dcram_we = 0xF
        elif self.first_store_hit_ack:
            dcram_we = self.mask(i['dcqmem_sel_i'], 4)
        else:
            dcram_we = 0

        tag_we = bool(biu_read and i['biudata_valid'] and not ci_active)
        if self.hitmiss_eval or not (biu_read or biu_write):
            dc_addr = self.mask(i['start_addr'], 32)
        else:
            dc_addr = self.mask(self.saved_addr_r, 32)

        o['saved_addr'] = self.mask(self.saved_addr_r, 32)
        o['dcram_we'] = self.mask(dcram_we, 4)
        o['biu_read'] = int(biu_read)
        o['biu_write'] = int(biu_write)
        o['first_hit_ack'] = int(first_hit_ack)
        o['first_miss_ack'] = int(first_miss_ack)
        o['first_miss_err'] = int(first_miss_err)
        o['burst'] = int(burst)
        o['tag_we'] = int(tag_we)
        o['dc_addr'] = self.mask(dc_addr, 32)
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return

        state = self.state

        if state == 'IDLE':
            if i['dc_en'] and i['dcqmem_cycstb_i']:
                self.saved_addr_r = self.mask(i['start_addr'], 32)
                self.hitmiss_eval = True
                self.store = bool(i['dcqmem_we_i'])
                self.load = not bool(i['dcqmem_we_i'])
                self.cache_inhibit = False
                self.state = 'CSTORE' if i['dcqmem_we_i'] else 'CLOAD'
            return

        if state == 'CLOAD':
            ci_now = bool(
                self.cache_inhibit
                or (i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            )

            if self.hitmiss_eval and not i['dcqmem_cycstb_i']:
                self.state = 'IDLE'
                self.hitmiss_eval = False
                self.load = False
                self.store = False
                return

            if i['biudata_error']:
                self.state = 'IDLE'
                self.hitmiss_eval = False
                self.load = False
                self.store = False
                return

            if i['dcqmem_cycstb_i'] and i['dcqmem_ci_i']:
                self.cache_inhibit = True
            if self.hitmiss_eval:
                self.hitmiss_eval = False

            if ci_now:
                if i['biudata_valid']:
                    self.state = 'IDLE'
                    self.load = False
                    self.store = False
                return

            if not i['tagcomp_miss']:
                self.state = 'IDLE'
                self.load = False
                self.store = False
                self.hitmiss_eval = False
                return

            if i['biudata_valid']:
                self.state = 'LREFILL3'
                self._increment_word_offset()
                self.cnt = 2
            return

        if state == 'CSTORE':
            ci_now = bool(
                self.cache_inhibit
                or (i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            )

            if self.hitmiss_eval and not i['dcqmem_cycstb_i']:
                self.state = 'IDLE'
                self.hitmiss_eval = False
                self.store = False
                self.load = False
                return

            if i['biudata_error']:
                self.state = 'IDLE'
                self.hitmiss_eval = False
                self.store = False
                self.load = False
                return

            if i['dcqmem_cycstb_i'] and i['dcqmem_ci_i']:
                self.cache_inhibit = True
            if self.hitmiss_eval:
                self.hitmiss_eval = False

            if ci_now:
                if i['biudata_valid']:
                    self.state = 'IDLE'
                    self.store = False
                    self.load = False
                return

            if i['biudata_valid']:
                if i['tagcomp_miss'] and self.store_refill_enabled:
                    self.state = 'SREFILL4'
                    self.store = False
                    self.load = True
                    self.cnt = 3
                else:
                    self.state = 'IDLE'
                    self.store = False
                    self.load = False
                    self.hitmiss_eval = False
            return

        if state == 'LREFILL3':
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    self._increment_word_offset()
                else:
                    self.state = 'IDLE'
                    self.load = False
                    self.store = False
                    self.hitmiss_eval = False
            return

        if state == 'SREFILL4':
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    self._increment_word_offset()
                else:
                    self.state = 'IDLE'
                    self.load = False
                    self.store = False
                    self.hitmiss_eval = False
            return
