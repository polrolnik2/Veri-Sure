"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.saved_addr_r = 0
        self.cnt = 0
        self.hitmiss_eval = 0
        self.store = 0
        self.load = 0
        self.cache_inhibit = 0
        self.store_refill_enabled = True

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        # rst is asynchronous: expose reset-state values without changing the FSM state here.
        if i['rst']:
            state = 'IDLE'
            saved_addr = 0
            hitmiss_eval = 0
            store = 0
            load = 0
            cache_inhibit = 0
            cnt = 0
        else:
            state = self.state
            saved_addr = self.saved_addr_r
            hitmiss_eval = self.hitmiss_eval
            store = self.store
            load = self.load
            cache_inhibit = self.cache_inhibit
            cnt = self.cnt

        ci_seen = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
        active_ci = bool(cache_inhibit or (state in ('CLOAD', 'CSTORE') and ci_seen))

        first_store_hit_ack = bool(
            state == 'CSTORE'
            and store
            and i['biudata_valid']
            and not i['tagcomp_miss']
            and not active_ci
        )
        biu_read = bool(
            load
            and (
                (state == 'CLOAD' and hitmiss_eval and i['tagcomp_miss'])
                or (not hitmiss_eval and state in ('CLOAD', 'LREFILL3', 'SREFILL4'))
            )
        )
        biu_write = bool(store)
        first_hit_ack = bool(
            (state == 'CLOAD' and load and not i['tagcomp_miss'] and not active_ci)
            or first_store_hit_ack
        )
        first_miss_ack = bool(state in ('CLOAD', 'CSTORE') and i['biudata_valid'])
        first_miss_err = bool(state in ('CLOAD', 'CSTORE') and i['biudata_error'])

        dcram_we = 0
        if load and i['biudata_valid'] and not active_ci:
            dcram_we = 0xF
        if first_store_hit_ack:
            dcram_we |= i['dcqmem_sel_i'] & 0xF

        burst = bool(
            (state == 'CLOAD' and load and i['tagcomp_miss'] and not active_ci)
            or state == 'LREFILL3'
            or (self.store_refill_enabled and state == 'SREFILL4')
        )
        tag_we = bool(biu_read and i['biudata_valid'] and not active_ci)

        if not hitmiss_eval and (biu_read or biu_write):
            dc_addr = saved_addr
        else:
            dc_addr = i['start_addr']

        o['saved_addr'] = self.mask(saved_addr, 32)
        o['dcram_we'] = self.mask(dcram_we, 4)
        o['biu_read'] = int(biu_read)
        o['biu_write'] = int(biu_write)
        o['first_hit_ack'] = int(first_hit_ack)
        o['first_miss_ack'] = int(first_miss_ack)
        o['first_miss_err'] = int(first_miss_err)
        o['burst'] = int(burst)
        o['tag_we'] = int(tag_we)
        o['dc_addr'] = self.mask(dc_addr, 32)

        self.idle = bool(state == 'IDLE')
        self.cload = bool(state == 'CLOAD')
        self.cstore = bool(state == 'CSTORE')
        self.lrefill3 = bool(state == 'LREFILL3')
        self.srefill4 = bool(state == 'SREFILL4')
        self.hitmiss_eval = bool(hitmiss_eval)
        self.store = bool(store)
        self.load = bool(load)
        self.cache_inhibit = bool(cache_inhibit)
        self.cnt_nonzero = bool(cnt != 0)
        self.first_store_hit_ack = bool(first_store_hit_ack)
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return

        if self.state == 'IDLE':
            if i['dc_en'] and i['dcqmem_cycstb_i']:
                self.saved_addr_r = self.mask(i['start_addr'], 32)
                self.hitmiss_eval = 1
                self.cache_inhibit = 0
                self.cnt = 0
                if i['dcqmem_we_i']:
                    self.state = 'CSTORE'
                    self.store = 1
                    self.load = 0
                else:
                    self.state = 'CLOAD'
                    self.store = 0
                    self.load = 1
            return

        if self.state == 'CLOAD':
            ci_seen = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            if ci_seen:
                self.cache_inhibit = 1
            active_ci = bool(self.cache_inhibit or ci_seen)

            if i['biudata_error'] or (self.hitmiss_eval and not i['dcqmem_cycstb_i']):
                self.state = 'IDLE'
                self.hitmiss_eval = 0
                self.store = 0
                self.load = 0
                self.cache_inhibit = 0
                self.cnt = 0
            elif active_ci:
                self.hitmiss_eval = 0
                if i['biudata_valid']:
                    self.state = 'IDLE'
                    self.store = 0
                    self.load = 0
                    self.cache_inhibit = 0
                    self.cnt = 0
            elif self.hitmiss_eval:
                if not i['tagcomp_miss']:
                    self.state = 'IDLE'
                    self.hitmiss_eval = 0
                    self.store = 0
                    self.load = 0
                    self.cache_inhibit = 0
                    self.cnt = 0
                else:
                    self.hitmiss_eval = 0
                    if i['biudata_valid']:
                        self.state = 'LREFILL3'
                        self.cnt = 2
                        offset = ((self.saved_addr_r >> 2) + 1) & 0x3
                        self.saved_addr_r = (self.saved_addr_r & ~0xC) | (offset << 2)
            elif i['biudata_valid']:
                self.state = 'LREFILL3'
                self.cnt = 2
                offset = ((self.saved_addr_r >> 2) + 1) & 0x3
                self.saved_addr_r = (self.saved_addr_r & ~0xC) | (offset << 2)
            return

        if self.state == 'CSTORE':
            ci_seen = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            if ci_seen:
                self.cache_inhibit = 1
            active_ci = bool(self.cache_inhibit or ci_seen)

            if i['biudata_error'] or (self.hitmiss_eval and not i['dcqmem_cycstb_i']):
                self.state = 'IDLE'
                self.hitmiss_eval = 0
                self.store = 0
                self.load = 0
                self.cache_inhibit = 0
                self.cnt = 0
            elif active_ci:
                self.hitmiss_eval = 0
                if i['biudata_valid']:
                    self.state = 'IDLE'
                    self.store = 0
                    self.load = 0
                    self.cache_inhibit = 0
                    self.cnt = 0
            else:
                self.hitmiss_eval = 0
                if i['biudata_valid']:
                    if i['tagcomp_miss'] and self.store_refill_enabled:
                        self.state = 'SREFILL4'
                        self.store = 0
                        self.load = 1
                        self.cnt = 3
                    else:
                        self.state = 'IDLE'
                        self.store = 0
                        self.load = 0
                        self.cache_inhibit = 0
                        self.cnt = 0
            return

        if self.state == 'LREFILL3':
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    offset = ((self.saved_addr_r >> 2) + 1) & 0x3
                    self.saved_addr_r = (self.saved_addr_r & ~0xC) | (offset << 2)
                else:
                    self.state = 'IDLE'
                    self.load = 0
                    self.store = 0
                    self.hitmiss_eval = 0
                    self.cache_inhibit = 0
                    self.cnt = 0
            return

        if self.state == 'SREFILL4':
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    offset = ((self.saved_addr_r >> 2) + 1) & 0x3
                    self.saved_addr_r = (self.saved_addr_r & ~0xC) | (offset << 2)
                else:
                    self.state = 'IDLE'
                    self.load = 0
                    self.store = 0
                    self.hitmiss_eval = 0
                    self.cache_inhibit = 0
                    self.cnt = 0
