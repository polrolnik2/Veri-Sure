"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['dcsb_dat_o', 'dcsb_ack_o', 'dcsb_err_o', 'sbbiu_dat_o', 'sbbiu_adr_o', 'sbbiu_cyc_o', 'sbbiu_stb_o', 'sbbiu_we_o', 'sbbiu_sel_o', 'sbbiu_cab_o']
    PROBE_PORTS = ['fifo_dat_i', 'fifo_dat_o', 'fifo_wr', 'fifo_rd', 'fifo_full', 'fifo_empty', 'sel_sb', 'outstanding_store', 'fifo_wr_ack']
    PROBE_WIDTHS = {'fifo_dat_i': 68, 'fifo_dat_o': 68, 'fifo_wr': 1, 'fifo_rd': 1, 'fifo_full': 1, 'fifo_empty': 1, 'sel_sb': 1, 'outstanding_store': 1, 'fifo_wr_ack': 1}
    LATENCY_CYCLES = 1

    def reset(self):
        self.sb_implemented = bool(getattr(self, "SB_IMPLEMENTED", True))
        self._fifo = []
        self._active = None
        self._outstanding = 0
        self._fifo_wr_ack = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        if self.sb_implemented:
            fifo_dat_i = ((self.mask(i['dcsb_sel_i'], 4) << 64) |
                          (self.mask(i['dcsb_dat_i'], 32) << 32) |
                          self.mask(i['dcsb_adr_i'], 32))
            fifo_empty = len(self._fifo) == 0
            fifo_full = False
            sel_sb = (not fifo_empty) or bool(self._outstanding)
            fifo_wr = (bool(i['dcsb_cyc_i'] & 1) and
                       bool(i['dcsb_stb_i'] & 1) and
                       bool(i['dcsb_we_i'] & 1) and
                       not fifo_full and
                       not bool(self._fifo_wr_ack))
            fifo_rd = not bool(self._outstanding)
            if self._active is not None:
                fifo_dat_o = self._active
            elif self._fifo:
                fifo_dat_o = self._fifo[0]
            else:
                fifo_dat_o = 0

            self.fifo_dat_i = self.mask(fifo_dat_i, 68)
            self.fifo_dat_o = self.mask(fifo_dat_o, 68)
            self.fifo_wr = bool(fifo_wr)
            self.fifo_rd = bool(fifo_rd)
            self.fifo_full = bool(fifo_full)
            self.fifo_empty = bool(fifo_empty)
            self.sel_sb = bool(sel_sb)
            self.outstanding_store = bool(self._outstanding)
            self.fifo_wr_ack = bool(self._fifo_wr_ack)

            o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)
            if sel_sb:
                o['dcsb_ack_o'] = int(bool(self._fifo_wr_ack))
                o['dcsb_err_o'] = 0
                o['sbbiu_dat_o'] = (fifo_dat_o >> 32) & 0xffffffff
                o['sbbiu_adr_o'] = fifo_dat_o & 0xffffffff
                o['sbbiu_cyc_o'] = 1
                o['sbbiu_stb_o'] = 1
                o['sbbiu_we_o'] = 1
                o['sbbiu_sel_o'] = (fifo_dat_o >> 64) & 0xf
                o['sbbiu_cab_o'] = 0
            else:
                o['dcsb_ack_o'] = int(bool(i['sbbiu_ack_i'] & 1))
                o['dcsb_err_o'] = int(bool(i['sbbiu_err_i'] & 1))
                o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
                o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
                o['sbbiu_cyc_o'] = int(bool(i['dcsb_cyc_i'] & 1))
                o['sbbiu_stb_o'] = int(bool(i['dcsb_stb_i'] & 1))
                o['sbbiu_we_o'] = int(bool(i['dcsb_we_i'] & 1))
                o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
                o['sbbiu_cab_o'] = int(bool(i['dcsb_cab_i'] & 1))
        else:
            self.fifo_dat_i = 0
            self.fifo_dat_o = 0
            self.fifo_wr = False
            self.fifo_rd = False
            self.fifo_full = False
            self.fifo_empty = False
            self.sel_sb = False
            self.outstanding_store = False
            self.fifo_wr_ack = False

            o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)
            o['dcsb_ack_o'] = int(bool(i['sbbiu_ack_i'] & 1))
            o['dcsb_err_o'] = int(bool(i['sbbiu_err_i'] & 1))
            o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
            o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
            o['sbbiu_cyc_o'] = int(bool(i['dcsb_cyc_i'] & 1))
            o['sbbiu_stb_o'] = int(bool(i['dcsb_stb_i'] & 1))
            o['sbbiu_we_o'] = int(bool(i['dcsb_we_i'] & 1))
            o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
            o['sbbiu_cab_o'] = int(bool(i['dcsb_cab_i'] & 1))

        return o

    def advance(self, i):
        if not self.sb_implemented:
            return
        if i['rst'] & 1:
            self.reset()
            return

        old_outstanding = bool(self._outstanding)
        old_fifo_empty = len(self._fifo) == 0
        old_sel_sb = (not old_fifo_empty) or old_outstanding
        fifo_wr = (bool(i['dcsb_cyc_i'] & 1) and
                   bool(i['dcsb_stb_i'] & 1) and
                   bool(i['dcsb_we_i'] & 1) and
                   not bool(self._fifo_wr_ack))
        ack = bool(i['sbbiu_ack_i'] & 1)
        payload = ((self.mask(i['dcsb_sel_i'], 4) << 64) |
                   (self.mask(i['dcsb_dat_i'], 32) << 32) |
                   self.mask(i['dcsb_adr_i'], 32))

        if old_outstanding:
            if ack:
                self._active = None
            if fifo_wr:
                self._fifo.append(payload)
        elif self._fifo:
            next_payload = self._fifo.pop(0)
            if fifo_wr:
                self._fifo.append(payload)
            if ack:
                self._active = None
            else:
                self._active = next_payload
        elif fifo_wr:
            if ack:
                # The current path was still direct; retain this new FIFO entry.
                self._fifo.append(payload)
                self._active = None
            else:
                # Model an empty-FIFO read and write on the same edge as a bypass.
                self._active = payload
        else:
            self._active = None

        if ack:
            self._outstanding = 0
        elif old_sel_sb or fifo_wr:
            self._outstanding = 1

        self._fifo_wr_ack = int(bool(fifo_wr))
