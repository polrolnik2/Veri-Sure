"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['dcsb_dat_o', 'dcsb_ack_o', 'dcsb_err_o', 'sbbiu_dat_o', 'sbbiu_adr_o', 'sbbiu_cyc_o', 'sbbiu_stb_o', 'sbbiu_we_o', 'sbbiu_sel_o', 'sbbiu_cab_o']
    PROBE_PORTS = ['fifo_dat_i', 'fifo_dat_o', 'fifo_wr', 'fifo_rd', 'fifo_full', 'fifo_empty', 'sel_sb', 'outstanding_store', 'fifo_wr_ack']
    PROBE_WIDTHS = {'fifo_dat_i': 68, 'fifo_dat_o': 68, 'fifo_wr': 1, 'fifo_rd': 1, 'fifo_full': 1, 'fifo_empty': 1, 'sel_sb': 1, 'outstanding_store': 1, 'fifo_wr_ack': 1}
    LATENCY_CYCLES = 1

    SB_IMPLEMENTED = True
    FIFO_DEPTH = 4

    def reset(self):
        self._fifo = []
        self._active = None
        self._outstanding_store = 0
        self._fifo_wr_ack = 0

    def _pack_payload(self, payload):
        sel, data, addr = payload
        return self.mask((self.mask(sel, 4) << 64) | (self.mask(data, 32) << 32) | self.mask(addr, 32), 68)

    def _signals(self, i):
        if not self.SB_IMPLEMENTED:
            return {
                "fifo_dat_i": 0,
                "fifo_dat_o": 0,
                "fifo_wr": 0,
                "fifo_rd": 0,
                "fifo_full": 0,
                "fifo_empty": 0,
                "sel_sb": 0,
                "outstanding_store": 0,
                "fifo_wr_ack": 0,
                "payload": None,
            }

        fifo_empty = int(len(self._fifo) == 0)
        fifo_full = int(len(self._fifo) >= self.FIFO_DEPTH)
        valid_write = bool(i["dcsb_cyc_i"] and i["dcsb_stb_i"] and i["dcsb_we_i"])
        fifo_wr = int(valid_write and not fifo_full and not self._fifo_wr_ack)
        fifo_rd = int(not self._outstanding_store)
        sel_sb = int((not fifo_empty) or self._outstanding_store)

        payload = (
            self._active
            if self._active is not None
            else (self._fifo[0] if self._fifo else None)
        )
        fifo_dat_o = self._pack_payload(payload) if payload is not None else 0
        fifo_dat_i = self._pack_payload((i["dcsb_sel_i"], i["dcsb_dat_i"], i["dcsb_adr_i"]))

        return {
            "fifo_dat_i": fifo_dat_i,
            "fifo_dat_o": fifo_dat_o,
            "fifo_wr": fifo_wr,
            "fifo_rd": fifo_rd,
            "fifo_full": fifo_full,
            "fifo_empty": fifo_empty,
            "sel_sb": sel_sb,
            "outstanding_store": int(bool(self._outstanding_store)),
            "fifo_wr_ack": int(bool(self._fifo_wr_ack)),
            "payload": payload,
        }

    def outputs(self, i):
        s = self._signals(i)

        self.fifo_dat_i = s["fifo_dat_i"]
        self.fifo_dat_o = s["fifo_dat_o"]
        self.fifo_wr = bool(s["fifo_wr"])
        self.fifo_rd = bool(s["fifo_rd"])
        self.fifo_full = bool(s["fifo_full"])
        self.fifo_empty = bool(s["fifo_empty"])
        self.sel_sb = bool(s["sel_sb"])
        self.outstanding_store = bool(s["outstanding_store"])
        self.fifo_wr_ack = bool(s["fifo_wr_ack"])

        o = {p: None for p in self.OUTPUT_PORTS}
        o["dcsb_dat_o"] = self.mask(i["sbbiu_dat_i"], 32)

        if not self.SB_IMPLEMENTED:
            o["dcsb_ack_o"] = self.mask(i["sbbiu_ack_i"], 1)
            o["dcsb_err_o"] = self.mask(i["sbbiu_err_i"], 1)
            o["sbbiu_dat_o"] = self.mask(i["dcsb_dat_i"], 32)
            o["sbbiu_adr_o"] = self.mask(i["dcsb_adr_i"], 32)
            o["sbbiu_cyc_o"] = self.mask(i["dcsb_cyc_i"], 1)
            o["sbbiu_stb_o"] = self.mask(i["dcsb_stb_i"], 1)
            o["sbbiu_we_o"] = self.mask(i["dcsb_we_i"], 1)
            o["sbbiu_sel_o"] = self.mask(i["dcsb_sel_i"], 4)
            o["sbbiu_cab_o"] = self.mask(i["dcsb_cab_i"], 1)
            return o

        if s["sel_sb"]:
            payload = s["payload"]
            if payload is None:
                sel, data, addr = 0, 0, 0
            else:
                sel, data, addr = payload
            o["sbbiu_dat_o"] = self.mask(data, 32)
            o["sbbiu_adr_o"] = self.mask(addr, 32)
            o["sbbiu_cyc_o"] = 1
            o["sbbiu_stb_o"] = 1
            o["sbbiu_we_o"] = 1
            o["sbbiu_sel_o"] = self.mask(sel, 4)
            o["sbbiu_cab_o"] = 0
            o["dcsb_ack_o"] = self.mask(self._fifo_wr_ack, 1)
            o["dcsb_err_o"] = 0
        else:
            o["sbbiu_dat_o"] = self.mask(i["dcsb_dat_i"], 32)
            o["sbbiu_adr_o"] = self.mask(i["dcsb_adr_i"], 32)
            o["sbbiu_cyc_o"] = self.mask(i["dcsb_cyc_i"], 1)
            o["sbbiu_stb_o"] = self.mask(i["dcsb_stb_i"], 1)
            o["sbbiu_we_o"] = self.mask(i["dcsb_we_i"], 1)
            o["sbbiu_sel_o"] = self.mask(i["dcsb_sel_i"], 4)
            o["sbbiu_cab_o"] = self.mask(i["dcsb_cab_i"], 1)
            o["dcsb_ack_o"] = self.mask(i["sbbiu_ack_i"], 1)
            o["dcsb_err_o"] = self.mask(i["sbbiu_err_i"], 1)
        return o

    def advance(self, i):
        if i["rst"]:
            self.reset()
            return
        if not self.SB_IMPLEMENTED:
            return

        s = self._signals(i)
        ack = bool(i["sbbiu_ack_i"])
        fifo_wr = bool(s["fifo_wr"])
        old_fifo = list(self._fifo)
        new_fifo = list(old_fifo)
        read_payload = None
        bypass_write = False

        if s["fifo_rd"]:
            if new_fifo:
                read_payload = new_fifo.pop(0)
            elif fifo_wr and not ack:
                # A fall-through FIFO can deliver a newly accepted word directly
                # to its output when read is enabled while the FIFO was empty.
                read_payload = (
                    self.mask(i["dcsb_sel_i"], 4),
                    self.mask(i["dcsb_dat_i"], 32),
                    self.mask(i["dcsb_adr_i"], 32),
                )
                bypass_write = True

        if fifo_wr and not bypass_write:
            new_fifo.append((
                self.mask(i["dcsb_sel_i"], 4),
                self.mask(i["dcsb_dat_i"], 32),
                self.mask(i["dcsb_adr_i"], 32),
            ))

        if ack:
            self._active = None
        elif read_payload is not None:
            self._active = read_payload

        self._fifo = new_fifo
        if ack:
            self._outstanding_store = 0
        elif s["sel_sb"] or fifo_wr:
            self._outstanding_store = 1
        self._fifo_wr_ack = int(fifo_wr)
