"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['dcsb_dat_o', 'dcsb_ack_o', 'dcsb_err_o', 'sbbiu_dat_o', 'sbbiu_adr_o', 'sbbiu_cyc_o', 'sbbiu_stb_o', 'sbbiu_we_o', 'sbbiu_sel_o', 'sbbiu_cab_o']
    PROBE_PORTS = ['fifo_dat_i', 'fifo_dat_o', 'fifo_wr', 'fifo_rd', 'fifo_full', 'fifo_empty', 'sel_sb', 'outstanding_store', 'fifo_wr_ack']
    PROBE_WIDTHS = {'fifo_dat_i': 68, 'fifo_dat_o': 68, 'fifo_wr': 1, 'fifo_rd': 1, 'fifo_full': 1, 'fifo_empty': 1, 'sel_sb': 1, 'outstanding_store': 1, 'fifo_wr_ack': 1}
    LATENCY_CYCLES = 1

    def reset(self):
        self.fifo = []
        self.fifo_depth = 4
        self.outstanding_store = False
        self.fifo_wr_ack = False
        self.fifo_dat_i = 0
        self.fifo_dat_o = 0
        self.fifo_wr = False
        self.fifo_rd = True
        self.fifo_full = False
        self.fifo_empty = True
        self.sel_sb = False

    def _signals(self, i):
        sel = self.mask(i['dcsb_sel_i'], 4)
        data = self.mask(i['dcsb_dat_i'], 32)
        addr = self.mask(i['dcsb_adr_i'], 32)
        fifo_dat_i = self.mask((sel << 64) | (data << 32) | addr, 68)
        fifo_empty = len(self.fifo) == 0
        fifo_full = len(self.fifo) >= self.fifo_depth
        fifo_wr = bool(i['dcsb_cyc_i'] and i['dcsb_stb_i'] and i['dcsb_we_i'] and not fifo_full and not self.fifo_wr_ack)
        fifo_rd = not self.outstanding_store
        sel_sb = (not fifo_empty) or self.outstanding_store
        fifo_dat_o = self.fifo[0] if not fifo_empty else 0
        return {
            'fifo_dat_i': fifo_dat_i,
            'fifo_dat_o': self.mask(fifo_dat_o, 68),
            'fifo_wr': fifo_wr,
            'fifo_rd': fifo_rd,
            'fifo_full': fifo_full,
            'fifo_empty': fifo_empty,
            'sel_sb': sel_sb,
        }

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        s = self._signals(i)

        self.fifo_dat_i = s['fifo_dat_i']
        self.fifo_dat_o = s['fifo_dat_o']
        self.fifo_wr = bool(s['fifo_wr'])
        self.fifo_rd = bool(s['fifo_rd'])
        self.fifo_full = bool(s['fifo_full'])
        self.fifo_empty = bool(s['fifo_empty'])
        self.sel_sb = bool(s['sel_sb'])
        self.outstanding_store = bool(self.outstanding_store)
        self.fifo_wr_ack = bool(self.fifo_wr_ack)

        o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)
        if s['sel_sb']:
            o['dcsb_ack_o'] = int(self.fifo_wr_ack)
            o['dcsb_err_o'] = 0
            packed = s['fifo_dat_o']
            o['sbbiu_dat_o'] = self.mask(packed >> 32, 32)
            o['sbbiu_adr_o'] = self.mask(packed, 32)
            o['sbbiu_sel_o'] = self.mask(packed >> 64, 4)
            o['sbbiu_cyc_o'] = 1
            o['sbbiu_stb_o'] = 1
            o['sbbiu_we_o'] = 1
            o['sbbiu_cab_o'] = 0
        else:
            o['dcsb_ack_o'] = int(bool(i['sbbiu_ack_i']))
            o['dcsb_err_o'] = int(bool(i['sbbiu_err_i']))
            o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
            o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
            o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
            o['sbbiu_cyc_o'] = int(bool(i['dcsb_cyc_i']))
            o['sbbiu_stb_o'] = int(bool(i['dcsb_stb_i']))
            o['sbbiu_we_o'] = int(bool(i['dcsb_we_i']))
            o['sbbiu_cab_o'] = int(bool(i['dcsb_cab_i']))
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return

        s = self._signals(i)
        next_fifo = list(self.fifo)
        if s['fifo_rd'] and next_fifo:
            next_fifo.pop(0)
        if s['fifo_wr']:
            next_fifo.append(s['fifo_dat_i'])
        self.fifo = next_fifo

        if i['sbbiu_ack_i']:
            self.outstanding_store = False
        elif s['sel_sb'] or s['fifo_wr']:
            self.outstanding_store = True

        self.fifo_wr_ack = bool(s['fifo_wr'])
