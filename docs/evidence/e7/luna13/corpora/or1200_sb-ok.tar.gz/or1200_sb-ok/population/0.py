"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['dcsb_dat_o', 'dcsb_ack_o', 'dcsb_err_o', 'sbbiu_dat_o', 'sbbiu_adr_o', 'sbbiu_cyc_o', 'sbbiu_stb_o', 'sbbiu_we_o', 'sbbiu_sel_o', 'sbbiu_cab_o']
    PROBE_PORTS = ['fifo_dat_i', 'fifo_dat_o', 'fifo_wr', 'fifo_rd', 'fifo_full', 'fifo_empty', 'sel_sb', 'outstanding_store', 'fifo_wr_ack']
    PROBE_WIDTHS = {'fifo_dat_i': 68, 'fifo_dat_o': 68, 'fifo_wr': 1, 'fifo_rd': 1, 'fifo_full': 1, 'fifo_empty': 1, 'sel_sb': 1, 'outstanding_store': 1, 'fifo_wr_ack': 1}
    LATENCY_CYCLES = 1

    def reset(self):
        self.sb_implemented = getattr(self, "sb_implemented", True)
        self.fifo_depth = 4
        self.fifo = []
        self.active = None
        self.outstanding_store = False
        self.fifo_wr_ack = False


    def _signals(self, i):
        fifo_full = len(self.fifo) >= self.fifo_depth
        fifo_empty = len(self.fifo) == 0
        payload = ((self.mask(i['dcsb_sel_i'], 4) << 64) |
                   (self.mask(i['dcsb_dat_i'], 32) << 32) |
                   self.mask(i['dcsb_adr_i'], 32))
        fifo_wr = bool(i['dcsb_cyc_i'] and i['dcsb_stb_i'] and
                       i['dcsb_we_i'] and not fifo_full and
                       not self.fifo_wr_ack)
        fifo_rd = not self.outstanding_store
        sel_sb = bool((not fifo_empty) or
                      (fifo_empty and self.outstanding_store))
        if self.active is not None:
            fifo_dat_o = self.active
        elif self.fifo:
            fifo_dat_o = self.fifo[0]
        else:
            fifo_dat_o = 0
        return {
            'fifo_full': fifo_full,
            'fifo_empty': fifo_empty,
            'fifo_dat_i': self.mask(payload, 68),
            'fifo_dat_o': self.mask(fifo_dat_o, 68),
            'fifo_wr': fifo_wr,
            'fifo_rd': fifo_rd,
            'sel_sb': sel_sb,
            'outstanding_store': self.outstanding_store,
            'fifo_wr_ack': self.fifo_wr_ack,
        }


    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        if not self.sb_implemented:
            self.fifo_dat_i = 0
            self.fifo_dat_o = 0
            self.fifo_wr = False
            self.fifo_rd = False
            self.fifo_full = False
            self.fifo_empty = True
            self.sel_sb = False
            self.outstanding_store = False
            self.fifo_wr_ack = False
            o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)
            o['dcsb_ack_o'] = int(bool(i['sbbiu_ack_i']))
            o['dcsb_err_o'] = int(bool(i['sbbiu_err_i']))
            o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
            o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
            o['sbbiu_cyc_o'] = int(bool(i['dcsb_cyc_i']))
            o['sbbiu_stb_o'] = int(bool(i['dcsb_stb_i']))
            o['sbbiu_we_o'] = int(bool(i['dcsb_we_i']))
            o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
            o['sbbiu_cab_o'] = int(bool(i['dcsb_cab_i']))
            return o

        s = self._signals(i)
        self.fifo_dat_i = s['fifo_dat_i']
        self.fifo_dat_o = s['fifo_dat_o']
        self.fifo_wr = bool(s['fifo_wr'])
        self.fifo_rd = bool(s['fifo_rd'])
        self.fifo_full = bool(s['fifo_full'])
        self.fifo_empty = bool(s['fifo_empty'])
        self.sel_sb = bool(s['sel_sb'])
        self.outstanding_store = bool(s['outstanding_store'])
        self.fifo_wr_ack = bool(s['fifo_wr_ack'])

        o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)
        o['dcsb_ack_o'] = int(bool(self.fifo_wr_ack if s['sel_sb'] else i['sbbiu_ack_i']))
        o['dcsb_err_o'] = int(bool(i['sbbiu_err_i']) and not s['sel_sb'])
        if s['sel_sb']:
            o['sbbiu_sel_o'] = (s['fifo_dat_o'] >> 64) & 0xF
            o['sbbiu_dat_o'] = (s['fifo_dat_o'] >> 32) & 0xFFFFFFFF
            o['sbbiu_adr_o'] = s['fifo_dat_o'] & 0xFFFFFFFF
            o['sbbiu_cyc_o'] = 1
            o['sbbiu_stb_o'] = 1
            o['sbbiu_we_o'] = 1
            o['sbbiu_cab_o'] = 0
        else:
            o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
            o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
            o['sbbiu_cyc_o'] = int(bool(i['dcsb_cyc_i']))
            o['sbbiu_stb_o'] = int(bool(i['dcsb_stb_i']))
            o['sbbiu_we_o'] = int(bool(i['dcsb_we_i']))
            o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
            o['sbbiu_cab_o'] = int(bool(i['dcsb_cab_i']))
        return o


    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not self.sb_implemented:
            return

        s = self._signals(i)
        fifo_wr = s['fifo_wr']
        payload = s['fifo_dat_i']
        biu_ack = bool(i['sbbiu_ack_i'])
        old_outstanding = self.outstanding_store
        new_fifo = self.fifo[:]
        new_active = self.active

        if old_outstanding:
            if biu_ack:
                new_outstanding = False
                new_active = None
            else:
                new_outstanding = True
            if fifo_wr:
                new_fifo.append(payload)
        elif new_fifo:
            issued = new_fifo.pop(0)
            if biu_ack:
                new_outstanding = False
                new_active = None
            else:
                new_outstanding = True
                new_active = issued
            if fifo_wr:
                new_fifo.append(payload)
        elif fifo_wr:
            if biu_ack:
                new_fifo.append(payload)
                new_outstanding = False
                new_active = None
            else:
                # Model an empty-FIFO simultaneous write/read as a fall-through issue.
                new_outstanding = True
                new_active = payload
        else:
            new_outstanding = False
            new_active = None

        self.fifo = new_fifo
        self.active = new_active
        self.outstanding_store = bool(new_outstanding)
        self.fifo_wr_ack = bool(fifo_wr)
