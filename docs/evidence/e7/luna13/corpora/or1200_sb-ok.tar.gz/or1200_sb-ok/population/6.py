"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['dcsb_dat_o', 'dcsb_ack_o', 'dcsb_err_o', 'sbbiu_dat_o', 'sbbiu_adr_o', 'sbbiu_cyc_o', 'sbbiu_stb_o', 'sbbiu_we_o', 'sbbiu_sel_o', 'sbbiu_cab_o']
    PROBE_PORTS = ['fifo_dat_i', 'fifo_dat_o', 'fifo_wr', 'fifo_rd', 'fifo_full', 'fifo_empty', 'sel_sb', 'outstanding_store', 'fifo_wr_ack']
    PROBE_WIDTHS = {'fifo_dat_i': 68, 'fifo_dat_o': 68, 'fifo_wr': 1, 'fifo_rd': 1, 'fifo_full': 1, 'fifo_empty': 1, 'sel_sb': 1, 'outstanding_store': 1, 'fifo_wr_ack': 1}
    LATENCY_CYCLES = 1

    SB_IMPLEMENTED = True
    FIFO_DEPTH = 4

    def reset(self):
        if not hasattr(self, 'sb_implemented'):
            self.sb_implemented = bool(self.SB_IMPLEMENTED)
        self.fifo = []
        self.outstanding_store = False
        self.fifo_wr_ack = False
        self.active_data = 0
        self.active_valid = False

    def _signals(self, i):
        if not self.sb_implemented:
            return {
                'fifo_dat_i': 0,
                'fifo_dat_o': 0,
                'fifo_wr': False,
                'fifo_rd': False,
                'fifo_full': False,
                'fifo_empty': True,
                'sel_sb': False,
                'outstanding_store': False,
                'fifo_wr_ack': False,
            }

        fifo_dat_i = self.mask(
            (self.mask(i['dcsb_sel_i'], 4) << 64)
            | (self.mask(i['dcsb_dat_i'], 32) << 32)
            | self.mask(i['dcsb_adr_i'], 32),
            68,
        )
        fifo_empty = len(self.fifo) == 0
        fifo_full = len(self.fifo) >= self.FIFO_DEPTH
        sel_sb = (not fifo_empty) or bool(self.outstanding_store)

        if self.outstanding_store and self.active_valid:
            fifo_dat_o = self.active_data
        elif not fifo_empty:
            fifo_dat_o = self.fifo[0]
        else:
            fifo_dat_o = 0

        fifo_wr = bool(
            i['dcsb_cyc_i']
            and i['dcsb_stb_i']
            and i['dcsb_we_i']
            and not fifo_full
            and not self.fifo_wr_ack
        )
        fifo_rd = not bool(self.outstanding_store)
        return {
            'fifo_dat_i': fifo_dat_i,
            'fifo_dat_o': self.mask(fifo_dat_o, 68),
            'fifo_wr': fifo_wr,
            'fifo_rd': fifo_rd,
            'fifo_full': fifo_full,
            'fifo_empty': fifo_empty,
            'sel_sb': sel_sb,
            'outstanding_store': bool(self.outstanding_store),
            'fifo_wr_ack': bool(self.fifo_wr_ack),
        }

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        s = self._signals(i)

        self.fifo_dat_i = s['fifo_dat_i']
        self.fifo_dat_o = s['fifo_dat_o']
        self.fifo_wr = bool(s['fifo_wr'])
        self.fifo_rd = bool(s['fifo_rd'])
        self.fifo_full = bool(s['fifo_full'])
        self.fifo_empty = bool(s['fifo_empty'])
        self.sel_sb = bool(s['sel_sb'])
        self.outstanding_store = bool(s['outstanding_store'])
        self.fifo_wr_ack = bool(s['fifo_wr_ack'])

        o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)
        if s['sel_sb']:
            fifo_data = s['fifo_dat_o']
            o['dcsb_ack_o'] = int(bool(s['fifo_wr_ack']))
            o['dcsb_err_o'] = 0
            o['sbbiu_dat_o'] = self.mask(fifo_data >> 32, 32)
            o['sbbiu_adr_o'] = self.mask(fifo_data, 32)
            o['sbbiu_cyc_o'] = 1
            o['sbbiu_stb_o'] = 1
            o['sbbiu_we_o'] = 1
            o['sbbiu_sel_o'] = self.mask(fifo_data >> 64, 4)
            o['sbbiu_cab_o'] = 0
        else:
            o['dcsb_ack_o'] = self.mask(i['sbbiu_ack_i'], 1)
            o['dcsb_err_o'] = self.mask(i['sbbiu_err_i'], 1)
            o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
            o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
            o['sbbiu_cyc_o'] = self.mask(i['dcsb_cyc_i'], 1)
            o['sbbiu_stb_o'] = self.mask(i['dcsb_stb_i'], 1)
            o['sbbiu_we_o'] = self.mask(i['dcsb_we_i'], 1)
            o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
            o['sbbiu_cab_o'] = self.mask(i['dcsb_cab_i'], 1)
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not self.sb_implemented:
            return

        s = self._signals(i)

        # fifo_rd is an enable; the FIFO's empty control prevents an empty pop.
        if s['fifo_rd'] and self.fifo:
            self.active_data = self.fifo.pop(0)
            self.active_valid = True
        if s['fifo_wr']:
            self.fifo.append(s['fifo_dat_i'])

        self.fifo_wr_ack = bool(s['fifo_wr'])
        if i['sbbiu_ack_i']:
            self.outstanding_store = False
            self.active_valid = False
        elif s['sel_sb'] or s['fifo_wr']:
            self.outstanding_store = True
