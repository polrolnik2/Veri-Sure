"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['dcsb_dat_o', 'dcsb_ack_o', 'dcsb_err_o', 'sbbiu_dat_o', 'sbbiu_adr_o', 'sbbiu_cyc_o', 'sbbiu_stb_o', 'sbbiu_we_o', 'sbbiu_sel_o', 'sbbiu_cab_o']
    PROBE_PORTS = ['fifo_dat_i', 'fifo_dat_o', 'fifo_wr', 'fifo_rd', 'fifo_full', 'fifo_empty', 'sel_sb', 'outstanding_store', 'fifo_wr_ack']
    PROBE_WIDTHS = {'fifo_dat_i': 68, 'fifo_dat_o': 68, 'fifo_wr': 1, 'fifo_rd': 1, 'fifo_full': 1, 'fifo_empty': 1, 'sel_sb': 1, 'outstanding_store': 1, 'fifo_wr_ack': 1}
    LATENCY_CYCLES = 1

    def reset(self):
        self.sb_implemented = getattr(self, "SB_IMPLEMENTED", getattr(self, "sb_implemented", True))
        self.fifo_depth = getattr(self, "FIFO_DEPTH", getattr(self, "fifo_depth", 4))
        self.fifo = []
        self.fifo_active_data = 0
        self.fifo_active_valid = False
        self.outstanding_store = False
        self.fifo_wr_ack = False
        self.fifo_dat_i = 0
        self.fifo_dat_o = 0
        self.fifo_wr = False
        self.fifo_rd = False
        self.fifo_full = False
        self.fifo_empty = True
        self.sel_sb = False

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        if self.sb_implemented:
            fifo_full = len(self.fifo) >= self.fifo_depth
            fifo_empty = len(self.fifo) == 0
            fifo_dat_i = self.mask(i['dcsb_sel_i'], 4) << 64
            fifo_dat_i |= self.mask(i['dcsb_dat_i'], 32) << 32
            fifo_dat_i |= self.mask(i['dcsb_adr_i'], 32)
            fifo_wr = bool(i['dcsb_cyc_i'] and i['dcsb_stb_i'] and i['dcsb_we_i'] and not fifo_full and not self.fifo_wr_ack)
            fifo_rd = not self.outstanding_store
            sel_sb = (not fifo_empty) or self.outstanding_store

            if self.outstanding_store and self.fifo_active_valid:
                fifo_dat_o = self.fifo_active_data
            elif self.fifo:
                fifo_dat_o = self.fifo[0]
            elif self.fifo_active_valid:
                fifo_dat_o = self.fifo_active_data
            else:
                fifo_dat_o = 0

            self.fifo_dat_i = self.mask(fifo_dat_i, 68)
            self.fifo_dat_o = self.mask(fifo_dat_o, 68)
            self.fifo_wr = fifo_wr
            self.fifo_rd = bool(fifo_rd)
            self.fifo_full = bool(fifo_full)
            self.fifo_empty = bool(fifo_empty)
            self.sel_sb = bool(sel_sb)

            if sel_sb:
                o['sbbiu_dat_o'] = self.mask((fifo_dat_o >> 32) & 0xffffffff, 32)
                o['sbbiu_adr_o'] = self.mask(fifo_dat_o & 0xffffffff, 32)
                o['sbbiu_cyc_o'] = 1
                o['sbbiu_stb_o'] = 1
                o['sbbiu_we_o'] = 1
                o['sbbiu_sel_o'] = self.mask((fifo_dat_o >> 64) & 0xf, 4)
                o['sbbiu_cab_o'] = 0
                o['dcsb_ack_o'] = int(bool(self.fifo_wr_ack))
                o['dcsb_err_o'] = 0
            else:
                o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
                o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
                o['sbbiu_cyc_o'] = self.mask(i['dcsb_cyc_i'], 1)
                o['sbbiu_stb_o'] = self.mask(i['dcsb_stb_i'], 1)
                o['sbbiu_we_o'] = self.mask(i['dcsb_we_i'], 1)
                o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
                o['sbbiu_cab_o'] = self.mask(i['dcsb_cab_i'], 1)
                o['dcsb_ack_o'] = self.mask(i['sbbiu_ack_i'], 1)
                o['dcsb_err_o'] = self.mask(i['sbbiu_err_i'], 1)
        else:
            self.fifo_dat_i = 0
            self.fifo_dat_o = 0
            self.fifo_wr = False
            self.fifo_rd = False
            self.fifo_full = False
            self.fifo_empty = True
            self.sel_sb = False
            self.outstanding_store = False
            self.fifo_wr_ack = False
            o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
            o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
            o['sbbiu_cyc_o'] = self.mask(i['dcsb_cyc_i'], 1)
            o['sbbiu_stb_o'] = self.mask(i['dcsb_stb_i'], 1)
            o['sbbiu_we_o'] = self.mask(i['dcsb_we_i'], 1)
            o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
            o['sbbiu_cab_o'] = self.mask(i['dcsb_cab_i'], 1)
            o['dcsb_ack_o'] = self.mask(i['sbbiu_ack_i'], 1)
            o['dcsb_err_o'] = self.mask(i['sbbiu_err_i'], 1)

        o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not self.sb_implemented:
            return

        fifo_full = len(self.fifo) >= self.fifo_depth
        fifo_empty = len(self.fifo) == 0
        fifo_wr = bool(i['dcsb_cyc_i'] and i['dcsb_stb_i'] and i['dcsb_we_i'] and not fifo_full and not self.fifo_wr_ack)
        fifo_rd = not self.outstanding_store
        sel_sb = (not fifo_empty) or self.outstanding_store
        sbbiu_ack = bool(i['sbbiu_ack_i'])

        fifo_dat_i = self.mask(i['dcsb_sel_i'], 4) << 64
        fifo_dat_i |= self.mask(i['dcsb_dat_i'], 32) << 32
        fifo_dat_i |= self.mask(i['dcsb_adr_i'], 32)

        next_fifo = list(self.fifo)
        popped_data = None
        if fifo_rd and next_fifo:
            popped_data = next_fifo.pop(0)
        if fifo_wr:
            next_fifo.append(self.mask(fifo_dat_i, 68))
        self.fifo = next_fifo

        if sbbiu_ack:
            self.fifo_active_valid = False
        elif popped_data is not None:
            self.fifo_active_data = popped_data
            self.fifo_active_valid = True

        if sbbiu_ack:
            self.outstanding_store = False
        elif sel_sb or fifo_wr:
            self.outstanding_store = True

        self.fifo_wr_ack = bool(fifo_wr)
