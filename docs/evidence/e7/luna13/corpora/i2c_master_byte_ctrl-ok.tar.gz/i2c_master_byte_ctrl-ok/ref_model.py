"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'dcnt_nonzero', 'cnt_done', 'core_ack', 'core_rxd', 'core_txd', 'core_cmd_start', 'core_cmd_read', 'core_cmd_write', 'core_cmd_stop', 'core_cmd_nop']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'dcnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_rxd': 1, 'core_txd': 1, 'core_cmd_start': 1, 'core_cmd_read': 1, 'core_cmd_write': 1, 'core_cmd_stop': 1, 'core_cmd_nop': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.sr = 0
        self.dcnt = 0
        self.core_cmd = 'NOP'
        self.cmd_ack = 0
        self.ack_out = 0
        self.ld = 0
        self.shift = 0
        self.transfer_read = False
        self._core_ack = 0
        self._bit_pending = False
        self._sampled_rxd = 0
        self._busy = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        async_reset = not bool(i.get('nReset', 1))
        state = 'IDLE' if async_reset else self.state
        sr = 0 if async_reset else self.sr
        dcnt = 0 if async_reset else self.dcnt
        command = 'NOP' if async_reset else self.core_cmd
        cmd_ack = 0 if async_reset else self.cmd_ack
        ack_out = 0 if async_reset else self.ack_out
        ld = 0 if async_reset else self.ld
        shift = 0 if async_reset else self.shift
        core_ack = 0 if async_reset else int(bool(i.get('core_ack', self._core_ack)))
        core_rxd = int(bool(i.get('core_rxd', i.get('sda_i', self._sampled_rxd))))
        busy = 0 if async_reset else self._busy
        arbitration_lost = 0 if async_reset else int(bool(i.get('i2c_al', 0)))
        transfer_read = False if async_reset else self.transfer_read

        self.st_idle = bool(state == 'IDLE')
        self.st_start = bool(state == 'START')
        self.st_read = bool(state == 'READ')
        self.st_write = bool(state == 'WRITE')
        self.st_ack = bool(state == 'ACK')
        self.st_stop = bool(state == 'STOP')
        self.go = bool((i.get('read', 0) or i.get('write', 0) or i.get('stop', 0)) and not cmd_ack)
        self.ld = bool(ld)
        self.shift = bool(shift)
        self.dcnt_nonzero = bool(dcnt != 0)
        self.cnt_done = bool(dcnt == 0)
        self.core_ack = bool(core_ack)
        self.core_rxd = bool(core_rxd)
        self.core_txd = bool((i.get('ack_in', 0) if state == 'ACK' and transfer_read else ((sr >> 7) & 1)))
        self.core_cmd_start = bool(command == 'START')
        self.core_cmd_read = bool(command == 'READ')
        self.core_cmd_write = bool(command == 'WRITE')
        self.core_cmd_stop = bool(command == 'STOP')
        self.core_cmd_nop = bool(command == 'NOP')

        o['cmd_ack'] = int(bool(cmd_ack))
        o['ack_out'] = int(bool(ack_out))
        o['dout'] = self.mask(sr, 8)
        o['i2c_busy'] = int(bool(busy))
        o['i2c_al'] = int(bool(arbitration_lost))
        # The lower-level bit controller owns the waveforms; idle pads are released.
        o['scl_o'] = 0
        o['scl_oen'] = 1
        o['sda_o'] = 0
        o['sda_oen'] = 1
        return o

    def advance(self, i):
        if not bool(i.get('nReset', 1)):
            self.reset()
            return
        if bool(i.get('rst', 0)):
            self.reset()
            return

        old_command = self.core_cmd
        old_ld = self.ld
        old_shift = self.shift
        core_ack = int(bool(i.get('core_ack', self._core_ack)))
        core_rxd = int(bool(i.get('core_rxd', i.get('sda_i', self._sampled_rxd))))
        arbitration_lost = int(bool(i.get('i2c_al', 0)))

        # The datapath consumes the controls from the current state, as it would
        # at this edge; the FSM below schedules controls for the following state.
        if old_ld:
            self.sr = self.mask(i.get('din', 0), 8)
            self.dcnt = 7
        elif old_shift:
            shift_bit = int(bool(i['core_rxd'])) if 'core_rxd' in i else self._sampled_rxd
            self.sr = self.mask((self.sr << 1) | shift_bit, 8)
            self.dcnt = self.mask(self.dcnt - 1, 3)
        self._sampled_rxd = core_rxd

        if arbitration_lost:
            self.state = 'IDLE'
            self.core_cmd = 'NOP'
            self.ld = 0
            self.shift = 0
            self.cmd_ack = 0
            self._core_ack = 0
            self._bit_pending = False
            return

        next_state = self.state
        next_command = 'NOP'
        next_ld = 0
        next_shift = 0
        next_cmd_ack = 0

        if self.state == 'IDLE':
            go = bool((i.get('read', 0) or i.get('write', 0) or i.get('stop', 0)) and not self.cmd_ack)
            if go:
                if bool(i.get('start', 0)):
                    next_state = 'START'
                    next_command = 'START'
                    next_ld = 1
                elif bool(i.get('read', 0)):
                    next_state = 'READ'
                    next_command = 'READ'
                    next_ld = 1
                    self.transfer_read = True
                elif bool(i.get('write', 0)):
                    next_state = 'WRITE'
                    next_command = 'WRITE'
                    next_ld = 1
                    self.transfer_read = False
                else:
                    next_state = 'STOP'
                    next_command = 'STOP'
                    self.transfer_read = False
        elif self.state == 'START':
            if core_ack:
                if bool(i.get('read', 0)):
                    next_state = 'READ'
                    next_command = 'READ'
                    self.transfer_read = True
                else:
                    next_state = 'WRITE'
                    next_command = 'WRITE'
                    self.transfer_read = False
                self._busy = 1
        elif self.state == 'WRITE':
            if core_ack:
                if self.dcnt == 0:
                    next_state = 'ACK'
                    next_command = 'READ'
                    self.transfer_read = False
                else:
                    next_command = 'WRITE'
                    next_shift = 1
        elif self.state == 'READ':
            if core_ack:
                next_shift = 1
                if self.dcnt == 0:
                    next_state = 'ACK'
                    next_command = 'WRITE'
                    self.transfer_read = True
                else:
                    next_command = 'READ'
        elif self.state == 'ACK':
            if core_ack:
                self.ack_out = core_rxd
                if bool(i.get('stop', 0)):
                    next_state = 'STOP'
                    next_command = 'STOP'
                else:
                    next_state = 'IDLE'
                    next_cmd_ack = 1
        elif self.state == 'STOP':
            if core_ack:
                next_state = 'IDLE'
                next_cmd_ack = 1
                self._busy = 0

        self.state = next_state
        self.core_cmd = next_command
        self.ld = next_ld
        self.shift = next_shift
        self.cmd_ack = next_cmd_ack

        # Abstract bit-controller completion: a launched command completes after
        # an enabled controller opportunity. Keep it pending while ena is low.
        if core_ack:
            self._bit_pending = False
            self._core_ack = 0
        else:
            pending = bool(self._bit_pending or old_command != 'NOP')
            if pending and bool(i.get('ena', 0)):
                self._bit_pending = False
                self._core_ack = 1
            else:
                self._bit_pending = pending
                self._core_ack = 0

        # Preserve the declared lower-controller inputs in the abstract model.
        self._bit_ena = self.mask(i.get('ena', 0), 1)
        self._bit_clk_cnt = self.mask(i.get('clk_cnt', 0), 16)
        self._bit_scl_i = self.mask(i.get('scl_i', 1), 1)
        self._bit_sda_i = self.mask(i.get('sda_i', 1), 1)
