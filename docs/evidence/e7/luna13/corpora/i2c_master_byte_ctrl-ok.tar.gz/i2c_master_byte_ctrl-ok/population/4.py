"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'dcnt_nonzero', 'cnt_done', 'core_ack', 'core_rxd', 'core_txd', 'core_cmd_start', 'core_cmd_read', 'core_cmd_write', 'core_cmd_stop', 'core_cmd_nop']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'dcnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_rxd': 1, 'core_txd': 1, 'core_cmd_start': 1, 'core_cmd_read': 1, 'core_cmd_write': 1, 'core_cmd_stop': 1, 'core_cmd_nop': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.core_cmd = 'NOP'
        self.sr = 0
        self.dcnt = 0
        self.cmd_ack = 0
        self.ack_out = 0
        self.busy = 0
        self.al_status = False

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        async_reset = not bool(i['nReset'])
        state = 'IDLE' if async_reset else self.state
        core_cmd = 'NOP' if async_reset else self.core_cmd
        sr = 0 if async_reset else self.sr
        dcnt = 0 if async_reset else self.dcnt
        cmd_ack = 0 if async_reset else self.cmd_ack
        ack_out = 0 if async_reset else self.ack_out
        busy = 0 if async_reset else self.busy
        al_status = False if async_reset else bool(self.al_status)

        go = bool((i['read'] or i['write'] or i['stop']) and not cmd_ack)
        core_ack = bool(i['ena'] and core_cmd != 'NOP')
        core_rxd = bool(i['sda_i'] & 1)
        ld = bool(state == 'IDLE' and go)
        shift = bool(core_ack and state in ('READ', 'WRITE'))

        self.st_idle = bool(state == 'IDLE')
        self.st_start = bool(state == 'START')
        self.st_read = bool(state == 'READ')
        self.st_write = bool(state == 'WRITE')
        self.st_ack = bool(state == 'ACK')
        self.st_stop = bool(state == 'STOP')
        self.go = bool(go)
        self.ld = bool(ld)
        self.shift = bool(shift)
        self.dcnt_nonzero = bool(dcnt != 0)
        self.cnt_done = bool(dcnt == 0)
        self.core_ack = bool(core_ack)
        self.core_rxd = bool(core_rxd)
        self.core_txd = bool((i['ack_in'] & 1) if state == 'ACK' else ((sr >> 7) & 1))
        self.core_cmd_start = bool(core_cmd == 'START')
        self.core_cmd_read = bool(core_cmd == 'READ')
        self.core_cmd_write = bool(core_cmd == 'WRITE')
        self.core_cmd_stop = bool(core_cmd == 'STOP')
        self.core_cmd_nop = bool(core_cmd == 'NOP')

        o['cmd_ack'] = int(cmd_ack)
        o['ack_out'] = int(ack_out)
        o['dout'] = self.mask(sr, 8)
        o['i2c_busy'] = int(busy)
        o['i2c_al'] = int(al_status)
        o['scl_o'] = 0
        o['scl_oen'] = 1
        o['sda_o'] = 0
        o['sda_oen'] = 1
        return o

    def advance(self, i):
        if not i['nReset'] or i['rst']:
            self.reset()
            return

        if self.al_status:
            self.state = 'IDLE'
            self.core_cmd = 'NOP'
            self.cmd_ack = 0
            self.ack_out = 0
            return

        state = self.state
        core_ack = bool(i['ena'] and self.core_cmd != 'NOP')
        core_rxd = i['sda_i'] & 1
        go = bool((i['read'] or i['write'] or i['stop']) and not self.cmd_ack)
        ld = bool(state == 'IDLE' and go)
        shift = bool(core_ack and state in ('READ', 'WRITE'))
        cnt_done = self.dcnt == 0

        if ld:
            self.sr = self.mask(i['din'], 8)
            self.dcnt = 7
        elif shift:
            self.sr = self.mask((self.sr << 1) | core_rxd, 8)
            self.dcnt = (self.dcnt - 1) & 7

        self.cmd_ack = 0

        if state == 'IDLE':
            if go:
                if i['start']:
                    self.state = 'START'
                    self.core_cmd = 'START'
                elif i['read']:
                    self.state = 'READ'
                    self.core_cmd = 'READ'
                elif i['write']:
                    self.state = 'WRITE'
                    self.core_cmd = 'WRITE'
                else:
                    self.state = 'STOP'
                    self.core_cmd = 'STOP'
        elif state == 'START':
            if core_ack:
                self.busy = 1
                if i['read']:
                    self.state = 'READ'
                    self.core_cmd = 'READ'
                else:
                    self.state = 'WRITE'
                    self.core_cmd = 'WRITE'
        elif state == 'WRITE':
            if core_ack:
                if cnt_done:
                    self.state = 'ACK'
                    self.core_cmd = 'READ'
                else:
                    self.core_cmd = 'WRITE'
        elif state == 'READ':
            if core_ack:
                if cnt_done:
                    self.state = 'ACK'
                    self.core_cmd = 'WRITE'
                else:
                    self.core_cmd = 'READ'
        elif state == 'ACK':
            if core_ack:
                self.ack_out = core_rxd
                if i['stop']:
                    self.state = 'STOP'
                    self.core_cmd = 'STOP'
                else:
                    self.state = 'IDLE'
                    self.core_cmd = 'NOP'
                    self.cmd_ack = 1
        elif state == 'STOP':
            if core_ack:
                self.busy = 0
                self.state = 'IDLE'
                self.core_cmd = 'NOP'
                self.cmd_ack = 1
