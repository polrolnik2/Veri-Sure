"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'dcnt_nonzero', 'cnt_done', 'core_ack', 'core_rxd', 'core_txd', 'core_cmd_start', 'core_cmd_read', 'core_cmd_write', 'core_cmd_stop', 'core_cmd_nop']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'dcnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_rxd': 1, 'core_txd': 1, 'core_cmd_start': 1, 'core_cmd_read': 1, 'core_cmd_write': 1, 'core_cmd_stop': 1, 'core_cmd_nop': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'ST_IDLE'
        self.sr = 0
        self.dcnt = 0
        self.core_cmd = 'NOP'
        self.cmd_ack = 0
        self.ack_out = 0
        self.transfer_read = False
        self.busy = 0
        self.i2c_al = 0

    def _view(self, i):
        async_reset = not i.get('nReset', 1)
        if async_reset:
            state = 'ST_IDLE'
            sr = 0
            dcnt = 0
            cmd = 'NOP'
            cmd_ack = 0
            transfer_read = False
        else:
            state = self.state
            sr = self.sr
            dcnt = self.dcnt
            cmd = self.core_cmd
            cmd_ack = self.cmd_ack
            transfer_read = self.transfer_read

        go = int(bool((i['read'] or i['write'] or i['stop']) and not cmd_ack))
        core_ack = state in ('ST_START', 'ST_READ', 'ST_WRITE', 'ST_ACK', 'ST_STOP')
        core_rxd = int(i.get('sda_i', 1)) & 1
        cnt_done = dcnt == 0
        ld = not async_reset and state == 'ST_IDLE' and bool(go)
        shift = False
        if not async_reset and core_ack:
            if state == 'ST_READ':
                shift = True
            elif state == 'ST_WRITE' and not cnt_done:
                shift = True

        core_txd = (int(i['ack_in']) & 1) if state == 'ST_ACK' and transfer_read else ((sr >> 7) & 1)
        return {
            'state': state,
            'sr': sr,
            'dcnt': dcnt,
            'cmd': cmd,
            'cmd_ack': cmd_ack,
            'go': go,
            'ld': bool(ld),
            'shift': bool(shift),
            'cnt_done': bool(cnt_done),
            'core_ack': bool(core_ack),
            'core_rxd': core_rxd,
            'core_txd': core_txd,
        }

    def outputs(self, i):
        v = self._view(i)
        state = v['state']
        self.st_idle = state == 'ST_IDLE'
        self.st_start = state == 'ST_START'
        self.st_read = state == 'ST_READ'
        self.st_write = state == 'ST_WRITE'
        self.st_ack = state == 'ST_ACK'
        self.st_stop = state == 'ST_STOP'
        self.go = bool(v['go'])
        self.ld = v['ld']
        self.shift = v['shift']
        self.dcnt_nonzero = v['dcnt'] != 0
        self.cnt_done = v['cnt_done']
        self.core_ack = v['core_ack']
        self.core_rxd = bool(v['core_rxd'])
        self.core_txd = bool(v['core_txd'])
        self.core_cmd_start = v['cmd'] == 'START'
        self.core_cmd_read = v['cmd'] == 'READ'
        self.core_cmd_write = v['cmd'] == 'WRITE'
        self.core_cmd_stop = v['cmd'] == 'STOP'
        self.core_cmd_nop = v['cmd'] == 'NOP'

        async_reset = not i.get('nReset', 1)
        o = {p: None for p in self.OUTPUT_PORTS}
        o['cmd_ack'] = v['cmd_ack']
        o['ack_out'] = 0 if async_reset else self.ack_out
        o['dout'] = v['sr']
        o['i2c_busy'] = 0 if async_reset else self.busy
        o['i2c_al'] = self.i2c_al
        o['scl_o'] = 0
        o['scl_oen'] = 1
        o['sda_o'] = 0
        o['sda_oen'] = 1
        return o

    def advance(self, i):
        if not i.get('nReset', 1):
            self.reset()
            return
        if i['rst']:
            self.reset()
            return

        v = self._view(i)
        if self.i2c_al:
            self.state = 'ST_IDLE'
            self.core_cmd = 'NOP'
            self.cmd_ack = 0
            return

        if v['ld']:
            self.sr = self.mask(i['din'], 8)
            self.dcnt = 7
        elif v['shift']:
            self.sr = self.mask((self.sr << 1) | v['core_rxd'], 8)
            self.dcnt = self.mask(self.dcnt - 1, 3)

        self.cmd_ack = 0
        state = self.state
        if state == 'ST_IDLE':
            if v['go']:
                if i['start']:
                    self.state = 'ST_START'
                    self.core_cmd = 'START'
                    self.transfer_read = bool(i['read'])
                elif i['read']:
                    self.state = 'ST_READ'
                    self.core_cmd = 'READ'
                    self.transfer_read = True
                elif i['write']:
                    self.state = 'ST_WRITE'
                    self.core_cmd = 'WRITE'
                    self.transfer_read = False
                else:
                    self.state = 'ST_STOP'
                    self.core_cmd = 'STOP'
                    self.transfer_read = False
        elif state == 'ST_START':
            if v['core_ack']:
                self.busy = 1
                if i['read']:
                    self.state = 'ST_READ'
                    self.core_cmd = 'READ'
                    self.transfer_read = True
                else:
                    self.state = 'ST_WRITE'
                    self.core_cmd = 'WRITE'
                    self.transfer_read = False
        elif state == 'ST_WRITE':
            if v['core_ack']:
                if v['cnt_done']:
                    self.state = 'ST_ACK'
                    self.core_cmd = 'READ'
                else:
                    self.core_cmd = 'WRITE'
        elif state == 'ST_READ':
            if v['core_ack']:
                if v['cnt_done']:
                    self.state = 'ST_ACK'
                    self.core_cmd = 'WRITE'
                    self.transfer_read = True
                else:
                    self.core_cmd = 'READ'
        elif state == 'ST_ACK':
            if v['core_ack']:
                if not self.transfer_read:
                    self.ack_out = v['core_rxd']
                if i['stop']:
                    self.state = 'ST_STOP'
                    self.core_cmd = 'STOP'
                else:
                    self.state = 'ST_IDLE'
                    self.core_cmd = 'NOP'
                    self.cmd_ack = 1
        elif state == 'ST_STOP':
            if v['core_ack']:
                self.state = 'ST_IDLE'
                self.core_cmd = 'NOP'
                self.cmd_ack = 1
                self.busy = 0
