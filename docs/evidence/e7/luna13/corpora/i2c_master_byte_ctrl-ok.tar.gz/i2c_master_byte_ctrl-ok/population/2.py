"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'dcnt_nonzero', 'cnt_done', 'core_ack', 'core_rxd', 'core_txd', 'core_cmd_start', 'core_cmd_read', 'core_cmd_write', 'core_cmd_stop', 'core_cmd_nop']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'dcnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_rxd': 1, 'core_txd': 1, 'core_cmd_start': 1, 'core_cmd_read': 1, 'core_cmd_write': 1, 'core_cmd_stop': 1, 'core_cmd_nop': 1}
    LATENCY_CYCLES = 0

    def _clear(self):
        self.state = 'ST_IDLE'
        self.sr = 0
        self.dcnt = 0
        self.cmd_ack = 0
        self.ack_out = 0
        self.op_read = False
        self.busy = 0
        self.al = 0

    def reset(self):
        self._clear()

    def _view(self, i):
        async_reset = (i['nReset'] == 0)
        if async_reset:
            state = 'ST_IDLE'
            sr = 0
            dcnt = 0
            cmd_ack = 0
            ack_out = 0
            op_read = False
            busy = 0
            al = 0
        else:
            state = self.state
            sr = self.sr
            dcnt = self.dcnt
            cmd_ack = self.cmd_ack
            ack_out = self.ack_out
            op_read = self.op_read
            busy = self.busy
            al = self.al

        go = int(bool(i['read'] or i['write'] or i['stop']) and not bool(cmd_ack))
        active_state = state in ('ST_START', 'ST_READ', 'ST_WRITE', 'ST_ACK', 'ST_STOP')
        core_ack = int(bool(i['ena']) and active_state and not bool(al))
        core_rxd = 0 if async_reset else self.mask(i['sda_i'], 1)
        cnt_done = int(dcnt == 0)
        ld = int(not async_reset and state == 'ST_IDLE' and bool(go))
        shift = int(
            not async_reset
            and bool(core_ack)
            and (
                state == 'ST_READ'
                or (state == 'ST_WRITE' and dcnt != 0)
            )
        )

        if state == 'ST_START':
            cmd = 'START'
        elif state == 'ST_READ':
            cmd = 'READ'
        elif state == 'ST_WRITE':
            cmd = 'WRITE'
        elif state == 'ST_ACK':
            cmd = 'WRITE' if op_read else 'READ'
        elif state == 'ST_STOP':
            cmd = 'STOP'
        else:
            cmd = 'NOP'

        if state == 'ST_ACK' and op_read:
            core_txd = self.mask(i['ack_in'], 1)
        else:
            core_txd = (sr >> 7) & 1

        return {
            'state': state,
            'sr': sr,
            'dcnt': dcnt,
            'cmd_ack': cmd_ack,
            'ack_out': ack_out,
            'op_read': op_read,
            'busy': busy,
            'al': al,
            'go': go,
            'ld': ld,
            'shift': shift,
            'cnt_done': cnt_done,
            'core_ack': core_ack,
            'core_rxd': core_rxd,
            'core_txd': core_txd,
            'cmd': cmd,
        }

    def outputs(self, i):
        v = self._view(i)
        o = {p: None for p in self.OUTPUT_PORTS}
        o['cmd_ack'] = int(bool(v['cmd_ack']))
        o['ack_out'] = int(bool(v['ack_out']))
        o['dout'] = self.mask(v['sr'], 8)
        o['i2c_busy'] = int(bool(v['busy']))
        o['i2c_al'] = int(bool(v['al']))
        o['scl_o'] = 0
        o['scl_oen'] = 1
        o['sda_o'] = 0
        o['sda_oen'] = 1

        self.st_idle = bool(v['state'] == 'ST_IDLE')
        self.st_start = bool(v['state'] == 'ST_START')
        self.st_read = bool(v['state'] == 'ST_READ')
        self.st_write = bool(v['state'] == 'ST_WRITE')
        self.st_ack = bool(v['state'] == 'ST_ACK')
        self.st_stop = bool(v['state'] == 'ST_STOP')
        self.go = bool(v['go'])
        self.ld = bool(v['ld'])
        self.shift = bool(v['shift'])
        self.dcnt_nonzero = bool(v['dcnt'] != 0)
        self.cnt_done = bool(v['cnt_done'])
        self.core_ack = bool(v['core_ack'])
        self.core_rxd = bool(v['core_rxd'])
        self.core_txd = bool(v['core_txd'])
        self.core_cmd_start = bool(v['cmd'] == 'START')
        self.core_cmd_read = bool(v['cmd'] == 'READ')
        self.core_cmd_write = bool(v['cmd'] == 'WRITE')
        self.core_cmd_stop = bool(v['cmd'] == 'STOP')
        self.core_cmd_nop = bool(v['cmd'] == 'NOP')
        return o

    def advance(self, i):
        if i['nReset'] == 0:
            self._clear()
            return
        if i['rst']:
            self._clear()
            return
        if self.al:
            self.state = 'ST_IDLE'
            self.cmd_ack = 0
            self.op_read = False
            self.al = 0
            return

        v = self._view(i)
        old_state = v['state']
        old_dcnt = v['dcnt']
        self.cmd_ack = 0

        if v['ld']:
            self.sr = self.mask(i['din'], 8)
            self.dcnt = 7
        elif v['shift']:
            self.sr = self.mask((self.sr << 1) | v['core_rxd'], 8)
            self.dcnt = self.mask(self.dcnt - 1, 3)

        if old_state == 'ST_IDLE':
            if v['go']:
                if i['start']:
                    self.state = 'ST_START'
                    self.op_read = False
                elif i['read']:
                    self.state = 'ST_READ'
                    self.op_read = True
                elif i['write']:
                    self.state = 'ST_WRITE'
                    self.op_read = False
                else:
                    self.state = 'ST_STOP'
                    self.op_read = False
        elif old_state == 'ST_START':
            if v['core_ack']:
                self.busy = 1
                if i['read']:
                    self.state = 'ST_READ'
                    self.op_read = True
                else:
                    self.state = 'ST_WRITE'
                    self.op_read = False
        elif old_state == 'ST_WRITE':
            if v['core_ack'] and old_dcnt == 0:
                self.state = 'ST_ACK'
                self.op_read = False
        elif old_state == 'ST_READ':
            if v['core_ack'] and old_dcnt == 0:
                self.state = 'ST_ACK'
                self.op_read = True
        elif old_state == 'ST_ACK':
            if v['core_ack']:
                if not v['op_read']:
                    self.ack_out = v['core_rxd']
                if i['stop']:
                    self.state = 'ST_STOP'
                else:
                    self.state = 'ST_IDLE'
                    self.cmd_ack = 1
        elif old_state == 'ST_STOP':
            if v['core_ack']:
                self.state = 'ST_IDLE'
                self.busy = 0
                self.cmd_ack = 1
