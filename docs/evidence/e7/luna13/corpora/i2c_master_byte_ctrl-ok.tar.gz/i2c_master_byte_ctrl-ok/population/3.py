"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'dcnt_nonzero', 'cnt_done', 'core_ack', 'core_rxd', 'core_txd', 'core_cmd_start', 'core_cmd_read', 'core_cmd_write', 'core_cmd_stop', 'core_cmd_nop']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'dcnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_rxd': 1, 'core_txd': 1, 'core_cmd_start': 1, 'core_cmd_read': 1, 'core_cmd_write': 1, 'core_cmd_stop': 1, 'core_cmd_nop': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'ST_IDLE'
        self.cmd = 'NOP'
        self.sr = 0
        self.dcnt = 0
        self.ld = False
        self.shift = False
        self.cmd_ack = 0
        self.ack_out = 0
        self.txd = 0
        self.core_ack = False
        self.core_wait = 0
        self.rxd = 0
        self.busy = 0
        self.al = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        reset_active = not bool(i['nReset'] & 1)
        if reset_active:
            state = 'ST_IDLE'
            cmd = 'NOP'
            sr = 0
            dcnt = 0
            ld = False
            shift = False
            cmd_ack = 0
            ack_out = 0
            txd = 0
            core_ack = False
            rxd = 0
            busy = 0
            al = 0
        else:
            state = self.state
            cmd = self.cmd
            sr = self.sr
            dcnt = self.dcnt
            ld = bool(self.ld)
            shift = bool(self.shift)
            cmd_ack = self.cmd_ack
            ack_out = self.ack_out
            txd = self.txd
            core_ack = bool(self.core_ack)
            rxd = self.rxd
            busy = self.busy
            al = self.al

        self.st_idle = bool(state == 'ST_IDLE')
        self.st_start = bool(state == 'ST_START')
        self.st_read = bool(state == 'ST_READ')
        self.st_write = bool(state == 'ST_WRITE')
        self.st_ack = bool(state == 'ST_ACK')
        self.st_stop = bool(state == 'ST_STOP')
        self.go = bool(((i['read'] | i['write'] | i['stop']) & 1) and not cmd_ack)
        self.ld = bool(ld)
        self.shift = bool(shift)
        self.dcnt_nonzero = bool(dcnt != 0)
        self.cnt_done = bool(dcnt == 0)
        self.core_ack = bool(core_ack)
        self.core_rxd = bool(rxd & 1)
        self.core_txd = bool(txd & 1)
        self.core_cmd_start = bool(cmd == 'START')
        self.core_cmd_read = bool(cmd == 'READ')
        self.core_cmd_write = bool(cmd == 'WRITE')
        self.core_cmd_stop = bool(cmd == 'STOP')
        self.core_cmd_nop = bool(cmd == 'NOP')

        o['cmd_ack'] = int(bool(cmd_ack))
        o['ack_out'] = int(bool(ack_out))
        o['dout'] = self.mask(sr, 8)
        o['i2c_busy'] = int(bool(busy))
        o['i2c_al'] = int(bool(al))
        # The lower-level bit controller is not specified here; these values
        # represent released open-drain pads in the abstract model.
        o['scl_o'] = 0
        o['scl_oen'] = 0
        o['sda_o'] = 0
        o['sda_oen'] = 0
        return o

    def advance(self, i):
        if not (i['nReset'] & 1):
            self.reset()
            return
        if i['rst'] & 1:
            self.reset()
            return
        if self.al:
            # Arbitration loss aborts the FSM and its active controls. The
            # separate datapath is not reset by this abort condition.
            self.state = 'ST_IDLE'
            self.cmd = 'NOP'
            self.ld = False
            self.shift = False
            self.cmd_ack = 0
            self.ack_out = 0
            self.txd = 0
            self.core_ack = False
            self.core_wait = 0
            return

        old_sr = self.sr
        old_dcnt = self.dcnt
        next_sr = old_sr
        next_dcnt = old_dcnt
        if self.ld:
            next_sr = self.mask(i['din'], 8)
            next_dcnt = 7
        if self.shift:
            next_sr = self.mask((old_sr << 1) | (self.rxd & 1), 8)
            next_dcnt = self.mask(old_dcnt - 1, 3)

        next_state = self.state
        next_cmd = self.cmd
        next_ld = False
        next_shift = False
        next_cmd_ack = 0
        next_ack_out = self.ack_out
        next_txd = (old_sr >> 7) & 1
        next_busy = self.busy
        cnt_done = (self.dcnt == 0)

        if self.state == 'ST_IDLE':
            go = bool(((i['read'] | i['write'] | i['stop']) & 1) and not self.cmd_ack)
            if go:
                next_ld = True
                if i['start'] & 1:
                    next_state = 'ST_START'
                    next_cmd = 'START'
                elif i['read'] & 1:
                    next_state = 'ST_READ'
                    next_cmd = 'READ'
                elif i['write'] & 1:
                    next_state = 'ST_WRITE'
                    next_cmd = 'WRITE'
                else:
                    next_state = 'ST_STOP'
                    next_cmd = 'STOP'

        elif self.state == 'ST_START':
            if self.core_ack:
                next_busy = 1
                if i['read'] & 1:
                    next_state = 'ST_READ'
                    next_cmd = 'READ'
                else:
                    next_state = 'ST_WRITE'
                    next_cmd = 'WRITE'

        elif self.state == 'ST_WRITE':
            if self.core_ack:
                if cnt_done:
                    next_state = 'ST_ACK'
                    next_cmd = 'READ'
                else:
                    next_shift = True
                    next_cmd = 'WRITE'

        elif self.state == 'ST_READ':
            if self.core_ack:
                # Every completed READ contributes its sampled bit, including
                # the final data bit, before the ACK/NACK command is completed.
                next_shift = True
                if cnt_done:
                    next_state = 'ST_ACK'
                    next_cmd = 'WRITE'
                    next_txd = i['ack_in'] & 1
                else:
                    next_cmd = 'READ'

        elif self.state == 'ST_ACK':
            if self.cmd == 'WRITE':
                next_txd = i['ack_in'] & 1
            if self.core_ack:
                next_ack_out = self.rxd & 1
                if i['stop'] & 1:
                    next_state = 'ST_STOP'
                    next_cmd = 'STOP'
                else:
                    next_state = 'ST_IDLE'
                    next_cmd = 'NOP'
                    next_cmd_ack = 1

        elif self.state == 'ST_STOP':
            if self.core_ack:
                next_state = 'ST_IDLE'
                next_cmd = 'NOP'
                next_cmd_ack = 1
                next_busy = 0

        # Abstract bit-controller handshake: allow setup time for registered
        # data/control, then present one completion pulse for each bit command.
        next_core_ack = False
        next_core_wait = self.core_wait
        next_rxd = self.rxd
        if next_cmd != self.cmd:
            if next_cmd == 'NOP':
                next_core_wait = 0
            else:
                next_core_wait = 2
        elif self.core_ack:
            next_core_wait = 2
        elif self.cmd != 'NOP':
            if self.core_wait > 1:
                next_core_wait = self.core_wait - 1
            else:
                next_core_wait = 0
                next_core_ack = True
                next_rxd = self.mask(i['sda_i'], 1)
        else:
            next_core_wait = 0

        self.sr = next_sr
        self.dcnt = next_dcnt
        self.state = next_state
        self.cmd = next_cmd
        self.ld = next_ld
        self.shift = next_shift
        self.cmd_ack = next_cmd_ack
        self.ack_out = next_ack_out
        self.txd = next_txd & 1
        self.core_ack = next_core_ack
        self.core_wait = next_core_wait
        self.rxd = next_rxd & 1
        self.busy = next_busy
