"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'dcnt_nonzero', 'cnt_done', 'core_ack', 'core_rxd', 'core_txd', 'core_cmd_start', 'core_cmd_read', 'core_cmd_write', 'core_cmd_stop', 'core_cmd_nop']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'dcnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_rxd': 1, 'core_txd': 1, 'core_cmd_start': 1, 'core_cmd_read': 1, 'core_cmd_write': 1, 'core_cmd_stop': 1, 'core_cmd_nop': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'ST_IDLE'
        self.sr = 0
        self.dcnt = 0
        self.core_cmd = 'NOP'
        self.cmd_ack = 0
        self.ack_out = 0
        self.ld = 0
        self.shift = 0
        self.pending = 0
        self.pending_delay = 0
        self.busy = 0

    def _bit_signals(self, i, state=None, cmd=None, sr=None, pending=None, delay=None):
        if state is None:
            state = self.state
        if cmd is None:
            cmd = self.core_cmd
        if sr is None:
            sr = self.sr
        if pending is None:
            pending = self.pending
        if delay is None:
            delay = self.pending_delay

        ena = int(i['ena']) & 1
        rxd = int(i['sda_i']) & 1
        if state == 'ST_ACK' and cmd == 'WRITE':
            txd = int(i['ack_in']) & 1
        else:
            txd = (sr >> 7) & 1

        ack = int(bool(pending) and delay == 0 and ena)
        arbitration_lost = int(
            bool(ena)
            and bool(pending)
            and delay == 0
            and state in ('ST_WRITE', 'ST_ACK')
            and cmd == 'WRITE'
            and txd == 1
            and (int(i['scl_i']) & 1) == 1
            and (int(i['sda_i']) & 1) == 0
        )
        return ack, rxd, txd, arbitration_lost

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        async_reset = (int(i['nReset']) & 1) == 0

        if async_reset:
            state = 'ST_IDLE'
            sr = 0
            dcnt = 0
            cmd = 'NOP'
            cmd_ack = 0
            ack_out = 0
            ld = 0
            shift = 0
            pending = 0
            delay = 0
            busy = 0
            ack, rxd, txd, arbitration_lost = 0, 0, 0, 0
        else:
            state = self.state
            sr = self.sr
            dcnt = self.dcnt
            cmd = self.core_cmd
            cmd_ack = self.cmd_ack
            ack_out = self.ack_out
            ld = self.ld
            shift = self.shift
            pending = self.pending
            delay = self.pending_delay
            busy = self.busy
            ack, rxd, txd, arbitration_lost = self._bit_signals(
                i, state, cmd, sr, pending, delay
            )

        go = bool(((int(i['read']) | int(i['write']) | int(i['stop'])) & 1) and not cmd_ack)
        self.st_idle = (state == 'ST_IDLE')
        self.st_start = (state == 'ST_START')
        self.st_read = (state == 'ST_READ')
        self.st_write = (state == 'ST_WRITE')
        self.st_ack = (state == 'ST_ACK')
        self.st_stop = (state == 'ST_STOP')
        self.go = bool(go)
        self.ld = bool(ld)
        self.shift = bool(shift)
        self.dcnt_nonzero = bool(dcnt != 0)
        self.cnt_done = bool(dcnt == 0)
        self.core_ack = bool(ack)
        self.core_rxd = bool(rxd)
        self.core_txd = bool(txd)
        self.core_cmd_start = (cmd == 'START')
        self.core_cmd_read = (cmd == 'READ')
        self.core_cmd_write = (cmd == 'WRITE')
        self.core_cmd_stop = (cmd == 'STOP')
        self.core_cmd_nop = (cmd == 'NOP')

        o['cmd_ack'] = int(cmd_ack)
        o['ack_out'] = int(ack_out)
        o['dout'] = self.mask(sr, 8)
        o['i2c_busy'] = int(busy)
        o['i2c_al'] = int(arbitration_lost)
        # The lower-level controller's exact waveforms are unspecified here.
        # In the idle abstraction, release both open-drain lines; their output
        # values are immaterial while released.
        o['scl_o'] = 0
        o['scl_oen'] = 1
        o['sda_o'] = 0
        o['sda_oen'] = 1
        return o

    def advance(self, i):
        if (int(i['nReset']) & 1) == 0:
            self.reset()
            return
        if int(i['rst']) & 1:
            self.reset()
            return

        old_state = self.state
        old_cnt_done = (self.dcnt == 0)
        ack, rxd, txd, arbitration_lost = self._bit_signals(i)

        if arbitration_lost:
            self.state = 'ST_IDLE'
            self.core_cmd = 'NOP'
            self.cmd_ack = 0
            self.ack_out = 0
            self.ld = 0
            self.shift = 0
            self.pending = 0
            self.pending_delay = 0
            return

        # The datapath consumes the registered controls from the current cycle.
        if self.ld:
            self.sr = self.mask(i['din'], 8)
            self.dcnt = 7
        elif self.shift:
            self.sr = self.mask((self.sr << 1) | rxd, 8)
            self.dcnt = self.mask(self.dcnt - 1, 3)

        next_state = old_state
        next_cmd = self.core_cmd
        next_cmd_ack = 0
        next_ack_out = self.ack_out
        next_ld = 0
        next_shift = 0
        next_pending = self.pending
        next_delay = self.pending_delay
        if next_pending and next_delay > 0 and (int(i['ena']) & 1):
            next_delay -= 1

        if old_state == 'ST_IDLE':
            go = bool(((int(i['read']) | int(i['write']) | int(i['stop'])) & 1) and not self.cmd_ack)
            if go:
                next_ld = 1
                if int(i['start']) & 1:
                    next_state = 'ST_START'
                    next_cmd = 'START'
                    next_pending = 1
                    next_delay = 1
                elif int(i['read']) & 1:
                    next_state = 'ST_READ'
                    next_cmd = 'READ'
                    next_pending = 1
                    next_delay = 1
                elif int(i['write']) & 1:
                    next_state = 'ST_WRITE'
                    next_cmd = 'WRITE'
                    next_pending = 1
                    next_delay = 1
                else:
                    next_state = 'ST_STOP'
                    next_cmd = 'STOP'
                    next_pending = 1
                    next_delay = 1

        elif old_state == 'ST_START':
            if ack:
                self.busy = 1
                if int(i['read']) & 1:
                    next_state = 'ST_READ'
                    next_cmd = 'READ'
                else:
                    next_state = 'ST_WRITE'
                    next_cmd = 'WRITE'
                next_pending = 1
                next_delay = 1

        elif old_state == 'ST_WRITE':
            if ack:
                if old_cnt_done:
                    next_state = 'ST_ACK'
                    next_cmd = 'READ'
                else:
                    next_shift = 1
                    next_cmd = 'WRITE'
                next_pending = 1
                next_delay = 1

        elif old_state == 'ST_READ':
            if ack:
                if old_cnt_done:
                    next_state = 'ST_ACK'
                    next_cmd = 'WRITE'
                else:
                    next_shift = 1
                    next_cmd = 'READ'
                next_pending = 1
                next_delay = 1

        elif old_state == 'ST_ACK':
            if ack:
                next_ack_out = rxd
                if int(i['stop']) & 1:
                    next_state = 'ST_STOP'
                    next_cmd = 'STOP'
                    next_pending = 1
                    next_delay = 1
                else:
                    next_state = 'ST_IDLE'
                    next_cmd = 'NOP'
                    next_cmd_ack = 1
                    next_pending = 0
                    next_delay = 0

        elif old_state == 'ST_STOP':
            if ack:
                self.busy = 0
                next_state = 'ST_IDLE'
                next_cmd = 'NOP'
                next_cmd_ack = 1
                next_pending = 0
                next_delay = 0

        self.state = next_state
        self.core_cmd = next_cmd
        self.cmd_ack = next_cmd_ack
        self.ack_out = next_ack_out
        self.ld = next_ld
        self.shift = next_shift
        self.pending = next_pending
        self.pending_delay = next_delay
