"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'dcnt_nonzero', 'cnt_done', 'core_ack', 'core_rxd', 'core_txd', 'core_cmd_start', 'core_cmd_read', 'core_cmd_write', 'core_cmd_stop', 'core_cmd_nop']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'dcnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_rxd': 1, 'core_txd': 1, 'core_cmd_start': 1, 'core_cmd_read': 1, 'core_cmd_write': 1, 'core_cmd_stop': 1, 'core_cmd_nop': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.sr = 0
        self.dcnt = 0
        self._ld = False
        self._shift = False
        self._core_cmd = 'NOP'
        self._core_ack = False
        self.cmd_ack = 0
        self.ack_out = 0
        self.i2c_busy = 0
        self.i2c_al = 0
        self.lower_ena = 0
        self.lower_clk_cnt = 0


    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        async_reset = (int(i['nReset']) & 1) == 0
        state = 'IDLE' if async_reset else self.state
        sr = 0 if async_reset else self.sr
        dcnt = 0 if async_reset else self.dcnt
        ld = False if async_reset else self._ld
        shift = False if async_reset else self._shift
        core_cmd = 'NOP' if async_reset else self._core_cmd
        core_ack = False if async_reset else self._core_ack
        cmd_ack = 0 if async_reset else self.cmd_ack
        ack_out = 0 if async_reset else self.ack_out
        busy = 0 if async_reset else self.i2c_busy
        al = 0 if async_reset else self.i2c_al

        core_rxd = int(i.get('sda_i', 1)) & 1
        if state == 'ACK' and core_cmd == 'WRITE':
            core_txd = int(i['ack_in']) & 1
        else:
            core_txd = (sr >> 7) & 1

        go = bool((int(i['read']) | int(i['write']) | int(i['stop'])) & (not bool(cmd_ack)))
        self.st_idle = bool(state == 'IDLE')
        self.st_start = bool(state == 'START')
        self.st_read = bool(state == 'READ')
        self.st_write = bool(state == 'WRITE')
        self.st_ack = bool(state == 'ACK')
        self.st_stop = bool(state == 'STOP')
        self.go = bool(go)
        self.ld = bool(ld)
        self.shift = bool(shift)
        self.dcnt_nonzero = bool(dcnt != 0)
        self.cnt_done = bool(dcnt == 0)
        self.core_ack = bool(core_ack)
        self.core_rxd = bool(core_rxd)
        self.core_txd = bool(core_txd)
        self.core_cmd_start = bool(core_cmd == 'START')
        self.core_cmd_read = bool(core_cmd == 'READ')
        self.core_cmd_write = bool(core_cmd == 'WRITE')
        self.core_cmd_stop = bool(core_cmd == 'STOP')
        self.core_cmd_nop = bool(core_cmd == 'NOP')

        o['cmd_ack'] = int(bool(cmd_ack))
        o['ack_out'] = int(bool(ack_out))
        o['dout'] = self.mask(sr, 8)
        o['i2c_busy'] = int(bool(busy))
        o['i2c_al'] = int(bool(al))
        # The lower-level bit controller's detailed pad waveform is unspecified.
        # These are the open-drain drive values with both lines released.
        o['scl_o'] = 0
        o['scl_oen'] = 1
        o['sda_o'] = 0
        o['sda_oen'] = 1
        return o


    def advance(self, i):
        nreset = int(i['nReset']) & 1
        rst = int(i['rst']) & 1
        if not nreset or rst:
            self.reset()
            return

        self.lower_ena = int(i['ena']) & 1
        self.lower_clk_cnt = self.mask(i['clk_cnt'], 16)

        # The datapath and FSM sample the same pre-edge values, as separate
        # clocked blocks would. ld has priority over shift in the datapath.
        old_state = self.state
        old_cmd = self._core_cmd
        old_ack = self._core_ack
        old_dcnt = self.dcnt
        old_cmd_ack = self.cmd_ack
        old_ld = self._ld
        old_shift = self._shift

        if old_ld:
            self.sr = self.mask(i['din'], 8)
            self.dcnt = 7
        elif old_shift:
            self.sr = self.mask((self.sr << 1) | (int(i.get('sda_i', 1)) & 1), 8)
            self.dcnt = self.mask(self.dcnt - 1, 3)

        # Abstract lower-controller completion: an active command completes
        # after a wait edge, and the acknowledgement is a pulse.
        next_core_ack = bool(old_cmd != 'NOP' and not old_ack and self.lower_ena)
        if old_ack and old_cmd == 'START':
            self.i2c_busy = 1
        elif old_ack and old_cmd == 'STOP':
            self.i2c_busy = 0

        next_state = old_state
        next_cmd = old_cmd
        next_ld = False
        next_shift = False
        next_cmd_ack = 0
        next_ack_out = self.ack_out

        # Arbitration loss is supplied by the lower controller. This model has
        # no specified arbitration detector; retain the specified abort action
        # should that internal status ever be asserted.
        if self.i2c_al:
            next_state = 'IDLE'
            next_cmd = 'NOP'
            next_core_ack = False
            next_cmd_ack = 0
            next_ack_out = 0
        elif old_state == 'IDLE':
            go = bool((int(i['read']) | int(i['write']) | int(i['stop'])) & (not bool(old_cmd_ack)))
            if go:
                next_ld = True
                if int(i['start']) & 1:
                    next_state = 'START'
                    next_cmd = 'START'
                elif int(i['read']) & 1:
                    next_state = 'READ'
                    next_cmd = 'READ'
                elif int(i['write']) & 1:
                    next_state = 'WRITE'
                    next_cmd = 'WRITE'
                else:
                    next_state = 'STOP'
                    next_cmd = 'STOP'
        elif old_state == 'START':
            if old_ack:
                if int(i['read']) & 1:
                    next_state = 'READ'
                    next_cmd = 'READ'
                else:
                    next_state = 'WRITE'
                    next_cmd = 'WRITE'
        elif old_state == 'WRITE':
            if old_ack:
                if old_dcnt == 0:
                    next_state = 'ACK'
                    next_cmd = 'READ'
                else:
                    next_shift = True
                    next_cmd = 'WRITE'
        elif old_state == 'READ':
            if old_ack:
                # Shift every completed data READ, including the eighth bit.
                next_shift = True
                if old_dcnt == 0:
                    next_state = 'ACK'
                    next_cmd = 'WRITE'
                else:
                    next_cmd = 'READ'
        elif old_state == 'ACK':
            if old_ack:
                next_ack_out = int(i.get('sda_i', 1)) & 1
                if int(i['stop']) & 1:
                    next_state = 'STOP'
                    next_cmd = 'STOP'
                else:
                    next_state = 'IDLE'
                    next_cmd = 'NOP'
                    next_cmd_ack = 1
        elif old_state == 'STOP':
            if old_ack:
                next_state = 'IDLE'
                next_cmd = 'NOP'
                next_cmd_ack = 1

        self.state = next_state
        self._core_cmd = next_cmd
        self._core_ack = bool(next_core_ack)
        self._ld = bool(next_ld)
        self._shift = bool(next_shift)
        self.cmd_ack = int(bool(next_cmd_ack))
        self.ack_out = int(bool(next_ack_out))
