"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'dcnt_nonzero', 'cnt_done', 'core_ack', 'core_rxd', 'core_txd', 'core_cmd_start', 'core_cmd_read', 'core_cmd_write', 'core_cmd_stop', 'core_cmd_nop']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'dcnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_rxd': 1, 'core_txd': 1, 'core_cmd_start': 1, 'core_cmd_read': 1, 'core_cmd_write': 1, 'core_cmd_stop': 1, 'core_cmd_nop': 1}
    LATENCY_CYCLES = 0

    def _clear_state(self):
        self.state = 'IDLE'
        self.sr = 0
        self.dcnt = 0
        self.ack_out = 0
        self.ack_from_slave = False
        self.bus_busy = 0

    def reset(self):
        self._clear_state()

    def _decode(self, i):
        async_reset = int(i.get('nReset', 1)) == 0
        if async_reset:
            state = 'IDLE'
            sr = 0
            dcnt = 0
            ack_out = 0
            ack_from_slave = False
            bus_busy = 0
        else:
            state = self.state
            sr = self.sr
            dcnt = self.dcnt
            ack_out = self.ack_out
            ack_from_slave = self.ack_from_slave
            bus_busy = self.bus_busy

        bit_al = 0
        core_ack = int(state != 'IDLE')
        core_rxd = (int(i.get('sda_i', 0)) & 1) if core_ack else 0
        read = int(i.get('read', 0)) & 1
        write = int(i.get('write', 0)) & 1
        stop = int(i.get('stop', 0)) & 1
        start = int(i.get('start', 0)) & 1
        ack_in = int(i.get('ack_in', 0)) & 1

        command = 'NOP'
        next_state = state
        ld = 0
        shift = 0
        cmd_ack = 0
        core_txd = (sr >> 7) & 1

        if not async_reset:
            if state == 'IDLE':
                launch = int(bool(read or write or stop))
                if launch:
                    ld = 1
                    if start:
                        next_state = 'START'
                        command = 'START'
                    elif read:
                        next_state = 'READ'
                        command = 'READ'
                    elif write:
                        next_state = 'WRITE'
                        command = 'WRITE'
                    else:
                        next_state = 'STOP'
                        command = 'STOP'
            elif state == 'START':
                if core_ack:
                    if read:
                        next_state = 'READ'
                        command = 'READ'
                    else:
                        next_state = 'WRITE'
                        command = 'WRITE'
            elif state == 'WRITE':
                if core_ack:
                    if dcnt == 0:
                        next_state = 'ACK'
                        command = 'READ'
                    else:
                        shift = 1
                        command = 'WRITE'
            elif state == 'READ':
                if core_ack:
                    shift = 1
                    if dcnt == 0:
                        next_state = 'ACK'
                        command = 'WRITE'
                        core_txd = ack_in
                    else:
                        command = 'READ'
            elif state == 'ACK':
                if not ack_from_slave:
                    core_txd = ack_in
                if core_ack:
                    if stop:
                        next_state = 'STOP'
                        command = 'STOP'
                    else:
                        next_state = 'IDLE'
                        cmd_ack = 1
            elif state == 'STOP':
                if core_ack:
                    next_state = 'IDLE'
                    cmd_ack = 1

        go = int(bool((read or write or stop) and not cmd_ack))
        return {
            'state': state,
            'sr': sr,
            'dcnt': dcnt,
            'ack_out': ack_out,
            'ack_from_slave': ack_from_slave,
            'bus_busy': bus_busy,
            'bit_al': bit_al,
            'core_ack': core_ack,
            'core_rxd': core_rxd,
            'core_txd': core_txd,
            'command': command,
            'next_state': next_state,
            'ld': ld,
            'shift': shift,
            'cmd_ack': cmd_ack,
            'go': go,
            'async_reset': async_reset
        }

    def outputs(self, i):
        d = self._decode(i)
        o = {p: None for p in self.OUTPUT_PORTS}
        o['cmd_ack'] = int(d['cmd_ack'])
        o['ack_out'] = int(d['ack_out'])
        o['dout'] = self.mask(d['sr'], 8)
        o['i2c_busy'] = int(d['bus_busy'])
        o['i2c_al'] = int(d['bit_al'])
        o['scl_o'] = 0
        o['scl_oen'] = 1
        o['sda_o'] = 0
        o['sda_oen'] = 1

        self.st_idle = bool(d['state'] == 'IDLE')
        self.st_start = bool(d['state'] == 'START')
        self.st_read = bool(d['state'] == 'READ')
        self.st_write = bool(d['state'] == 'WRITE')
        self.st_ack = bool(d['state'] == 'ACK')
        self.st_stop = bool(d['state'] == 'STOP')
        self.go = bool(d['go'])
        self.ld = bool(d['ld'])
        self.shift = bool(d['shift'])
        self.dcnt_nonzero = bool(d['dcnt'] != 0)
        self.cnt_done = bool(d['dcnt'] == 0)
        self.core_ack = bool(d['core_ack'])
        self.core_rxd = bool(d['core_rxd'])
        self.core_txd = bool(d['core_txd'])
        self.core_cmd_start = bool(d['command'] == 'START')
        self.core_cmd_read = bool(d['command'] == 'READ')
        self.core_cmd_write = bool(d['command'] == 'WRITE')
        self.core_cmd_stop = bool(d['command'] == 'STOP')
        self.core_cmd_nop = bool(d['command'] == 'NOP')
        return o

    def advance(self, i):
        d = self._decode(i)
        if d['async_reset']:
            self._clear_state()
            return
        if int(i.get('rst', 0)) or d['bit_al']:
            self._clear_state()
            return

        state = d['state']
        if d['ld']:
            self.sr = self.mask(i.get('din', 0), 8)
            self.dcnt = 7
        elif d['shift']:
            self.sr = self.mask((self.sr << 1) | d['core_rxd'], 8)
            self.dcnt = self.mask(self.dcnt - 1, 3)

        if state == 'ACK' and d['core_ack'] and d['ack_from_slave']:
            self.ack_out = d['core_rxd']

        if state == 'START' and d['core_ack']:
            self.bus_busy = 1
        elif state == 'STOP' and d['core_ack']:
            self.bus_busy = 0

        if state == 'IDLE' and d['next_state'] != 'IDLE':
            self.ack_from_slave = False
        elif state == 'WRITE' and d['next_state'] == 'ACK':
            self.ack_from_slave = True
        elif state == 'READ' and d['next_state'] == 'ACK':
            self.ack_from_slave = False

        self.state = d['next_state']
