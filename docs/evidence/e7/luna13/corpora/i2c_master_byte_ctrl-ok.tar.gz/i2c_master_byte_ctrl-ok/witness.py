"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'dcnt_nonzero', 'cnt_done', 'core_ack', 'core_rxd', 'core_txd', 'core_cmd_start', 'core_cmd_read', 'core_cmd_write', 'core_cmd_stop', 'core_cmd_nop']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'dcnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_rxd': 1, 'core_txd': 1, 'core_cmd_start': 1, 'core_cmd_read': 1, 'core_cmd_write': 1, 'core_cmd_stop': 1, 'core_cmd_nop': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = "ST_IDLE"
        self.sr = 0
        self.dcnt = 0
        self.cmd = "NOP"
        self.cmd_ack = 0
        self.ack_out = 0
        self.busy = 0
        self.i2c_al = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        # nReset is asynchronous: present reset values immediately while it is low.
        async_reset = not (i["nReset"] & 1)
        state = "ST_IDLE" if async_reset else self.state
        sr = 0 if async_reset else self.sr
        dcnt = 0 if async_reset else self.dcnt
        cmd = "NOP" if async_reset else self.cmd
        cmd_ack = 0 if async_reset else self.cmd_ack
        ack_out = 0 if async_reset else self.ack_out
        busy = 0 if async_reset else self.busy
        al = 0 if async_reset else self.i2c_al

        go = bool(((i["read"] | i["write"] | i["stop"]) & 1) and not cmd_ack)
        core_ack = bool(not async_reset and cmd != "NOP")
        core_rxd = bool(i["sda_i"] & 1)
        cnt_done = dcnt == 0
        ld = bool(not async_reset and not al and state == "ST_IDLE" and go)
        shift = bool(
            not async_reset and not al and core_ack and
            ((state == "ST_READ") or (state == "ST_WRITE" and not cnt_done))
        )
        core_txd = (i["ack_in"] & 1) if state == "ST_ACK" and (i["read"] & 1) else ((sr >> 7) & 1)

        # Probes describe this same pre-edge view; they are not returned as ports.
        self.st_idle = bool(state == "ST_IDLE")
        self.st_start = bool(state == "ST_START")
        self.st_read = bool(state == "ST_READ")
        self.st_write = bool(state == "ST_WRITE")
        self.st_ack = bool(state == "ST_ACK")
        self.st_stop = bool(state == "ST_STOP")
        self.go = bool(go)
        self.ld = bool(ld)
        self.shift = bool(shift)
        self.dcnt_nonzero = bool(dcnt != 0)
        self.cnt_done = bool(cnt_done)
        self.core_ack = bool(core_ack)
        self.core_rxd = bool(core_rxd)
        self.core_txd = bool(core_txd)
        self.core_cmd_start = bool(cmd == "START")
        self.core_cmd_read = bool(cmd == "READ")
        self.core_cmd_write = bool(cmd == "WRITE")
        self.core_cmd_stop = bool(cmd == "STOP")
        self.core_cmd_nop = bool(cmd == "NOP")

        o["cmd_ack"] = int(cmd_ack)
        o["ack_out"] = int(ack_out)
        o["dout"] = self.mask(sr, 8)
        o["i2c_busy"] = int(busy)
        o["i2c_al"] = int(al)
        # The byte-controller specification does not define bit-controller waveforms.
        # These idle open-drain values leave both lines released.
        o["scl_o"] = 0
        o["scl_oen"] = 1
        o["sda_o"] = 0
        o["sda_oen"] = 1
        return o

    def advance(self, i):
        # Each call represents one rising edge. Asynchronous reset is applied as soon
        # as it is observed by the model; synchronous rst takes effect on this edge.
        if not (i["nReset"] & 1):
            self.reset()
            return
        if i["rst"] & 1:
            self.reset()
            return
        if self.i2c_al:
            self.state = "ST_IDLE"
            self.cmd = "NOP"
            self.cmd_ack = 0
            self.ack_out = 0
            return

        old_state = self.state
        old_dcnt = self.dcnt
        go = bool(((i["read"] | i["write"] | i["stop"]) & 1) and not self.cmd_ack)
        core_ack = self.cmd != "NOP"
        core_rxd = i["sda_i"] & 1
        cnt_done = old_dcnt == 0
        ld = old_state == "ST_IDLE" and go
        shift = core_ack and (
            old_state == "ST_READ" or
            (old_state == "ST_WRITE" and not cnt_done)
        )

        # Datapath controls are evaluated from the pre-edge state.
        if ld:
            self.sr = self.mask(i["din"], 8)
            self.dcnt = 7
        elif shift:
            self.sr = self.mask((self.sr << 1) | core_rxd, 8)
            self.dcnt = (self.dcnt - 1) & 0x7

        self.cmd_ack = 0
        if old_state == "ST_IDLE":
            if go:
                if i["start"] & 1:
                    self.state = "ST_START"
                    self.cmd = "START"
                elif i["read"] & 1:
                    self.state = "ST_READ"
                    self.cmd = "READ"
                elif i["write"] & 1:
                    self.state = "ST_WRITE"
                    self.cmd = "WRITE"
                else:
                    self.state = "ST_STOP"
                    self.cmd = "STOP"
        elif old_state == "ST_START":
            if core_ack:
                self.busy = 1
                if i["read"] & 1:
                    self.state = "ST_READ"
                    self.cmd = "READ"
                else:
                    self.state = "ST_WRITE"
                    self.cmd = "WRITE"
        elif old_state == "ST_WRITE":
            if core_ack:
                if cnt_done:
                    self.state = "ST_ACK"
                    self.cmd = "READ"
                else:
                    self.state = "ST_WRITE"
                    self.cmd = "WRITE"
        elif old_state == "ST_READ":
            if core_ack:
                if cnt_done:
                    self.state = "ST_ACK"
                    self.cmd = "WRITE"
                else:
                    self.state = "ST_READ"
                    self.cmd = "READ"
        elif old_state == "ST_ACK":
            if core_ack:
                self.ack_out = core_rxd
                if i["stop"] & 1:
                    self.state = "ST_STOP"
                    self.cmd = "STOP"
                else:
                    self.state = "ST_IDLE"
                    self.cmd = "NOP"
                    self.cmd_ack = 1
        elif old_state == "ST_STOP":
            if core_ack:
                self.state = "ST_IDLE"
                self.cmd = "NOP"
                self.cmd_ack = 1
                self.busy = 0
        else:
            self.state = "ST_IDLE"
            self.cmd = "NOP"
