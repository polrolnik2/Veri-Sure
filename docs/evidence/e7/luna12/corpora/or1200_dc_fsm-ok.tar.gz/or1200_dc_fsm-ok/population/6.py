"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.saved_addr_r = 0
        self.cnt = 0
        self.hitmiss_eval_flag = 0
        self.store_flag = 0
        self.load_flag = 0
        self.cache_inhibit_flag = 0
        self.idle = True
        self.cload = False
        self.cstore = False
        self.lrefill3 = False
        self.srefill4 = False
        self.hitmiss_eval = False
        self.store = False
        self.load = False
        self.cache_inhibit = False
        self.cnt_nonzero = False
        self.first_store_hit_ack = False

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        reset_view = bool(i['rst'])
        if reset_view:
            state = 'IDLE'
            saved_addr = 0
            hitmiss_eval = False
            store = False
            load = False
            cache_inhibit = False
            cnt = 0
        else:
            state = self.state
            saved_addr = self.saved_addr_r
            hitmiss_eval = bool(self.hitmiss_eval_flag)
            store = bool(self.store_flag)
            load = bool(self.load_flag)
            cache_inhibit = bool(self.cache_inhibit_flag)
            cnt = self.cnt

        ci_observed = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
        ci_active = bool(cache_inhibit or (not reset_view and state in ('CLOAD', 'CSTORE') and ci_observed))
        tag_miss = bool(i['tagcomp_miss'])
        data_valid = bool(i['biudata_valid'])

        first_store_hit_ack = bool(
            state == 'CSTORE' and data_valid and not tag_miss and not ci_active
        )
        biu_read = bool(
            (state == 'CLOAD' and hitmiss_eval and tag_miss)
            or (not hitmiss_eval and load)
        )
        biu_write = bool(store)
        first_hit_ack = bool(
            (state == 'CLOAD' and hitmiss_eval and not tag_miss and not ci_active)
            or first_store_hit_ack
        )
        first_miss_ack = bool(state in ('CLOAD', 'CSTORE') and data_valid)
        first_miss_err = bool(state in ('CLOAD', 'CSTORE') and i['biudata_error'])
        burst = bool(
            (state == 'CLOAD' and tag_miss and not ci_active)
            or state == 'LREFILL3'
            or state == 'SREFILL4'
        )
        dcram_we = 0
        if load and data_valid and not ci_active:
            dcram_we |= 0xF
        if first_store_hit_ack:
            dcram_we |= self.mask(i['dcqmem_sel_i'], 4)
        tag_we = bool(biu_read and data_valid and not ci_active)

        start_addr = self.mask(i['start_addr'], 32)
        if not hitmiss_eval and (biu_read or biu_write):
            dc_addr = saved_addr
        else:
            dc_addr = start_addr

        o['saved_addr'] = self.mask(saved_addr, 32)
        o['dcram_we'] = self.mask(dcram_we, 4)
        o['biu_read'] = int(biu_read)
        o['biu_write'] = int(biu_write)
        o['first_hit_ack'] = int(first_hit_ack)
        o['first_miss_ack'] = int(first_miss_ack)
        o['first_miss_err'] = int(first_miss_err)
        o['burst'] = int(burst)
        o['tag_we'] = int(tag_we)
        o['dc_addr'] = self.mask(dc_addr, 32)

        self.idle = bool(state == 'IDLE')
        self.cload = bool(state == 'CLOAD')
        self.cstore = bool(state == 'CSTORE')
        self.lrefill3 = bool(state == 'LREFILL3')
        self.srefill4 = bool(state == 'SREFILL4')
        self.hitmiss_eval = bool(hitmiss_eval)
        self.store = bool(store)
        self.load = bool(load)
        self.cache_inhibit = bool(cache_inhibit)
        self.cnt_nonzero = bool(cnt != 0)
        self.first_store_hit_ack = bool(first_store_hit_ack)
        return o

    def _increment_word_offset(self):
        offset = ((self.saved_addr_r >> 2) + 1) & 3
        self.saved_addr_r = self.mask(
            (self.saved_addr_r & 0xFFFFFFF3) | (offset << 2), 32
        )

    def advance(self, i):
        if i['rst']:
            self.reset()
            return

        data_valid = bool(i['biudata_valid'])
        data_error = bool(i['biudata_error'])
        cycstb = bool(i['dcqmem_cycstb_i'])
        ci_seen = bool(cycstb and i['dcqmem_ci_i'])
        tag_miss = bool(i['tagcomp_miss'])

        if self.state == 'IDLE':
            if i['dc_en'] and cycstb:
                self.saved_addr_r = self.mask(i['start_addr'], 32)
                self.hitmiss_eval_flag = 1
                self.cache_inhibit_flag = 0
                if i['dcqmem_we_i']:
                    self.state = 'CSTORE'
                    self.store_flag = 1
                    self.load_flag = 0
                else:
                    self.state = 'CLOAD'
                    self.store_flag = 0
                    self.load_flag = 1
            return

        if self.state == 'CLOAD':
            if ci_seen:
                self.cache_inhibit_flag = 1
            ci_active = bool(self.cache_inhibit_flag or ci_seen)

            if data_error:
                self.state = 'IDLE'
                self.hitmiss_eval_flag = 0
                self.store_flag = 0
                self.load_flag = 0
                return
            if self.hitmiss_eval_flag and not cycstb:
                self.state = 'IDLE'
                self.hitmiss_eval_flag = 0
                self.store_flag = 0
                self.load_flag = 0
                return
            if ci_active:
                self.hitmiss_eval_flag = 0
                if data_valid:
                    self.state = 'IDLE'
                    self.store_flag = 0
                    self.load_flag = 0
                return

            if self.hitmiss_eval_flag:
                self.hitmiss_eval_flag = 0
                if not tag_miss:
                    self.state = 'IDLE'
                    self.store_flag = 0
                    self.load_flag = 0
                    return
            if tag_miss and data_valid:
                self.state = 'LREFILL3'
                self._increment_word_offset()
                self.cnt = 2
            return

        if self.state == 'CSTORE':
            if ci_seen:
                self.cache_inhibit_flag = 1
            ci_active = bool(self.cache_inhibit_flag or ci_seen)

            if data_error:
                self.state = 'IDLE'
                self.hitmiss_eval_flag = 0
                self.store_flag = 0
                self.load_flag = 0
                return
            if self.hitmiss_eval_flag and not cycstb:
                self.state = 'IDLE'
                self.hitmiss_eval_flag = 0
                self.store_flag = 0
                self.load_flag = 0
                return

            self.hitmiss_eval_flag = 0
            if data_valid:
                if ci_active:
                    self.state = 'IDLE'
                    self.store_flag = 0
                    self.load_flag = 0
                elif tag_miss:
                    self.store_flag = 0
                    self.load_flag = 1
                    self.cnt = 3
                    self.state = 'SREFILL4'
                else:
                    self.state = 'IDLE'
                    self.store_flag = 0
                    self.load_flag = 0
            return

        if self.state == 'LREFILL3':
            if data_valid:
                if self.cnt != 0:
                    self.cnt -= 1
                    self._increment_word_offset()
                else:
                    self.state = 'IDLE'
                    self.load_flag = 0
                    self.store_flag = 0
            return

        if self.state == 'SREFILL4':
            if data_valid:
                if self.cnt != 0:
                    self.cnt -= 1
                    self._increment_word_offset()
                else:
                    self.state = 'IDLE'
                    self.load_flag = 0
                    self.store_flag = 0
            return
