"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.saved_addr_r = 0
        self.cnt = 0
        self.hitmiss_eval_r = 0
        self.store_r = 0
        self.load_r = 0
        self.cache_inhibit_r = 0
        self.store_refill_enabled = True
        self.idle = True
        self.cload = False
        self.cstore = False
        self.lrefill3 = False
        self.srefill4 = False
        self.hitmiss_eval = False
        self.store = False
        self.load = False
        self.cache_inhibit = False
        self.cnt_nonzero = False
        self.first_store_hit_ack = False

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        if i['rst']:
            state = 'IDLE'
            saved_addr = 0
            cnt = 0
            hitmiss_eval = 0
            store = 0
            load = 0
            cache_inhibit_r = 0
        else:
            state = self.state
            saved_addr = self.saved_addr_r
            cnt = self.cnt
            hitmiss_eval = self.hitmiss_eval_r
            store = self.store_r
            load = self.load_r
            cache_inhibit_r = self.cache_inhibit_r

        ci_seen = bool(state in ('CLOAD', 'CSTORE') and i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
        cache_inhibit = bool(cache_inhibit_r or ci_seen)
        biu_read = bool((state == 'CLOAD' and hitmiss_eval and i['tagcomp_miss']) or (load and not hitmiss_eval))
        biu_write = bool(store)
        first_store_hit_ack = bool(state == 'CSTORE' and i['biudata_valid'] and not i['tagcomp_miss'] and not cache_inhibit)
        first_hit_ack = bool((state == 'CLOAD' and hitmiss_eval and not i['tagcomp_miss'] and not cache_inhibit) or first_store_hit_ack)
        first_miss_ack = bool(state in ('CLOAD', 'CSTORE') and i['biudata_valid'])
        first_miss_err = bool(state in ('CLOAD', 'CSTORE') and i['biudata_error'])

        dcram_we = 0
        if load and i['biudata_valid'] and not cache_inhibit:
            dcram_we |= 15
        if first_store_hit_ack:
            dcram_we |= i['dcqmem_sel_i']

        burst = bool((state == 'CLOAD' and i['tagcomp_miss'] and not cache_inhibit) or state == 'LREFILL3' or state == 'SREFILL4')
        tag_we = bool(biu_read and i['biudata_valid'] and not cache_inhibit)
        if hitmiss_eval or not (biu_read or biu_write):
            dc_addr = i['start_addr']
        else:
            dc_addr = saved_addr

        self.idle = state == 'IDLE'
        self.cload = state == 'CLOAD'
        self.cstore = state == 'CSTORE'
        self.lrefill3 = state == 'LREFILL3'
        self.srefill4 = state == 'SREFILL4'
        self.hitmiss_eval = bool(hitmiss_eval)
        self.store = bool(store)
        self.load = bool(load)
        self.cache_inhibit = cache_inhibit
        self.cnt_nonzero = bool(cnt != 0)
        self.first_store_hit_ack = first_store_hit_ack

        o['saved_addr'] = self.mask(saved_addr, 32)
        o['dcram_we'] = self.mask(dcram_we, 4)
        o['biu_read'] = int(biu_read)
        o['biu_write'] = int(biu_write)
        o['first_hit_ack'] = int(first_hit_ack)
        o['first_miss_ack'] = int(first_miss_ack)
        o['first_miss_err'] = int(first_miss_err)
        o['burst'] = int(burst)
        o['tag_we'] = int(tag_we)
        o['dc_addr'] = self.mask(dc_addr, 32)
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return

        if self.state == 'IDLE':
            if i['dc_en'] and i['dcqmem_cycstb_i']:
                self.saved_addr_r = self.mask(i['start_addr'], 32)
                self.hitmiss_eval_r = 1
                self.cache_inhibit_r = 0
                if i['dcqmem_we_i']:
                    self.state = 'CSTORE'
                    self.store_r = 1
                    self.load_r = 0
                else:
                    self.state = 'CLOAD'
                    self.store_r = 0
                    self.load_r = 1
            return

        if self.state == 'CLOAD':
            ci_seen = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            cache_inhibit = bool(self.cache_inhibit_r or ci_seen)
            if ci_seen:
                self.cache_inhibit_r = 1

            if i['biudata_error']:
                self.state = 'IDLE'
                self.hitmiss_eval_r = 0
                self.load_r = 0
                self.store_r = 0
            elif self.hitmiss_eval_r and not i['dcqmem_cycstb_i']:
                self.state = 'IDLE'
                self.hitmiss_eval_r = 0
                self.load_r = 0
                self.store_r = 0
            elif self.hitmiss_eval_r and not cache_inhibit and not i['tagcomp_miss']:
                self.state = 'IDLE'
                self.hitmiss_eval_r = 0
                self.load_r = 0
                self.store_r = 0
            elif cache_inhibit and i['biudata_valid']:
                self.state = 'IDLE'
                self.hitmiss_eval_r = 0
                self.load_r = 0
                self.store_r = 0
            elif not cache_inhibit and i['biudata_valid']:
                self.state = 'LREFILL3'
                self.hitmiss_eval_r = 0
                self.cnt = 2
                self.saved_addr_r = self.mask((self.saved_addr_r & 0xFFFFFFF3) | (((((self.saved_addr_r >> 2) + 1) & 3) << 2)), 32)
            else:
                self.hitmiss_eval_r = 0
            return

        if self.state == 'LREFILL3':
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    self.saved_addr_r = self.mask((self.saved_addr_r & 0xFFFFFFF3) | (((((self.saved_addr_r >> 2) + 1) & 3) << 2)), 32)
                else:
                    self.state = 'IDLE'
                    self.load_r = 0
                    self.store_r = 0
                    self.hitmiss_eval_r = 0
            return

        if self.state == 'CSTORE':
            ci_seen = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            cache_inhibit = bool(self.cache_inhibit_r or ci_seen)
            if ci_seen:
                self.cache_inhibit_r = 1

            if i['biudata_error']:
                self.state = 'IDLE'
                self.hitmiss_eval_r = 0
                self.store_r = 0
                self.load_r = 0
            elif self.hitmiss_eval_r and not i['dcqmem_cycstb_i']:
                self.state = 'IDLE'
                self.hitmiss_eval_r = 0
                self.store_r = 0
                self.load_r = 0
            elif i['biudata_valid'] and cache_inhibit:
                self.state = 'IDLE'
                self.hitmiss_eval_r = 0
                self.store_r = 0
                self.load_r = 0
            elif i['biudata_valid'] and not i['tagcomp_miss']:
                self.state = 'IDLE'
                self.hitmiss_eval_r = 0
                self.store_r = 0
                self.load_r = 0
            elif i['biudata_valid'] and i['tagcomp_miss'] and self.store_refill_enabled:
                self.state = 'SREFILL4'
                self.hitmiss_eval_r = 0
                self.store_r = 0
                self.load_r = 1
                self.cnt = 3
            elif i['biudata_valid']:
                self.state = 'IDLE'
                self.hitmiss_eval_r = 0
                self.store_r = 0
                self.load_r = 0
            else:
                self.hitmiss_eval_r = 0
            return

        if self.state == 'SREFILL4':
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    self.saved_addr_r = self.mask((self.saved_addr_r & 0xFFFFFFF3) | (((((self.saved_addr_r >> 2) + 1) & 3) << 2)), 32)
                else:
                    self.state = 'IDLE'
                    self.load_r = 0
                    self.store_r = 0
                    self.hitmiss_eval_r = 0
            return
