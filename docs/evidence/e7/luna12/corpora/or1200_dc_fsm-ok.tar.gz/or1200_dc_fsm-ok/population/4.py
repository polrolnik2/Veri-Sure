"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.saved_addr_r = 0
        self.cnt = 0
        self.hitmiss_eval = False
        self.store = False
        self.load = False
        self.cache_inhibit = False
        self.first_store_hit_ack = False
        self.cnt_nonzero = False
        self.idle = True
        self.cload = False
        self.cstore = False
        self.lrefill3 = False
        self.srefill4 = False

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        state = self.state
        ci_active = bool(self.cache_inhibit or
                         (i['dcqmem_cycstb_i'] and i['dcqmem_ci_i']))

        self.idle = state == 'IDLE'
        self.cload = state == 'CLOAD'
        self.cstore = state == 'CSTORE'
        self.lrefill3 = state == 'LREFILL3'
        self.srefill4 = state == 'SREFILL4'
        self.hitmiss_eval = bool(self.hitmiss_eval)
        self.store = bool(self.store)
        self.load = bool(self.load)
        self.cache_inhibit = bool(self.cache_inhibit)
        self.cnt_nonzero = bool(self.cnt != 0)

        self.first_store_hit_ack = bool(
            state == 'CSTORE' and self.store and i['biudata_valid'] and
            not i['tagcomp_miss'] and not ci_active
        )

        biu_read = False
        if state == 'CLOAD' and self.load:
            if not self.hitmiss_eval:
                biu_read = True
            elif i['tagcomp_miss'] or ci_active:
                biu_read = True
        elif state in ('LREFILL3', 'SREFILL4') and self.load:
            biu_read = True

        biu_write = bool(self.store)
        load_hit_ack = bool(
            state == 'CLOAD' and self.load and not i['tagcomp_miss'] and
            not ci_active
        )

        if self.load and i['biudata_valid'] and not ci_active:
            dcram_we = 0xF
        elif self.first_store_hit_ack:
            dcram_we = self.mask(i['dcqmem_sel_i'], 4)
        else:
            dcram_we = 0

        if (state == 'CLOAD' and self.load and i['tagcomp_miss'] and
                not ci_active):
            burst = True
        elif state == 'LREFILL3':
            burst = True
        elif state == 'SREFILL4':
            burst = True
        else:
            burst = False

        post_eval_transfer = bool(
            not self.hitmiss_eval and (biu_read or biu_write)
        )
        dc_addr = (self.saved_addr_r if post_eval_transfer
                   else self.mask(i['start_addr'], 32))

        o['saved_addr'] = self.mask(self.saved_addr_r, 32)
        o['dcram_we'] = dcram_we
        o['biu_read'] = int(biu_read)
        o['biu_write'] = int(biu_write)
        o['first_hit_ack'] = int(load_hit_ack or self.first_store_hit_ack)
        o['first_miss_ack'] = int(
            state in ('CLOAD', 'CSTORE') and i['biudata_valid']
        )
        o['first_miss_err'] = int(
            state in ('CLOAD', 'CSTORE') and i['biudata_error']
        )
        o['burst'] = int(burst)
        o['tag_we'] = int(biu_read and i['biudata_valid'] and not ci_active)
        o['dc_addr'] = self.mask(dc_addr, 32)
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return

        if self.state == 'IDLE':
            if i['dc_en'] and i['dcqmem_cycstb_i']:
                self.saved_addr_r = self.mask(i['start_addr'], 32)
                self.hitmiss_eval = True
                self.cache_inhibit = False
                if i['dcqmem_we_i']:
                    self.state = 'CSTORE'
                    self.store = True
                    self.load = False
                else:
                    self.state = 'CLOAD'
                    self.store = False
                    self.load = True
            return

        if self.state == 'CLOAD':
            ci_seen = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            if ci_seen:
                self.cache_inhibit = True
            ci_active = bool(self.cache_inhibit or ci_seen)

            if self.hitmiss_eval and not i['dcqmem_cycstb_i']:
                self.state = 'IDLE'
                self.hitmiss_eval = False
                self.load = False
            elif i['biudata_error']:
                self.state = 'IDLE'
                self.hitmiss_eval = False
                self.load = False
            elif (self.hitmiss_eval and not ci_active and
                  not i['tagcomp_miss']):
                self.state = 'IDLE'
                self.hitmiss_eval = False
                self.load = False
            elif ci_active and i['biudata_valid']:
                self.state = 'IDLE'
                self.hitmiss_eval = False
                self.load = False
            elif i['biudata_valid']:
                self.state = 'LREFILL3'
                self.hitmiss_eval = False
                self.cnt = 2
                word_index = ((self.saved_addr_r >> 2) + 1) & 0x3
                self.saved_addr_r = self.mask(
                    (self.saved_addr_r & 0xFFFFFFF3) | (word_index << 2), 32
                )
            elif self.hitmiss_eval:
                self.hitmiss_eval = False
            return

        if self.state == 'CSTORE':
            ci_seen = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            if ci_seen:
                self.cache_inhibit = True
            ci_active = bool(self.cache_inhibit or ci_seen)

            if self.hitmiss_eval and not i['dcqmem_cycstb_i']:
                self.state = 'IDLE'
                self.hitmiss_eval = False
                self.store = False
            elif i['biudata_error']:
                self.state = 'IDLE'
                self.hitmiss_eval = False
                self.store = False
            elif ci_active and i['biudata_valid']:
                self.state = 'IDLE'
                self.hitmiss_eval = False
                self.store = False
            elif i['biudata_valid']:
                self.hitmiss_eval = False
                if i['tagcomp_miss']:
                    self.state = 'SREFILL4'
                    self.store = False
                    self.load = True
                    self.cnt = 3
                else:
                    self.state = 'IDLE'
                    self.store = False
                    self.load = False
            elif self.hitmiss_eval:
                self.hitmiss_eval = False
            return

        if self.state == 'LREFILL3':
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    word_index = ((self.saved_addr_r >> 2) + 1) & 0x3
                    self.saved_addr_r = self.mask(
                        (self.saved_addr_r & 0xFFFFFFF3) | (word_index << 2), 32
                    )
                else:
                    self.state = 'IDLE'
                    self.load = False
            return

        if self.state == 'SREFILL4':
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    word_index = ((self.saved_addr_r >> 2) + 1) & 0x3
                    self.saved_addr_r = self.mask(
                        (self.saved_addr_r & 0xFFFFFFF3) | (word_index << 2), 32
                    )
                else:
                    self.state = 'IDLE'
                    self.load = False
            return
