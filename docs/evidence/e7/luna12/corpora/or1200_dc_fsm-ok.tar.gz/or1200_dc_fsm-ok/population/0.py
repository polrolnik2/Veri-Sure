"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.saved_addr_r = 0
        self.cnt = 0
        self.hitmiss_eval = False
        self.store = False
        self.load = False
        self.cache_inhibit = False
        self.store_refill_enabled = True
        self.first_store_hit_ack = False
        self.cnt_nonzero = False
        self.idle = True
        self.cload = False
        self.cstore = False
        self.lrefill3 = False
        self.srefill4 = False

    def _finish_idle(self):
        self.state = 'IDLE'
        self.hitmiss_eval = False
        self.store = False
        self.load = False
        self.cnt = 0

    def _increment_word_offset(self):
        offset = ((self.saved_addr_r >> 2) + 1) & 3
        self.saved_addr_r = self.mask((self.saved_addr_r & ~0xC) | (offset << 2), 32)

    def _begin_load_refill(self):
        self.state = 'LREFILL3'
        self.hitmiss_eval = False
        self.cnt = 2
        self._increment_word_offset()

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        state = self.state
        hitmiss_eval = bool(self.hitmiss_eval)
        store = bool(self.store)
        load = bool(self.load)
        cache_inhibit = bool(self.cache_inhibit)
        cnt_nonzero = bool(self.cnt != 0)

        self.hitmiss_eval = hitmiss_eval
        self.store = store
        self.load = load
        self.cache_inhibit = cache_inhibit
        self.cnt_nonzero = cnt_nonzero

        self.idle = state == 'IDLE'
        self.cload = state == 'CLOAD'
        self.cstore = state == 'CSTORE'
        self.lrefill3 = state == 'LREFILL3'
        self.srefill4 = state == 'SREFILL4'

        ci_seen_now = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
        ci_access = cache_inhibit or (state in ('CLOAD', 'CSTORE') and ci_seen_now)

        biu_read = False
        if state == 'CLOAD' and load:
            biu_read = bool((hitmiss_eval and i['tagcomp_miss']) or (not hitmiss_eval) or ci_access)
        elif state in ('LREFILL3', 'SREFILL4') and load and not hitmiss_eval:
            biu_read = True

        biu_write = store
        store_hit_ack = bool(state == 'CSTORE' and store and i['biudata_valid'] and not i['tagcomp_miss'] and not ci_access)
        self.first_store_hit_ack = store_hit_ack

        load_hit_ack = bool(state == 'CLOAD' and load and hitmiss_eval and not i['tagcomp_miss'] and not ci_access)
        first_hit_ack = bool(load_hit_ack or store_hit_ack)
        first_miss_ack = bool(state in ('CLOAD', 'CSTORE') and i['biudata_valid'])
        first_miss_err = bool(state in ('CLOAD', 'CSTORE') and i['biudata_error'])

        burst = False
        if state == 'CLOAD' and load and not ci_access:
            burst = bool((hitmiss_eval and i['tagcomp_miss']) or not hitmiss_eval)
        elif state == 'LREFILL3':
            burst = True
        elif state == 'SREFILL4' and self.store_refill_enabled:
            burst = True

        dcram_we = 0
        if load and i['biudata_valid'] and not ci_access:
            dcram_we |= 0xF
        if store_hit_ack:
            dcram_we |= self.mask(i['dcqmem_sel_i'], 4)

        tag_we = bool(biu_read and i['biudata_valid'] and not ci_access)
        use_saved_addr = bool(not hitmiss_eval and (biu_read or biu_write))
        dc_addr = self.saved_addr_r if use_saved_addr else i['start_addr']

        o['saved_addr'] = self.mask(self.saved_addr_r, 32)
        o['dcram_we'] = self.mask(dcram_we, 4)
        o['biu_read'] = int(biu_read)
        o['biu_write'] = int(biu_write)
        o['first_hit_ack'] = int(first_hit_ack)
        o['first_miss_ack'] = int(first_miss_ack)
        o['first_miss_err'] = int(first_miss_err)
        o['burst'] = int(burst)
        o['tag_we'] = int(tag_we)
        o['dc_addr'] = self.mask(dc_addr, 32)
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return

        if self.state == 'IDLE':
            if i['dc_en'] and i['dcqmem_cycstb_i']:
                self.saved_addr_r = self.mask(i['start_addr'], 32)
                self.hitmiss_eval = True
                self.cache_inhibit = False
                self.cnt = 0
                if i['dcqmem_we_i']:
                    self.store = True
                    self.load = False
                    self.state = 'CSTORE'
                else:
                    self.store = False
                    self.load = True
                    self.state = 'CLOAD'
            return

        if self.state == 'CLOAD':
            ci_seen_now = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            if ci_seen_now:
                self.cache_inhibit = True

            if self.hitmiss_eval and not i['dcqmem_cycstb_i']:
                self._finish_idle()
            elif i['biudata_error']:
                self._finish_idle()
            elif self.cache_inhibit:
                self.hitmiss_eval = False
                if i['biudata_valid']:
                    self._finish_idle()
            elif self.hitmiss_eval:
                self.hitmiss_eval = False
                if i['tagcomp_miss']:
                    if i['biudata_valid']:
                        self._begin_load_refill()
                else:
                    self._finish_idle()
            elif i['biudata_valid']:
                self._begin_load_refill()
            return

        if self.state == 'CSTORE':
            ci_seen_now = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            if ci_seen_now:
                self.cache_inhibit = True

            if self.hitmiss_eval and not i['dcqmem_cycstb_i']:
                self._finish_idle()
            elif i['biudata_error']:
                self._finish_idle()
            elif self.cache_inhibit:
                self.hitmiss_eval = False
                if i['biudata_valid']:
                    self._finish_idle()
            else:
                self.hitmiss_eval = False
                if i['biudata_valid']:
                    if i['tagcomp_miss'] and self.store_refill_enabled:
                        self.state = 'SREFILL4'
                        self.store = False
                        self.load = True
                        self.hitmiss_eval = False
                        self.cnt = 3
                    else:
                        self._finish_idle()
            return

        if self.state == 'LREFILL3':
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    self._increment_word_offset()
                else:
                    self._finish_idle()
            return

        if self.state == 'SREFILL4' and self.store_refill_enabled:
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    self._increment_word_offset()
                else:
                    self._finish_idle()
