"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self._state = 'IDLE'
        self._saved_addr = 0
        self._cnt = 0
        self._hitmiss_eval = 0
        self._store = 0
        self._load = 0
        self._cache_inhibit = 0
        self._miss_pending = 0
        self._store_refill = True
        self.idle = True
        self.cload = False
        self.cstore = False
        self.lrefill3 = False
        self.srefill4 = False
        self.hitmiss_eval = False
        self.store = False
        self.load = False
        self.cache_inhibit = False
        self.cnt_nonzero = False
        self.first_store_hit_ack = False

    def _finish(self):
        self._state = 'IDLE'
        self._hitmiss_eval = 0
        self._store = 0
        self._load = 0
        self._miss_pending = 0

    def _inc_word_offset(self):
        word = ((self._saved_addr >> 2) + 1) & 3
        self._saved_addr = self.mask((self._saved_addr & ~0xC) | (word << 2), 32)

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        reset_view = bool(i['rst'])
        if reset_view:
            state = 'IDLE'
            saved_addr = 0
            hitmiss_eval = 0
            store = 0
            load = 0
            cache_inhibit = 0
            cnt_nonzero = 0
            miss_pending = 0
        else:
            state = self._state
            saved_addr = self._saved_addr
            hitmiss_eval = self._hitmiss_eval
            store = self._store
            load = self._load
            cache_inhibit = self._cache_inhibit
            cnt_nonzero = int(self._cnt != 0)
            miss_pending = self._miss_pending

        in_first_access = state in ('CLOAD', 'CSTORE')
        ci_now = bool(cache_inhibit or (in_first_access and i['dcqmem_cycstb_i'] and i['dcqmem_ci_i']))
        if hitmiss_eval:
            miss_now = bool(i['tagcomp_miss'])
        else:
            miss_now = bool(miss_pending)

        load_miss_eval = bool(load and hitmiss_eval and i['tagcomp_miss'] and not ci_now)
        post_eval_load = bool(load and not hitmiss_eval)
        ci_load_access = bool(state == 'CLOAD' and load and ci_now)
        biu_read = int(load_miss_eval or post_eval_load or ci_load_access)
        biu_write = int(bool(store))

        load_hit_ack = bool(state == 'CLOAD' and load and not ci_now and not miss_now)
        store_hit_ack = bool(state == 'CSTORE' and store and i['biudata_valid'] and not ci_now and not miss_now)
        first_hit_ack = int(load_hit_ack or store_hit_ack)
        first_miss_ack = int(state in ('CLOAD', 'CSTORE') and bool(i['biudata_valid']))
        first_miss_err = int(state in ('CLOAD', 'CSTORE') and bool(i['biudata_error']))

        if load and i['biudata_valid'] and not ci_now:
            dcram_we = 0xF
        elif store_hit_ack:
            dcram_we = self.mask(i['dcqmem_sel_i'], 4)
        else:
            dcram_we = 0

        tag_we = int(bool(biu_read and i['biudata_valid'] and not ci_now))
        load_miss_in_cload = bool(state == 'CLOAD' and load and not ci_now and miss_now)
        burst = int(load_miss_in_cload or state == 'LREFILL3' or (self._store_refill and state == 'SREFILL4'))

        transfer_active = bool(biu_read or biu_write)
        if hitmiss_eval or not transfer_active:
            dc_addr = self.mask(i['start_addr'], 32)
        else:
            dc_addr = self.mask(saved_addr, 32)

        self.idle = bool(state == 'IDLE')
        self.cload = bool(state == 'CLOAD')
        self.cstore = bool(state == 'CSTORE')
        self.lrefill3 = bool(state == 'LREFILL3')
        self.srefill4 = bool(state == 'SREFILL4')
        self.hitmiss_eval = bool(hitmiss_eval)
        self.store = bool(store)
        self.load = bool(load)
        self.cache_inhibit = bool(cache_inhibit)
        self.cnt_nonzero = bool(cnt_nonzero)
        self.first_store_hit_ack = bool(store_hit_ack)

        o['saved_addr'] = self.mask(saved_addr, 32)
        o['dcram_we'] = self.mask(dcram_we, 4)
        o['biu_read'] = int(bool(biu_read))
        o['biu_write'] = int(bool(biu_write))
        o['first_hit_ack'] = first_hit_ack
        o['first_miss_ack'] = first_miss_ack
        o['first_miss_err'] = first_miss_err
        o['burst'] = burst
        o['tag_we'] = tag_we
        o['dc_addr'] = self.mask(dc_addr, 32)
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return

        state = self._state
        if state == 'IDLE':
            if i['dc_en'] and i['dcqmem_cycstb_i']:
                self._saved_addr = self.mask(i['start_addr'], 32)
                self._hitmiss_eval = 1
                self._cache_inhibit = 0
                self._miss_pending = 0
                self._cnt = 0
                if i['dcqmem_we_i']:
                    self._store = 1
                    self._load = 0
                    self._state = 'CSTORE'
                else:
                    self._store = 0
                    self._load = 1
                    self._state = 'CLOAD'
            return

        if state == 'CLOAD':
            ci_detected = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            ci_now = bool(self._cache_inhibit or ci_detected)
            if i['biudata_error']:
                self._finish()
            elif self._hitmiss_eval and not i['dcqmem_cycstb_i']:
                self._finish()
            else:
                if ci_detected:
                    self._cache_inhibit = 1
                if ci_now:
                    self._hitmiss_eval = 0
                    self._miss_pending = 0
                    if i['biudata_valid']:
                        self._finish()
                elif self._hitmiss_eval:
                    if i['tagcomp_miss']:
                        self._miss_pending = 1
                        self._hitmiss_eval = 0
                        if i['biudata_valid']:
                            self._state = 'LREFILL3'
                            self._hitmiss_eval = 0
                            self._store = 0
                            self._load = 1
                            self._miss_pending = 0
                            self._cnt = 2
                            self._inc_word_offset()
                    else:
                        self._finish()
                elif self._miss_pending:
                    if i['biudata_valid']:
                        self._state = 'LREFILL3'
                        self._hitmiss_eval = 0
                        self._store = 0
                        self._load = 1
                        self._miss_pending = 0
                        self._cnt = 2
                        self._inc_word_offset()
                elif i['biudata_valid']:
                    self._finish()
            return

        if state == 'CSTORE':
            ci_detected = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            ci_now = bool(self._cache_inhibit or ci_detected)
            if i['biudata_error']:
                self._finish()
            elif self._hitmiss_eval and not i['dcqmem_cycstb_i']:
                self._finish()
            else:
                if ci_detected:
                    self._cache_inhibit = 1
                if ci_now:
                    self._hitmiss_eval = 0
                    self._miss_pending = 0
                    if i['biudata_valid']:
                        self._finish()
                elif self._hitmiss_eval:
                    miss = bool(i['tagcomp_miss'])
                    self._miss_pending = int(miss)
                    self._hitmiss_eval = 0
                    if i['biudata_valid']:
                        if miss and self._store_refill:
                            self._state = 'SREFILL4'
                            self._store = 0
                            self._load = 1
                            self._hitmiss_eval = 0
                            self._miss_pending = 0
                            self._cnt = 3
                        else:
                            self._finish()
                elif i['biudata_valid']:
                    if self._miss_pending and self._store_refill:
                        self._state = 'SREFILL4'
                        self._store = 0
                        self._load = 1
                        self._hitmiss_eval = 0
                        self._miss_pending = 0
                        self._cnt = 3
                    else:
                        self._finish()
            return

        if state == 'LREFILL3':
            if i['biudata_valid']:
                if self._cnt != 0:
                    self._cnt -= 1
                    self._inc_word_offset()
                else:
                    self._finish()
            return

        if state == 'SREFILL4':
            if i['biudata_valid']:
                if self._cnt != 0:
                    self._cnt -= 1
                    self._inc_word_offset()
                else:
                    self._finish()
            return
