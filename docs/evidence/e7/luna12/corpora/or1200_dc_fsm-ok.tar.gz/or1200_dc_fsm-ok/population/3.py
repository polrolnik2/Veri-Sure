"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self._saved_addr = 0
        self._cnt = 0
        self._hitmiss_eval = 0
        self._store = 0
        self._load = 0
        self._cache_inhibit = 0
        self._miss = 0
        self._store_refill = True
        self.idle = True
        self.cload = False
        self.cstore = False
        self.lrefill3 = False
        self.srefill4 = False
        self.hitmiss_eval = False
        self.store = False
        self.load = False
        self.cache_inhibit = False
        self.cnt_nonzero = False
        self.first_store_hit_ack = False

    def _enter_idle(self):
        self.state = 'IDLE'
        self._hitmiss_eval = 0
        self._store = 0
        self._load = 0
        self._cnt = 0
        self._miss = 0

    def _increment_word_offset(self):
        addr = self._saved_addr
        offset = ((addr >> 2) + 1) & 3
        self._saved_addr = self.mask((addr & ~0xC) | (offset << 2), 32)

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        if i['rst']:
            state = 'IDLE'
            saved_addr = 0
            cnt = 0
            hitmiss_eval = 0
            store = 0
            load = 0
            cache_inhibit = 0
            miss = 0
        else:
            state = self.state
            saved_addr = self._saved_addr
            cnt = self._cnt
            hitmiss_eval = self._hitmiss_eval
            store = self._store
            load = self._load
            cache_inhibit = self._cache_inhibit
            miss = self._miss

        in_idle = state == 'IDLE'
        in_cload = state == 'CLOAD'
        in_cstore = state == 'CSTORE'
        in_lrefill3 = state == 'LREFILL3'
        in_srefill4 = state == 'SREFILL4'
        ci_detected_now = bool(
            (in_cload or in_cstore)
            and i['dcqmem_cycstb_i']
            and i['dcqmem_ci_i']
        )
        effective_ci = bool(cache_inhibit or ci_detected_now)

        self.idle = bool(in_idle)
        self.cload = bool(in_cload)
        self.cstore = bool(in_cstore)
        self.lrefill3 = bool(in_lrefill3)
        self.srefill4 = bool(in_srefill4)
        self.hitmiss_eval = bool(hitmiss_eval)
        self.store = bool(store)
        self.load = bool(load)
        self.cache_inhibit = bool(cache_inhibit)
        self.cnt_nonzero = bool(cnt != 0)

        store_hit = bool(
            in_cstore
            and store
            and i['biudata_valid']
            and not effective_ci
            and (
                (hitmiss_eval and not i['tagcomp_miss'])
                or (not hitmiss_eval and not miss)
            )
        )
        self.first_store_hit_ack = store_hit

        biu_read = bool(
            (hitmiss_eval and i['tagcomp_miss'])
            or (hitmiss_eval and in_cload and effective_ci)
            or (not hitmiss_eval and load)
        )
        biu_write = bool(store)

        load_hit = bool(
            in_cload
            and load
            and hitmiss_eval
            and not i['tagcomp_miss']
            and not effective_ci
        )
        first_hit_ack = bool(load_hit or store_hit)

        dcram_we = 0
        if load and i['biudata_valid'] and not effective_ci:
            dcram_we = 0xF
        elif store_hit:
            dcram_we = self.mask(i['dcqmem_sel_i'], 4)

        if in_cload and load and not effective_ci:
            burst = bool(miss or (hitmiss_eval and i['tagcomp_miss']))
        else:
            burst = bool(in_lrefill3 or (in_srefill4 and self._store_refill))

        tag_we = bool(biu_read and i['biudata_valid'] and not effective_ci)
        if not hitmiss_eval and (biu_read or biu_write):
            dc_addr = saved_addr
        else:
            dc_addr = i['start_addr']

        o['saved_addr'] = self.mask(saved_addr, 32)
        o['dcram_we'] = self.mask(dcram_we, 4)
        o['biu_read'] = int(biu_read)
        o['biu_write'] = int(biu_write)
        o['first_hit_ack'] = int(first_hit_ack)
        o['first_miss_ack'] = int((in_cload or in_cstore) and i['biudata_valid'])
        o['first_miss_err'] = int((in_cload or in_cstore) and i['biudata_error'])
        o['burst'] = int(burst)
        o['tag_we'] = int(tag_we)
        o['dc_addr'] = self.mask(dc_addr, 32)
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return

        if self.state == 'IDLE':
            if i['dc_en'] and i['dcqmem_cycstb_i']:
                self._saved_addr = self.mask(i['start_addr'], 32)
                self._hitmiss_eval = 1
                self._cache_inhibit = 0
                self._miss = 0
                if i['dcqmem_we_i']:
                    self.state = 'CSTORE'
                    self._store = 1
                    self._load = 0
                else:
                    self.state = 'CLOAD'
                    self._store = 0
                    self._load = 1
            return

        if self.state == 'CLOAD':
            if i['dcqmem_cycstb_i'] and i['dcqmem_ci_i']:
                self._cache_inhibit = 1

            if self._hitmiss_eval and not i['dcqmem_cycstb_i']:
                self._enter_idle()
                return
            if i['biudata_error']:
                self._enter_idle()
                return

            if self._cache_inhibit:
                self._miss = 0
                if i['biudata_valid']:
                    self._enter_idle()
                else:
                    self._hitmiss_eval = 0
                return

            if self._hitmiss_eval:
                if not i['tagcomp_miss']:
                    self._enter_idle()
                    return
                self._miss = 1
                self._hitmiss_eval = 0

            if self._miss and i['biudata_valid']:
                self.state = 'LREFILL3'
                self._hitmiss_eval = 0
                self._cnt = 2
                self._increment_word_offset()
            return

        if self.state == 'CSTORE':
            if i['dcqmem_cycstb_i'] and i['dcqmem_ci_i']:
                self._cache_inhibit = 1

            if self._hitmiss_eval and not i['dcqmem_cycstb_i']:
                self._enter_idle()
                return
            if i['biudata_error']:
                self._enter_idle()
                return

            if self._cache_inhibit:
                if i['biudata_valid']:
                    self._enter_idle()
                else:
                    self._hitmiss_eval = 0
                return

            if self._hitmiss_eval:
                self._miss = int(bool(i['tagcomp_miss']))
                self._hitmiss_eval = 0

            if i['biudata_valid']:
                if self._miss and self._store_refill:
                    self.state = 'SREFILL4'
                    self._store = 0
                    self._load = 1
                    self._hitmiss_eval = 0
                    self._cnt = 3
                else:
                    self._enter_idle()
            return

        if self.state == 'LREFILL3':
            if i['biudata_valid']:
                if self._cnt != 0:
                    self._cnt -= 1
                    self._increment_word_offset()
                else:
                    self._enter_idle()
            return

        if self.state == 'SREFILL4':
            if i['biudata_valid']:
                if self._cnt != 0:
                    self._cnt -= 1
                    self._increment_word_offset()
                else:
                    self._enter_idle()
            return
