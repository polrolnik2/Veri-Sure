"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.saved_addr_r = 0
        self.cnt = 0
        self.hitmiss_eval = False
        self.store = False
        self.load = False
        self.cache_inhibit = False
        self.first_store_hit_ack = False
        self.idle = True
        self.cload = False
        self.cstore = False
        self.lrefill3 = False
        self.srefill4 = False
        self.cnt_nonzero = False


    @property
    def in_idle(self):
        return bool(self.state == 'IDLE')


    @property
    def in_cload(self):
        return bool(self.state == 'CLOAD')


    @property
    def in_cstore(self):
        return bool(self.state == 'CSTORE')


    @property
    def in_lrefill3(self):
        return bool(self.state == 'LREFILL3')


    @property
    def in_srefill4(self):
        return bool(self.state == 'SREFILL4')


    @property
    def in_hitmiss_eval(self):
        return bool(self.hitmiss_eval)


    @property
    def in_store(self):
        return bool(self.store)


    @property
    def in_load(self):
        return bool(self.load)


    @property
    def in_cache_inhibit(self):
        return bool(self.cache_inhibit)


    @property
    def in_cnt_nonzero(self):
        return bool(self.cnt != 0)


    @property
    def in_first_store_hit_ack(self):
        return bool(self.first_store_hit_ack)


    def _finish_idle(self):
        self.state = 'IDLE'
        self.hitmiss_eval = False
        self.store = False
        self.load = False


    def _increment_word(self):
        offset = ((self.saved_addr_r >> 2) + 1) & 3
        self.saved_addr_r = self.mask((self.saved_addr_r & ~12) | (offset << 2), 32)


    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        state = self.state
        data_phase = state in ('CLOAD', 'CSTORE')
        ci_now = bool(data_phase and i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
        effective_ci = bool(self.cache_inhibit or ci_now)

        self.idle = bool(state == 'IDLE')
        self.cload = bool(state == 'CLOAD')
        self.cstore = bool(state == 'CSTORE')
        self.lrefill3 = bool(state == 'LREFILL3')
        self.srefill4 = bool(state == 'SREFILL4')
        self.hitmiss_eval = bool(self.hitmiss_eval)
        self.store = bool(self.store)
        self.load = bool(self.load)
        self.cache_inhibit = bool(self.cache_inhibit)
        self.cnt_nonzero = bool(self.cnt != 0)

        first_store_hit = bool(
            state == 'CSTORE'
            and self.store
            and i['biudata_valid']
            and not i['tagcomp_miss']
            and not effective_ci
        )
        self.first_store_hit_ack = first_store_hit

        read_miss_eval = bool(
            state == 'CLOAD' and self.hitmiss_eval and i['tagcomp_miss']
        )
        read_cache_inhibited_load = bool(
            state == 'CLOAD' and self.load and effective_ci
        )
        read_post_eval_load = bool(self.load and not self.hitmiss_eval)
        biu_read = bool(
            read_miss_eval or read_cache_inhibited_load or read_post_eval_load
        )
        biu_write = bool(self.store)

        load_hit = bool(
            state == 'CLOAD'
            and self.load
            and not i['tagcomp_miss']
            and not effective_ci
        )
        first_hit_ack = bool(load_hit or first_store_hit)
        first_miss_ack = bool(data_phase and i['biudata_valid'])
        first_miss_err = bool(data_phase and i['biudata_error'])

        dcram_we = 0
        if self.load and i['biudata_valid'] and not effective_ci:
            dcram_we |= 15
        if first_store_hit:
            dcram_we |= self.mask(i['dcqmem_sel_i'], 4)

        burst = bool(
            (state == 'CLOAD' and self.load and i['tagcomp_miss'] and not effective_ci)
            or state == 'LREFILL3'
            or state == 'SREFILL4'
        )
        tag_we = bool(biu_read and i['biudata_valid'] and not effective_ci)

        if not self.hitmiss_eval and (biu_read or biu_write):
            dc_addr = self.saved_addr_r
        else:
            dc_addr = i['start_addr']

        o['saved_addr'] = self.mask(self.saved_addr_r, 32)
        o['dcram_we'] = self.mask(dcram_we, 4)
        o['biu_read'] = int(biu_read)
        o['biu_write'] = int(biu_write)
        o['first_hit_ack'] = int(first_hit_ack)
        o['first_miss_ack'] = int(first_miss_ack)
        o['first_miss_err'] = int(first_miss_err)
        o['burst'] = int(burst)
        o['tag_we'] = int(tag_we)
        o['dc_addr'] = self.mask(dc_addr, 32)
        return o


    def advance(self, i):
        if i['rst']:
            self.reset()
            return

        if self.state == 'IDLE':
            if i['dc_en'] and i['dcqmem_cycstb_i']:
                self.saved_addr_r = self.mask(i['start_addr'], 32)
                self.hitmiss_eval = True
                self.cache_inhibit = False
                self.store = bool(i['dcqmem_we_i'])
                self.load = not self.store
                self.state = 'CSTORE' if self.store else 'CLOAD'
            return

        if self.state == 'CLOAD':
            ci_now = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            if ci_now:
                self.cache_inhibit = True
            effective_ci = bool(self.cache_inhibit or ci_now)

            if i['biudata_error']:
                self._finish_idle()
            elif self.hitmiss_eval and not i['dcqmem_cycstb_i']:
                self._finish_idle()
            elif effective_ci and i['biudata_valid']:
                self._finish_idle()
            elif not effective_ci and not i['tagcomp_miss']:
                self._finish_idle()
            elif i['biudata_valid'] and not effective_ci:
                self.hitmiss_eval = False
                self.state = 'LREFILL3'
                self.cnt = 2
                self._increment_word()
            else:
                if self.hitmiss_eval:
                    self.hitmiss_eval = False
            return

        if self.state == 'CSTORE':
            ci_now = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            if ci_now:
                self.cache_inhibit = True
            effective_ci = bool(self.cache_inhibit or ci_now)

            if i['biudata_error']:
                self._finish_idle()
            elif self.hitmiss_eval and not i['dcqmem_cycstb_i']:
                self._finish_idle()
            elif effective_ci and i['biudata_valid']:
                self._finish_idle()
            else:
                if self.hitmiss_eval:
                    self.hitmiss_eval = False
                if i['biudata_valid']:
                    if i['tagcomp_miss']:
                        self.store = False
                        if True:
                            self.load = True
                            self.cnt = 3
                            self.state = 'SREFILL4'
                        else:
                            self._finish_idle()
                    else:
                        self._finish_idle()
            return

        if self.state == 'LREFILL3':
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    self._increment_word()
                else:
                    self._finish_idle()
            return

        if self.state == 'SREFILL4':
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    self._increment_word()
                else:
                    self._finish_idle()
