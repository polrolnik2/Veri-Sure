"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.saved_addr_r = 0
        self.cnt = 0
        self.hitmiss_eval_r = 0
        self.store_r = 0
        self.load_r = 0
        self.cache_inhibit_r = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        reset_now = bool(i['rst'])
        state = 'IDLE' if reset_now else self.state
        saved_addr = 0 if reset_now else self.saved_addr_r
        cnt = 0 if reset_now else self.cnt
        hitmiss_eval = 0 if reset_now else self.hitmiss_eval_r
        store = 0 if reset_now else self.store_r
        load = 0 if reset_now else self.load_r
        cache_inhibit = 0 if reset_now else self.cache_inhibit_r

        ci_seen_now = bool(
            not reset_now
            and state in ('CLOAD', 'CSTORE')
            and i['dcqmem_cycstb_i']
            and i['dcqmem_ci_i']
        )
        ci_effective = bool(cache_inhibit or ci_seen_now)

        first_store_hit_ack = bool(
            state == 'CSTORE'
            and store
            and i['biudata_valid']
            and not i['tagcomp_miss']
            and not ci_effective
        )
        biu_read = bool(
            (hitmiss_eval and i['tagcomp_miss'] and not ci_effective)
            or (not hitmiss_eval and load)
            or (state == 'CLOAD' and load and ci_effective)
        )
        biu_write = bool(store)
        load_hit_ack = bool(
            state == 'CLOAD'
            and load
            and not i['tagcomp_miss']
            and not ci_effective
        )

        self.idle = bool(state == 'IDLE')
        self.cload = bool(state == 'CLOAD')
        self.cstore = bool(state == 'CSTORE')
        self.lrefill3 = bool(state == 'LREFILL3')
        self.srefill4 = bool(state == 'SREFILL4')
        self.hitmiss_eval = bool(hitmiss_eval)
        self.store = bool(store)
        self.load = bool(load)
        self.cache_inhibit = bool(cache_inhibit)
        self.cnt_nonzero = bool(cnt != 0)
        self.first_store_hit_ack = first_store_hit_ack

        dcram_we = 0
        if load and i['biudata_valid'] and not ci_effective:
            dcram_we |= 0xF
        if first_store_hit_ack:
            dcram_we |= self.mask(i['dcqmem_sel_i'], 4)

        burst = bool(
            (state == 'CLOAD' and load and i['tagcomp_miss'] and not ci_effective)
            or state == 'LREFILL3'
            or state == 'SREFILL4'
        )
        tag_we = bool(biu_read and i['biudata_valid'] and not ci_effective)
        transfer_active = bool(biu_read or biu_write)
        if not hitmiss_eval and transfer_active:
            dc_addr = saved_addr
        else:
            dc_addr = self.mask(i['start_addr'], 32)

        o['saved_addr'] = self.mask(saved_addr, 32)
        o['dcram_we'] = self.mask(dcram_we, 4)
        o['biu_read'] = int(biu_read)
        o['biu_write'] = int(biu_write)
        o['first_hit_ack'] = int(load_hit_ack or first_store_hit_ack)
        o['first_miss_ack'] = int(state in ('CLOAD', 'CSTORE') and bool(i['biudata_valid']))
        o['first_miss_err'] = int(state in ('CLOAD', 'CSTORE') and bool(i['biudata_error']))
        o['burst'] = int(burst)
        o['tag_we'] = int(tag_we)
        o['dc_addr'] = self.mask(dc_addr, 32)
        return o

    def advance(self, i):
        if i['rst']:
            self.state = 'IDLE'
            self.saved_addr_r = 0
            self.cnt = 0
            self.hitmiss_eval_r = 0
            self.store_r = 0
            self.load_r = 0
            self.cache_inhibit_r = 0
            return

        if self.state == 'IDLE':
            if i['dc_en'] and i['dcqmem_cycstb_i']:
                self.saved_addr_r = self.mask(i['start_addr'], 32)
                self.hitmiss_eval_r = 1
                self.store_r = int(bool(i['dcqmem_we_i']))
                self.load_r = int(not bool(i['dcqmem_we_i']))
                self.cache_inhibit_r = 0
                self.state = 'CSTORE' if i['dcqmem_we_i'] else 'CLOAD'
            return

        if self.state == 'CLOAD':
            ci_seen_now = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            if self.hitmiss_eval_r and not i['dcqmem_cycstb_i']:
                self.state = 'IDLE'
                self.hitmiss_eval_r = 0
                self.store_r = 0
                self.load_r = 0
                self.cache_inhibit_r = 0
                return
            if i['biudata_error']:
                self.state = 'IDLE'
                self.hitmiss_eval_r = 0
                self.store_r = 0
                self.load_r = 0
                self.cache_inhibit_r = 0
                return

            if ci_seen_now:
                self.cache_inhibit_r = 1
            ci_effective = bool(self.cache_inhibit_r or ci_seen_now)
            self.hitmiss_eval_r = 0

            if ci_effective:
                if i['biudata_valid']:
                    self.state = 'IDLE'
                    self.hitmiss_eval_r = 0
                    self.store_r = 0
                    self.load_r = 0
                    self.cache_inhibit_r = 0
                return

            if not i['tagcomp_miss']:
                self.state = 'IDLE'
                self.hitmiss_eval_r = 0
                self.store_r = 0
                self.load_r = 0
                self.cache_inhibit_r = 0
            elif i['biudata_valid']:
                self.state = 'LREFILL3'
                self.saved_addr_r = self.mask(
                    (self.saved_addr_r & 0xFFFFFFF3)
                    | ((((self.saved_addr_r >> 2) + 1) & 0x3) << 2),
                    32,
                )
                self.cnt = 2
            return

        if self.state == 'CSTORE':
            ci_seen_now = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            if self.hitmiss_eval_r and not i['dcqmem_cycstb_i']:
                self.state = 'IDLE'
                self.hitmiss_eval_r = 0
                self.store_r = 0
                self.load_r = 0
                self.cache_inhibit_r = 0
                return
            if i['biudata_error']:
                self.state = 'IDLE'
                self.hitmiss_eval_r = 0
                self.store_r = 0
                self.load_r = 0
                self.cache_inhibit_r = 0
                return

            if ci_seen_now:
                self.cache_inhibit_r = 1
            ci_effective = bool(self.cache_inhibit_r or ci_seen_now)
            self.hitmiss_eval_r = 0

            if i['biudata_valid']:
                if not ci_effective and i['tagcomp_miss']:
                    self.state = 'SREFILL4'
                    self.store_r = 0
                    self.load_r = 1
                    self.hitmiss_eval_r = 0
                    self.cache_inhibit_r = 0
                    self.cnt = 3
                else:
                    self.state = 'IDLE'
                    self.hitmiss_eval_r = 0
                    self.store_r = 0
                    self.load_r = 0
                    self.cache_inhibit_r = 0
            return

        if self.state == 'LREFILL3':
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    self.saved_addr_r = self.mask(
                        (self.saved_addr_r & 0xFFFFFFF3)
                        | ((((self.saved_addr_r >> 2) + 1) & 0x3) << 2),
                        32,
                    )
                else:
                    self.state = 'IDLE'
                    self.hitmiss_eval_r = 0
                    self.store_r = 0
                    self.load_r = 0
                    self.cache_inhibit_r = 0
            return

        if self.state == 'SREFILL4':
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    self.saved_addr_r = self.mask(
                        (self.saved_addr_r & 0xFFFFFFF3)
                        | ((((self.saved_addr_r >> 2) + 1) & 0x3) << 2),
                        32,
                    )
                else:
                    self.state = 'IDLE'
                    self.hitmiss_eval_r = 0
                    self.store_r = 0
                    self.load_r = 0
                    self.cache_inhibit_r = 0
            return
