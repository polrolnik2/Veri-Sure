"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['saved_addr', 'dcram_we', 'biu_read', 'biu_write', 'first_hit_ack', 'first_miss_ack', 'first_miss_err', 'burst', 'tag_we', 'dc_addr']
    PROBE_PORTS = ['idle', 'cload', 'cstore', 'lrefill3', 'srefill4', 'hitmiss_eval', 'store', 'load', 'cache_inhibit', 'cnt_nonzero', 'first_store_hit_ack']
    PROBE_WIDTHS = {'idle': 1, 'cload': 1, 'cstore': 1, 'lrefill3': 1, 'srefill4': 1, 'hitmiss_eval': 1, 'store': 1, 'load': 1, 'cache_inhibit': 1, 'cnt_nonzero': 1, 'first_store_hit_ack': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.saved_addr_r = 0
        self.cnt = 0
        self.hitmiss_eval = False
        self.store = False
        self.load = False
        self.cache_inhibit = False
        self.store_refill_enabled = True


    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        # State and internal-state probes are sampled from the current state.
        self.idle = self.state == 'IDLE'
        self.cload = self.state == 'CLOAD'
        self.cstore = self.state == 'CSTORE'
        self.lrefill3 = self.state == 'LREFILL3'
        self.srefill4 = self.state == 'SREFILL4'
        self.hitmiss_eval = bool(self.hitmiss_eval)
        self.store = bool(self.store)
        self.load = bool(self.load)
        self.cache_inhibit = bool(self.cache_inhibit)
        self.cnt_nonzero = bool(self.cnt != 0)

        # A cache-inhibit observation is effective combinationally on this edge,
        # as well as being registered by advance.
        ci_observed = bool(
            (self.cload or self.cstore)
            and i['dcqmem_cycstb_i']
            and i['dcqmem_ci_i']
        )
        cache_inhibited_now = bool(self.cache_inhibit or ci_observed)

        self.first_store_hit_ack = bool(
            self.cstore
            and self.store
            and i['biudata_valid']
            and not i['tagcomp_miss']
            and not cache_inhibited_now
        )

        biu_read = bool(
            (self.hitmiss_eval and i['tagcomp_miss'])
            or ((not self.hitmiss_eval) and self.load)
        )
        biu_write = bool(self.store)

        dcram_we = 0
        if self.load and i['biudata_valid'] and not cache_inhibited_now:
            dcram_we |= 0xF
        if self.first_store_hit_ack:
            dcram_we |= self.mask(i['dcqmem_sel_i'], 4)

        load_hit_ack = bool(
            self.cload and not i['tagcomp_miss'] and not cache_inhibited_now
        )
        first_hit_ack = bool(load_hit_ack or self.first_store_hit_ack)
        first_miss_ack = bool(
            (self.cload or self.cstore) and i['biudata_valid']
        )
        first_miss_err = bool(
            (self.cload or self.cstore) and i['biudata_error']
        )

        burst = bool(
            (self.cload and self.load and i['tagcomp_miss'] and not cache_inhibited_now)
            or self.lrefill3
            or (self.store_refill_enabled and self.srefill4)
        )
        tag_we = bool(biu_read and i['biudata_valid'] and not cache_inhibited_now)

        if (not self.hitmiss_eval) and (biu_read or biu_write):
            dc_addr = self.saved_addr_r
        else:
            dc_addr = self.mask(i['start_addr'], 32)

        o['saved_addr'] = self.mask(self.saved_addr_r, 32)
        o['dcram_we'] = self.mask(dcram_we, 4)
        o['biu_read'] = int(biu_read)
        o['biu_write'] = int(biu_write)
        o['first_hit_ack'] = int(first_hit_ack)
        o['first_miss_ack'] = int(first_miss_ack)
        o['first_miss_err'] = int(first_miss_err)
        o['burst'] = int(burst)
        o['tag_we'] = int(tag_we)
        o['dc_addr'] = self.mask(dc_addr, 32)
        return o


    def advance(self, i):
        if i['rst']:
            self.reset()
            return

        if self.state == 'IDLE':
            if i['dc_en'] and i['dcqmem_cycstb_i']:
                self.saved_addr_r = self.mask(i['start_addr'], 32)
                self.hitmiss_eval = True
                self.cache_inhibit = False
                self.store = bool(i['dcqmem_we_i'])
                self.load = not bool(i['dcqmem_we_i'])
                self.state = 'CSTORE' if i['dcqmem_we_i'] else 'CLOAD'
            return

        if self.state == 'CLOAD':
            ci_observed = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            cache_inhibited_now = bool(self.cache_inhibit or ci_observed)

            if not i['dcqmem_cycstb_i'] and self.hitmiss_eval:
                self.state = 'IDLE'
                self.hitmiss_eval = False
                self.load = False
                return
            if i['biudata_error']:
                self.state = 'IDLE'
                self.hitmiss_eval = False
                self.load = False
                return

            if ci_observed:
                self.cache_inhibit = True
            self.hitmiss_eval = False

            if cache_inhibited_now:
                if i['biudata_valid']:
                    self.state = 'IDLE'
                    self.load = False
                return

            if not i['tagcomp_miss']:
                self.state = 'IDLE'
                self.load = False
                return

            if i['biudata_valid']:
                self.state = 'LREFILL3'
                self.saved_addr_r = self.mask(
                    (self.saved_addr_r & ~0xC)
                    | (((((self.saved_addr_r >> 2) + 1) & 0x3) << 2)),
                    32
                )
                self.cnt = 2
            return

        if self.state == 'CSTORE':
            ci_observed = bool(i['dcqmem_cycstb_i'] and i['dcqmem_ci_i'])
            cache_inhibited_now = bool(self.cache_inhibit or ci_observed)

            if not i['dcqmem_cycstb_i'] and self.hitmiss_eval:
                self.state = 'IDLE'
                self.hitmiss_eval = False
                self.store = False
                return
            if i['biudata_error']:
                self.state = 'IDLE'
                self.hitmiss_eval = False
                self.store = False
                return

            if ci_observed:
                self.cache_inhibit = True
            self.hitmiss_eval = False

            if cache_inhibited_now:
                if i['biudata_valid']:
                    self.state = 'IDLE'
                    self.store = False
                return

            if i['biudata_valid']:
                if i['tagcomp_miss'] and self.store_refill_enabled:
                    self.state = 'SREFILL4'
                    self.store = False
                    self.load = True
                    self.cnt = 3
                else:
                    self.state = 'IDLE'
                    self.store = False
            return

        if self.state == 'LREFILL3':
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    self.saved_addr_r = self.mask(
                        (self.saved_addr_r & ~0xC)
                        | (((((self.saved_addr_r >> 2) + 1) & 0x3) << 2)),
                        32
                    )
                else:
                    self.state = 'IDLE'
                    self.load = False
            return

        if self.state == 'SREFILL4':
            if i['biudata_valid']:
                if self.cnt != 0:
                    self.cnt -= 1
                    self.saved_addr_r = self.mask(
                        (self.saved_addr_r & ~0xC)
                        | (((((self.saved_addr_r >> 2) + 1) & 0x3) << 2)),
                        32
                    )
                else:
                    self.state = 'IDLE'
                    self.load = False
            return
