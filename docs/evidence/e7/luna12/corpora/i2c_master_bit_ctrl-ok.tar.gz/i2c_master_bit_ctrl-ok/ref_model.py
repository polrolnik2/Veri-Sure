"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['cnt_zero', 'cnt_reload', 'clk_en', 'slave_wait', 'scl_sync', 'cscl', 'csda', 'dscl', 'sta_condition', 'sto_condition', 'sda_chk', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence']
    PROBE_WIDTHS = {'cnt_zero': 1, 'cnt_reload': 1, 'clk_en': 1, 'slave_wait': 1, 'scl_sync': 1, 'cscl': 1, 'csda': 1, 'dscl': 1, 'sta_condition': 1, 'sto_condition': 1, 'sda_chk': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.scl_oen = 1
        self.sda_oen = 1
        self.sda_chk = 0
        self.cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0
        self.cnt = 0
        self.clk_en = 0
        self.filter_cnt = 0
        self.scl_meta = 1
        self.sda_meta = 1
        self.cscl = 1
        self.csda = 1
        self.fSCL = 7
        self.fSDA = 7
        self.dscl = 1
        self.dsda = 1

    def _majority(self, history):
        return int(((history & 1) + ((history >> 1) & 1) + ((history >> 2) & 1)) >= 2)

    def _filtered(self):
        return self._majority(self.fSCL), self._majority(self.fSDA)

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        if (int(i['nReset']) & 1) == 0:
            o['cmd_ack'] = 0
            o['busy'] = 0
            o['al'] = 0
            o['dout'] = 0
            o['scl_o'] = 0
            o['scl_oen'] = 1
            o['sda_o'] = 0
            o['sda_oen'] = 1
            self.cnt_zero = True
            self.cnt_reload = False
            self.clk_en = False
            self.slave_wait = False
            self.scl_sync = False
            self.cscl = True
            self.csda = True
            self.dscl = True
            self.sta_condition = False
            self.sto_condition = False
            self.sda_chk = False
            self.fsm_active = False
            self.in_start_sequence = False
            self.in_stop_sequence = False
            self.in_read_sequence = False
            self.in_write_sequence = False
            return o

        sSCL, sSDA = self._filtered()
        slave_wait = bool(self.scl_oen and not sSCL)
        scl_sync = bool(self.scl_oen and self.dscl and not sSCL)
        sta = bool((not sSDA) and self.dsda and sSCL)
        sto = bool(sSDA and (not self.dsda) and sSCL)
        ena = int(i['ena']) & 1
        rst = int(i['rst']) & 1
        if rst:
            cnt_reload = False
        else:
            cnt_reload = bool((not ena) or scl_sync or ((self.cnt == 0) and not slave_wait))

        o['cmd_ack'] = int(self.cmd_ack)
        o['busy'] = int(self.busy)
        o['al'] = int(self.al)
        o['dout'] = int(self.dout)
        o['scl_o'] = 0
        o['scl_oen'] = int(self.scl_oen)
        o['sda_o'] = 0
        o['sda_oen'] = int(self.sda_oen)

        self.cnt_zero = bool(self.cnt == 0)
        self.cnt_reload = bool(cnt_reload)
        self.clk_en = bool(self.clk_en)
        self.slave_wait = bool(slave_wait)
        self.scl_sync = bool(scl_sync)
        self.cscl = bool(self.cscl)
        self.csda = bool(self.csda)
        self.dscl = bool(self.dscl)
        self.sta_condition = bool(sta)
        self.sto_condition = bool(sto)
        self.sda_chk = bool(self.sda_chk)
        self.fsm_active = bool(self.state != 'IDLE')
        self.in_start_sequence = bool(self.state.startswith('START_'))
        self.in_stop_sequence = bool(self.state.startswith('STOP_'))
        self.in_read_sequence = bool(self.state.startswith('READ_'))
        self.in_write_sequence = bool(self.state.startswith('WRITE_'))
        return o

    def advance(self, i):
        nreset = int(i['nReset']) & 1
        rst = int(i['rst']) & 1
        if (not nreset) or rst:
            self.reset()
            return

        ena = int(i['ena']) & 1
        clk_cnt = int(i['clk_cnt']) & 0xffff
        sSCL, sSDA = self._filtered()
        sta = bool((not sSDA) and self.dsda and sSCL)
        sto = bool(sSDA and (not self.dsda) and sSCL)
        slave_wait = bool(self.scl_oen and not sSCL)
        scl_sync = bool(self.scl_oen and self.dscl and not sSCL)

        arbitration_lost = bool(self.sda_chk and self.sda_oen and not sSDA)
        unexpected_stop = bool(sto and self.state != 'IDLE' and not self.state.startswith('STOP_'))
        lost = bool(self.al or arbitration_lost or unexpected_stop)

        if sta:
            self.busy = 1
        elif sto:
            self.busy = 0

        if sSCL and not self.dscl:
            self.dout = int(sSDA)

        self.cmd_ack = 0
        self.al = int(lost)
        fsm_tick = bool(self.clk_en and ena and not slave_wait)

        if lost:
            self.state = 'IDLE'
            self.scl_oen = 1
            self.sda_oen = 1
            self.sda_chk = 0
        elif fsm_tick:
            if self.state == 'IDLE':
                cmd = int(i['cmd']) & 0xf
                if cmd == 1:
                    self.state = 'START_A'
                    self.scl_oen = 1
                    self.sda_oen = 1
                    self.sda_chk = 0
                elif cmd == 2:
                    self.state = 'STOP_A'
                    self.scl_oen = 0
                    self.sda_oen = 0
                    self.sda_chk = 0
                elif cmd == 8:
                    self.state = 'READ_A'
                    self.scl_oen = 0
                    self.sda_oen = 1
                    self.sda_chk = 0
                elif cmd == 4:
                    self.state = 'WRITE_A'
                    self.scl_oen = 0
                    self.sda_oen = int(bool(int(i['din']) & 1))
                    self.sda_chk = 0
            elif self.state == 'START_A':
                self.state = 'START_B'
                self.scl_oen = 1
                self.sda_oen = 0
            elif self.state == 'START_B':
                self.state = 'START_C'
                self.scl_oen = 0
                self.sda_oen = 0
            elif self.state == 'START_C':
                self.state = 'IDLE'
                self.cmd_ack = 1
            elif self.state == 'STOP_A':
                self.state = 'STOP_B'
                self.scl_oen = 1
                self.sda_oen = 0
            elif self.state == 'STOP_B':
                self.state = 'STOP_C'
                self.scl_oen = 1
                self.sda_oen = 1
            elif self.state == 'STOP_C':
                self.state = 'IDLE'
                self.cmd_ack = 1
            elif self.state == 'READ_A':
                self.state = 'READ_B'
                self.scl_oen = 1
                self.sda_oen = 1
            elif self.state == 'READ_B':
                self.state = 'READ_C'
                self.scl_oen = 0
                self.sda_oen = 1
            elif self.state == 'READ_C':
                self.state = 'IDLE'
                self.cmd_ack = 1
            elif self.state == 'WRITE_A':
                self.state = 'WRITE_B'
                self.scl_oen = 1
                self.sda_chk = 1
            elif self.state == 'WRITE_B':
                self.state = 'WRITE_C'
                self.scl_oen = 0
                self.sda_chk = 0
            elif self.state == 'WRITE_C':
                self.state = 'IDLE'
                self.cmd_ack = 1
                self.sda_chk = 0

        old_scl_meta = self.scl_meta
        old_sda_meta = self.sda_meta
        old_cscl = self.cscl
        old_csda = self.csda
        self.scl_meta = int(i['scl_i']) & 1
        self.sda_meta = int(i['sda_i']) & 1
        self.cscl = old_scl_meta
        self.csda = old_sda_meta

        old_sSCL, old_sSDA = self._filtered()
        self.dscl = old_sSCL
        self.dsda = old_sSDA

        if not ena:
            self.filter_cnt = 0
        elif self.filter_cnt == 0:
            self.fSCL = ((self.fSCL << 1) | old_cscl) & 7
            self.fSDA = ((self.fSDA << 1) | old_csda) & 7
            self.filter_cnt = (clk_cnt >> 2) & 0x3fff
        else:
            self.filter_cnt -= 1

        if not ena:
            self.cnt = clk_cnt
            self.clk_en = 1
        elif scl_sync:
            self.cnt = clk_cnt
            self.clk_en = 1
        elif slave_wait:
            self.clk_en = 0
        elif self.cnt == 0:
            self.cnt = clk_cnt
            self.clk_en = 1
        else:
            self.cnt = (self.cnt - 1) & 0xffff
            self.clk_en = 0
