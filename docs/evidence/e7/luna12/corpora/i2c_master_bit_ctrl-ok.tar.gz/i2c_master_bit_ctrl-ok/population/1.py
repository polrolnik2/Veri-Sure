"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['cnt_zero', 'cnt_reload', 'clk_en', 'slave_wait', 'scl_sync', 'cscl', 'csda', 'dscl', 'sta_condition', 'sto_condition', 'sda_chk', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence']
    PROBE_WIDTHS = {'cnt_zero': 1, 'cnt_reload': 1, 'clk_en': 1, 'slave_wait': 1, 'scl_sync': 1, 'cscl': 1, 'csda': 1, 'dscl': 1, 'sta_condition': 1, 'sto_condition': 1, 'sda_chk': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'idle'
        self.cnt = 0
        self.filter_cnt = 0
        self.cSCL1 = 1
        self.cSCL2 = 1
        self.cSDA1 = 1
        self.cSDA2 = 1
        self.fSCL = [1, 1, 1]
        self.fSDA = [1, 1, 1]
        self.dSCL = 1
        self.dSDA = 1
        self.scl_oen = 1
        self.sda_oen = 1
        self.sda_chk = 0
        self.cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0


    def _signals(self, i):
        sSCL = int(sum(self.fSCL) >= 2)
        sSDA = int(sum(self.fSDA) >= 2)
        sta_condition = int((not sSDA) and self.dSDA and sSCL)
        sto_condition = int(sSDA and (not self.dSDA) and sSCL)
        scl_sync = int(self.scl_oen and self.dSCL and (not sSCL))
        slave_wait = int(self.scl_oen and (not sSCL))
        cnt_zero = int(self.cnt == 0)

        if i['rst']:
            cnt_reload = 1
            clk_en = 0
        elif not i['ena']:
            cnt_reload = 1
            clk_en = 1
        elif scl_sync:
            cnt_reload = 1
            clk_en = int(not slave_wait)
        elif slave_wait:
            cnt_reload = 0
            clk_en = 0
        elif cnt_zero:
            cnt_reload = 1
            clk_en = 1
        else:
            cnt_reload = 0
            clk_en = 0

        return {
            'sSCL': sSCL,
            'sSDA': sSDA,
            'sta_condition': sta_condition,
            'sto_condition': sto_condition,
            'scl_sync': scl_sync,
            'slave_wait': slave_wait,
            'cnt_zero': cnt_zero,
            'cnt_reload': cnt_reload,
            'clk_en': clk_en,
            'scl_rise': int(sSCL and (not self.dSCL)),
        }


    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        if not i['nReset']:
            self.cnt_zero = True
            self.cnt_reload = True
            self.clk_en = False
            self.slave_wait = False
            self.scl_sync = False
            self.cscl = True
            self.csda = True
            self.dscl = True
            self.sta_condition = False
            self.sto_condition = False
            self.sda_chk = False
            self.fsm_active = False
            self.in_start_sequence = False
            self.in_stop_sequence = False
            self.in_read_sequence = False
            self.in_write_sequence = False
            o['cmd_ack'] = 0
            o['busy'] = 0
            o['al'] = 0
            o['dout'] = 0
            o['scl_o'] = 0
            o['scl_oen'] = 1
            o['sda_o'] = 0
            o['sda_oen'] = 1
            return o

        s = self._signals(i)
        self.cnt_zero = bool(s['cnt_zero'])
        self.cnt_reload = bool(s['cnt_reload'])
        self.clk_en = bool(s['clk_en'])
        self.slave_wait = bool(s['slave_wait'])
        self.scl_sync = bool(s['scl_sync'])
        self.cscl = bool(self.cSCL2)
        self.csda = bool(self.cSDA2)
        self.dscl = bool(self.dSCL)
        self.sta_condition = bool(s['sta_condition'])
        self.sto_condition = bool(s['sto_condition'])
        self.sda_chk = bool(self.sda_chk)
        self.fsm_active = bool(self.state != 'idle')
        self.in_start_sequence = bool(self.state in ('start_a', 'start_b'))
        self.in_stop_sequence = bool(self.state in ('stop_a', 'stop_b'))
        self.in_read_sequence = bool(self.state in ('read_a', 'read_b'))
        self.in_write_sequence = bool(self.state in ('write_a', 'write_b', 'write_c'))

        o['cmd_ack'] = int(self.cmd_ack)
        o['busy'] = int(self.busy)
        o['al'] = int(self.al)
        o['dout'] = int(self.dout)
        o['scl_o'] = 0
        o['scl_oen'] = int(self.scl_oen)
        o['sda_o'] = 0
        o['sda_oen'] = int(self.sda_oen)
        return o


    def advance(self, i):
        if not i['nReset']:
            self.reset()
            return
        if i['rst']:
            self.reset()
            return

        s = self._signals(i)
        active = self.state != 'idle'
        requested_stop = self.state in ('stop_a', 'stop_b')
        arbitration_lost = bool(
            (self.sda_chk and self.sda_oen and not s['sSDA']) or
            (s['sto_condition'] and active and not requested_stop)
        )

        old_cSCL1 = self.cSCL1
        old_cSDA1 = self.cSDA1
        self.cSCL1 = int(i['scl_i']) & 1
        self.cSCL2 = old_cSCL1
        self.cSDA1 = int(i['sda_i']) & 1
        self.cSDA2 = old_cSDA1

        if i['ena']:
            if self.filter_cnt == 0:
                self.fSCL = self.fSCL[1:] + [self.cSCL2]
                self.fSDA = self.fSDA[1:] + [self.cSDA2]
                self.filter_cnt = self.mask(i['clk_cnt'] >> 2, 14)
            else:
                self.filter_cnt = self.mask(self.filter_cnt - 1, 14)
        else:
            self.filter_cnt = 0

        if s['scl_rise']:
            self.dout = int(s['sSDA'])
        self.dSCL = int(s['sSCL'])
        self.dSDA = int(s['sSDA'])

        if s['sta_condition']:
            self.busy = 1
        elif s['sto_condition']:
            self.busy = 0

        self.cmd_ack = 0

        if not i['ena']:
            self.cnt = self.mask(i['clk_cnt'], 16)
        elif s['scl_sync']:
            self.cnt = self.mask(i['clk_cnt'], 16)
        elif s['slave_wait']:
            pass
        elif s['cnt_zero']:
            self.cnt = self.mask(i['clk_cnt'], 16)
        else:
            self.cnt = self.mask(self.cnt - 1, 16)

        if arbitration_lost:
            self.al = 1
            self.state = 'idle'
            self.scl_oen = 1
            self.sda_oen = 1
            self.sda_chk = 0
            return

        if not (i['ena'] and s['clk_en'] and not s['slave_wait']):
            return

        cmd = int(i['cmd']) & 15
        if self.state == 'idle':
            self.sda_chk = 0
            if cmd == 1:
                self.state = 'start_a'
                self.scl_oen = 1
                self.sda_oen = 1
            elif cmd == 2:
                self.state = 'stop_a'
                self.scl_oen = 0
                self.sda_oen = 0
            elif cmd == 8:
                self.state = 'read_a'
                self.scl_oen = 0
                self.sda_oen = 1
            elif cmd == 4:
                self.state = 'write_a'
                self.scl_oen = 0
                self.sda_oen = int(i['din']) & 1

        elif self.state == 'start_a':
            self.state = 'start_b'
            self.scl_oen = 1
            self.sda_oen = 0

        elif self.state == 'start_b':
            self.state = 'idle'
            self.scl_oen = 0
            self.sda_oen = 0
            self.cmd_ack = 1

        elif self.state == 'stop_a':
            self.state = 'stop_b'
            self.scl_oen = 1
            self.sda_oen = 0

        elif self.state == 'stop_b':
            self.state = 'idle'
            self.scl_oen = 1
            self.sda_oen = 1
            self.cmd_ack = 1

        elif self.state == 'read_a':
            self.state = 'read_b'
            self.scl_oen = 1
            self.sda_oen = 1

        elif self.state == 'read_b':
            self.state = 'idle'
            self.scl_oen = 0
            self.sda_oen = 1
            self.cmd_ack = 1

        elif self.state == 'write_a':
            self.state = 'write_b'
            self.scl_oen = 1

        elif self.state == 'write_b':
            self.state = 'write_c'
            self.sda_chk = 1

        elif self.state == 'write_c':
            self.state = 'idle'
            self.scl_oen = 0
            self.sda_chk = 0
            self.cmd_ack = 1
