"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['cnt_zero', 'cnt_reload', 'clk_en', 'slave_wait', 'scl_sync', 'cscl', 'csda', 'dscl', 'sta_condition', 'sto_condition', 'sda_chk', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence']
    PROBE_WIDTHS = {'cnt_zero': 1, 'cnt_reload': 1, 'clk_en': 1, 'slave_wait': 1, 'scl_sync': 1, 'cscl': 1, 'csda': 1, 'dscl': 1, 'sta_condition': 1, 'sto_condition': 1, 'sda_chk': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self._reset_state()

    def _reset_state(self):
        self.state = 'idle'
        self.cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0
        self.scl_oen = 1
        self.sda_oen = 1
        self.cnt = 0
        self.clk_en = 1
        self.filter_cnt = 0
        self.cSCL_meta = 1
        self.cSDA_meta = 1
        self.cSCL = 1
        self.cSDA = 1
        self.fSCL = 7
        self.fSDA = 7
        self.dSCL = 1
        self.dSDA = 1

    def _filtered_values(self):
        scl_ones = ((self.fSCL >> 0) & 1) + ((self.fSCL >> 1) & 1) + ((self.fSCL >> 2) & 1)
        sda_ones = ((self.fSDA >> 0) & 1) + ((self.fSDA >> 1) & 1) + ((self.fSDA >> 2) & 1)
        return (scl_ones >= 2, sda_ones >= 2)

    def _conditions(self, i):
        sscl, ssda = self._filtered_values()
        sta = bool(not ssda and self.dSDA and sscl)
        sto = bool(ssda and not self.dSDA and sscl)
        slave = bool(self.scl_oen and not sscl)
        sync = bool(self.scl_oen and self.dSCL and not sscl)
        reload = bool(i['rst'] or not i['nReset'] or not i['ena'] or sync or (self.cnt == 0 and not slave))
        return {
            'sscl': sscl,
            'ssda': ssda,
            'sta': sta,
            'sto': sto,
            'slave_wait': slave,
            'scl_sync': sync,
            'cnt_reload': bool(reload),
        }

    def _phase_values(self, state, din):
        din = self.mask(din, 1)
        if state == 'start_a':
            return (1, 1)
        if state == 'start_b':
            return (1, 0)
        if state == 'start_c':
            return (0, 0)
        if state == 'stop_a':
            return (0, 0)
        if state == 'stop_b':
            return (1, 0)
        if state == 'stop_c':
            return (1, 1)
        if state == 'rd_a':
            return (0, 1)
        if state == 'rd_b':
            return (1, 1)
        if state == 'rd_c':
            return (0, 1)
        if state == 'wr_a':
            return (0, din)
        if state == 'wr_b':
            return (1, din)
        if state == 'wr_c':
            return (0, din)
        return (1, 1)

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        if not i['nReset']:
            o['cmd_ack'] = 0
            o['busy'] = 0
            o['al'] = 0
            o['dout'] = 0
            o['scl_o'] = 0
            o['scl_oen'] = 1
            o['sda_o'] = 0
            o['sda_oen'] = 1
            self.cnt_zero = True
            self.cnt_reload = True
            self.clk_en = True
            self.slave_wait = False
            self.scl_sync = False
            self.cscl = True
            self.csda = True
            self.dscl = True
            self.sta_condition = False
            self.sto_condition = False
            self.sda_chk = False
            self.fsm_active = False
            self.in_start_sequence = False
            self.in_stop_sequence = False
            self.in_read_sequence = False
            self.in_write_sequence = False
            return o

        cond = self._conditions(i)
        o['cmd_ack'] = int(bool(self.cmd_ack))
        o['busy'] = int(bool(self.busy))
        o['al'] = int(bool(self.al))
        o['dout'] = int(bool(self.dout))
        o['scl_o'] = 0
        o['scl_oen'] = int(bool(self.scl_oen))
        o['sda_o'] = 0
        o['sda_oen'] = int(bool(self.sda_oen))

        self.cnt_zero = bool(self.cnt == 0)
        self.cnt_reload = cond['cnt_reload']
        self.clk_en = bool(self.clk_en and not cond['slave_wait'])
        self.slave_wait = cond['slave_wait']
        self.scl_sync = cond['scl_sync']
        self.cscl = bool(self.cSCL)
        self.csda = bool(self.cSDA)
        self.dscl = bool(self.dSCL)
        self.sta_condition = cond['sta']
        self.sto_condition = cond['sto']
        self.sda_chk = bool(self.state == 'wr_b' and not self.al)
        self.fsm_active = bool(self.state != 'idle')
        self.in_start_sequence = bool(self.state.startswith('start_'))
        self.in_stop_sequence = bool(self.state.startswith('stop_'))
        self.in_read_sequence = bool(self.state.startswith('rd_'))
        self.in_write_sequence = bool(self.state.startswith('wr_'))
        return o

    def advance(self, i):
        if not i['nReset'] or i['rst']:
            self._reset_state()
            return

        cond = self._conditions(i)
        sscl = cond['sscl']
        ssda = cond['ssda']
        old_cSCL_meta = self.cSCL_meta
        old_cSDA_meta = self.cSDA_meta
        old_cSCL = self.cSCL
        old_cSDA = self.cSDA

        if cond['sta']:
            self.busy = 1
        elif cond['sto']:
            self.busy = 0

        if sscl and not self.dSCL:
            self.dout = int(bool(ssda))

        self.dSCL = int(bool(sscl))
        self.dSDA = int(bool(ssda))
        self.cSCL_meta = self.mask(i['scl_i'], 1)
        self.cSDA_meta = self.mask(i['sda_i'], 1)
        self.cSCL = old_cSCL_meta
        self.cSDA = old_cSDA_meta

        if not i['ena']:
            self.filter_cnt = 0
        elif self.filter_cnt == 0:
            interval = self.mask(i['clk_cnt'], 16) >> 2
            self.filter_cnt = self.mask(interval, 14)
            self.fSCL = self.mask((self.fSCL << 1) | old_cSCL, 3)
            self.fSDA = self.mask((self.fSDA << 1) | old_cSDA, 3)
        else:
            self.filter_cnt = self.mask(self.filter_cnt - 1, 14)

        if not i['ena']:
            self.cnt = self.mask(i['clk_cnt'], 16)
            self.clk_en = 1
        elif cond['scl_sync']:
            self.cnt = self.mask(i['clk_cnt'], 16)
            self.clk_en = 1
        elif cond['slave_wait']:
            self.clk_en = 0
        elif self.cnt == 0:
            self.cnt = self.mask(i['clk_cnt'], 16)
            self.clk_en = 1
        else:
            self.cnt = self.mask(self.cnt - 1, 16)
            self.clk_en = 0

        arbitration_loss = bool(
            (self.state == 'wr_b' and self.sda_oen and not ssda)
            or (self.state != 'idle' and not self.state.startswith('stop_') and cond['sto'])
        )
        self.cmd_ack = 0

        if self.al:
            self.al = 0
            self.state = 'idle'
            self.scl_oen = 1
            self.sda_oen = 1
        elif arbitration_loss:
            self.al = 1
            self.state = 'idle'
            self.scl_oen = 1
            self.sda_oen = 1
        else:
            self.al = 0
            if self.clk_en and i['ena'] and not cond['slave_wait']:
                if self.state == 'idle':
                    command = self.mask(i['cmd'], 4)
                    if command == 1:
                        self.state = 'start_a'
                    elif command == 2:
                        self.state = 'stop_a'
                    elif command == 8:
                        self.state = 'rd_a'
                    elif command == 4:
                        self.state = 'wr_a'
                    if self.state != 'idle':
                        self.scl_oen, self.sda_oen = self._phase_values(self.state, i['din'])
                else:
                    terminal = self.state in ('start_c', 'stop_c', 'rd_c', 'wr_c')
                    if terminal:
                        self.state = 'idle'
                        self.cmd_ack = 1
                    else:
                        next_state = {
                            'start_a': 'start_b',
                            'start_b': 'start_c',
                            'stop_a': 'stop_b',
                            'stop_b': 'stop_c',
                            'rd_a': 'rd_b',
                            'rd_b': 'rd_c',
                            'wr_a': 'wr_b',
                            'wr_b': 'wr_c',
                        }.get(self.state, self.state)
                        self.state = next_state
                        self.scl_oen, self.sda_oen = self._phase_values(self.state, i['din'])
