"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['cnt_zero', 'cnt_reload', 'clk_en', 'slave_wait', 'scl_sync', 'cscl', 'csda', 'dscl', 'sta_condition', 'sto_condition', 'sda_chk', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence']
    PROBE_WIDTHS = {'cnt_zero': 1, 'cnt_reload': 1, 'clk_en': 1, 'slave_wait': 1, 'scl_sync': 1, 'cscl': 1, 'csda': 1, 'dscl': 1, 'sta_condition': 1, 'sto_condition': 1, 'sda_chk': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self._reset_state(0)

    def _reset_state(self, cnt_value):
        self.state = 'IDLE'
        self.cnt = self.mask(cnt_value, 16)
        self.filter_cnt = 0
        self.cSCL = 1
        self.cSDA = 1
        self.cSCL2 = 1
        self.cSDA2 = 1
        self.fSCL = 7
        self.fSDA = 7
        self.dSCL = 1
        self.dSDA = 1
        self.scl_oen_reg = 1
        self.sda_oen_reg = 1
        self.sda_chk_reg = 0
        self.write_bit = 1
        self.cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0

    def _majority(self, history):
        a = history & 1
        b = (history >> 1) & 1
        c = (history >> 2) & 1
        return (a & b) | (a & c) | (b & c)

    def _apply_phase_outputs(self):
        state = self.state
        self.sda_chk_reg = 0
        if state == 'START_RELEASE':
            self.scl_oen_reg, self.sda_oen_reg = 1, 1
        elif state == 'START_SDA':
            self.scl_oen_reg, self.sda_oen_reg = 1, 0
        elif state == 'START_LOW':
            self.scl_oen_reg, self.sda_oen_reg = 0, 0
        elif state == 'STOP_LOW':
            self.scl_oen_reg, self.sda_oen_reg = 0, 0
        elif state == 'STOP_HIGH':
            self.scl_oen_reg, self.sda_oen_reg = 1, 0
        elif state == 'STOP_RELEASE':
            self.scl_oen_reg, self.sda_oen_reg = 1, 1
        elif state == 'READ_LOW':
            self.scl_oen_reg, self.sda_oen_reg = 0, 1
        elif state == 'READ_HIGH':
            self.scl_oen_reg, self.sda_oen_reg = 1, 1
        elif state == 'READ_END':
            self.scl_oen_reg, self.sda_oen_reg = 0, 1
        elif state == 'WRITE_DATA':
            self.scl_oen_reg, self.sda_oen_reg = 0, self.write_bit
        elif state == 'WRITE_HIGH':
            self.scl_oen_reg, self.sda_oen_reg = 1, self.write_bit
            self.sda_chk_reg = 1
        elif state == 'WRITE_LOW':
            self.scl_oen_reg, self.sda_oen_reg = 0, self.write_bit

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        async_reset = (i['nReset'] & 1) == 0
        state = 'IDLE' if async_reset else self.state
        scl_oen = 1 if async_reset else self.scl_oen_reg
        sda_oen = 1 if async_reset else self.sda_oen_reg
        sscl = 1 if async_reset else self._majority(self.fSCL)
        ssda = 1 if async_reset else self._majority(self.fSDA)
        dscl = 1 if async_reset else self.dSCL
        dsda = 1 if async_reset else self.dSDA
        cnt = 0 if async_reset else self.cnt
        slave_wait = bool(scl_oen and not sscl)
        scl_sync = bool(dscl and not sscl and scl_oen)
        sta_condition = bool((not ssda) and dsda and sscl)
        sto_condition = bool(ssda and (not dsda) and sscl)
        sync_reset = bool(i['rst'] & 1)
        ena = bool(i['ena'] & 1)
        cnt_zero = (cnt == 0)
        cnt_reload = bool(async_reset or sync_reset or (not ena) or scl_sync or (cnt_zero and not slave_wait))
        clk_en = bool((not slave_wait) and (async_reset or sync_reset or (not ena) or cnt_zero or scl_sync))

        self.cnt_zero = bool(cnt_zero)
        self.cnt_reload = bool(cnt_reload)
        self.clk_en = bool(clk_en)
        self.slave_wait = bool(slave_wait)
        self.scl_sync = bool(scl_sync)
        self.cscl = bool(1 if async_reset else self.cSCL)
        self.csda = bool(1 if async_reset else self.cSDA)
        self.dscl = bool(dscl)
        self.sta_condition = bool(sta_condition)
        self.sto_condition = bool(sto_condition)
        self.sda_chk = bool((not async_reset) and self.sda_chk_reg)
        self.fsm_active = bool(state != 'IDLE')
        self.in_start_sequence = bool(state.startswith('START_'))
        self.in_stop_sequence = bool(state.startswith('STOP_'))
        self.in_read_sequence = bool(state.startswith('READ_'))
        self.in_write_sequence = bool(state.startswith('WRITE_'))

        o['cmd_ack'] = 0 if async_reset else self.cmd_ack
        o['busy'] = 0 if async_reset else self.busy
        o['al'] = 0 if async_reset else self.al
        o['dout'] = 0 if async_reset else self.dout
        o['scl_o'] = 0
        o['scl_oen'] = scl_oen
        o['sda_o'] = 0
        o['sda_oen'] = sda_oen
        return o

    def advance(self, i):
        clk_cnt = self.mask(i['clk_cnt'], 16)
        if (i['nReset'] & 1) == 0 or (i['rst'] & 1):
            self._reset_state(clk_cnt)
            return

        ena = bool(i['ena'] & 1)
        scl_sample = self._majority(self.fSCL)
        sda_sample = self._majority(self.fSDA)
        old_dscl = self.dSCL
        old_dsda = self.dSDA
        sta_condition = bool((not sda_sample) and old_dsda and scl_sample)
        sto_condition = bool(sda_sample and (not old_dsda) and scl_sample)
        slave_wait = bool(self.scl_oen_reg and not scl_sample)
        scl_sync = bool(old_dscl and (not scl_sample) and self.scl_oen_reg)
        timing_tick = bool((not slave_wait) and (self.cnt == 0 or scl_sync))

        arbitration_lost = bool(
            (self.sda_chk_reg and self.sda_oen_reg and not sda_sample)
            or (sto_condition and self.state != 'IDLE' and not self.state.startswith('STOP_'))
        )

        if sta_condition:
            self.busy = 1
        elif sto_condition:
            self.busy = 0

        if scl_sample and not old_dscl:
            self.dout = sda_sample

        old_cSCL = self.cSCL
        old_cSDA = self.cSDA
        old_cSCL2 = self.cSCL2
        old_cSDA2 = self.cSDA2
        self.cSCL = i['scl_i'] & 1
        self.cSDA = i['sda_i'] & 1
        self.cSCL2 = old_cSCL
        self.cSDA2 = old_cSDA

        if not ena:
            self.filter_cnt = 0
        elif self.filter_cnt == 0:
            self.fSCL = self.mask((self.fSCL << 1) | old_cSCL2, 3)
            self.fSDA = self.mask((self.fSDA << 1) | old_cSDA2, 3)
            self.filter_cnt = self.mask(clk_cnt >> 2, 14)
        else:
            self.filter_cnt = self.mask(self.filter_cnt - 1, 14)

        self.dSCL = scl_sample
        self.dSDA = sda_sample

        if not ena:
            self.cnt = clk_cnt
        elif scl_sync:
            self.cnt = clk_cnt
        elif slave_wait:
            pass
        elif self.cnt == 0:
            self.cnt = clk_cnt
        else:
            self.cnt = self.mask(self.cnt - 1, 16)

        self.cmd_ack = 0
        self.al = int(arbitration_lost)
        if arbitration_lost:
            self.state = 'IDLE'
            self.scl_oen_reg = 1
            self.sda_oen_reg = 1
            self.sda_chk_reg = 0
            return

        if timing_tick and ena:
            old_state = self.state
            if old_state == 'IDLE':
                command = i['cmd'] & 15
                if command == 1:
                    self.state = 'START_RELEASE'
                elif command == 2:
                    self.state = 'STOP_LOW'
                elif command == 8:
                    self.state = 'READ_LOW'
                elif command == 4:
                    self.write_bit = i['din'] & 1
                    self.state = 'WRITE_DATA'
            elif old_state == 'START_RELEASE':
                self.state = 'START_SDA'
            elif old_state == 'START_SDA':
                self.state = 'START_LOW'
            elif old_state == 'START_LOW':
                self.state = 'IDLE'
                self.cmd_ack = 1
            elif old_state == 'STOP_LOW':
                self.state = 'STOP_HIGH'
            elif old_state == 'STOP_HIGH':
                self.state = 'STOP_RELEASE'
            elif old_state == 'STOP_RELEASE':
                self.state = 'IDLE'
                self.cmd_ack = 1
            elif old_state == 'READ_LOW':
                self.state = 'READ_HIGH'
            elif old_state == 'READ_HIGH':
                self.state = 'READ_END'
            elif old_state == 'READ_END':
                self.state = 'IDLE'
                self.cmd_ack = 1
            elif old_state == 'WRITE_DATA':
                self.state = 'WRITE_HIGH'
            elif old_state == 'WRITE_HIGH':
                self.state = 'WRITE_LOW'
            elif old_state == 'WRITE_LOW':
                self.state = 'IDLE'
                self.cmd_ack = 1

            if self.state != 'IDLE':
                self._apply_phase_outputs()
            elif old_state != 'IDLE':
                self.sda_chk_reg = 0
