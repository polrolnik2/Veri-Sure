"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['cnt_zero', 'cnt_reload', 'clk_en', 'slave_wait', 'scl_sync', 'cscl', 'csda', 'dscl', 'sta_condition', 'sto_condition', 'sda_chk', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence']
    PROBE_WIDTHS = {'cnt_zero': 1, 'cnt_reload': 1, 'clk_en': 1, 'slave_wait': 1, 'scl_sync': 1, 'cscl': 1, 'csda': 1, 'dscl': 1, 'sta_condition': 1, 'sto_condition': 1, 'sda_chk': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.active_cmd = None
        self.cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0
        self.scl_oen = 1
        self.sda_oen = 1
        self.sda_chk = 0
        self.cnt = 0
        self.clk_en = 1
        self.filter_cnt = 0
        self.cSCL = 1
        self.cSDA = 1
        self.fSCL = 7
        self.fSDA = 7
        self.dSCL = 1
        self.dSDA = 1

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        if not i['nReset']:
            o['cmd_ack'] = 0
            o['busy'] = 0
            o['al'] = 0
            o['dout'] = 0
            o['scl_o'] = 0
            o['scl_oen'] = 1
            o['sda_o'] = 0
            o['sda_oen'] = 1
            self.cnt_zero = True
            self.cnt_reload = True
            self.clk_en = True
            self.slave_wait = False
            self.scl_sync = False
            self.cscl = True
            self.csda = True
            self.dscl = True
            self.sta_condition = False
            self.sto_condition = False
            self.sda_chk = False
            self.fsm_active = False
            self.in_start_sequence = False
            self.in_stop_sequence = False
            self.in_read_sequence = False
            self.in_write_sequence = False
            return o

        fscl = self.fSCL
        fsda = self.fSDA
        sscl = int(((fscl & 1) + ((fscl >> 1) & 1) + ((fscl >> 2) & 1)) >= 2)
        ssda = int(((fsda & 1) + ((fsda >> 1) & 1) + ((fsda >> 2) & 1)) >= 2)
        sta = bool((not ssda) and self.dSDA and sscl)
        sto = bool(ssda and (not self.dSDA) and sscl)
        slave_wait = bool(self.scl_oen and (not sscl))
        scl_sync = bool(self.scl_oen and self.dSCL and (not sscl))

        o['cmd_ack'] = self.cmd_ack
        o['busy'] = self.busy
        o['al'] = self.al
        o['dout'] = self.dout
        o['scl_o'] = 0
        o['scl_oen'] = self.scl_oen
        o['sda_o'] = 0
        o['sda_oen'] = self.sda_oen

        self.cnt_zero = bool(self.cnt == 0)
        self.cnt_reload = bool(i['rst'] or (not i['ena']) or scl_sync or ((self.cnt == 0) and (not slave_wait)))
        self.clk_en = bool(self.clk_en)
        self.slave_wait = slave_wait
        self.scl_sync = scl_sync
        self.cscl = bool(self.cSCL)
        self.csda = bool(self.cSDA)
        self.dscl = bool(self.dSCL)
        self.sta_condition = sta
        self.sto_condition = sto
        self.sda_chk = bool(self.sda_chk)
        self.fsm_active = bool(self.state != 'IDLE')
        self.in_start_sequence = bool(self.state in ('START_A', 'START_B', 'START_C'))
        self.in_stop_sequence = bool(self.state in ('STOP_A', 'STOP_B', 'STOP_C'))
        self.in_read_sequence = bool(self.state in ('READ_A', 'READ_B', 'READ_C'))
        self.in_write_sequence = bool(self.state in ('WRITE_A', 'WRITE_B', 'WRITE_C'))
        return o

    def advance(self, i):
        if (not i['nReset']) or i['rst']:
            self.reset()
            return

        sscl = int(((self.fSCL & 1) + ((self.fSCL >> 1) & 1) + ((self.fSCL >> 2) & 1)) >= 2)
        ssda = int(((self.fSDA & 1) + ((self.fSDA >> 1) & 1) + ((self.fSDA >> 2) & 1)) >= 2)
        sta = bool((not ssda) and self.dSDA and sscl)
        sto = bool(ssda and (not self.dSDA) and sscl)
        slave_wait = bool(self.scl_oen and (not sscl))
        scl_sync = bool(self.scl_oen and self.dSCL and (not sscl))
        rising_scl = bool(sscl and (not self.dSCL))

        old_sscl = sscl
        old_ssda = ssda
        old_cscl = self.cSCL
        old_csda = self.cSDA
        old_dscl = self.dSCL
        old_dsda = self.dSDA
        old_fscl = self.fSCL
        old_fsda = self.fSDA

        if sta:
            self.busy = 1
        elif sto:
            self.busy = 0

        if rising_scl:
            self.dout = old_ssda

        arbitration_loss = bool((self.sda_chk and self.sda_oen and (not ssda)) or (sto and self.state != 'IDLE' and self.active_cmd != 'STOP'))
        self.cmd_ack = 0
        self.al = int(arbitration_loss)

        if arbitration_loss:
            self.state = 'IDLE'
            self.active_cmd = None
            self.scl_oen = 1
            self.sda_oen = 1
            self.sda_chk = 0
        elif i['ena'] and self.clk_en and (not slave_wait):
            if self.state == 'IDLE':
                cmd = self.mask(i['cmd'], 4)
                if cmd == 1:
                    self.state = 'START_A'
                    self.active_cmd = 'START'
                elif cmd == 2:
                    self.state = 'STOP_A'
                    self.active_cmd = 'STOP'
                elif cmd == 8:
                    self.state = 'READ_A'
                    self.active_cmd = 'READ'
                elif cmd == 4:
                    self.state = 'WRITE_A'
                    self.active_cmd = 'WRITE'
            elif self.state == 'START_A':
                self.scl_oen = 1
                self.sda_oen = 1
                self.state = 'START_B'
            elif self.state == 'START_B':
                self.scl_oen = 1
                self.sda_oen = 0
                self.state = 'START_C'
            elif self.state == 'START_C':
                self.scl_oen = 0
                self.sda_oen = 0
                self.sda_chk = 0
                self.state = 'IDLE'
                self.active_cmd = None
                self.cmd_ack = 1
            elif self.state == 'STOP_A':
                self.scl_oen = 0
                self.sda_oen = 0
                self.state = 'STOP_B'
            elif self.state == 'STOP_B':
                self.scl_oen = 1
                self.sda_oen = 0
                self.state = 'STOP_C'
            elif self.state == 'STOP_C':
                self.scl_oen = 1
                self.sda_oen = 1
                self.sda_chk = 0
                self.state = 'IDLE'
                self.active_cmd = None
                self.cmd_ack = 1
            elif self.state == 'READ_A':
                self.scl_oen = 0
                self.sda_oen = 1
                self.state = 'READ_B'
            elif self.state == 'READ_B':
                self.scl_oen = 1
                self.sda_oen = 1
                self.state = 'READ_C'
            elif self.state == 'READ_C':
                self.scl_oen = 0
                self.sda_oen = 1
                self.sda_chk = 0
                self.state = 'IDLE'
                self.active_cmd = None
                self.cmd_ack = 1
            elif self.state == 'WRITE_A':
                self.scl_oen = 0
                self.sda_oen = self.mask(i['din'], 1)
                self.sda_chk = 0
                self.state = 'WRITE_B'
            elif self.state == 'WRITE_B':
                self.scl_oen = 1
                self.sda_oen = self.mask(i['din'], 1)
                self.sda_chk = 1
                self.state = 'WRITE_C'
            elif self.state == 'WRITE_C':
                self.scl_oen = 0
                self.sda_oen = self.mask(i['din'], 1)
                self.sda_chk = 0
                self.state = 'IDLE'
                self.active_cmd = None
                self.cmd_ack = 1

        if not i['ena']:
            self.cnt = self.mask(i['clk_cnt'], 16)
            self.clk_en = 1
        elif scl_sync:
            self.cnt = self.mask(i['clk_cnt'], 16)
            self.clk_en = 1
        elif slave_wait:
            self.clk_en = 0
        elif self.cnt == 0:
            self.cnt = self.mask(i['clk_cnt'], 16)
            self.clk_en = 1
        else:
            self.cnt = self.mask(self.cnt - 1, 16)
            self.clk_en = 0

        if not i['ena']:
            self.filter_cnt = 0
        elif self.filter_cnt == 0:
            self.fSCL = self.mask((old_fscl << 1) | old_cscl, 3)
            self.fSDA = self.mask((old_fsda << 1) | old_csda, 3)
            self.filter_cnt = self.mask(i['clk_cnt'] >> 2, 16)
        else:
            self.filter_cnt = self.mask(self.filter_cnt - 1, 16)

        self.cSCL = self.mask(i['scl_i'], 1)
        self.cSDA = self.mask(i['sda_i'], 1)
        self.dSCL = old_sscl
        self.dSDA = old_ssda
