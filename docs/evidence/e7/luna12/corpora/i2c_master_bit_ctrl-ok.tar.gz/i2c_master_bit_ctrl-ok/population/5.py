"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['cnt_zero', 'cnt_reload', 'clk_en', 'slave_wait', 'scl_sync', 'cscl', 'csda', 'dscl', 'sta_condition', 'sto_condition', 'sda_chk', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence']
    PROBE_WIDTHS = {'cnt_zero': 1, 'cnt_reload': 1, 'clk_en': 1, 'slave_wait': 1, 'scl_sync': 1, 'cscl': 1, 'csda': 1, 'dscl': 1, 'sta_condition': 1, 'sto_condition': 1, 'sda_chk': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'idle'
        self.command = 0
        self.scl_oen = 1
        self.sda_oen = 1
        self.cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0
        self.sda_chk = 0
        self.cSCL_meta = 1
        self.cSDA_meta = 1
        self.cSCL = 1
        self.cSDA = 1
        self.fSCL = 7
        self.fSDA = 7
        self.dSCL = 1
        self.dSDA = 1
        self.cnt = 0
        self.filter_cnt = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        fscl = self.fSCL
        fsda = self.fSDA
        sscl = int(((fscl & 1) + ((fscl >> 1) & 1) + ((fscl >> 2) & 1)) >= 2)
        ssda = int(((fsda & 1) + ((fsda >> 1) & 1) + ((fsda >> 2) & 1)) >= 2)
        slave_wait = bool(self.scl_oen and not sscl)
        scl_sync = bool(self.scl_oen and self.dSCL and not sscl)
        cnt_zero = bool(self.cnt == 0)
        clk_en = bool(not slave_wait and (not (i['ena'] & 1) or scl_sync or cnt_zero))
        cnt_reload = bool((not (i['nReset'] & 1)) or (i['rst'] & 1) or not (i['ena'] & 1) or scl_sync or (cnt_zero and not slave_wait))
        sta_condition = bool((not ssda) and self.dSDA and sscl)
        sto_condition = bool(ssda and (not self.dSDA) and sscl)

        if not (i['nReset'] & 1):
            o['cmd_ack'] = 0
            o['busy'] = 0
            o['al'] = 0
            o['dout'] = 0
            o['scl_o'] = 0
            o['scl_oen'] = 1
            o['sda_o'] = 0
            o['sda_oen'] = 1
            self.cnt_zero = True
            self.cnt_reload = True
            self.clk_en = True
            self.slave_wait = False
            self.scl_sync = False
            self.cscl = True
            self.csda = True
            self.dscl = True
            self.sta_condition = False
            self.sto_condition = False
            self.sda_chk = False
            self.fsm_active = False
            self.in_start_sequence = False
            self.in_stop_sequence = False
            self.in_read_sequence = False
            self.in_write_sequence = False
            return o

        o['cmd_ack'] = self.cmd_ack
        o['busy'] = self.busy
        o['al'] = self.al
        o['dout'] = self.dout
        o['scl_o'] = 0
        o['scl_oen'] = self.scl_oen
        o['sda_o'] = 0
        o['sda_oen'] = self.sda_oen

        self.cnt_zero = cnt_zero
        self.cnt_reload = cnt_reload
        self.clk_en = clk_en
        self.slave_wait = slave_wait
        self.scl_sync = scl_sync
        self.cscl = bool(self.cSCL)
        self.csda = bool(self.cSDA)
        self.dscl = bool(self.dSCL)
        self.sta_condition = sta_condition
        self.sto_condition = sto_condition
        self.sda_chk = bool(self.sda_chk)
        self.fsm_active = self.state != 'idle'
        self.in_start_sequence = self.state in ('start_a', 'start_b', 'start_c')
        self.in_stop_sequence = self.state in ('stop_a', 'stop_b', 'stop_c')
        self.in_read_sequence = self.state in ('read_a', 'read_b', 'read_c')
        self.in_write_sequence = self.state in ('write_a', 'write_b', 'write_c')
        return o

    def advance(self, i):
        if not (i['nReset'] & 1) or (i['rst'] & 1):
            self.reset()
            return

        ena = i['ena'] & 1
        clk_cnt = self.mask(i['clk_cnt'], 16)
        fscl = self.fSCL
        fsda = self.fSDA
        sscl = int(((fscl & 1) + ((fscl >> 1) & 1) + ((fscl >> 2) & 1)) >= 2)
        ssda = int(((fsda & 1) + ((fsda >> 1) & 1) + ((fsda >> 2) & 1)) >= 2)
        slave_wait = bool(self.scl_oen and not sscl)
        scl_sync = bool(self.scl_oen and self.dSCL and not sscl)
        cnt_zero = self.cnt == 0
        clk_en = bool(not slave_wait and (not ena or scl_sync or cnt_zero))
        sta_condition = bool((not ssda) and self.dSDA and sscl)
        sto_condition = bool(ssda and (not self.dSDA) and sscl)

        old_al = self.al
        arbitration_lost = bool((self.sda_chk and self.sda_oen and not ssda) or (sto_condition and self.state != 'idle' and self.command != 2))

        if sta_condition:
            self.busy = 1
        elif sto_condition:
            self.busy = 0

        self.al = int(arbitration_lost)
        if sscl and not self.dSCL:
            self.dout = ssda

        self.dSCL = sscl
        self.dSDA = ssda

        if ena:
            if self.filter_cnt == 0:
                self.fSCL = self.mask((self.fSCL << 1) | self.cSCL, 3)
                self.fSDA = self.mask((self.fSDA << 1) | self.cSDA, 3)
                self.filter_cnt = self.mask(clk_cnt >> 2, 14)
            else:
                self.filter_cnt = self.mask(self.filter_cnt - 1, 14)
        else:
            self.filter_cnt = 0

        old_cSCL_meta = self.cSCL_meta
        old_cSDA_meta = self.cSDA_meta
        self.cSCL = old_cSCL_meta
        self.cSDA = old_cSDA_meta
        self.cSCL_meta = i['scl_i'] & 1
        self.cSDA_meta = i['sda_i'] & 1

        if not ena:
            self.cnt = clk_cnt
        elif scl_sync:
            self.cnt = clk_cnt
        elif slave_wait:
            pass
        elif cnt_zero:
            self.cnt = clk_cnt
        else:
            self.cnt = self.mask(self.cnt - 1, 16)

        self.cmd_ack = 0
        if old_al:
            self.state = 'idle'
            self.command = 0
            self.scl_oen = 1
            self.sda_oen = 1
            self.sda_chk = 0
        elif ena and clk_en:
            if self.state == 'idle':
                cmd = i['cmd'] & 15
                if cmd in (1, 2, 4, 8):
                    self.command = cmd
                    self.sda_chk = 0
                    if cmd == 1:
                        self.state = 'start_a'
                    elif cmd == 2:
                        self.state = 'stop_a'
                    elif cmd == 4:
                        self.state = 'write_a'
                    else:
                        self.state = 'read_a'
            elif self.state == 'start_a':
                self.scl_oen = 1
                self.sda_oen = 1
                self.state = 'start_b'
            elif self.state == 'start_b':
                self.scl_oen = 1
                self.sda_oen = 0
                self.state = 'start_c'
            elif self.state == 'start_c':
                self.scl_oen = 0
                self.sda_oen = 0
                self.sda_chk = 0
                self.state = 'idle'
                self.command = 0
                self.cmd_ack = 1
            elif self.state == 'stop_a':
                self.scl_oen = 0
                self.sda_oen = 0
                self.state = 'stop_b'
            elif self.state == 'stop_b':
                self.scl_oen = 1
                self.state = 'stop_c'
            elif self.state == 'stop_c':
                self.sda_oen = 1
                self.sda_chk = 0
                self.state = 'idle'
                self.command = 0
                self.cmd_ack = 1
            elif self.state == 'read_a':
                self.scl_oen = 0
                self.sda_oen = 1
                self.state = 'read_b'
            elif self.state == 'read_b':
                self.scl_oen = 1
                self.state = 'read_c'
            elif self.state == 'read_c':
                self.scl_oen = 0
                self.sda_chk = 0
                self.state = 'idle'
                self.command = 0
                self.cmd_ack = 1
            elif self.state == 'write_a':
                self.scl_oen = 0
                self.sda_oen = i['din'] & 1
                self.state = 'write_b'
            elif self.state == 'write_b':
                self.scl_oen = 1
                self.sda_chk = 1
                self.state = 'write_c'
            elif self.state == 'write_c':
                self.scl_oen = 0
                self.sda_chk = 0
                self.state = 'idle'
                self.command = 0
                self.cmd_ack = 1
