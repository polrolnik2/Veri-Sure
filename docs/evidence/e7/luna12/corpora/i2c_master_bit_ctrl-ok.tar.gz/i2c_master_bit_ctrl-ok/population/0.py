"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['cnt_zero', 'cnt_reload', 'clk_en', 'slave_wait', 'scl_sync', 'cscl', 'csda', 'dscl', 'sta_condition', 'sto_condition', 'sda_chk', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence']
    PROBE_WIDTHS = {'cnt_zero': 1, 'cnt_reload': 1, 'clk_en': 1, 'slave_wait': 1, 'scl_sync': 1, 'cscl': 1, 'csda': 1, 'dscl': 1, 'sta_condition': 1, 'sto_condition': 1, 'sda_chk': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self._state = 'idle'
        self._scl_oen = 1
        self._sda_oen = 1
        self._cmd_ack = 0
        self._busy = 0
        self._al = 0
        self._dout = 0
        self._sda_chk = 0
        self._cnt = 0
        self._clk_en = 1
        self._filter_cnt = 0
        self._meta_scl = 1
        self._meta_sda = 1
        self._cSCL = 1
        self._cSDA = 1
        self._fSCL = 7
        self._fSDA = 7
        self._dSCL = 1
        self._dSDA = 1

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        if not i['nReset']:
            state = 'idle'
            scl_oen = 1
            sda_oen = 1
            cmd_ack = 0
            busy = 0
            al = 0
            dout = 0
            sda_chk = 0
            cnt = 0
            clk_en = 1
            cscl = 1
            csda = 1
            dscl = 1
            sSCL = 1
            sSDA = 1
            slave_wait = False
            scl_sync = False
            sta_condition = False
            sto_condition = False
            cnt_reload = True
        else:
            state = self._state
            scl_oen = self._scl_oen
            sda_oen = self._sda_oen
            cmd_ack = self._cmd_ack
            busy = self._busy
            al = self._al
            dout = self._dout
            sda_chk = self._sda_chk
            cnt = self._cnt
            clk_en = self._clk_en
            cscl = self._cSCL
            csda = self._cSDA
            dscl = self._dSCL
            sSCL = int((((self._fSCL >> 2) & 1) + ((self._fSCL >> 1) & 1) + (self._fSCL & 1)) >= 2)
            sSDA = int((((self._fSDA >> 2) & 1) + ((self._fSDA >> 1) & 1) + (self._fSDA & 1)) >= 2)
            slave_wait = bool(scl_oen and not sSCL)
            scl_sync = bool(scl_oen and self._dSCL and not sSCL)
            sta_condition = bool((not sSDA) and self._dSDA and sSCL)
            sto_condition = bool(sSDA and (not self._dSDA) and sSCL)
            cnt_reload = bool(i['rst'] or (not i['ena']) or scl_sync or ((cnt == 0) and not slave_wait))

        self.cnt_zero = bool(cnt == 0)
        self.cnt_reload = bool(cnt_reload)
        self.clk_en = bool(clk_en)
        self.slave_wait = bool(slave_wait)
        self.scl_sync = bool(scl_sync)
        self.cscl = bool(cscl)
        self.csda = bool(csda)
        self.dscl = bool(dscl)
        self.sta_condition = bool(sta_condition)
        self.sto_condition = bool(sto_condition)
        self.sda_chk = bool(sda_chk)
        self.fsm_active = bool(state != 'idle')
        self.in_start_sequence = bool(state.startswith('start_'))
        self.in_stop_sequence = bool(state.startswith('stop_'))
        self.in_read_sequence = bool(state.startswith('read_'))
        self.in_write_sequence = bool(state.startswith('write_'))

        o['cmd_ack'] = int(cmd_ack)
        o['busy'] = int(busy)
        o['al'] = int(al)
        o['dout'] = int(dout)
        o['scl_o'] = 0
        o['scl_oen'] = int(scl_oen)
        o['sda_o'] = 0
        o['sda_oen'] = int(sda_oen)
        return o

    def advance(self, i):
        if not i['nReset']:
            self.reset()
            return
        if i['rst']:
            self.reset()
            return

        sSCL = int((((self._fSCL >> 2) & 1) + ((self._fSCL >> 1) & 1) + (self._fSCL & 1)) >= 2)
        sSDA = int((((self._fSDA >> 2) & 1) + ((self._fSDA >> 1) & 1) + (self._fSDA & 1)) >= 2)
        sta_condition = bool((not sSDA) and self._dSDA and sSCL)
        sto_condition = bool(sSDA and (not self._dSDA) and sSCL)
        slave_wait = bool(self._scl_oen and not sSCL)
        scl_sync = bool(self._scl_oen and self._dSCL and not sSCL)
        tick = bool(self._clk_en)
        state = self._state
        arbitration_loss = bool(self._sda_chk and self._sda_oen and not sSDA)
        unexpected_stop = bool(sto_condition and state != 'idle' and not state.startswith('stop_'))

        if sta_condition:
            self._busy = 1
        elif sto_condition:
            self._busy = 0

        if sSCL and not self._dSCL:
            self._dout = int(sSDA)

        self._dSCL = int(sSCL)
        self._dSDA = int(sSDA)

        if i['ena']:
            if self._filter_cnt == 0:
                self._fSCL = ((self._fSCL << 1) & 7) | self._cSCL
                self._fSDA = ((self._fSDA << 1) & 7) | self._cSDA
                self._filter_cnt = (self.mask(i['clk_cnt'], 16) >> 2) & 65535
            else:
                self._filter_cnt = (self._filter_cnt - 1) & 65535
        else:
            self._filter_cnt = 0

        old_meta_scl = self._meta_scl
        old_meta_sda = self._meta_sda
        self._meta_scl = int(i['scl_i']) & 1
        self._meta_sda = int(i['sda_i']) & 1
        self._cSCL = old_meta_scl
        self._cSDA = old_meta_sda

        if not i['ena']:
            self._cnt = self.mask(i['clk_cnt'], 16)
            self._clk_en = 1
        elif scl_sync:
            self._cnt = self.mask(i['clk_cnt'], 16)
            self._clk_en = 1
        elif slave_wait:
            self._clk_en = 0
        elif self._cnt == 0:
            self._cnt = self.mask(i['clk_cnt'], 16)
            self._clk_en = 1
        else:
            self._cnt = (self._cnt - 1) & 65535
            self._clk_en = 0

        self._cmd_ack = 0
        if arbitration_loss or unexpected_stop:
            self._al = 1
            self._state = 'idle'
            self._scl_oen = 1
            self._sda_oen = 1
            self._sda_chk = 0
        elif tick and i['ena'] and not slave_wait:
            if state == 'idle':
                self._sda_chk = 0
                cmd = int(i['cmd']) & 15
                if cmd == 1:
                    self._state = 'start_release'
                elif cmd == 2:
                    self._state = 'stop_drive_low'
                elif cmd == 8:
                    self._state = 'read_prepare'
                elif cmd == 4:
                    self._state = 'write_setup'
            elif state == 'start_release':
                self._scl_oen = 1
                self._sda_oen = 1
                self._state = 'start_data_low'
            elif state == 'start_data_low':
                self._scl_oen = 1
                self._sda_oen = 0
                self._state = 'start_clock_low'
            elif state == 'start_clock_low':
                self._scl_oen = 0
                self._state = 'idle'
                self._cmd_ack = 1
            elif state == 'stop_drive_low':
                self._scl_oen = 0
                self._sda_oen = 0
                self._state = 'stop_release_scl'
            elif state == 'stop_release_scl':
                self._scl_oen = 1
                self._state = 'stop_release_sda'
            elif state == 'stop_release_sda':
                self._sda_oen = 1
                self._state = 'idle'
                self._cmd_ack = 1
            elif state == 'read_prepare':
                self._sda_oen = 1
                self._scl_oen = 0
                self._state = 'read_release_scl'
            elif state == 'read_release_scl':
                self._scl_oen = 1
                self._state = 'read_pull_scl_low'
            elif state == 'read_pull_scl_low':
                self._scl_oen = 0
                self._state = 'idle'
                self._cmd_ack = 1
            elif state == 'write_setup':
                self._scl_oen = 0
                self._sda_oen = int(i['din']) & 1
                self._sda_chk = 0
                self._state = 'write_release_scl'
            elif state == 'write_release_scl':
                self._scl_oen = 1
                self._sda_chk = 1
                self._state = 'write_pull_scl_low'
            elif state == 'write_pull_scl_low':
                self._scl_oen = 0
                self._sda_chk = 0
                self._state = 'idle'
                self._cmd_ack = 1
