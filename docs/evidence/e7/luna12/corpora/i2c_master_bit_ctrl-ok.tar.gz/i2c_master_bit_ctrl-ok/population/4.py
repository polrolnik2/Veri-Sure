"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['cnt_zero', 'cnt_reload', 'clk_en', 'slave_wait', 'scl_sync', 'cscl', 'csda', 'dscl', 'sta_condition', 'sto_condition', 'sda_chk', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence']
    PROBE_WIDTHS = {'cnt_zero': 1, 'cnt_reload': 1, 'clk_en': 1, 'slave_wait': 1, 'scl_sync': 1, 'cscl': 1, 'csda': 1, 'dscl': 1, 'sta_condition': 1, 'sto_condition': 1, 'sda_chk': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self._reset_state()

    def _reset_state(self):
        self.state = 'idle'
        self.cnt = 0
        self.clk_en = 1
        self.filter_cnt = 0
        self.sync_scl1 = 1
        self.sync_sda1 = 1
        self.cscl = 1
        self.csda = 1
        self.fSCL = 7
        self.fSDA = 7
        self.dSCL = 1
        self.dSDA = 1
        self.busy = 0
        self.al = 0
        self.dout = 0
        self.cmd_ack = 0
        self.scl_oen = 1
        self.sda_oen = 1
        self.sda_chk = 0

    def _filtered(self):
        scl_ones = ((self.fSCL >> 0) & 1) + ((self.fSCL >> 1) & 1) + ((self.fSCL >> 2) & 1)
        sda_ones = ((self.fSDA >> 0) & 1) + ((self.fSDA >> 1) & 1) + ((self.fSDA >> 2) & 1)
        return bool(scl_ones >= 2), bool(sda_ones >= 2)

    def _events(self):
        s_scl, s_sda = self._filtered()
        sta = bool((not s_sda) and self.dSDA and s_scl)
        sto = bool(s_sda and (not self.dSDA) and s_scl)
        slave_wait = bool(self.scl_oen and (not s_scl))
        scl_sync = bool(self.scl_oen and self.dSCL and (not s_scl))
        return s_scl, s_sda, sta, sto, slave_wait, scl_sync

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        if not i['nReset']:
            o['cmd_ack'] = 0
            o['busy'] = 0
            o['al'] = 0
            o['dout'] = 0
            o['scl_o'] = 0
            o['scl_oen'] = 1
            o['sda_o'] = 0
            o['sda_oen'] = 1
            self.cnt_zero = True
            self.cnt_reload = True
            self.clk_en = True
            self.slave_wait = False
            self.scl_sync = False
            self.cscl = True
            self.csda = True
            self.dscl = True
            self.sta_condition = False
            self.sto_condition = False
            self.sda_chk = False
            self.fsm_active = False
            self.in_start_sequence = False
            self.in_stop_sequence = False
            self.in_read_sequence = False
            self.in_write_sequence = False
            return o

        s_scl, s_sda, sta, sto, slave_wait, scl_sync = self._events()
        reload_due = bool(i['rst']) or (not bool(i['ena'])) or scl_sync or ((not slave_wait) and self.cnt == 0)

        o['cmd_ack'] = int(bool(self.cmd_ack))
        o['busy'] = int(bool(self.busy))
        o['al'] = int(bool(self.al))
        o['dout'] = int(bool(self.dout))
        o['scl_o'] = 0
        o['scl_oen'] = int(bool(self.scl_oen))
        o['sda_o'] = 0
        o['sda_oen'] = int(bool(self.sda_oen))

        self.cnt_zero = bool(self.cnt == 0)
        self.cnt_reload = bool(reload_due)
        self.slave_wait = bool(slave_wait)
        self.scl_sync = bool(scl_sync)
        self.cscl = bool(self.cscl)
        self.csda = bool(self.csda)
        self.dscl = bool(self.dSCL)
        self.sta_condition = bool(sta)
        self.sto_condition = bool(sto)
        self.sda_chk = bool(self.sda_chk)
        self.clk_en = bool(self.clk_en)
        self.fsm_active = bool(self.state != 'idle')
        self.in_start_sequence = bool(self.state.startswith('start_'))
        self.in_stop_sequence = bool(self.state.startswith('stop_'))
        self.in_read_sequence = bool(self.state.startswith('read_'))
        self.in_write_sequence = bool(self.state.startswith('write_'))
        return o

    def advance(self, i):
        if (not i['nReset']) or i['rst']:
            self._reset_state()
            return

        s_scl, s_sda, sta, sto, slave_wait, scl_sync = self._events()
        old_cscl = self.cscl
        old_csda = self.csda
        old_scl_sync1 = self.sync_scl1
        old_sda_sync1 = self.sync_sda1
        active = self.state != 'idle'
        unexpected_stop = bool(sto and active and not self.state.startswith('stop_'))
        arbitration_loss = bool((self.sda_chk and self.sda_oen and (not s_sda)) or unexpected_stop)

        if sta:
            self.busy = 1
        elif sto:
            self.busy = 0

        if s_scl and (not self.dSCL):
            self.dout = int(bool(s_sda))
        self.dSCL = int(bool(s_scl))
        self.dSDA = int(bool(s_sda))

        self.sync_scl1 = self.mask(i['scl_i'], 1)
        self.sync_sda1 = self.mask(i['sda_i'], 1)
        self.cscl = self.mask(old_scl_sync1, 1)
        self.csda = self.mask(old_sda_sync1, 1)

        if not i['ena']:
            self.filter_cnt = 0
        elif self.filter_cnt == 0:
            self.fSCL = ((self.fSCL << 1) | old_cscl) & 7
            self.fSDA = ((self.fSDA << 1) | old_csda) & 7
            self.filter_cnt = self.mask(i['clk_cnt'] >> 2, 14)
        else:
            self.filter_cnt = self.mask(self.filter_cnt - 1, 14)

        self.cmd_ack = 0
        if arbitration_loss:
            self.al = 1
            self.state = 'idle'
            self.scl_oen = 1
            self.sda_oen = 1
            self.sda_chk = 0
        elif self.al:
            self.state = 'idle'
            self.scl_oen = 1
            self.sda_oen = 1
            self.sda_chk = 0
        elif i['ena'] and self.clk_en and (not slave_wait) and (not scl_sync):
            cmd = self.mask(i['cmd'], 4)
            if self.state == 'idle':
                if cmd == 1:
                    self.state = 'start_release'
                    self.scl_oen = 1
                    self.sda_oen = 1
                    self.sda_chk = 0
                elif cmd == 2:
                    self.state = 'stop_sda_low'
                    self.sda_oen = 0
                    self.sda_chk = 0
                elif cmd == 8:
                    self.state = 'read_sda_release'
                    self.sda_oen = 1
                    self.sda_chk = 0
                elif cmd == 4:
                    self.state = 'write_sda'
                    self.scl_oen = 0
                    self.sda_oen = self.mask(i['din'], 1)
                    self.sda_chk = 0
            elif self.state == 'start_release':
                self.state = 'start_sda_low'
                self.scl_oen = 1
                self.sda_oen = 0
            elif self.state == 'start_sda_low':
                self.state = 'start_scl_low'
                self.scl_oen = 0
            elif self.state == 'start_scl_low':
                self.state = 'idle'
                self.cmd_ack = 1
            elif self.state == 'stop_sda_low':
                self.state = 'stop_scl_release'
                self.scl_oen = 1
            elif self.state == 'stop_scl_release':
                self.state = 'stop_sda_release'
                self.sda_oen = 1
            elif self.state == 'stop_sda_release':
                self.state = 'idle'
                self.cmd_ack = 1
            elif self.state == 'read_sda_release':
                self.state = 'read_scl_release'
                self.sda_oen = 1
            elif self.state == 'read_scl_release':
                self.state = 'read_scl_low'
                self.scl_oen = 0
            elif self.state == 'read_scl_low':
                self.state = 'idle'
                self.cmd_ack = 1
            elif self.state == 'write_sda':
                self.state = 'write_scl_release'
                self.scl_oen = 1
                self.sda_chk = 1
            elif self.state == 'write_scl_release':
                self.state = 'write_scl_low'
                self.scl_oen = 0
                self.sda_chk = 0
            elif self.state == 'write_scl_low':
                self.state = 'idle'
                self.cmd_ack = 1
                self.sda_chk = 0

        if scl_sync:
            self.cnt = self.mask(i['clk_cnt'], 16)
            self.clk_en = 1
        elif not i['ena']:
            self.cnt = self.mask(i['clk_cnt'], 16)
            self.clk_en = 1
        elif slave_wait:
            self.clk_en = 0
        elif self.cnt == 0:
            self.cnt = self.mask(i['clk_cnt'], 16)
            self.clk_en = 1
        else:
            self.cnt = self.mask(self.cnt - 1, 16)
            self.clk_en = 0
