"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['cnt_zero', 'cnt_reload', 'clk_en', 'slave_wait', 'scl_sync', 'cscl', 'csda', 'dscl', 'sta_condition', 'sto_condition', 'sda_chk', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence']
    PROBE_WIDTHS = {'cnt_zero': 1, 'cnt_reload': 1, 'clk_en': 1, 'slave_wait': 1, 'scl_sync': 1, 'cscl': 1, 'csda': 1, 'dscl': 1, 'sta_condition': 1, 'sto_condition': 1, 'sda_chk': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'idle'
        self.cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0
        self.scl_oen = 1
        self.sda_oen = 1
        self.sda_chk = False
        self.cnt = 0
        self.clk_en = 1
        self.filter_cnt = 0
        self.cSCL1 = 1
        self.cSCL2 = 1
        self.cSDA1 = 1
        self.cSDA2 = 1
        self.fSCL = 7
        self.fSDA = 7
        self.dSCL = 1
        self.dSDA = 1

    def _filtered(self):
        scl_ones = (self.fSCL & 1) + ((self.fSCL >> 1) & 1) + ((self.fSCL >> 2) & 1)
        sda_ones = (self.fSDA & 1) + ((self.fSDA >> 1) & 1) + ((self.fSDA >> 2) & 1)
        return int(scl_ones >= 2), int(sda_ones >= 2)

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        if (i['nReset'] & 1) == 0:
            self.cnt_zero = True
            self.cnt_reload = True
            self.clk_en = True
            self.slave_wait = False
            self.scl_sync = False
            self.cscl = True
            self.csda = True
            self.dscl = True
            self.sta_condition = False
            self.sto_condition = False
            self.sda_chk = False
            self.fsm_active = False
            self.in_start_sequence = False
            self.in_stop_sequence = False
            self.in_read_sequence = False
            self.in_write_sequence = False
            o['cmd_ack'] = 0
            o['busy'] = 0
            o['al'] = 0
            o['dout'] = 0
            o['scl_o'] = 0
            o['scl_oen'] = 1
            o['sda_o'] = 0
            o['sda_oen'] = 1
            return o

        sSCL, sSDA = self._filtered()
        self.slave_wait = bool(self.scl_oen and not sSCL)
        self.scl_sync = bool(self.scl_oen and self.dSCL and not sSCL)
        self.sta_condition = bool((not sSDA) and self.dSDA and sSCL)
        self.sto_condition = bool(sSDA and (not self.dSDA) and sSCL)
        self.cnt_zero = bool(self.cnt == 0)
        self.cnt_reload = bool((i['rst'] & 1) or not (i['ena'] & 1) or self.scl_sync or (self.cnt == 0 and not self.slave_wait))
        self.cscl = bool(self.cSCL2)
        self.csda = bool(self.cSDA2)
        self.dscl = bool(self.dSCL)
        self.sda_chk = bool(self.sda_chk)
        self.fsm_active = bool(self.state != 'idle')
        self.in_start_sequence = bool(self.state in ('start_a', 'start_b', 'start_c'))
        self.in_stop_sequence = bool(self.state in ('stop_a', 'stop_b'))
        self.in_read_sequence = bool(self.state in ('read_a', 'read_b'))
        self.in_write_sequence = bool(self.state in ('write_a', 'write_b'))
        self.clk_en = bool(self.clk_en)

        o['cmd_ack'] = int(self.cmd_ack)
        o['busy'] = int(self.busy)
        o['al'] = int(self.al)
        o['dout'] = int(self.dout)
        o['scl_o'] = 0
        o['scl_oen'] = int(self.scl_oen)
        o['sda_o'] = 0
        o['sda_oen'] = int(self.sda_oen)
        return o

    def advance(self, i):
        if (i['nReset'] & 1) == 0:
            self.reset()
            return
        if (i['rst'] & 1) != 0:
            self.reset()
            return

        ena = int(i['ena']) & 1
        clk_cnt = self.mask(i['clk_cnt'], 16)
        sSCL, sSDA = self._filtered()
        sta_condition = bool((not sSDA) and self.dSDA and sSCL)
        sto_condition = bool(sSDA and (not self.dSDA) and sSCL)
        slave_wait = bool(self.scl_oen and not sSCL)
        scl_sync = bool(self.scl_oen and self.dSCL and not sSCL)
        old_clk_en = bool(self.clk_en)

        if sta_condition:
            self.busy = 1
        elif sto_condition:
            self.busy = 0

        if sSCL and not self.dSCL:
            self.dout = int(sSDA)

        arbitration_check_lost = bool(self.sda_chk and self.sda_oen and not sSDA)
        unexpected_stop = bool(sto_condition and self.state != 'idle' and self.state not in ('stop_a', 'stop_b'))
        arbitration_event = arbitration_check_lost or unexpected_stop

        old_cSCL1 = self.cSCL1
        old_cSDA1 = self.cSDA1
        sampled_cSCL = self.cSCL2
        sampled_cSDA = self.cSDA2
        self.cSCL1 = int(i['scl_i']) & 1
        self.cSCL2 = old_cSCL1
        self.cSDA1 = int(i['sda_i']) & 1
        self.cSDA2 = old_cSDA1

        if not ena:
            self.filter_cnt = 0
        elif self.filter_cnt == 0:
            self.filter_cnt = self.mask(clk_cnt >> 2, 14)
            self.fSCL = self.mask((self.fSCL << 1) | sampled_cSCL, 3)
            self.fSDA = self.mask((self.fSDA << 1) | sampled_cSDA, 3)
        else:
            self.filter_cnt -= 1

        self.dSCL = sSCL
        self.dSDA = sSDA

        self.cmd_ack = 0
        if not ena:
            self.cnt = clk_cnt
            self.clk_en = 1
        elif scl_sync:
            self.cnt = clk_cnt
            self.clk_en = 1
        elif slave_wait:
            self.clk_en = 0
        elif self.cnt == 0:
            self.cnt = clk_cnt
            self.clk_en = 1
        else:
            self.cnt = self.mask(self.cnt - 1, 16)
            self.clk_en = 0

        if arbitration_event:
            self.al = 1
            self.state = 'idle'
            self.scl_oen = 1
            self.sda_oen = 1
            self.sda_chk = False
        elif ena and old_clk_en and not slave_wait:
            if self.state == 'idle':
                command = self.mask(i['cmd'], 4)
                if command == 1:
                    self.state = 'start_a'
                    self.scl_oen = 1
                    self.sda_oen = 1
                    self.sda_chk = False
                elif command == 2:
                    self.state = 'stop_a'
                    self.sda_oen = 0
                    self.sda_chk = False
                elif command == 8:
                    self.state = 'read_a'
                    self.sda_oen = 1
                    self.sda_chk = False
                elif command == 4:
                    self.state = 'write_a'
                    self.sda_oen = int(i['din']) & 1
                    self.sda_chk = False
            elif self.state == 'start_a':
                self.sda_oen = 0
                self.state = 'start_b'
            elif self.state == 'start_b':
                self.scl_oen = 0
                self.state = 'start_c'
            elif self.state == 'start_c':
                self.state = 'idle'
                self.cmd_ack = 1
            elif self.state == 'stop_a':
                self.scl_oen = 1
                self.state = 'stop_b'
            elif self.state == 'stop_b':
                self.sda_oen = 1
                self.state = 'idle'
                self.cmd_ack = 1
            elif self.state == 'read_a':
                self.scl_oen = 1
                self.state = 'read_b'
            elif self.state == 'read_b':
                self.scl_oen = 0
                self.state = 'idle'
                self.cmd_ack = 1
            elif self.state == 'write_a':
                self.scl_oen = 1
                self.sda_chk = True
                self.state = 'write_b'
            elif self.state == 'write_b':
                self.scl_oen = 0
                self.sda_chk = False
                self.state = 'idle'
                self.cmd_ack = 1
