"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'dcnt_nonzero', 'cnt_done', 'core_ack', 'core_rxd', 'core_txd', 'core_cmd_start', 'core_cmd_read', 'core_cmd_write', 'core_cmd_stop', 'core_cmd_nop', 'core_cmd', 'bit_controller', 'i2c_master_bit_ctrl', 'contentreference']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'dcnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_rxd': 1, 'core_txd': 1, 'core_cmd_start': 1, 'core_cmd_read': 1, 'core_cmd_write': 1, 'core_cmd_stop': 1, 'core_cmd_nop': 1, 'core_cmd': 1, 'bit_controller': 1, 'i2c_master_bit_ctrl': 1, 'contentreference': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'ST_IDLE'
        self.core_cmd = 'NOP'
        self.sr = 0
        self.dcnt = 0
        self.cmd_ack = 0
        self.ack_out = 0
        self.busy = 0
        self.arbitration_lost = 0

    def _bit(self, i, name, default=0):
        return self.mask(int(i.get(name, default)), 1)

    def _controls(self, i, state, cmd, cmd_ack, sr, dcnt):
        go = int(bool(self._bit(i, 'read') or self._bit(i, 'write') or self._bit(i, 'stop')) and not cmd_ack)
        core_ack = int(cmd != 'NOP')
        core_rxd = self._bit(i, 'sda_i')
        aborted = bool(self._bit(i, 'rst') or not self._bit(i, 'nReset', 1) or self.arbitration_lost)
        ld = int(state == 'ST_IDLE' and go and not aborted)
        shift = 0
        if not aborted and core_ack:
            if state == 'ST_READ':
                shift = 1
            elif state == 'ST_WRITE' and dcnt != 0:
                shift = 1
        core_txd = self._bit(i, 'ack_in') if state == 'ST_ACK' and cmd == 'WRITE' else ((sr >> 7) & 1)
        return go, ld, shift, core_ack, core_rxd, core_txd

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        async_reset = not self._bit(i, 'nReset', 1)
        state = 'ST_IDLE' if async_reset else self.state
        cmd = 'NOP' if async_reset else self.core_cmd
        sr = 0 if async_reset else self.sr
        dcnt = 0 if async_reset else self.dcnt
        cmd_ack = 0 if async_reset else self.cmd_ack
        ack_out = 0 if async_reset else self.ack_out
        go, ld, shift, core_ack, core_rxd, core_txd = self._controls(i, state, cmd, cmd_ack, sr, dcnt)

        self.st_idle = int(state == 'ST_IDLE')
        self.st_start = int(state == 'ST_START')
        self.st_read = int(state == 'ST_READ')
        self.st_write = int(state == 'ST_WRITE')
        self.st_ack = int(state == 'ST_ACK')
        self.st_stop = int(state == 'ST_STOP')
        self.go = go
        self.ld = ld
        self.shift = shift
        self.dcnt_nonzero = int(dcnt != 0)
        self.cnt_done = int(dcnt == 0)
        self.core_ack = core_ack
        self.core_rxd = core_rxd
        self.core_txd = core_txd
        self.core_cmd_start = int(cmd == 'START')
        self.core_cmd_read = int(cmd == 'READ')
        self.core_cmd_write = int(cmd == 'WRITE')
        self.core_cmd_stop = int(cmd == 'STOP')
        self.core_cmd_nop = int(cmd == 'NOP')
        self.core_cmd = int(cmd != 'NOP')
        self.bit_controller = 1
        self.i2c_master_bit_ctrl = 1
        self.contentreference = 1

        o['cmd_ack'] = cmd_ack
        o['ack_out'] = ack_out
        o['dout'] = sr
        o['i2c_busy'] = 0 if async_reset else self.busy
        o['i2c_al'] = 0 if async_reset else self.arbitration_lost
        # The lower-level controller's waveform is outside this byte-level model;
        # use an idle, released open-drain interface as its deterministic default.
        o['scl_o'] = 0
        o['scl_oen'] = 1
        o['sda_o'] = 0
        o['sda_oen'] = 1
        return o

    def advance(self, i):
        if not self._bit(i, 'nReset', 1) or self._bit(i, 'rst'):
            self.reset()
            return

        if self.arbitration_lost:
            self.state = 'ST_IDLE'
            self.core_cmd = 'NOP'
            self.cmd_ack = 0
            return

        state = self.state
        cmd = self.core_cmd
        go, ld, shift, core_ack, core_rxd, core_txd = self._controls(
            i, state, cmd, self.cmd_ack, self.sr, self.dcnt
        )
        cnt_done = self.dcnt == 0

        if ld:
            self.sr = self.mask(i.get('din', 0), 8)
            self.dcnt = 7
        elif shift:
            self.sr = self.mask((self.sr << 1) | core_rxd, 8)
            self.dcnt = self.mask(self.dcnt - 1, 3)

        if state == 'ST_IDLE':
            if go:
                if self._bit(i, 'start'):
                    self.state = 'ST_START'
                    self.core_cmd = 'START'
                elif self._bit(i, 'read'):
                    self.state = 'ST_READ'
                    self.core_cmd = 'READ'
                elif self._bit(i, 'write'):
                    self.state = 'ST_WRITE'
                    self.core_cmd = 'WRITE'
                else:
                    self.state = 'ST_STOP'
                    self.core_cmd = 'STOP'
            else:
                self.core_cmd = 'NOP'
                self.cmd_ack = 0

        elif state == 'ST_START':
            if core_ack:
                self.busy = 1
                if self._bit(i, 'read'):
                    self.state = 'ST_READ'
                    self.core_cmd = 'READ'
                else:
                    self.state = 'ST_WRITE'
                    self.core_cmd = 'WRITE'

        elif state == 'ST_WRITE':
            if core_ack:
                if cnt_done:
                    self.state = 'ST_ACK'
                    self.core_cmd = 'READ'
                else:
                    self.core_cmd = 'WRITE'

        elif state == 'ST_READ':
            if core_ack:
                if cnt_done:
                    self.state = 'ST_ACK'
                    self.core_cmd = 'WRITE'
                else:
                    self.core_cmd = 'READ'

        elif state == 'ST_ACK':
            if core_ack:
                if cmd == 'READ':
                    self.ack_out = core_rxd
                if self._bit(i, 'stop'):
                    self.state = 'ST_STOP'
                    self.core_cmd = 'STOP'
                else:
                    self.state = 'ST_IDLE'
                    self.core_cmd = 'NOP'
                    self.cmd_ack = 1

        elif state == 'ST_STOP':
            if core_ack:
                self.busy = 0
                self.state = 'ST_IDLE'
                self.core_cmd = 'NOP'
                self.cmd_ack = 1
