"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'dcnt_nonzero', 'cnt_done', 'core_ack', 'core_rxd', 'core_txd', 'core_cmd_start', 'core_cmd_read', 'core_cmd_write', 'core_cmd_stop', 'core_cmd_nop', 'core_cmd', 'bit_controller', 'i2c_master_bit_ctrl', 'contentreference']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'dcnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_rxd': 1, 'core_txd': 1, 'core_cmd_start': 1, 'core_cmd_read': 1, 'core_cmd_write': 1, 'core_cmd_stop': 1, 'core_cmd_nop': 1, 'core_cmd': 1, 'bit_controller': 1, 'i2c_master_bit_ctrl': 1, 'contentreference': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self._clear_state()

    def _clear_state(self):
        self.state = 'ST_IDLE'
        self.sr = 0
        self.dcnt = 0
        self.cmd_ack = 0
        self.ack_out = 0
        self.read_flow = False
        self.busy = 0

    def _abort(self):
        self.state = 'ST_IDLE'
        self.cmd_ack = 0
        self.ack_out = 0
        self.read_flow = False

    def _signals(self, i):
        async_reset = int(i['nReset']) == 0
        state = 'ST_IDLE' if async_reset else self.state
        sr = 0 if async_reset else self.sr
        dcnt = 0 if async_reset else self.dcnt
        cmd_ack = 0 if async_reset else self.cmd_ack
        ack_out = 0 if async_reset else self.ack_out
        busy = 0 if async_reset else self.busy
        read_flow = False if async_reset else self.read_flow

        go = int(bool((int(i['read']) | int(i['write']) | int(i['stop'])) and not cmd_ack))
        active = state in ('ST_START', 'ST_READ', 'ST_WRITE', 'ST_ACK', 'ST_STOP')
        # The lower-level bit controller is abstracted as completing an active
        # byte-controller command. Optional internal-signal keys permit a harness
        # to provide those otherwise non-port signals explicitly.
        core_ack = int(i.get('core_ack', int(active))) & 1
        core_rxd = int(i.get('core_rxd', i['sda_i'])) & 1
        ld = int(state == 'ST_IDLE' and bool(go))
        shift = int(bool(core_ack and (state == 'ST_READ' or
                                       (state == 'ST_WRITE' and dcnt != 0))))
        cnt_done = int(dcnt == 0)

        command = 'NOP'
        if state == 'ST_START':
            command = 'START'
        elif state == 'ST_READ':
            command = 'READ'
        elif state == 'ST_WRITE':
            command = 'WRITE'
        elif state == 'ST_ACK':
            command = 'WRITE' if read_flow else 'READ'
        elif state == 'ST_STOP':
            command = 'STOP'

        core_txd = int(i['ack_in']) & 1 if state == 'ST_ACK' and read_flow else (sr >> 7) & 1
        i2c_al = 0 if async_reset else int(i.get('i2c_al', 0)) & 1
        return {
            'state': state,
            'sr': sr,
            'dcnt': dcnt,
            'cmd_ack': cmd_ack,
            'ack_out': ack_out,
            'busy': busy,
            'read_flow': read_flow,
            'go': go,
            'ld': ld,
            'shift': shift,
            'cnt_done': cnt_done,
            'core_ack': core_ack,
            'core_rxd': core_rxd,
            'core_txd': core_txd,
            'command': command,
            'i2c_al': i2c_al,
        }

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        s = self._signals(i)

        self.st_idle = s['state'] == 'ST_IDLE'
        self.st_start = s['state'] == 'ST_START'
        self.st_read = s['state'] == 'ST_READ'
        self.st_write = s['state'] == 'ST_WRITE'
        self.st_ack = s['state'] == 'ST_ACK'
        self.st_stop = s['state'] == 'ST_STOP'
        self.go = bool(s['go'])
        self.ld = bool(s['ld'])
        self.shift = bool(s['shift'])
        self.dcnt_nonzero = s['dcnt'] != 0
        self.cnt_done = bool(s['cnt_done'])
        self.core_ack = bool(s['core_ack'])
        self.core_rxd = bool(s['core_rxd'])
        self.core_txd = bool(s['core_txd'])
        self.core_cmd_start = s['command'] == 'START'
        self.core_cmd_read = s['command'] == 'READ'
        self.core_cmd_write = s['command'] == 'WRITE'
        self.core_cmd_stop = s['command'] == 'STOP'
        self.core_cmd_nop = s['command'] == 'NOP'
        self.core_cmd = s['command'] != 'NOP'
        self.bit_controller = True
        self.i2c_master_bit_ctrl = True
        self.contentreference = True

        o['cmd_ack'] = s['cmd_ack']
        o['ack_out'] = s['ack_out']
        o['dout'] = s['sr']
        o['i2c_busy'] = s['busy']
        o['i2c_al'] = s['i2c_al']
        # Waveform and pad-drive values belong to the unspecified bit controller.
        o['scl_o'] = 0
        o['scl_oen'] = 0
        o['sda_o'] = 0
        o['sda_oen'] = 0
        return o

    def advance(self, i):
        if int(i['nReset']) == 0 or int(i['rst']):
            self._clear_state()
            return

        s = self._signals(i)
        if s['i2c_al']:
            self._abort()
            return

        state = self.state
        self.cmd_ack = 0

        if state == 'ST_IDLE':
            if s['go']:
                self.sr = self.mask(i['din'], 8)
                self.dcnt = 7
                if int(i['start']):
                    self.state = 'ST_START'
                    self.read_flow = False
                elif int(i['read']):
                    self.state = 'ST_READ'
                    self.read_flow = True
                elif int(i['write']):
                    self.state = 'ST_WRITE'
                    self.read_flow = False
                else:
                    self.state = 'ST_STOP'
                    self.read_flow = False

        elif state == 'ST_START':
            if s['core_ack']:
                if int(i['read']):
                    self.state = 'ST_READ'
                    self.read_flow = True
                else:
                    self.state = 'ST_WRITE'
                    self.read_flow = False
                self.busy = 1

        elif state == 'ST_WRITE':
            if s['core_ack']:
                if s['cnt_done']:
                    self.state = 'ST_ACK'
                else:
                    self.sr = self.mask((self.sr << 1) | s['core_rxd'], 8)
                    self.dcnt = self.mask(self.dcnt - 1, 3)

        elif state == 'ST_READ':
            if s['core_ack']:
                self.sr = self.mask((self.sr << 1) | s['core_rxd'], 8)
                self.dcnt = self.mask(self.dcnt - 1, 3)
                if s['cnt_done']:
                    self.state = 'ST_ACK'

        elif state == 'ST_ACK':
            if s['core_ack']:
                if not self.read_flow:
                    self.ack_out = s['core_rxd']
                if int(i['stop']):
                    self.state = 'ST_STOP'
                else:
                    self.state = 'ST_IDLE'
                    self.cmd_ack = 1

        elif state == 'ST_STOP':
            if s['core_ack']:
                self.state = 'ST_IDLE'
                self.cmd_ack = 1
                self.busy = 0
