"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'dcnt_nonzero', 'cnt_done', 'core_ack', 'core_rxd', 'core_txd', 'core_cmd_start', 'core_cmd_read', 'core_cmd_write', 'core_cmd_stop', 'core_cmd_nop', 'core_cmd', 'bit_controller', 'i2c_master_bit_ctrl', 'contentreference']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'dcnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_rxd': 1, 'core_txd': 1, 'core_cmd_start': 1, 'core_cmd_read': 1, 'core_cmd_write': 1, 'core_cmd_stop': 1, 'core_cmd_nop': 1, 'core_cmd': 1, 'bit_controller': 1, 'i2c_master_bit_ctrl': 1, 'contentreference': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'IDLE'
        self.sr = 0
        self.dcnt = 0
        self.cmd = 'NOP'
        self.cmd_ack = 0
        self.ack_out = 0
        self.ld = 0
        self.shift = 0
        self.op_read = 0
        self.busy = 0
        self.al = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        reset_visible = (int(i['nReset']) & 1) == 0
        if reset_visible:
            state = 'IDLE'
            sr = 0
            dcnt = 0
            cmd = 'NOP'
            cmd_ack = 0
            ack_out = 0
            ld = 0
            shift = 0
            busy = 0
            al = 0
            op_read = 0
        else:
            state = self.state
            sr = self.sr
            dcnt = self.dcnt
            cmd = self.cmd
            cmd_ack = self.cmd_ack
            ack_out = self.ack_out
            ld = self.ld
            shift = self.shift
            busy = self.busy
            al = self.al
            op_read = self.op_read

        go = bool(((int(i['read']) | int(i['write']) | int(i['stop'])) != 0) and not cmd_ack)
        core_ack = bool(cmd != 'NOP')
        core_rxd = bool(int(i['sda_i']) & 1) if not reset_visible else False
        if state == 'ACK' and op_read:
            core_txd = bool(int(i['ack_in']) & 1) if not reset_visible else False
        else:
            core_txd = bool((sr >> 7) & 1)

        self.st_idle = (state == 'IDLE')
        self.st_start = (state == 'START')
        self.st_read = (state == 'READ')
        self.st_write = (state == 'WRITE')
        self.st_ack = (state == 'ACK')
        self.st_stop = (state == 'STOP')
        self.go = go
        self.ld = bool(ld)
        self.shift = bool(shift)
        self.dcnt_nonzero = bool(dcnt != 0)
        self.cnt_done = bool(dcnt == 0)
        self.core_ack = core_ack
        self.core_rxd = core_rxd
        self.core_txd = core_txd
        self.core_cmd_start = (cmd == 'START')
        self.core_cmd_read = (cmd == 'READ')
        self.core_cmd_write = (cmd == 'WRITE')
        self.core_cmd_stop = (cmd == 'STOP')
        self.core_cmd_nop = (cmd == 'NOP')
        self.core_cmd = (cmd != 'NOP')
        self.bit_controller = True
        self.i2c_master_bit_ctrl = True
        self.contentreference = True

        o['cmd_ack'] = self.mask(cmd_ack, 1)
        o['ack_out'] = self.mask(ack_out, 1)
        o['dout'] = self.mask(sr, 8)
        o['i2c_busy'] = self.mask(busy, 1)
        o['i2c_al'] = self.mask(al, 1)
        o['scl_o'] = 0
        o['scl_oen'] = 1
        o['sda_o'] = 0
        o['sda_oen'] = 1
        return o

    def advance(self, i):
        if (int(i['nReset']) & 1) == 0:
            self.reset()
            return
        if int(i['rst']) & 1:
            self.reset()
            return

        if self.al:
            self.state = 'IDLE'
            self.cmd = 'NOP'
            self.cmd_ack = 0
            self.ack_out = 0
            self.ld = 0
            self.shift = 0
            self.op_read = 0
            return

        old_state = self.state
        command_ack = (self.cmd != 'NOP')
        cnt_done = (self.dcnt == 0)
        rxd = int(i['sda_i']) & 1
        launch = ((int(i['read']) | int(i['write']) | int(i['stop'])) != 0) and not self.cmd_ack

        self.cmd_ack = 0
        self.ld = 0
        self.shift = 0
        self.cmd = 'NOP'

        if old_state == 'IDLE':
            if launch:
                self.sr = self.mask(i['din'], 8)
                self.dcnt = 7
                self.ld = 1
                if int(i['start']) & 1:
                    self.state = 'START'
                    self.cmd = 'START'
                    self.op_read = int(bool(int(i['read']) & 1))
                elif int(i['read']) & 1:
                    self.state = 'READ'
                    self.cmd = 'READ'
                    self.op_read = 1
                elif int(i['write']) & 1:
                    self.state = 'WRITE'
                    self.cmd = 'WRITE'
                    self.op_read = 0
                else:
                    self.state = 'STOP'
                    self.cmd = 'STOP'
                    self.op_read = 0
            else:
                self.state = 'IDLE'

        elif old_state == 'START':
            if command_ack:
                self.busy = 1
                if int(i['read']) & 1:
                    self.state = 'READ'
                    self.cmd = 'READ'
                    self.op_read = 1
                else:
                    self.state = 'WRITE'
                    self.cmd = 'WRITE'
                    self.op_read = 0
            else:
                self.state = 'START'

        elif old_state == 'WRITE':
            if command_ack:
                if cnt_done:
                    self.state = 'ACK'
                    self.cmd = 'READ'
                else:
                    self.sr = self.mask((self.sr << 1) | rxd, 8)
                    self.dcnt = self.mask(self.dcnt - 1, 3)
                    self.shift = 1
                    self.state = 'WRITE'
                    self.cmd = 'WRITE'
            else:
                self.state = 'WRITE'

        elif old_state == 'READ':
            if command_ack:
                self.sr = self.mask((self.sr << 1) | rxd, 8)
                self.dcnt = self.mask(self.dcnt - 1, 3)
                self.shift = 1
                if cnt_done:
                    self.state = 'ACK'
                    self.cmd = 'WRITE'
                    self.op_read = 1
                else:
                    self.state = 'READ'
                    self.cmd = 'READ'
            else:
                self.state = 'READ'

        elif old_state == 'ACK':
            if command_ack:
                if not self.op_read:
                    self.ack_out = rxd
                if int(i['stop']) & 1:
                    self.state = 'STOP'
                    self.cmd = 'STOP'
                else:
                    self.state = 'IDLE'
                    self.cmd = 'NOP'
                    self.cmd_ack = 1
            else:
                self.state = 'ACK'

        elif old_state == 'STOP':
            if command_ack:
                self.state = 'IDLE'
                self.cmd = 'NOP'
                self.cmd_ack = 1
                self.busy = 0
            else:
                self.state = 'STOP'

        else:
            self.state = 'IDLE'
            self.cmd = 'NOP'
