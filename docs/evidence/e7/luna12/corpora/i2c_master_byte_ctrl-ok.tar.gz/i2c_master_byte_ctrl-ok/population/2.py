"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'dcnt_nonzero', 'cnt_done', 'core_ack', 'core_rxd', 'core_txd', 'core_cmd_start', 'core_cmd_read', 'core_cmd_write', 'core_cmd_stop', 'core_cmd_nop', 'core_cmd', 'bit_controller', 'i2c_master_bit_ctrl', 'contentreference']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'dcnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_rxd': 1, 'core_txd': 1, 'core_cmd_start': 1, 'core_cmd_read': 1, 'core_cmd_write': 1, 'core_cmd_stop': 1, 'core_cmd_nop': 1, 'core_cmd': 1, 'bit_controller': 1, 'i2c_master_bit_ctrl': 1, 'contentreference': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'ST_IDLE'
        self.sr = 0
        self.dcnt = 0
        self.core_cmd = 'NOP'
        self.cmd_ack = 0
        self.ack_out = 0
        self.ld = 0
        self.shift = 0
        self.bit_ack = 0
        self.ack_kind = 'NOP'
        self.ack_mode_read = False
        self.busy = 0
        self.bit_al_status = 0
        self.bit_ctrl_inputs = (0, 0, 1, 1)

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        async_reset = not (i['nReset'] & 1)
        if async_reset:
            state = 'ST_IDLE'
            sr = 0
            cmd = 'NOP'
            cmd_ack = 0
            ack_out = 0
            ld = 0
            shift = 0
            dcnt = 0
            busy = 0
            bit_ack = 0
            ack_mode_read = False
        else:
            state = self.state
            sr = self.sr
            cmd = self.core_cmd
            cmd_ack = self.cmd_ack
            ack_out = self.ack_out
            ld = self.ld
            shift = self.shift
            dcnt = self.dcnt
            busy = self.busy
            bit_ack = self.bit_ack
            ack_mode_read = self.ack_mode_read

        go = bool(((i['read'] | i['write'] | i['stop']) & 1) and not cmd_ack)
        core_rxd = 0 if async_reset else (i['sda_i'] & 1)
        core_txd = (i['ack_in'] & 1) if (state == 'ST_ACK' and ack_mode_read and not async_reset) else ((sr >> 7) & 1)

        o['cmd_ack'] = int(cmd_ack)
        o['ack_out'] = int(ack_out)
        o['dout'] = self.mask(sr, 8)
        o['i2c_busy'] = int(busy)
        o['i2c_al'] = int(self.bit_al_status)
        o['scl_o'] = 0
        o['scl_oen'] = 1
        o['sda_o'] = 0
        o['sda_oen'] = 1

        self.st_idle = state == 'ST_IDLE'
        self.st_start = state == 'ST_START'
        self.st_read = state == 'ST_READ'
        self.st_write = state == 'ST_WRITE'
        self.st_ack = state == 'ST_ACK'
        self.st_stop = state == 'ST_STOP'
        self.go = go
        self.ld = bool(ld)
        self.shift = bool(shift)
        self.dcnt_nonzero = bool(dcnt != 0)
        self.cnt_done = bool(dcnt == 0)
        self.core_ack = bool(bit_ack)
        self.core_rxd = bool(core_rxd)
        self.core_txd = bool(core_txd)
        self.core_cmd_start = cmd == 'START'
        self.core_cmd_read = cmd == 'READ'
        self.core_cmd_write = cmd == 'WRITE'
        self.core_cmd_stop = cmd == 'STOP'
        self.core_cmd_nop = cmd == 'NOP'
        self.core_cmd = cmd != 'NOP'
        self.bit_controller = True
        self.i2c_master_bit_ctrl = True
        self.contentreference = True
        return o

    def advance(self, i):
        if not (i['nReset'] & 1) or (i['rst'] & 1):
            self.reset()
            return

        if self.bit_al_status:
            self.state = 'ST_IDLE'
            self.core_cmd = 'NOP'
            self.cmd_ack = 0
            self.ack_out = 0
            self.ld = 0
            self.shift = 0
            self.bit_ack = 0
            self.ack_kind = 'NOP'
            self.ack_mode_read = False
            return

        self.bit_ctrl_inputs = (
            i['ena'] & 1,
            self.mask(i['clk_cnt'], 16),
            i['scl_i'] & 1,
            i['sda_i'] & 1,
        )

        current_state = self.state
        current_cmd = self.core_cmd
        ack_now = bool(self.bit_ack)
        completed_kind = self.ack_kind

        if self.ld:
            self.sr = self.mask(i['din'], 8)
            self.dcnt = 7
        elif self.shift:
            self.sr = self.mask((self.sr << 1) | (i['sda_i'] & 1), 8)
            self.dcnt = self.mask(self.dcnt - 1, 3)

        if ack_now and completed_kind == 'START':
            self.busy = 1
        elif ack_now and completed_kind == 'STOP':
            self.busy = 0

        next_state = current_state
        next_cmd = 'NOP'
        next_cmd_ack = 0
        next_ack_out = self.ack_out
        next_ld = 0
        next_shift = 0
        next_ack_mode_read = self.ack_mode_read

        if current_state == 'ST_IDLE':
            go = bool(((i['read'] | i['write'] | i['stop']) & 1) and not self.cmd_ack)
            if go:
                next_ld = 1
                if i['start'] & 1:
                    next_state = 'ST_START'
                    next_cmd = 'START'
                elif i['read'] & 1:
                    next_state = 'ST_READ'
                    next_cmd = 'READ'
                elif i['write'] & 1:
                    next_state = 'ST_WRITE'
                    next_cmd = 'WRITE'
                else:
                    next_state = 'ST_STOP'
                    next_cmd = 'STOP'
                next_ack_mode_read = False
        elif current_state == 'ST_START':
            if ack_now:
                if i['read'] & 1:
                    next_state = 'ST_READ'
                    next_cmd = 'READ'
                else:
                    next_state = 'ST_WRITE'
                    next_cmd = 'WRITE'
        elif current_state == 'ST_READ':
            if ack_now:
                next_shift = 1
                if self.dcnt == 0:
                    next_state = 'ST_ACK'
                    next_cmd = 'WRITE'
                    next_ack_mode_read = True
                else:
                    next_state = 'ST_READ'
                    next_cmd = 'READ'
        elif current_state == 'ST_WRITE':
            if ack_now:
                if self.dcnt == 0:
                    next_state = 'ST_ACK'
                    next_cmd = 'READ'
                    next_ack_mode_read = False
                else:
                    next_state = 'ST_WRITE'
                    next_cmd = 'WRITE'
                    next_shift = 1
        elif current_state == 'ST_ACK':
            if ack_now:
                next_ack_out = i['sda_i'] & 1
                if i['stop'] & 1:
                    next_state = 'ST_STOP'
                    next_cmd = 'STOP'
                else:
                    next_state = 'ST_IDLE'
                    next_cmd_ack = 1
                next_ack_mode_read = False
        elif current_state == 'ST_STOP':
            if ack_now:
                next_state = 'ST_IDLE'
                next_cmd_ack = 1
                next_ack_mode_read = False
        else:
            next_state = 'ST_IDLE'

        self.state = next_state
        self.core_cmd = next_cmd
        self.cmd_ack = next_cmd_ack
        self.ack_out = next_ack_out
        self.ld = next_ld
        self.shift = next_shift
        self.ack_mode_read = next_ack_mode_read

        if current_cmd != 'NOP':
            self.bit_ack = 1
            self.ack_kind = current_cmd
        else:
            self.bit_ack = 0
            self.ack_kind = 'NOP'
