"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'dcnt_nonzero', 'cnt_done', 'core_ack', 'core_rxd', 'core_txd', 'core_cmd_start', 'core_cmd_read', 'core_cmd_write', 'core_cmd_stop', 'core_cmd_nop', 'core_cmd', 'bit_controller', 'i2c_master_bit_ctrl', 'contentreference']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'dcnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_rxd': 1, 'core_txd': 1, 'core_cmd_start': 1, 'core_cmd_read': 1, 'core_cmd_write': 1, 'core_cmd_stop': 1, 'core_cmd_nop': 1, 'core_cmd': 1, 'bit_controller': 1, 'i2c_master_bit_ctrl': 1, 'contentreference': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'ST_IDLE'
        self.sr = 0
        self.dcnt = 0
        self.cmd_ack = 0
        self.ack_out = 0
        self.pending = False
        self.pending_cmd = 'NOP'
        self.mode = None
        self.busy = 0
        self.al = 0

    def _bit_controller_inputs(self, i):
        return {
            'ena': self.mask(i['ena'], 1),
            'clk_cnt': self.mask(i['clk_cnt'], 16),
            'scl_i': self.mask(i['scl_i'], 1),
            'sda_i': self.mask(i['sda_i'], 1),
        }

    def _bit_controller_outputs(self, i):
        if i.get('nReset', 1) == 0:
            busy = 0
            al = 0
        else:
            busy = self.busy
            al = self.al
        return {
            'i2c_busy': int(bool(busy)),
            'i2c_al': int(bool(al)),
            'scl_o': 0,
            'scl_oen': 0,
            'sda_o': 0,
            'sda_oen': 0,
        }

    def _logic(self, i):
        bus_inputs = self._bit_controller_inputs(i)
        async_reset = (i.get('nReset', 1) == 0)
        if async_reset:
            state = 'ST_IDLE'
            sr = 0
            dcnt = 0
            cmd_ack = 0
            pending = False
            mode = None
        else:
            state = self.state
            sr = self.sr
            dcnt = self.dcnt
            cmd_ack = self.cmd_ack
            pending = self.pending
            mode = self.mode

        go = int(bool((i['read'] or i['write'] or i['stop']) and not cmd_ack))
        core_rxd = bus_inputs['sda_i']
        if async_reset:
            return {
                'state': state, 'go': go, 'cmd': 'NOP', 'ld': 0, 'shift': 0,
                'dcnt': dcnt, 'core_ack': 0, 'core_rxd': core_rxd,
                'core_txd': 0, 'next_state': 'ST_IDLE', 'next_cmd_ack': 0,
                'next_mode': None, 'capture_ack': 0,
            }

        next_state = state
        next_cmd_ack = 0
        next_mode = mode
        cmd = 'NOP'
        ld = 0
        shift = 0
        core_txd = (sr >> 7) & 1
        core_ack = int(bool(pending))
        capture_ack = 0

        if state == 'ST_IDLE':
            if go:
                if i['start']:
                    next_state = 'ST_START'
                    cmd = 'START'
                    ld = 1
                    next_mode = 'read' if i['read'] else 'write'
                elif i['read']:
                    next_state = 'ST_READ'
                    cmd = 'READ'
                    ld = 1
                    next_mode = 'read'
                elif i['write']:
                    next_state = 'ST_WRITE'
                    cmd = 'WRITE'
                    ld = 1
                    next_mode = 'write'
                else:
                    next_state = 'ST_STOP'
                    cmd = 'STOP'
                    next_mode = None

        elif state == 'ST_START':
            cmd = 'START'
            if core_ack:
                if i['read']:
                    next_state = 'ST_READ'
                    cmd = 'READ'
                    next_mode = 'read'
                else:
                    next_state = 'ST_WRITE'
                    cmd = 'WRITE'
                    next_mode = 'write'

        elif state == 'ST_WRITE':
            cmd = 'WRITE'
            if core_ack:
                if dcnt == 0:
                    next_state = 'ST_ACK'
                    cmd = 'READ'
                else:
                    shift = 1

        elif state == 'ST_READ':
            cmd = 'READ'
            if core_ack:
                shift = 1
                if dcnt == 0:
                    next_state = 'ST_ACK'
                    cmd = 'WRITE'
                    core_txd = self.mask(i['ack_in'], 1)

        elif state == 'ST_ACK':
            if mode == 'read':
                core_txd = self.mask(i['ack_in'], 1)
            if core_ack:
                if mode == 'write':
                    capture_ack = 1
                if i['stop']:
                    next_state = 'ST_STOP'
                    cmd = 'STOP'
                else:
                    next_state = 'ST_IDLE'
                    next_mode = None
                    next_cmd_ack = 1

        elif state == 'ST_STOP':
            if core_ack:
                next_state = 'ST_IDLE'
                next_mode = None
                next_cmd_ack = 1

        return {
            'state': state, 'go': go, 'cmd': cmd, 'ld': ld, 'shift': shift,
            'dcnt': dcnt, 'core_ack': core_ack, 'core_rxd': core_rxd,
            'core_txd': core_txd, 'next_state': next_state,
            'next_cmd_ack': next_cmd_ack, 'next_mode': next_mode,
            'capture_ack': capture_ack,
        }

    def outputs(self, i):
        sig = self._logic(i)
        bit_outputs = self._bit_controller_outputs(i)
        async_reset = (i.get('nReset', 1) == 0)
        if async_reset:
            sr = 0
            ack_out = 0
            cmd_ack = 0
        else:
            sr = self.sr
            ack_out = self.ack_out
            cmd_ack = self.cmd_ack

        o = {p: None for p in self.OUTPUT_PORTS}
        o['cmd_ack'] = int(bool(cmd_ack))
        o['ack_out'] = int(bool(ack_out))
        o['dout'] = self.mask(sr, 8)
        o['i2c_busy'] = bit_outputs['i2c_busy']
        o['i2c_al'] = bit_outputs['i2c_al']
        o['scl_o'] = bit_outputs['scl_o']
        o['scl_oen'] = bit_outputs['scl_oen']
        o['sda_o'] = bit_outputs['sda_o']
        o['sda_oen'] = bit_outputs['sda_oen']

        state = sig['state']
        self.st_idle = bool(state == 'ST_IDLE')
        self.st_start = bool(state == 'ST_START')
        self.st_read = bool(state == 'ST_READ')
        self.st_write = bool(state == 'ST_WRITE')
        self.st_ack = bool(state == 'ST_ACK')
        self.st_stop = bool(state == 'ST_STOP')
        self.go = bool(sig['go'])
        self.ld = bool(sig['ld'])
        self.shift = bool(sig['shift'])
        self.dcnt_nonzero = bool(sig['dcnt'] != 0)
        self.cnt_done = bool(sig['dcnt'] == 0)
        self.core_ack = bool(sig['core_ack'])
        self.core_rxd = bool(sig['core_rxd'])
        self.core_txd = bool(sig['core_txd'])
        self.core_cmd_start = bool(sig['cmd'] == 'START')
        self.core_cmd_read = bool(sig['cmd'] == 'READ')
        self.core_cmd_write = bool(sig['cmd'] == 'WRITE')
        self.core_cmd_stop = bool(sig['cmd'] == 'STOP')
        self.core_cmd_nop = bool(sig['cmd'] == 'NOP')
        self.core_cmd = bool(sig['cmd'] != 'NOP')
        self.bit_controller = True
        self.i2c_master_bit_ctrl = True
        self.contentreference = True
        return o

    def advance(self, i):
        if i.get('nReset', 1) == 0 or i['rst']:
            self.reset()
            return

        if self.al:
            self.state = 'ST_IDLE'
            self.pending = False
            self.pending_cmd = 'NOP'
            self.cmd_ack = 0
            self.mode = None
            return

        sig = self._logic(i)
        if self.pending and self.pending_cmd == 'START':
            self.busy = 1
        elif self.pending and self.pending_cmd == 'STOP':
            self.busy = 0

        if sig['ld']:
            self.sr = self.mask(i['din'], 8)
            self.dcnt = 7
        elif sig['shift']:
            self.sr = self.mask((self.sr << 1) | sig['core_rxd'], 8)
            self.dcnt = self.mask(self.dcnt - 1, 3)

        if sig['capture_ack']:
            self.ack_out = self.mask(sig['core_rxd'], 1)

        self.state = sig['next_state']
        self.cmd_ack = sig['next_cmd_ack']
        self.mode = sig['next_mode']

        if sig['cmd'] != 'NOP':
            self.pending = True
            self.pending_cmd = sig['cmd']
        else:
            self.pending = False
            self.pending_cmd = 'NOP'
