"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'dcnt_nonzero', 'cnt_done', 'core_ack', 'core_rxd', 'core_txd', 'core_cmd_start', 'core_cmd_read', 'core_cmd_write', 'core_cmd_stop', 'core_cmd_nop', 'core_cmd', 'bit_controller', 'i2c_master_bit_ctrl', 'contentreference']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'dcnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_rxd': 1, 'core_txd': 1, 'core_cmd_start': 1, 'core_cmd_read': 1, 'core_cmd_write': 1, 'core_cmd_stop': 1, 'core_cmd_nop': 1, 'core_cmd': 1, 'bit_controller': 1, 'i2c_master_bit_ctrl': 1, 'contentreference': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self._reset_all()

    def _reset_all(self):
        self.state = 'IDLE'
        self.sr = 0
        self.dcnt = 0
        self.cmd_ack = 0
        self.ack_out = 0
        self.bit_pending = False
        self.bit_active = 'NOP'
        self.busy = 0
        self.transfer = 'none'

    def _signals(self, i):
        reset_active = not int(i['nReset'])
        if reset_active:
            state = 'IDLE'
            sr = 0
            dcnt = 0
            cmd_ack = 0
            pending = False
            bit_active = 'NOP'
            busy = 0
            transfer = 'none'
        else:
            state = self.state
            sr = self.sr
            dcnt = self.dcnt
            cmd_ack = self.cmd_ack
            pending = self.bit_pending
            bit_active = self.bit_active
            busy = self.busy
            transfer = self.transfer

        go = bool((int(i['read']) | int(i['write']) | int(i['stop'])) and not cmd_ack)
        core_ack = bool(pending)
        core_rxd = int(i['sda_i']) & 1
        core_txd = (sr >> 7) & 1
        ld = False
        shift = False
        command = 'NOP'
        next_state = state
        next_cmd_ack = 0
        capture_ack = False
        next_transfer = transfer

        if state == 'IDLE':
            if go:
                ld = True
                if i['start']:
                    command = 'START'
                    next_state = 'START'
                    next_transfer = 'none'
                elif i['read']:
                    command = 'READ'
                    next_state = 'READ'
                    next_transfer = 'read'
                elif i['write']:
                    command = 'WRITE'
                    next_state = 'WRITE'
                    next_transfer = 'write'
                else:
                    command = 'STOP'
                    next_state = 'STOP'
                    next_transfer = 'none'
        elif state == 'START':
            if core_ack:
                if i['read']:
                    command = 'READ'
                    next_state = 'READ'
                    next_transfer = 'read'
                else:
                    command = 'WRITE'
                    next_state = 'WRITE'
                    next_transfer = 'write'
        elif state == 'WRITE':
            if core_ack:
                if dcnt == 0:
                    command = 'READ'
                    next_state = 'ACK'
                else:
                    command = 'WRITE'
                    next_state = 'WRITE'
                    shift = True
        elif state == 'READ':
            if core_ack:
                shift = True
                if dcnt == 0:
                    command = 'WRITE'
                    next_state = 'ACK'
                    core_txd = int(i['ack_in']) & 1
                else:
                    command = 'READ'
                    next_state = 'READ'
        elif state == 'ACK':
            core_txd = int(i['ack_in']) & 1
            if core_ack:
                capture_ack = True
                if i['stop']:
                    command = 'STOP'
                    next_state = 'STOP'
                else:
                    next_state = 'IDLE'
                    next_cmd_ack = 1
        elif state == 'STOP':
            if core_ack:
                next_state = 'IDLE'
                next_cmd_ack = 1

        arbitration_lost = bool(
            not reset_active
            and pending
            and state == 'WRITE'
            and bit_active == 'WRITE'
            and core_txd == 1
            and int(i['scl_i']) == 1
            and int(i['sda_i']) == 0
        )

        return {
            'state': state,
            'sr': sr,
            'dcnt': dcnt,
            'cmd_ack': cmd_ack,
            'go': go,
            'ld': ld,
            'shift': shift,
            'core_ack': core_ack,
            'core_rxd': core_rxd,
            'core_txd': core_txd,
            'command': command,
            'next_state': next_state,
            'next_cmd_ack': next_cmd_ack,
            'capture_ack': capture_ack,
            'next_transfer': next_transfer,
            'busy': busy,
            'i2c_al': arbitration_lost,
        }

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        s = self._signals(i)
        o['cmd_ack'] = int(s['cmd_ack'])
        o['ack_out'] = 0 if not int(i['nReset']) else int(self.ack_out) & 1
        o['dout'] = self.mask(s['sr'], 8)
        o['i2c_busy'] = int(s['busy'])
        o['i2c_al'] = int(s['i2c_al'])
        o['scl_o'] = 0
        o['scl_oen'] = 1
        o['sda_o'] = 0
        o['sda_oen'] = 1

        self.st_idle = bool(s['state'] == 'IDLE')
        self.st_start = bool(s['state'] == 'START')
        self.st_read = bool(s['state'] == 'READ')
        self.st_write = bool(s['state'] == 'WRITE')
        self.st_ack = bool(s['state'] == 'ACK')
        self.st_stop = bool(s['state'] == 'STOP')
        self.go = bool(s['go'])
        self.ld = bool(s['ld'])
        self.shift = bool(s['shift'])
        self.dcnt_nonzero = bool(s['dcnt'] != 0)
        self.cnt_done = bool(s['dcnt'] == 0)
        self.core_ack = bool(s['core_ack'])
        self.core_rxd = bool(s['core_rxd'])
        self.core_txd = bool(s['core_txd'])
        self.core_cmd_start = bool(s['command'] == 'START')
        self.core_cmd_read = bool(s['command'] == 'READ')
        self.core_cmd_write = bool(s['command'] == 'WRITE')
        self.core_cmd_stop = bool(s['command'] == 'STOP')
        self.core_cmd_nop = bool(s['command'] == 'NOP')
        self.core_cmd = bool(s['command'] != 'NOP')
        self.bit_controller = True
        self.i2c_master_bit_ctrl = True
        self.contentreference = True
        return o

    def advance(self, i):
        s = self._signals(i)
        if not int(i['nReset']):
            self._reset_all()
            return
        if int(i['rst']):
            self._reset_all()
            return
        if s['i2c_al']:
            self.state = 'IDLE'
            self.cmd_ack = 0
            self.ack_out = 0
            self.bit_pending = False
            self.bit_active = 'NOP'
            self.transfer = 'none'
            return

        if s['ld']:
            self.sr = self.mask(i['din'], 8)
            self.dcnt = 7
        elif s['shift']:
            self.sr = self.mask((self.sr << 1) | s['core_rxd'], 8)
            self.dcnt = self.mask(self.dcnt - 1, 3)

        if s['state'] == 'START' and s['core_ack']:
            self.busy = 1
        elif s['state'] == 'STOP' and s['core_ack']:
            self.busy = 0

        self.state = s['next_state']
        self.cmd_ack = int(s['next_cmd_ack'])
        if s['capture_ack']:
            self.ack_out = s['core_rxd']
        self.transfer = s['next_transfer']

        if s['command'] != 'NOP':
            self.bit_pending = True
            self.bit_active = s['command']
        elif s['core_ack']:
            self.bit_pending = False
            self.bit_active = 'NOP'
