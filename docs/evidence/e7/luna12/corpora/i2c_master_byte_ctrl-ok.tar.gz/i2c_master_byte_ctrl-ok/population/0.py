"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'dcnt_nonzero', 'cnt_done', 'core_ack', 'core_rxd', 'core_txd', 'core_cmd_start', 'core_cmd_read', 'core_cmd_write', 'core_cmd_stop', 'core_cmd_nop', 'core_cmd', 'bit_controller', 'i2c_master_bit_ctrl', 'contentreference']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'dcnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_rxd': 1, 'core_txd': 1, 'core_cmd_start': 1, 'core_cmd_read': 1, 'core_cmd_write': 1, 'core_cmd_stop': 1, 'core_cmd_nop': 1, 'core_cmd': 1, 'bit_controller': 1, 'i2c_master_bit_ctrl': 1, 'contentreference': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'ST_IDLE'
        self.sr = 0
        self.dcnt = 0
        self.cmd_ack = 0
        self.ack_out = 0
        self.transfer_read = 0
        self.bit_ack = 0
        self.bit_al = 0
        self.busy = 0

    def _decode(self, i):
        async_reset = int(i.get('nReset', 1)) == 0
        if async_reset:
            state = 'ST_IDLE'
            sr = 0
            dcnt = 0
            cmd_ack = 0
            bit_ack = 0
            transfer_read = 0
        else:
            state = self.state
            sr = self.sr
            dcnt = self.dcnt
            cmd_ack = self.cmd_ack
            bit_ack = self.bit_ack
            transfer_read = self.transfer_read

        read = int(i.get('read', 0)) & 1
        write = int(i.get('write', 0)) & 1
        stop = int(i.get('stop', 0)) & 1
        start = int(i.get('start', 0)) & 1
        ack_in = int(i.get('ack_in', 0)) & 1
        rxd = int(i.get('sda_i', 1)) & 1
        ack = 0 if async_reset else int(bool(bit_ack))
        arbitration_lost = int(bool(self.bit_al))
        go = int(bool((read or write or stop) and not cmd_ack))
        cnt_done = int(dcnt == 0)
        command = 'NOP'
        ld = 0
        shift = 0
        txd = (sr >> 7) & 1

        if not async_reset:
            if state == 'ST_IDLE':
                if go:
                    ld = 1
                    if start:
                        command = 'START'
                    elif read:
                        command = 'READ'
                    elif write:
                        command = 'WRITE'
                    else:
                        command = 'STOP'
            elif state == 'ST_START':
                command = 'START'
            elif state == 'ST_WRITE':
                command = 'WRITE'
                if ack:
                    if cnt_done:
                        command = 'READ'
                    else:
                        shift = 1
            elif state == 'ST_READ':
                command = 'READ'
                if ack:
                    shift = 1
                    if cnt_done:
                        command = 'WRITE'
                        txd = ack_in
            elif state == 'ST_ACK':
                if transfer_read:
                    command = 'WRITE'
                    txd = ack_in
                else:
                    command = 'READ'
            elif state == 'ST_STOP':
                command = 'STOP'

        return {
            'state': state,
            'sr': sr,
            'dcnt': dcnt,
            'cmd_ack': cmd_ack,
            'go': go,
            'ld': ld,
            'shift': shift,
            'cnt_done': cnt_done,
            'ack': ack,
            'rxd': rxd,
            'txd': txd,
            'command': command,
            'read': read,
            'write': write,
            'stop': stop,
            'start': start,
            'ack_in': ack_in,
            'transfer_read': transfer_read,
            'arbitration_lost': arbitration_lost,
            'async_reset': async_reset
        }

    def _lower_interface(self, i, sig):
        # Boundary values for the unspecified lower-level bit controller.
        # The pins are modeled released; clk_cnt and ena are passed to this boundary.
        return {
            'ena': int(i.get('ena', 0)) & 1,
            'clk_cnt': self.mask(i.get('clk_cnt', 0), 16),
            'scl_i': int(i.get('scl_i', 1)) & 1,
            'sda_i': int(i.get('sda_i', 1)) & 1,
            'i2c_busy': 0 if sig['async_reset'] else int(bool(self.busy)),
            'i2c_al': sig['arbitration_lost'],
            'scl_o': 0,
            'scl_oen': 0,
            'sda_o': 0,
            'sda_oen': 0
        }

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        sig = self._decode(i)
        lower = self._lower_interface(i, sig)

        o['cmd_ack'] = sig['cmd_ack']
        o['ack_out'] = 0 if sig['async_reset'] else int(bool(self.ack_out))
        o['dout'] = self.mask(sig['sr'], 8)
        o['i2c_busy'] = lower['i2c_busy']
        o['i2c_al'] = lower['i2c_al']
        o['scl_o'] = lower['scl_o']
        o['scl_oen'] = lower['scl_oen']
        o['sda_o'] = lower['sda_o']
        o['sda_oen'] = lower['sda_oen']

        state = sig['state']
        self.st_idle = bool(state == 'ST_IDLE')
        self.st_start = bool(state == 'ST_START')
        self.st_read = bool(state == 'ST_READ')
        self.st_write = bool(state == 'ST_WRITE')
        self.st_ack = bool(state == 'ST_ACK')
        self.st_stop = bool(state == 'ST_STOP')
        self.go = bool(sig['go'])
        self.ld = bool(sig['ld'])
        self.shift = bool(sig['shift'])
        self.dcnt_nonzero = bool(sig['dcnt'] != 0)
        self.cnt_done = bool(sig['cnt_done'])
        self.core_ack = bool(sig['ack'])
        self.core_rxd = bool(sig['rxd'])
        self.core_txd = bool(sig['txd'])
        self.core_cmd_start = bool(sig['command'] == 'START')
        self.core_cmd_read = bool(sig['command'] == 'READ')
        self.core_cmd_write = bool(sig['command'] == 'WRITE')
        self.core_cmd_stop = bool(sig['command'] == 'STOP')
        self.core_cmd_nop = bool(sig['command'] == 'NOP')
        self.core_cmd = bool(sig['command'] != 'NOP')
        self.bit_controller = True
        self.i2c_master_bit_ctrl = True
        self.contentreference = True
        return o

    def advance(self, i):
        if int(i.get('nReset', 1)) == 0 or int(i.get('rst', 0)) != 0:
            self.reset()
            return

        sig = self._decode(i)
        if sig['arbitration_lost']:
            self.state = 'ST_IDLE'
            self.cmd_ack = 0
            self.bit_ack = 0
            self.transfer_read = 0
            return

        old_state = self.state
        old_ack = sig['ack']

        if sig['ld']:
            self.sr = self.mask(i.get('din', 0), 8)
            self.dcnt = 7
        elif sig['shift']:
            self.sr = self.mask((self.sr << 1) | sig['rxd'], 8)
            self.dcnt = self.mask(self.dcnt - 1, 3)

        self.cmd_ack = 0
        if old_state == 'ST_IDLE' and sig['go']:
            if sig['start']:
                self.state = 'ST_START'
                self.transfer_read = 0
            elif sig['read']:
                self.state = 'ST_READ'
                self.transfer_read = 1
            elif sig['write']:
                self.state = 'ST_WRITE'
                self.transfer_read = 0
            else:
                self.state = 'ST_STOP'
                self.transfer_read = 0
        elif old_state == 'ST_START' and old_ack:
            self.busy = 1
            if sig['read']:
                self.state = 'ST_READ'
                self.transfer_read = 1
            else:
                self.state = 'ST_WRITE'
                self.transfer_read = 0
        elif old_state == 'ST_WRITE' and old_ack and sig['cnt_done']:
            self.state = 'ST_ACK'
        elif old_state == 'ST_READ' and old_ack and sig['cnt_done']:
            self.state = 'ST_ACK'
        elif old_state == 'ST_ACK' and old_ack:
            self.ack_out = sig['rxd']
            if sig['stop']:
                self.state = 'ST_STOP'
            else:
                self.state = 'ST_IDLE'
                self.cmd_ack = 1
        elif old_state == 'ST_STOP' and old_ack:
            self.state = 'ST_IDLE'
            self.cmd_ack = 1
            self.busy = 0

        # Abstract the unspecified bit controller as completing each issued
        # command once, on a later model edge.
        if old_ack:
            self.bit_ack = 0
        elif sig['command'] != 'NOP':
            self.bit_ack = 1
        else:
            self.bit_ack = 0
