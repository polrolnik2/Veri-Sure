"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'dcnt_nonzero', 'cnt_done', 'core_ack', 'core_rxd', 'core_txd', 'core_cmd_start', 'core_cmd_read', 'core_cmd_write', 'core_cmd_stop', 'core_cmd_nop', 'core_cmd', 'bit_controller', 'i2c_master_bit_ctrl', 'contentreference']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'dcnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_rxd': 1, 'core_txd': 1, 'core_cmd_start': 1, 'core_cmd_read': 1, 'core_cmd_write': 1, 'core_cmd_stop': 1, 'core_cmd_nop': 1, 'core_cmd': 1, 'bit_controller': 1, 'i2c_master_bit_ctrl': 1, 'contentreference': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'ST_IDLE'
        self.sr = 0
        self.dcnt = 0
        self.ack_out = 0
        self.busy = 0
        self.bit_al = 0
        self.bit_pending = False
        self.bit_wait = 0
        self.ack_command = 'NOP'

    def _abort(self):
        self.state = 'ST_IDLE'
        self.ack_out = 0
        self.bit_pending = False
        self.bit_wait = 0
        self.ack_command = 'NOP'
        self.bit_al = 0

    def _comb(self, i):
        async_reset = not bool(i.get('nReset', 1))
        if async_reset:
            state = 'ST_IDLE'
            sr = 0
            dcnt = 0
            pending = False
            wait = 0
            ack_command = 'NOP'
        else:
            state = self.state
            sr = self.sr
            dcnt = self.dcnt
            pending = self.bit_pending
            wait = self.bit_wait
            ack_command = self.ack_command

        ena = int(i.get('ena', 1)) & 1
        core_ack = bool(not async_reset and pending and wait == 0 and ena)
        core_rxd = int(i.get('sda_i', 1)) & 1
        cnt_done = (dcnt == 0)
        request = bool(i.get('read', 0) or i.get('write', 0) or i.get('stop', 0))

        command = 'NOP'
        next_state = state
        ld = 0
        shift = 0
        core_txd = (sr >> 7) & 1
        cmd_ack = 0

        if state == 'ST_IDLE':
            if request:
                if i.get('start', 0):
                    next_state = 'ST_START'
                    command = 'START'
                    ld = 1
                elif i.get('read', 0):
                    next_state = 'ST_READ'
                    command = 'READ'
                    ld = 1
                elif i.get('write', 0):
                    next_state = 'ST_WRITE'
                    command = 'WRITE'
                    ld = 1
                else:
                    next_state = 'ST_STOP'
                    command = 'STOP'
        elif state == 'ST_START':
            if core_ack:
                if i.get('read', 0):
                    next_state = 'ST_READ'
                    command = 'READ'
                else:
                    next_state = 'ST_WRITE'
                    command = 'WRITE'
            else:
                command = 'START'
        elif state == 'ST_WRITE':
            command = 'WRITE'
            if core_ack:
                if cnt_done:
                    next_state = 'ST_ACK'
                    command = 'READ'
                else:
                    shift = 1
        elif state == 'ST_READ':
            command = 'READ'
            if core_ack:
                shift = 1
                if cnt_done:
                    next_state = 'ST_ACK'
                    command = 'WRITE'
                    core_txd = int(i.get('ack_in', 0)) & 1
        elif state == 'ST_ACK':
            if ack_command == 'WRITE':
                core_txd = int(i.get('ack_in', 0)) & 1
            if core_ack:
                if i.get('stop', 0):
                    next_state = 'ST_STOP'
                    command = 'STOP'
                else:
                    next_state = 'ST_IDLE'
                    cmd_ack = 1
            else:
                command = ack_command
        elif state == 'ST_STOP':
            if core_ack:
                next_state = 'ST_IDLE'
                cmd_ack = 1
            else:
                command = 'STOP'

        go = bool(request and not cmd_ack)
        return {
            'state': state,
            'next_state': next_state,
            'sr': sr,
            'dcnt': dcnt,
            'cnt_done': cnt_done,
            'command': command,
            'ld': ld,
            'shift': shift,
            'core_ack': core_ack,
            'core_rxd': core_rxd,
            'core_txd': core_txd,
            'cmd_ack': cmd_ack,
            'go': go,
            'clk_cnt': self.mask(i.get('clk_cnt', 0), 16),
        }

    def outputs(self, i):
        d = self._comb(i)
        async_reset = not bool(i.get('nReset', 1))
        o = {p: None for p in self.OUTPUT_PORTS}
        o['cmd_ack'] = int(d['cmd_ack'])
        o['ack_out'] = 0 if async_reset else int(self.ack_out)
        o['dout'] = 0 if async_reset else self.mask(self.sr, 8)
        o['i2c_busy'] = 0 if async_reset else int(self.busy)
        o['i2c_al'] = 0 if async_reset else int(self.bit_al)
        o['scl_o'] = 0
        o['scl_oen'] = 1
        o['sda_o'] = 0
        o['sda_oen'] = 1

        self.st_idle = bool(d['state'] == 'ST_IDLE')
        self.st_start = bool(d['state'] == 'ST_START')
        self.st_read = bool(d['state'] == 'ST_READ')
        self.st_write = bool(d['state'] == 'ST_WRITE')
        self.st_ack = bool(d['state'] == 'ST_ACK')
        self.st_stop = bool(d['state'] == 'ST_STOP')
        self.go = bool(d['go'])
        self.ld = bool(d['ld'])
        self.shift = bool(d['shift'])
        self.dcnt_nonzero = bool(d['dcnt'] != 0)
        self.cnt_done = bool(d['cnt_done'])
        self.core_ack = bool(d['core_ack'])
        self.core_rxd = bool(d['core_rxd'])
        self.core_txd = bool(d['core_txd'])
        self.core_cmd_start = bool(d['command'] == 'START')
        self.core_cmd_read = bool(d['command'] == 'READ')
        self.core_cmd_write = bool(d['command'] == 'WRITE')
        self.core_cmd_stop = bool(d['command'] == 'STOP')
        self.core_cmd_nop = bool(d['command'] == 'NOP')
        self.core_cmd = bool(d['command'] != 'NOP')
        self.bit_controller = True
        self.i2c_master_bit_ctrl = True
        self.contentreference = True
        return o

    def advance(self, i):
        if not bool(i.get('nReset', 1)):
            self.reset()
            return
        if i.get('rst', 0):
            self.reset()
            return
        if self.bit_al:
            self._abort()
            return

        d = self._comb(i)
        old_state = self.state
        old_pending = self.bit_pending
        old_wait = self.bit_wait
        ena = bool(int(i.get('ena', 1)) & 1)

        if d['ld']:
            self.sr = self.mask(i.get('din', 0), 8)
            self.dcnt = 7
        elif d['shift']:
            self.sr = self.mask((self.sr << 1) | d['core_rxd'], 8)
            self.dcnt = self.mask(self.dcnt - 1, 3)

        if old_state == 'ST_ACK' and d['core_ack'] and self.ack_command == 'READ':
            self.ack_out = d['core_rxd']
        if old_state == 'ST_START' and d['core_ack']:
            self.busy = 1
        if old_state == 'ST_STOP' and d['core_ack']:
            self.busy = 0
        if d['next_state'] == 'ST_ACK' and old_state in ('ST_READ', 'ST_WRITE'):
            self.ack_command = 'READ' if old_state == 'ST_WRITE' else 'WRITE'

        self.state = d['next_state']

        if d['core_ack']:
            if d['command'] != 'NOP':
                self.bit_pending = True
                self.bit_wait = 1
            else:
                self.bit_pending = False
                self.bit_wait = 0
        elif old_pending:
            self.bit_pending = True
            self.bit_wait = old_wait - 1 if old_wait > 0 and ena else old_wait
        elif d['command'] != 'NOP':
            self.bit_pending = True
            self.bit_wait = 1
        else:
            self.bit_pending = False
            self.bit_wait = 0

        if (ena and old_state == 'ST_WRITE' and d['command'] == 'WRITE'
                and d['core_txd'] and (int(i.get('scl_i', 1)) & 1)
                and not (int(i.get('sda_i', 1)) & 1)):
            self.bit_al = 1
