"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'ack_out', 'dout', 'i2c_busy', 'i2c_al', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['st_idle', 'st_start', 'st_read', 'st_write', 'st_ack', 'st_stop', 'go', 'ld', 'shift', 'dcnt_nonzero', 'cnt_done', 'core_ack', 'core_rxd', 'core_txd', 'core_cmd_start', 'core_cmd_read', 'core_cmd_write', 'core_cmd_stop', 'core_cmd_nop', 'core_cmd', 'bit_controller', 'i2c_master_bit_ctrl', 'contentreference']
    PROBE_WIDTHS = {'st_idle': 1, 'st_start': 1, 'st_read': 1, 'st_write': 1, 'st_ack': 1, 'st_stop': 1, 'go': 1, 'ld': 1, 'shift': 1, 'dcnt_nonzero': 1, 'cnt_done': 1, 'core_ack': 1, 'core_rxd': 1, 'core_txd': 1, 'core_cmd_start': 1, 'core_cmd_read': 1, 'core_cmd_write': 1, 'core_cmd_stop': 1, 'core_cmd_nop': 1, 'core_cmd': 1, 'bit_controller': 1, 'i2c_master_bit_ctrl': 1, 'contentreference': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self._reset_state()

    def _reset_state(self):
        self.state = 'ST_IDLE'
        self.sr = 0
        self.dcnt = 0
        self.cmd_ack = 0
        self.ack_out = 0
        self.core_ack = 0
        self.busy = 0
        self.i2c_al = 0
        self.read_mode = 0

    def _decode(self, i, reset_view=False):
        if reset_view:
            state = 'ST_IDLE'
            sr = 0
            dcnt = 0
            cmd_ack = 0
            core_ack = 0
            read_mode = 0
        else:
            state = self.state
            sr = self.sr
            dcnt = self.dcnt
            cmd_ack = self.cmd_ack
            core_ack = self.core_ack
            read_mode = self.read_mode

        go = bool((int(i['read']) | int(i['write']) | int(i['stop'])) & (not bool(cmd_ack)))
        cmd = 'NOP'
        ld = False
        shift = False
        next_state = state
        finish = False
        txd = (sr >> 7) & 1

        if not reset_view:
            if state == 'ST_IDLE':
                if go:
                    if int(i['start']) & 1:
                        cmd = 'START'
                        ld = True
                        next_state = 'ST_START'
                    elif int(i['read']) & 1:
                        cmd = 'READ'
                        ld = True
                        next_state = 'ST_READ'
                    elif int(i['write']) & 1:
                        cmd = 'WRITE'
                        ld = True
                        next_state = 'ST_WRITE'
                    else:
                        cmd = 'STOP'
                        next_state = 'ST_STOP'
            elif state == 'ST_START':
                if core_ack:
                    if int(i['read']) & 1:
                        cmd = 'READ'
                        next_state = 'ST_READ'
                    else:
                        cmd = 'WRITE'
                        next_state = 'ST_WRITE'
            elif state == 'ST_WRITE':
                if core_ack:
                    if dcnt == 0:
                        cmd = 'READ'
                        next_state = 'ST_ACK'
                    else:
                        cmd = 'WRITE'
                        shift = True
            elif state == 'ST_READ':
                if core_ack:
                    shift = True
                    if dcnt == 0:
                        cmd = 'WRITE'
                        txd = int(i['ack_in']) & 1
                        next_state = 'ST_ACK'
                    else:
                        cmd = 'READ'
            elif state == 'ST_ACK':
                if read_mode:
                    txd = int(i['ack_in']) & 1
                if core_ack:
                    if int(i['stop']) & 1:
                        cmd = 'STOP'
                        next_state = 'ST_STOP'
                    else:
                        next_state = 'ST_IDLE'
                        finish = True
            elif state == 'ST_STOP':
                if core_ack:
                    next_state = 'ST_IDLE'
                    finish = True

        return {
            'state': state,
            'go': go,
            'cmd': cmd,
            'ld': ld,
            'shift': shift,
            'next_state': next_state,
            'finish': finish,
            'txd': txd & 1,
            'dcnt': dcnt,
            'sr': sr,
            'core_ack': core_ack,
        }

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        reset_view = not (int(i['nReset']) & 1)
        d = self._decode(i, reset_view)

        o['cmd_ack'] = 0 if reset_view else int(self.cmd_ack) & 1
        o['ack_out'] = 0 if reset_view else int(self.ack_out) & 1
        o['dout'] = self.mask(0 if reset_view else self.sr, 8)
        o['i2c_busy'] = 0 if reset_view else int(self.busy) & 1
        o['i2c_al'] = 0 if reset_view else int(self.i2c_al) & 1
        o['scl_o'] = 0
        o['scl_oen'] = 1
        o['sda_o'] = 0
        o['sda_oen'] = 1

        self.st_idle = d['state'] == 'ST_IDLE'
        self.st_start = d['state'] == 'ST_START'
        self.st_read = d['state'] == 'ST_READ'
        self.st_write = d['state'] == 'ST_WRITE'
        self.st_ack = d['state'] == 'ST_ACK'
        self.st_stop = d['state'] == 'ST_STOP'
        self.go = bool(d['go'])
        self.ld = bool(d['ld'])
        self.shift = bool(d['shift'])
        self.dcnt_nonzero = bool(d['dcnt'] != 0)
        self.cnt_done = bool(d['dcnt'] == 0)
        self.core_ack = bool(d['core_ack'])
        self.core_rxd = bool((int(i['sda_i']) & 1) if not reset_view else 0)
        self.core_txd = bool(d['txd'] if not reset_view else 0)
        self.core_cmd_start = d['cmd'] == 'START'
        self.core_cmd_read = d['cmd'] == 'READ'
        self.core_cmd_write = d['cmd'] == 'WRITE'
        self.core_cmd_stop = d['cmd'] == 'STOP'
        self.core_cmd_nop = d['cmd'] == 'NOP'
        self.core_cmd = d['cmd'] != 'NOP'
        self.bit_controller = True
        self.i2c_master_bit_ctrl = True
        self.contentreference = True
        return o

    def advance(self, i):
        if not (int(i['nReset']) & 1):
            self._reset_state()
            return
        if (int(i['rst']) & 1) or self.i2c_al:
            self._reset_state()
            return

        d = self._decode(i)
        old_state = self.state
        old_core_ack = self.core_ack

        if d['ld']:
            self.sr = self.mask(i['din'], 8)
            self.dcnt = 7
        elif d['shift']:
            self.sr = self.mask((self.sr << 1) | (int(i['sda_i']) & 1), 8)
            self.dcnt = self.mask(self.dcnt - 1, 3)

        if old_state == 'ST_ACK' and old_core_ack:
            self.ack_out = int(i['sda_i']) & 1
        if old_state == 'ST_START' and old_core_ack:
            self.busy = 1
        if old_state == 'ST_STOP' and old_core_ack:
            self.busy = 0

        self.state = d['next_state']
        if self.state == 'ST_READ':
            self.read_mode = 1
        elif self.state == 'ST_WRITE':
            self.read_mode = 0
        elif self.state == 'ST_IDLE' and d['finish']:
            self.read_mode = 0

        self.cmd_ack = int(d['finish'])

        # Abstract lower-level completion: a non-NOP command starts a bit operation;
        # an enabled waiting edge produces its completion pulse.
        if d['cmd'] != 'NOP':
            self.core_ack = 0
        elif old_core_ack:
            self.core_ack = 0
        elif old_state != 'ST_IDLE' and (int(i['ena']) & 1):
            self.core_ack = 1
        else:
            self.core_ack = 0
