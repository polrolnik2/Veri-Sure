"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['dcsb_dat_o', 'dcsb_ack_o', 'dcsb_err_o', 'sbbiu_dat_o', 'sbbiu_adr_o', 'sbbiu_cyc_o', 'sbbiu_stb_o', 'sbbiu_we_o', 'sbbiu_sel_o', 'sbbiu_cab_o']
    PROBE_PORTS = ['fifo_dat_i', 'fifo_dat_o', 'fifo_wr', 'fifo_rd', 'fifo_full', 'fifo_empty', 'sel_sb', 'outstanding_store', 'fifo_wr_ack', 'or1200_sb_fifo']
    PROBE_WIDTHS = {'fifo_dat_i': 68, 'fifo_dat_o': 68, 'fifo_wr': 1, 'fifo_rd': 1, 'fifo_full': 1, 'fifo_empty': 1, 'sel_sb': 1, 'outstanding_store': 1, 'fifo_wr_ack': 1, 'or1200_sb_fifo': 1}
    LATENCY_CYCLES = 1

    def reset(self):
        self.implemented = bool(getattr(self, 'OR1200_SB_IMPLEMENTED', getattr(self, 'implemented', True)))
        self.fifo_depth = 16
        self.fifo = []
        self.last_fifo_word = 0
        self.outstanding_store = 0
        self.fifo_wr_ack = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        if not self.implemented:
            self.fifo_dat_i = 0
            self.fifo_dat_o = 0
            self.fifo_wr = 0
            self.fifo_rd = 0
            self.fifo_full = 0
            self.fifo_empty = 1
            self.sel_sb = 0
            self.outstanding_store = 0
            self.fifo_wr_ack = 0
            self.or1200_sb_fifo = 0
            o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)
            o['dcsb_ack_o'] = self.mask(i['sbbiu_ack_i'], 1)
            o['dcsb_err_o'] = self.mask(i['sbbiu_err_i'], 1)
            o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
            o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
            o['sbbiu_cyc_o'] = self.mask(i['dcsb_cyc_i'], 1)
            o['sbbiu_stb_o'] = self.mask(i['dcsb_stb_i'], 1)
            o['sbbiu_we_o'] = self.mask(i['dcsb_we_i'], 1)
            o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
            o['sbbiu_cab_o'] = self.mask(i['dcsb_cab_i'], 1)
            return o

        dat = self.mask(i['dcsb_dat_i'], 32)
        adr = self.mask(i['dcsb_adr_i'], 32)
        byte_sel = self.mask(i['dcsb_sel_i'], 4)
        payload = (byte_sel << 64) | (dat << 32) | adr

        fifo_empty = int(len(self.fifo) == 0)
        fifo_full = int(len(self.fifo) >= self.fifo_depth)
        sel_sb = int((not fifo_empty) or (fifo_empty and self.outstanding_store))
        fifo_rd = int(not self.outstanding_store)
        fifo_wr = int(
            self.mask(i['dcsb_cyc_i'], 1)
            and self.mask(i['dcsb_stb_i'], 1)
            and self.mask(i['dcsb_we_i'], 1)
            and not fifo_full
            and not self.fifo_wr_ack
        )
        fifo_word = self.fifo[0] if self.fifo else self.last_fifo_word
        popped = int(bool(fifo_rd and not fifo_empty))

        self.fifo_dat_i = self.mask(payload, 68)
        self.fifo_dat_o = self.mask(fifo_word, 68)
        self.fifo_wr = int(fifo_wr)
        self.fifo_rd = int(fifo_rd)
        self.fifo_full = int(fifo_full)
        self.fifo_empty = int(fifo_empty)
        self.sel_sb = int(sel_sb)
        self.outstanding_store = int(self.outstanding_store)
        self.fifo_wr_ack = int(self.fifo_wr_ack)
        self.or1200_sb_fifo = int(popped)

        o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)
        if sel_sb:
            o['dcsb_ack_o'] = int(self.fifo_wr_ack)
            o['dcsb_err_o'] = 0
            o['sbbiu_dat_o'] = self.mask(fifo_word >> 32, 32)
            o['sbbiu_adr_o'] = self.mask(fifo_word, 32)
            o['sbbiu_cyc_o'] = 1
            o['sbbiu_stb_o'] = 1
            o['sbbiu_we_o'] = 1
            o['sbbiu_sel_o'] = self.mask(fifo_word >> 64, 4)
            o['sbbiu_cab_o'] = 0
        else:
            o['dcsb_ack_o'] = self.mask(i['sbbiu_ack_i'], 1)
            o['dcsb_err_o'] = self.mask(i['sbbiu_err_i'], 1)
            o['sbbiu_dat_o'] = dat
            o['sbbiu_adr_o'] = adr
            o['sbbiu_cyc_o'] = self.mask(i['dcsb_cyc_i'], 1)
            o['sbbiu_stb_o'] = self.mask(i['dcsb_stb_i'], 1)
            o['sbbiu_we_o'] = self.mask(i['dcsb_we_i'], 1)
            o['sbbiu_sel_o'] = byte_sel
            o['sbbiu_cab_o'] = self.mask(i['dcsb_cab_i'], 1)
        return o

    def advance(self, i):
        if not self.implemented:
            return

        if self.mask(i['rst'], 1):
            self.fifo = []
            self.last_fifo_word = 0
            self.outstanding_store = 0
            self.fifo_wr_ack = 0
            return

        fifo_empty = len(self.fifo) == 0
        fifo_full = len(self.fifo) >= self.fifo_depth
        sel_sb = int((not fifo_empty) or (fifo_empty and self.outstanding_store))
        fifo_wr = int(
            self.mask(i['dcsb_cyc_i'], 1)
            and self.mask(i['dcsb_stb_i'], 1)
            and self.mask(i['dcsb_we_i'], 1)
            and not fifo_full
            and not self.fifo_wr_ack
        )
        fifo_rd = int(not self.outstanding_store)
        pop = bool(fifo_rd and not fifo_empty)

        dat = self.mask(i['dcsb_dat_i'], 32)
        adr = self.mask(i['dcsb_adr_i'], 32)
        byte_sel = self.mask(i['dcsb_sel_i'], 4)
        payload = self.mask((byte_sel << 64) | (dat << 32) | adr, 68)

        next_fifo = list(self.fifo)
        if pop:
            self.last_fifo_word = next_fifo.pop(0)
        if fifo_wr:
            next_fifo.append(payload)
        self.fifo = next_fifo

        if self.mask(i['sbbiu_ack_i'], 1):
            self.outstanding_store = 0
        elif sel_sb or fifo_wr:
            self.outstanding_store = 1
        self.fifo_wr_ack = int(fifo_wr)
