"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['dcsb_dat_o', 'dcsb_ack_o', 'dcsb_err_o', 'sbbiu_dat_o', 'sbbiu_adr_o', 'sbbiu_cyc_o', 'sbbiu_stb_o', 'sbbiu_we_o', 'sbbiu_sel_o', 'sbbiu_cab_o']
    PROBE_PORTS = ['fifo_dat_i', 'fifo_dat_o', 'fifo_wr', 'fifo_rd', 'fifo_full', 'fifo_empty', 'sel_sb', 'outstanding_store', 'fifo_wr_ack', 'or1200_sb_fifo']
    PROBE_WIDTHS = {'fifo_dat_i': 68, 'fifo_dat_o': 68, 'fifo_wr': 1, 'fifo_rd': 1, 'fifo_full': 1, 'fifo_empty': 1, 'sel_sb': 1, 'outstanding_store': 1, 'fifo_wr_ack': 1, 'or1200_sb_fifo': 1}
    LATENCY_CYCLES = 1

    def reset(self):
        if not hasattr(self, 'sb_implemented'):
            self.sb_implemented = True
        self._fifo_depth = 16
        self._fifo = []
        self._outstanding_store = 0
        self._fifo_wr_ack = 0
        self._active_word = 0
        self._active_valid = False

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        sel_i = self.mask(i['dcsb_sel_i'], 4)
        dat_i = self.mask(i['dcsb_dat_i'], 32)
        adr_i = self.mask(i['dcsb_adr_i'], 32)
        fifo_dat_i = self.mask((sel_i << 64) | (dat_i << 32) | adr_i, 68)
        self.fifo_dat_i = fifo_dat_i

        if not self.sb_implemented:
            self.fifo_dat_o = 0
            self.fifo_wr = False
            self.fifo_rd = False
            self.fifo_full = False
            self.fifo_empty = True
            self.sel_sb = False
            self.outstanding_store = False
            self.fifo_wr_ack = False
            self.or1200_sb_fifo = False

            o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)
            o['dcsb_ack_o'] = self.mask(i['sbbiu_ack_i'], 1)
            o['dcsb_err_o'] = self.mask(i['sbbiu_err_i'], 1)
            o['sbbiu_dat_o'] = dat_i
            o['sbbiu_adr_o'] = adr_i
            o['sbbiu_cyc_o'] = self.mask(i['dcsb_cyc_i'], 1)
            o['sbbiu_stb_o'] = self.mask(i['dcsb_stb_i'], 1)
            o['sbbiu_we_o'] = self.mask(i['dcsb_we_i'], 1)
            o['sbbiu_sel_o'] = sel_i
            o['sbbiu_cab_o'] = self.mask(i['dcsb_cab_i'], 1)
            return o

        fifo_empty = len(self._fifo) == 0
        fifo_full = len(self._fifo) >= self._fifo_depth
        outstanding = bool(self._outstanding_store)
        fifo_rd = not outstanding
        fifo_wr = bool(i['dcsb_cyc_i'] and i['dcsb_stb_i'] and i['dcsb_we_i']) and not fifo_full and not bool(self._fifo_wr_ack)
        sel_sb = (not fifo_empty) or (fifo_empty and outstanding)

        if outstanding and self._active_valid:
            fifo_dat_o = self._active_word
        elif not fifo_empty:
            fifo_dat_o = self._fifo[0]
        elif self._active_valid:
            fifo_dat_o = self._active_word
        else:
            fifo_dat_o = 0
        fifo_dat_o = self.mask(fifo_dat_o, 68)

        self.fifo_dat_o = fifo_dat_o
        self.fifo_wr = bool(fifo_wr)
        self.fifo_rd = bool(fifo_rd)
        self.fifo_full = bool(fifo_full)
        self.fifo_empty = bool(fifo_empty)
        self.sel_sb = bool(sel_sb)
        self.outstanding_store = bool(outstanding)
        self.fifo_wr_ack = bool(self._fifo_wr_ack)
        self.or1200_sb_fifo = bool(fifo_rd and not fifo_empty and not i['rst'])

        o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)
        o['dcsb_ack_o'] = self.mask(self._fifo_wr_ack if sel_sb else i['sbbiu_ack_i'], 1)
        o['dcsb_err_o'] = 0 if sel_sb else self.mask(i['sbbiu_err_i'], 1)

        if sel_sb:
            o['sbbiu_dat_o'] = self.mask(fifo_dat_o >> 32, 32)
            o['sbbiu_adr_o'] = self.mask(fifo_dat_o, 32)
            o['sbbiu_cyc_o'] = 1
            o['sbbiu_stb_o'] = 1
            o['sbbiu_we_o'] = 1
            o['sbbiu_sel_o'] = self.mask(fifo_dat_o >> 64, 4)
            o['sbbiu_cab_o'] = 0
        else:
            o['sbbiu_dat_o'] = dat_i
            o['sbbiu_adr_o'] = adr_i
            o['sbbiu_cyc_o'] = self.mask(i['dcsb_cyc_i'], 1)
            o['sbbiu_stb_o'] = self.mask(i['dcsb_stb_i'], 1)
            o['sbbiu_we_o'] = self.mask(i['dcsb_we_i'], 1)
            o['sbbiu_sel_o'] = sel_i
            o['sbbiu_cab_o'] = self.mask(i['dcsb_cab_i'], 1)
        return o

    def advance(self, i):
        if not self.sb_implemented:
            if i['rst']:
                self.reset()
            return

        if i['rst']:
            self._fifo = []
            self._outstanding_store = 0
            self._fifo_wr_ack = 0
            self._active_word = 0
            self._active_valid = False
            return

        fifo_empty = len(self._fifo) == 0
        fifo_full = len(self._fifo) >= self._fifo_depth
        outstanding = bool(self._outstanding_store)
        fifo_rd = not outstanding
        fifo_wr = bool(i['dcsb_cyc_i'] and i['dcsb_stb_i'] and i['dcsb_we_i']) and not fifo_full and not bool(self._fifo_wr_ack)
        sel_sb = (not fifo_empty) or (fifo_empty and outstanding)

        sel_i = self.mask(i['dcsb_sel_i'], 4)
        dat_i = self.mask(i['dcsb_dat_i'], 32)
        adr_i = self.mask(i['dcsb_adr_i'], 32)
        fifo_dat_i = self.mask((sel_i << 64) | (dat_i << 32) | adr_i, 68)

        fifo_after = self._fifo[:]
        popped_word = None
        if fifo_rd and not fifo_empty:
            popped_word = fifo_after.pop(0)
        if fifo_wr:
            fifo_after.append(fifo_dat_i)
        self._fifo = fifo_after

        if popped_word is not None:
            self._active_word = self.mask(popped_word, 68)
            self._active_valid = True

        if i['sbbiu_ack_i']:
            self._outstanding_store = 0
        elif sel_sb or fifo_wr:
            self._outstanding_store = 1

        self._fifo_wr_ack = int(bool(fifo_wr))
