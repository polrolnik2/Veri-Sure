"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['dcsb_dat_o', 'dcsb_ack_o', 'dcsb_err_o', 'sbbiu_dat_o', 'sbbiu_adr_o', 'sbbiu_cyc_o', 'sbbiu_stb_o', 'sbbiu_we_o', 'sbbiu_sel_o', 'sbbiu_cab_o']
    PROBE_PORTS = ['fifo_dat_i', 'fifo_dat_o', 'fifo_wr', 'fifo_rd', 'fifo_full', 'fifo_empty', 'sel_sb', 'outstanding_store', 'fifo_wr_ack', 'or1200_sb_fifo']
    PROBE_WIDTHS = {'fifo_dat_i': 68, 'fifo_dat_o': 68, 'fifo_wr': 1, 'fifo_rd': 1, 'fifo_full': 1, 'fifo_empty': 1, 'sel_sb': 1, 'outstanding_store': 1, 'fifo_wr_ack': 1, 'or1200_sb_fifo': 1}
    LATENCY_CYCLES = 1

    def reset(self):
        self.sb_implemented = bool(getattr(self, "OR1200_SB_IMPLEMENTED", True))
        self.fifo_depth = 4
        self.fifo = []
        self.fifo_last = 0
        self.outstanding_store = False
        self.fifo_wr_ack = False


    def _signals(self, i):
        sel_i = self.mask(i['dcsb_sel_i'], 4)
        dat_i = self.mask(i['dcsb_dat_i'], 32)
        adr_i = self.mask(i['dcsb_adr_i'], 32)
        fifo_dat_i = self.mask((sel_i << 64) | (dat_i << 32) | adr_i, 68)

        if not self.sb_implemented:
            return {
                'fifo_dat_i': fifo_dat_i,
                'fifo_dat_o': 0,
                'fifo_wr': False,
                'fifo_rd': False,
                'fifo_full': False,
                'fifo_empty': True,
                'sel_sb': False,
                'outstanding_store': False,
                'fifo_wr_ack': False,
                'or1200_sb_fifo': False,
            }

        fifo_empty = len(self.fifo) == 0
        fifo_full = len(self.fifo) >= self.fifo_depth
        fifo_dat_o = self.fifo[0] if not fifo_empty else self.fifo_last
        fifo_rd = not self.outstanding_store
        fifo_wr = bool(
            i['dcsb_cyc_i']
            and i['dcsb_stb_i']
            and i['dcsb_we_i']
            and not fifo_full
            and not self.fifo_wr_ack
        )
        sel_sb = (not fifo_empty) or (fifo_empty and self.outstanding_store)
        return {
            'fifo_dat_i': fifo_dat_i,
            'fifo_dat_o': self.mask(fifo_dat_o, 68),
            'fifo_wr': fifo_wr,
            'fifo_rd': fifo_rd,
            'fifo_full': fifo_full,
            'fifo_empty': fifo_empty,
            'sel_sb': bool(sel_sb),
            'outstanding_store': bool(self.outstanding_store),
            'fifo_wr_ack': bool(self.fifo_wr_ack),
            'or1200_sb_fifo': bool(fifo_rd and not fifo_empty),
        }


    def outputs(self, i):
        s = self._signals(i)
        self.fifo_dat_i = s['fifo_dat_i']
        self.fifo_dat_o = s['fifo_dat_o']
        self.fifo_wr = bool(s['fifo_wr'])
        self.fifo_rd = bool(s['fifo_rd'])
        self.fifo_full = bool(s['fifo_full'])
        self.fifo_empty = bool(s['fifo_empty'])
        self.sel_sb = bool(s['sel_sb'])
        self.outstanding_store = bool(s['outstanding_store'])
        self.fifo_wr_ack = bool(s['fifo_wr_ack'])
        self.or1200_sb_fifo = bool(s['or1200_sb_fifo'])

        o = {p: None for p in self.OUTPUT_PORTS}
        o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)

        if not self.sb_implemented or not s['sel_sb']:
            o['dcsb_ack_o'] = int(bool(i['sbbiu_ack_i']))
            o['dcsb_err_o'] = int(bool(i['sbbiu_err_i']))
            o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
            o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
            o['sbbiu_cyc_o'] = int(bool(i['dcsb_cyc_i']))
            o['sbbiu_stb_o'] = int(bool(i['dcsb_stb_i']))
            o['sbbiu_we_o'] = int(bool(i['dcsb_we_i']))
            o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
            o['sbbiu_cab_o'] = int(bool(i['dcsb_cab_i']))
        else:
            fifo_data = s['fifo_dat_o']
            o['dcsb_ack_o'] = int(bool(s['fifo_wr_ack']))
            o['dcsb_err_o'] = 0
            o['sbbiu_dat_o'] = (fifo_data >> 32) & 0xffffffff
            o['sbbiu_adr_o'] = fifo_data & 0xffffffff
            o['sbbiu_cyc_o'] = 1
            o['sbbiu_stb_o'] = 1
            o['sbbiu_we_o'] = 1
            o['sbbiu_sel_o'] = (fifo_data >> 64) & 0xf
            o['sbbiu_cab_o'] = 0
        return o


    def advance(self, i):
        if i['rst']:
            self.fifo = []
            self.fifo_last = 0
            self.outstanding_store = False
            self.fifo_wr_ack = False
            return

        s = self._signals(i)
        if not self.sb_implemented:
            return

        if s['or1200_sb_fifo']:
            self.fifo_last = self.fifo.pop(0)
        if s['fifo_wr']:
            self.fifo.append(s['fifo_dat_i'])

        if i['sbbiu_ack_i']:
            self.outstanding_store = False
        elif s['sel_sb'] or s['fifo_wr']:
            self.outstanding_store = True

        self.fifo_wr_ack = bool(s['fifo_wr'])
