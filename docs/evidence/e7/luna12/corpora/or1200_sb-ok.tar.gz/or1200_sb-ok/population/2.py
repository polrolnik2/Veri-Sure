"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['dcsb_dat_o', 'dcsb_ack_o', 'dcsb_err_o', 'sbbiu_dat_o', 'sbbiu_adr_o', 'sbbiu_cyc_o', 'sbbiu_stb_o', 'sbbiu_we_o', 'sbbiu_sel_o', 'sbbiu_cab_o']
    PROBE_PORTS = ['fifo_dat_i', 'fifo_dat_o', 'fifo_wr', 'fifo_rd', 'fifo_full', 'fifo_empty', 'sel_sb', 'outstanding_store', 'fifo_wr_ack', 'or1200_sb_fifo']
    PROBE_WIDTHS = {'fifo_dat_i': 68, 'fifo_dat_o': 68, 'fifo_wr': 1, 'fifo_rd': 1, 'fifo_full': 1, 'fifo_empty': 1, 'sel_sb': 1, 'outstanding_store': 1, 'fifo_wr_ack': 1, 'or1200_sb_fifo': 1}
    LATENCY_CYCLES = 1

    SB_IMPLEMENTED = True
    FIFO_DEPTH = 4

    def reset(self):
        self.implemented = bool(getattr(self, 'SB_IMPLEMENTED', True))
        self.fifo = []
        self.fifo_dat_o_hold = 0
        self.outstanding_store = 0
        self.fifo_wr_ack = 0

    def _signals(self, i):
        if not self.implemented:
            return {
                'implemented': 0,
                'fifo_dat_i': 0,
                'fifo_dat_o': 0,
                'fifo_wr': 0,
                'fifo_rd': 0,
                'fifo_full': 0,
                'fifo_empty': 1,
                'sel_sb': 0,
                'outstanding_store': 0,
                'fifo_wr_ack': 0,
                'pop': 0,
            }

        empty = int(len(self.fifo) == 0)
        depth = max(1, int(self.FIFO_DEPTH))
        full = int(len(self.fifo) >= depth)
        outstanding = int(bool(self.outstanding_store))
        wr_ack = int(bool(self.fifo_wr_ack))
        sel_sb = int((not empty) or (empty and outstanding))
        fifo_rd = int(not outstanding)
        fifo_wr = int(
            self.mask(i['dcsb_cyc_i'], 1)
            and self.mask(i['dcsb_stb_i'], 1)
            and self.mask(i['dcsb_we_i'], 1)
            and not full
            and not wr_ack
        )
        sel = self.mask(i['dcsb_sel_i'], 4)
        dat = self.mask(i['dcsb_dat_i'], 32)
        adr = self.mask(i['dcsb_adr_i'], 32)
        fifo_dat_i = self.mask((sel << 64) | (dat << 32) | adr, 68)
        fifo_dat_o = self.fifo[0] if self.fifo else self.fifo_dat_o_hold
        pop = int(bool(fifo_rd and not empty))
        return {
            'implemented': 1,
            'fifo_dat_i': fifo_dat_i,
            'fifo_dat_o': self.mask(fifo_dat_o, 68),
            'fifo_wr': fifo_wr,
            'fifo_rd': fifo_rd,
            'fifo_full': full,
            'fifo_empty': empty,
            'sel_sb': sel_sb,
            'outstanding_store': outstanding,
            'fifo_wr_ack': wr_ack,
            'pop': pop,
        }

    def outputs(self, i):
        s = self._signals(i)
        self.fifo_dat_i = s['fifo_dat_i']
        self.fifo_dat_o = s['fifo_dat_o']
        self.fifo_wr = bool(s['fifo_wr'])
        self.fifo_rd = bool(s['fifo_rd'])
        self.fifo_full = bool(s['fifo_full'])
        self.fifo_empty = bool(s['fifo_empty'])
        self.sel_sb = bool(s['sel_sb'])
        self.outstanding_store = bool(s['outstanding_store'])
        self.fifo_wr_ack = bool(s['fifo_wr_ack'])
        self.or1200_sb_fifo = bool(s['pop'])

        o = {p: None for p in self.OUTPUT_PORTS}
        o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)
        if s['implemented'] and s['sel_sb']:
            fifo_data = s['fifo_dat_o']
            o['dcsb_ack_o'] = s['fifo_wr_ack']
            o['dcsb_err_o'] = 0
            o['sbbiu_dat_o'] = self.mask(fifo_data >> 32, 32)
            o['sbbiu_adr_o'] = self.mask(fifo_data, 32)
            o['sbbiu_cyc_o'] = 1
            o['sbbiu_stb_o'] = 1
            o['sbbiu_we_o'] = 1
            o['sbbiu_sel_o'] = self.mask(fifo_data >> 64, 4)
            o['sbbiu_cab_o'] = 0
        else:
            o['dcsb_ack_o'] = self.mask(i['sbbiu_ack_i'], 1)
            o['dcsb_err_o'] = self.mask(i['sbbiu_err_i'], 1)
            o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
            o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
            o['sbbiu_cyc_o'] = self.mask(i['dcsb_cyc_i'], 1)
            o['sbbiu_stb_o'] = self.mask(i['dcsb_stb_i'], 1)
            o['sbbiu_we_o'] = self.mask(i['dcsb_we_i'], 1)
            o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
            o['sbbiu_cab_o'] = self.mask(i['dcsb_cab_i'], 1)
        return o

    def advance(self, i):
        if self.mask(i['rst'], 1):
            self.reset()
            return
        if not self.implemented:
            return

        s = self._signals(i)
        old_fifo = self.fifo
        if s['pop']:
            self.fifo_dat_o_hold = old_fifo[0]
            new_fifo = old_fifo[1:]
        else:
            new_fifo = old_fifo[:]
        if s['fifo_wr']:
            new_fifo.append(s['fifo_dat_i'])
        self.fifo = new_fifo

        self.fifo_wr_ack = s['fifo_wr']
        if self.mask(i['sbbiu_ack_i'], 1):
            self.outstanding_store = 0
        elif s['sel_sb'] or s['fifo_wr']:
            self.outstanding_store = 1
