"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['dcsb_dat_o', 'dcsb_ack_o', 'dcsb_err_o', 'sbbiu_dat_o', 'sbbiu_adr_o', 'sbbiu_cyc_o', 'sbbiu_stb_o', 'sbbiu_we_o', 'sbbiu_sel_o', 'sbbiu_cab_o']
    PROBE_PORTS = ['fifo_dat_i', 'fifo_dat_o', 'fifo_wr', 'fifo_rd', 'fifo_full', 'fifo_empty', 'sel_sb', 'outstanding_store', 'fifo_wr_ack', 'or1200_sb_fifo']
    PROBE_WIDTHS = {'fifo_dat_i': 68, 'fifo_dat_o': 68, 'fifo_wr': 1, 'fifo_rd': 1, 'fifo_full': 1, 'fifo_empty': 1, 'sel_sb': 1, 'outstanding_store': 1, 'fifo_wr_ack': 1, 'or1200_sb_fifo': 1}
    LATENCY_CYCLES = 1

    def reset(self):
        self.implemented = getattr(self, 'implemented', True)
        self.fifo_depth = getattr(self, 'fifo_depth', 4)
        self.fifo = []
        self.outstanding_store = False
        self.fifo_wr_ack = False
        self.fifo_active_data = 0
        self.fifo_active_valid = False

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        payload = self.mask(
            (self.mask(i['dcsb_sel_i'], 4) << 64)
            | (self.mask(i['dcsb_dat_i'], 32) << 32)
            | self.mask(i['dcsb_adr_i'], 32),
            68
        )
        self.fifo_dat_i = payload

        if not self.implemented:
            self.fifo_dat_o = 0
            self.fifo_wr = False
            self.fifo_rd = False
            self.fifo_full = False
            self.fifo_empty = True
            self.sel_sb = False
            self.or1200_sb_fifo = False
            self.outstanding_store = bool(self.outstanding_store)
            self.fifo_wr_ack = bool(self.fifo_wr_ack)

            o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)
            o['dcsb_ack_o'] = self.mask(i['sbbiu_ack_i'], 1)
            o['dcsb_err_o'] = self.mask(i['sbbiu_err_i'], 1)
            o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
            o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
            o['sbbiu_cyc_o'] = self.mask(i['dcsb_cyc_i'], 1)
            o['sbbiu_stb_o'] = self.mask(i['dcsb_stb_i'], 1)
            o['sbbiu_we_o'] = self.mask(i['dcsb_we_i'], 1)
            o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
            o['sbbiu_cab_o'] = self.mask(i['dcsb_cab_i'], 1)
            return o

        self.fifo_full = len(self.fifo) >= self.fifo_depth
        self.fifo_empty = len(self.fifo) == 0
        self.fifo_wr = bool(
            self.mask(i['dcsb_cyc_i'], 1)
            and self.mask(i['dcsb_stb_i'], 1)
            and self.mask(i['dcsb_we_i'], 1)
            and not self.fifo_full
            and not self.fifo_wr_ack
        )
        self.fifo_rd = not self.outstanding_store
        self.sel_sb = bool(
            (not self.fifo_empty)
            or (self.fifo_empty and self.outstanding_store)
        )
        self.or1200_sb_fifo = bool(self.fifo_rd and not self.fifo_empty)

        if self.outstanding_store and self.fifo_active_valid:
            self.fifo_dat_o = self.mask(self.fifo_active_data, 68)
        elif self.fifo:
            self.fifo_dat_o = self.mask(self.fifo[0], 68)
        elif self.fifo_active_valid:
            self.fifo_dat_o = self.mask(self.fifo_active_data, 68)
        else:
            self.fifo_dat_o = 0

        o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)
        o['dcsb_ack_o'] = self.fifo_wr_ack if self.sel_sb else self.mask(i['sbbiu_ack_i'], 1)
        o['dcsb_err_o'] = 0 if self.sel_sb else self.mask(i['sbbiu_err_i'], 1)

        if self.sel_sb:
            o['sbbiu_dat_o'] = self.mask(self.fifo_dat_o >> 32, 32)
            o['sbbiu_adr_o'] = self.mask(self.fifo_dat_o, 32)
            o['sbbiu_cyc_o'] = 1
            o['sbbiu_stb_o'] = 1
            o['sbbiu_we_o'] = 1
            o['sbbiu_sel_o'] = self.mask(self.fifo_dat_o >> 64, 4)
            o['sbbiu_cab_o'] = 0
        else:
            o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
            o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
            o['sbbiu_cyc_o'] = self.mask(i['dcsb_cyc_i'], 1)
            o['sbbiu_stb_o'] = self.mask(i['dcsb_stb_i'], 1)
            o['sbbiu_we_o'] = self.mask(i['dcsb_we_i'], 1)
            o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
            o['sbbiu_cab_o'] = self.mask(i['dcsb_cab_i'], 1)
        return o

    def advance(self, i):
        if not self.implemented:
            return

        if self.mask(i['rst'], 1):
            self.fifo = []
            self.outstanding_store = False
            self.fifo_wr_ack = False
            self.fifo_active_data = 0
            self.fifo_active_valid = False
            return

        payload = self.mask(
            (self.mask(i['dcsb_sel_i'], 4) << 64)
            | (self.mask(i['dcsb_dat_i'], 32) << 32)
            | self.mask(i['dcsb_adr_i'], 32),
            68
        )
        old_fifo = self.fifo
        old_outstanding = bool(self.outstanding_store)
        old_empty = len(old_fifo) == 0
        old_full = len(old_fifo) >= self.fifo_depth
        old_wr_ack = bool(self.fifo_wr_ack)

        fifo_wr = bool(
            self.mask(i['dcsb_cyc_i'], 1)
            and self.mask(i['dcsb_stb_i'], 1)
            and self.mask(i['dcsb_we_i'], 1)
            and not old_full
            and not old_wr_ack
        )
        fifo_rd = not old_outstanding
        popped = bool(fifo_rd and not old_empty)
        sel_sb = bool((not old_empty) or (old_empty and old_outstanding))

        if self.mask(i['sbbiu_ack_i'], 1):
            next_outstanding = False
        elif sel_sb or fifo_wr:
            next_outstanding = True
        else:
            next_outstanding = old_outstanding

        next_fifo = list(old_fifo)
        if popped:
            next_fifo.pop(0)
        if fifo_wr:
            next_fifo.append(payload)

        if popped:
            self.fifo_active_data = old_fifo[0]
            self.fifo_active_valid = True
        elif not old_outstanding and next_outstanding:
            if old_fifo:
                self.fifo_active_data = old_fifo[0]
                self.fifo_active_valid = True
            elif fifo_wr:
                self.fifo_active_data = payload
                self.fifo_active_valid = True

        self.fifo = next_fifo
        self.outstanding_store = next_outstanding
        self.fifo_wr_ack = fifo_wr
