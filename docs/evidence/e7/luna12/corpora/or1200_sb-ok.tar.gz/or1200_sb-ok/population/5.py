"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['dcsb_dat_o', 'dcsb_ack_o', 'dcsb_err_o', 'sbbiu_dat_o', 'sbbiu_adr_o', 'sbbiu_cyc_o', 'sbbiu_stb_o', 'sbbiu_we_o', 'sbbiu_sel_o', 'sbbiu_cab_o']
    PROBE_PORTS = ['fifo_dat_i', 'fifo_dat_o', 'fifo_wr', 'fifo_rd', 'fifo_full', 'fifo_empty', 'sel_sb', 'outstanding_store', 'fifo_wr_ack', 'or1200_sb_fifo']
    PROBE_WIDTHS = {'fifo_dat_i': 68, 'fifo_dat_o': 68, 'fifo_wr': 1, 'fifo_rd': 1, 'fifo_full': 1, 'fifo_empty': 1, 'sel_sb': 1, 'outstanding_store': 1, 'fifo_wr_ack': 1, 'or1200_sb_fifo': 1}
    LATENCY_CYCLES = 1

    def _clear_state(self):
        self.fifo_depth = 4
        self._fifo = []
        self._outstanding_store = 0
        self._fifo_wr_ack = 0
        self._active_word = 0
        self._active_valid = False

    def reset(self):
        if not hasattr(self, 'sb_implemented'):
            self.sb_implemented = True
        self._clear_state()

    def _signals(self, i):
        if not self.sb_implemented:
            return {
                'data_i': 0,
                'data_o': 0,
                'fifo_wr': 0,
                'fifo_rd': 0,
                'fifo_full': 0,
                'fifo_empty': 1,
                'sel_sb': 0,
                'pop': 0,
            }

        data_i = ((self.mask(i['dcsb_sel_i'], 4) << 64) |
                  (self.mask(i['dcsb_dat_i'], 32) << 32) |
                  self.mask(i['dcsb_adr_i'], 32))
        fifo_empty = int(len(self._fifo) == 0)
        fifo_full = int(len(self._fifo) >= self.fifo_depth)
        fifo_wr = int(bool(self.mask(i['dcsb_cyc_i'], 1)) and
                       bool(self.mask(i['dcsb_stb_i'], 1)) and
                       bool(self.mask(i['dcsb_we_i'], 1)) and
                       not fifo_full and not self._fifo_wr_ack)
        fifo_rd = int(not self._outstanding_store)
        sel_sb = int((not fifo_empty) or
                     (fifo_empty and bool(self._outstanding_store)))
        pop = int(bool(fifo_rd) and not fifo_empty)

        if self._outstanding_store and self._active_valid:
            data_o = self._active_word
        elif self._fifo:
            data_o = self._fifo[0]
        elif self._active_valid:
            data_o = self._active_word
        else:
            data_o = 0

        return {
            'data_i': self.mask(data_i, 68),
            'data_o': self.mask(data_o, 68),
            'fifo_wr': fifo_wr,
            'fifo_rd': fifo_rd,
            'fifo_full': fifo_full,
            'fifo_empty': fifo_empty,
            'sel_sb': sel_sb,
            'pop': pop,
        }

    def outputs(self, i):
        s = self._signals(i)

        self.fifo_dat_i = s['data_i']
        self.fifo_dat_o = s['data_o']
        self.fifo_wr = bool(s['fifo_wr'])
        self.fifo_rd = bool(s['fifo_rd'])
        self.fifo_full = bool(s['fifo_full'])
        self.fifo_empty = bool(s['fifo_empty'])
        self.sel_sb = bool(s['sel_sb'])
        self.outstanding_store = bool(self._outstanding_store)
        self.fifo_wr_ack = bool(self._fifo_wr_ack)
        self.or1200_sb_fifo = bool(s['pop'])

        o = {p: None for p in self.OUTPUT_PORTS}
        o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)

        if not self.sb_implemented:
            o['dcsb_ack_o'] = self.mask(i['sbbiu_ack_i'], 1)
            o['dcsb_err_o'] = self.mask(i['sbbiu_err_i'], 1)
            o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
            o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
            o['sbbiu_cyc_o'] = self.mask(i['dcsb_cyc_i'], 1)
            o['sbbiu_stb_o'] = self.mask(i['dcsb_stb_i'], 1)
            o['sbbiu_we_o'] = self.mask(i['dcsb_we_i'], 1)
            o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
            o['sbbiu_cab_o'] = self.mask(i['dcsb_cab_i'], 1)
            return o

        if s['sel_sb']:
            word = s['data_o']
            o['dcsb_ack_o'] = int(bool(self._fifo_wr_ack))
            o['dcsb_err_o'] = 0
            o['sbbiu_dat_o'] = self.mask(word >> 32, 32)
            o['sbbiu_adr_o'] = self.mask(word, 32)
            o['sbbiu_cyc_o'] = 1
            o['sbbiu_stb_o'] = 1
            o['sbbiu_we_o'] = 1
            o['sbbiu_sel_o'] = self.mask(word >> 64, 4)
            o['sbbiu_cab_o'] = 0
        else:
            o['dcsb_ack_o'] = self.mask(i['sbbiu_ack_i'], 1)
            o['dcsb_err_o'] = self.mask(i['sbbiu_err_i'], 1)
            o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
            o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
            o['sbbiu_cyc_o'] = self.mask(i['dcsb_cyc_i'], 1)
            o['sbbiu_stb_o'] = self.mask(i['dcsb_stb_i'], 1)
            o['sbbiu_we_o'] = self.mask(i['dcsb_we_i'], 1)
            o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
            o['sbbiu_cab_o'] = self.mask(i['dcsb_cab_i'], 1)
        return o

    def advance(self, i):
        if self.mask(i['rst'], 1):
            self._clear_state()
            return
        if not self.sb_implemented:
            return

        s = self._signals(i)
        fifo_wr = bool(s['fifo_wr'])
        data_i = s['data_i']
        bypass_to_active = False

        if s['pop']:
            popped_word = self._fifo.pop(0)
            self._active_word = popped_word
            self._active_valid = True
        else:
            # A write into an empty FIFO can become its active first word when
            # fifo_rd is enabled; fifo_empty still prevents reporting a FIFO pop.
            bypass_to_active = bool(fifo_wr and s['fifo_empty'] and
                                    not self._outstanding_store and s['fifo_rd'])
            if bypass_to_active:
                self._active_word = data_i
                self._active_valid = True

        if fifo_wr and not bypass_to_active:
            self._fifo.append(data_i)

        if self.mask(i['sbbiu_ack_i'], 1):
            self._outstanding_store = 0
        else:
            self._outstanding_store = int(bool(s['sel_sb']) or fifo_wr)

        self._fifo_wr_ack = int(fifo_wr)
