"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['dcsb_dat_o', 'dcsb_ack_o', 'dcsb_err_o', 'sbbiu_dat_o', 'sbbiu_adr_o', 'sbbiu_cyc_o', 'sbbiu_stb_o', 'sbbiu_we_o', 'sbbiu_sel_o', 'sbbiu_cab_o']
    PROBE_PORTS = ['fifo_dat_i', 'fifo_dat_o', 'fifo_wr', 'fifo_rd', 'fifo_full', 'fifo_empty', 'sel_sb', 'outstanding_store', 'fifo_wr_ack', 'or1200_sb_fifo']
    PROBE_WIDTHS = {'fifo_dat_i': 68, 'fifo_dat_o': 68, 'fifo_wr': 1, 'fifo_rd': 1, 'fifo_full': 1, 'fifo_empty': 1, 'sel_sb': 1, 'outstanding_store': 1, 'fifo_wr_ack': 1, 'or1200_sb_fifo': 1}
    LATENCY_CYCLES = 1

    def reset(self):
        self.sb_enabled = getattr(self, "sb_enabled", True)
        self.fifo_depth = 4
        self.fifo = []
        self.outstanding_store = False
        self.fifo_wr_ack = False
        self.active_fifo_data = 0
        self.active_fifo_valid = False

    def _payload(self, i):
        sel = self.mask(i['dcsb_sel_i'], 4)
        data = self.mask(i['dcsb_dat_i'], 32)
        adr = self.mask(i['dcsb_adr_i'], 32)
        return self.mask((sel << 64) | (data << 32) | adr, 68)

    def _signals(self, i):
        if not self.sb_enabled:
            return {
                'fifo_dat_i': 0,
                'fifo_dat_o': 0,
                'fifo_wr': 0,
                'fifo_rd': 0,
                'fifo_full': 0,
                'fifo_empty': 1,
                'sel_sb': 0,
                'outstanding_store': 0,
                'fifo_wr_ack': 0,
                'or1200_sb_fifo': 0,
            }

        empty = int(len(self.fifo) == 0)
        full = int(len(self.fifo) >= self.fifo_depth)
        fifo_wr = int(bool(i['dcsb_cyc_i'] and i['dcsb_stb_i'] and i['dcsb_we_i']) and not full and not self.fifo_wr_ack)
        fifo_rd = int(not self.outstanding_store)
        sel_sb = int((not empty) or (empty and bool(self.outstanding_store)))

        if self.outstanding_store and self.active_fifo_valid:
            fifo_dat_o = self.active_fifo_data
        elif self.fifo:
            fifo_dat_o = self.fifo[0]
        else:
            fifo_dat_o = self.active_fifo_data

        return {
            'fifo_dat_i': self._payload(i),
            'fifo_dat_o': self.mask(fifo_dat_o, 68),
            'fifo_wr': fifo_wr,
            'fifo_rd': fifo_rd,
            'fifo_full': full,
            'fifo_empty': empty,
            'sel_sb': sel_sb,
            'outstanding_store': int(bool(self.outstanding_store)),
            'fifo_wr_ack': int(bool(self.fifo_wr_ack)),
            'or1200_sb_fifo': int(bool(fifo_rd and not empty)),
        }

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        s = self._signals(i)

        self.fifo_dat_i = s['fifo_dat_i']
        self.fifo_dat_o = s['fifo_dat_o']
        self.fifo_wr = bool(s['fifo_wr'])
        self.fifo_rd = bool(s['fifo_rd'])
        self.fifo_full = bool(s['fifo_full'])
        self.fifo_empty = bool(s['fifo_empty'])
        self.sel_sb = bool(s['sel_sb'])
        self.or1200_sb_fifo = bool(s['or1200_sb_fifo'])

        o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)

        if not self.sb_enabled:
            o['dcsb_ack_o'] = i['sbbiu_ack_i'] & 1
            o['dcsb_err_o'] = i['sbbiu_err_i'] & 1
            o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
            o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
            o['sbbiu_cyc_o'] = i['dcsb_cyc_i'] & 1
            o['sbbiu_stb_o'] = i['dcsb_stb_i'] & 1
            o['sbbiu_we_o'] = i['dcsb_we_i'] & 1
            o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
            o['sbbiu_cab_o'] = i['dcsb_cab_i'] & 1
            return o

        if s['sel_sb']:
            fifo_data = s['fifo_dat_o']
            o['dcsb_ack_o'] = s['fifo_wr_ack']
            o['dcsb_err_o'] = 0
            o['sbbiu_dat_o'] = (fifo_data >> 32) & 0xffffffff
            o['sbbiu_adr_o'] = fifo_data & 0xffffffff
            o['sbbiu_cyc_o'] = 1
            o['sbbiu_stb_o'] = 1
            o['sbbiu_we_o'] = 1
            o['sbbiu_sel_o'] = (fifo_data >> 64) & 0xf
            o['sbbiu_cab_o'] = 0
        else:
            o['dcsb_ack_o'] = i['sbbiu_ack_i'] & 1
            o['dcsb_err_o'] = i['sbbiu_err_i'] & 1
            o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
            o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
            o['sbbiu_cyc_o'] = i['dcsb_cyc_i'] & 1
            o['sbbiu_stb_o'] = i['dcsb_stb_i'] & 1
            o['sbbiu_we_o'] = i['dcsb_we_i'] & 1
            o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
            o['sbbiu_cab_o'] = i['dcsb_cab_i'] & 1
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not self.sb_enabled:
            return

        s = self._signals(i)
        popped_data = self.fifo[0] if s['or1200_sb_fifo'] else None
        if s['or1200_sb_fifo']:
            self.fifo.pop(0)
        if s['fifo_wr']:
            self.fifo.append(s['fifo_dat_i'])

        self.fifo_wr_ack = bool(s['fifo_wr'])
        if i['sbbiu_ack_i']:
            self.outstanding_store = False
            self.active_fifo_valid = False
        else:
            if s['sel_sb'] or s['fifo_wr']:
                self.outstanding_store = True
            if s['or1200_sb_fifo']:
                self.active_fifo_data = self.mask(popped_data, 68)
                self.active_fifo_valid = True
