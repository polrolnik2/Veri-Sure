"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['dcsb_dat_o', 'dcsb_ack_o', 'dcsb_err_o', 'sbbiu_dat_o', 'sbbiu_adr_o', 'sbbiu_cyc_o', 'sbbiu_stb_o', 'sbbiu_we_o', 'sbbiu_sel_o', 'sbbiu_cab_o']
    PROBE_PORTS = ['fifo_dat_i', 'fifo_dat_o', 'fifo_wr', 'fifo_rd', 'fifo_full', 'fifo_empty', 'sel_sb', 'outstanding_store', 'fifo_wr_ack', 'or1200_sb_fifo']
    PROBE_WIDTHS = {'fifo_dat_i': 68, 'fifo_dat_o': 68, 'fifo_wr': 1, 'fifo_rd': 1, 'fifo_full': 1, 'fifo_empty': 1, 'sel_sb': 1, 'outstanding_store': 1, 'fifo_wr_ack': 1, 'or1200_sb_fifo': 1}
    LATENCY_CYCLES = 1

    def reset(self):
        if not hasattr(self, 'sb_implemented'):
            self.sb_implemented = True
        self.fifo = []
        self.outstanding_store = False
        self.fifo_wr_ack = False
        self.active_data = 0
        self.active_valid = False
        self.fifo_dat_i = 0
        self.fifo_dat_o = 0
        self.fifo_wr = False
        self.fifo_rd = False
        self.fifo_full = False
        self.fifo_empty = True
        self.sel_sb = False
        self.or1200_sb_fifo = False

    def _payload(self, i):
        sel = self.mask(i['dcsb_sel_i'], 4)
        data = self.mask(i['dcsb_dat_i'], 32)
        addr = self.mask(i['dcsb_adr_i'], 32)
        return self.mask((sel << 64) | (data << 32) | addr, 68)

    def _fifo_full_now(self):
        return len(self.fifo) >= 4

    def _fifo_write_now(self, i):
        return bool(i['dcsb_cyc_i'] and i['dcsb_stb_i'] and i['dcsb_we_i'] and not self._fifo_full_now() and not self.fifo_wr_ack)

    def _sel_sb_now(self):
        fifo_empty = not self.fifo
        return bool((not fifo_empty) or (fifo_empty and self.outstanding_store))

    def _fifo_data_now(self):
        if self.outstanding_store and self.active_valid:
            return self.mask(self.active_data, 68)
        if self.fifo:
            return self.mask(self.fifo[0], 68)
        if self.active_valid:
            return self.mask(self.active_data, 68)
        return 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        if not self.sb_implemented:
            self.fifo_dat_i = 0
            self.fifo_dat_o = 0
            self.fifo_wr = False
            self.fifo_rd = False
            self.fifo_full = False
            self.fifo_empty = True
            self.sel_sb = False
            self.outstanding_store = False
            self.fifo_wr_ack = False
            self.or1200_sb_fifo = False
            o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)
            o['dcsb_ack_o'] = self.mask(i['sbbiu_ack_i'], 1)
            o['dcsb_err_o'] = self.mask(i['sbbiu_err_i'], 1)
            o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
            o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
            o['sbbiu_cyc_o'] = self.mask(i['dcsb_cyc_i'], 1)
            o['sbbiu_stb_o'] = self.mask(i['dcsb_stb_i'], 1)
            o['sbbiu_we_o'] = self.mask(i['dcsb_we_i'], 1)
            o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
            o['sbbiu_cab_o'] = self.mask(i['dcsb_cab_i'], 1)
            return o

        fifo_wr = self._fifo_write_now(i)
        fifo_rd = not self.outstanding_store
        sel_sb = self._sel_sb_now()
        fifo_empty = not self.fifo
        fifo_full = self._fifo_full_now()
        payload = self._payload(i)
        fifo_dat_o = self._fifo_data_now()

        self.fifo_dat_i = payload
        self.fifo_dat_o = fifo_dat_o
        self.fifo_wr = bool(fifo_wr)
        self.fifo_rd = bool(fifo_rd)
        self.fifo_full = bool(fifo_full)
        self.fifo_empty = bool(fifo_empty)
        self.sel_sb = bool(sel_sb)
        self.fifo_wr_ack = bool(self.fifo_wr_ack)
        self.or1200_sb_fifo = bool(fifo_rd and (not fifo_empty or fifo_wr))

        o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)
        o['dcsb_ack_o'] = int(self.fifo_wr_ack if sel_sb else bool(i['sbbiu_ack_i']))
        o['dcsb_err_o'] = 0 if sel_sb else self.mask(i['sbbiu_err_i'], 1)

        if sel_sb:
            o['sbbiu_dat_o'] = self.mask((fifo_dat_o >> 32) & 0xffffffff, 32)
            o['sbbiu_adr_o'] = self.mask(fifo_dat_o & 0xffffffff, 32)
            o['sbbiu_cyc_o'] = 1
            o['sbbiu_stb_o'] = 1
            o['sbbiu_we_o'] = 1
            o['sbbiu_sel_o'] = self.mask((fifo_dat_o >> 64) & 0xf, 4)
            o['sbbiu_cab_o'] = 0
        else:
            o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
            o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
            o['sbbiu_cyc_o'] = self.mask(i['dcsb_cyc_i'], 1)
            o['sbbiu_stb_o'] = self.mask(i['dcsb_stb_i'], 1)
            o['sbbiu_we_o'] = self.mask(i['dcsb_we_i'], 1)
            o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
            o['sbbiu_cab_o'] = self.mask(i['dcsb_cab_i'], 1)
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not self.sb_implemented:
            return

        fifo_wr = self._fifo_write_now(i)
        sel_sb = self._sel_sb_now()
        fifo_rd = not self.outstanding_store
        payload = self._payload(i)
        next_fifo = list(self.fifo)
        popped_new_write = False

        # Model a write-through FIFO when a read enable coincides with a write
        # into an otherwise empty FIFO; otherwise a read consumes the old head.
        if fifo_rd:
            if next_fifo:
                self.active_data = next_fifo.pop(0)
                self.active_valid = True
            elif fifo_wr:
                self.active_data = payload
                self.active_valid = True
                popped_new_write = True

        if fifo_wr and not popped_new_write:
            next_fifo.append(payload)
        self.fifo = next_fifo

        self.fifo_wr_ack = bool(fifo_wr)
        if i['sbbiu_ack_i']:
            self.outstanding_store = False
        elif sel_sb or fifo_wr:
            self.outstanding_store = True
