"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['dcsb_dat_o', 'dcsb_ack_o', 'dcsb_err_o', 'sbbiu_dat_o', 'sbbiu_adr_o', 'sbbiu_cyc_o', 'sbbiu_stb_o', 'sbbiu_we_o', 'sbbiu_sel_o', 'sbbiu_cab_o']
    PROBE_PORTS = ['fifo_dat_i', 'fifo_dat_o', 'fifo_wr', 'fifo_rd', 'fifo_full', 'fifo_empty', 'sel_sb', 'outstanding_store', 'fifo_wr_ack', 'or1200_sb_fifo']
    PROBE_WIDTHS = {'fifo_dat_i': 68, 'fifo_dat_o': 68, 'fifo_wr': 1, 'fifo_rd': 1, 'fifo_full': 1, 'fifo_empty': 1, 'sel_sb': 1, 'outstanding_store': 1, 'fifo_wr_ack': 1, 'or1200_sb_fifo': 1}
    LATENCY_CYCLES = 1

    def reset(self):
        self.sb_implemented = getattr(self, 'sb_implemented', True)
        self.fifo_depth = 4
        self.fifo = []
        self.last_fifo_word = 0
        self.outstanding_store = 0
        self.fifo_wr_ack = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        if not self.sb_implemented:
            o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)
            o['dcsb_ack_o'] = self.mask(i['sbbiu_ack_i'], 1)
            o['dcsb_err_o'] = self.mask(i['sbbiu_err_i'], 1)
            o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
            o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
            o['sbbiu_cyc_o'] = self.mask(i['dcsb_cyc_i'], 1)
            o['sbbiu_stb_o'] = self.mask(i['dcsb_stb_i'], 1)
            o['sbbiu_we_o'] = self.mask(i['dcsb_we_i'], 1)
            o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
            o['sbbiu_cab_o'] = self.mask(i['dcsb_cab_i'], 1)
            self.fifo_dat_i = 0
            self.fifo_dat_o = 0
            self.fifo_wr = 0
            self.fifo_rd = 0
            self.fifo_full = 0
            self.fifo_empty = 1
            self.sel_sb = 0
            self.outstanding_store = int(bool(self.outstanding_store))
            self.fifo_wr_ack = int(bool(self.fifo_wr_ack))
            self.or1200_sb_fifo = 0
            return o

        empty = int(len(self.fifo) == 0)
        full = int(len(self.fifo) >= self.fifo_depth)
        payload = (self.mask(i['dcsb_sel_i'], 4) << 64) | (self.mask(i['dcsb_dat_i'], 32) << 32) | self.mask(i['dcsb_adr_i'], 32)
        wr = int(bool(self.mask(i['dcsb_cyc_i'], 1) and self.mask(i['dcsb_stb_i'], 1) and self.mask(i['dcsb_we_i'], 1) and not full and not self.fifo_wr_ack))
        rd = int(not self.outstanding_store)
        sel = int(bool(not empty or self.outstanding_store))
        fifo_word = self.fifo[0] if self.fifo else self.last_fifo_word

        self.fifo_dat_i = self.mask(payload, 68)
        self.fifo_dat_o = self.mask(fifo_word, 68)
        self.fifo_wr = wr
        self.fifo_rd = rd
        self.fifo_full = full
        self.fifo_empty = empty
        self.sel_sb = sel
        self.outstanding_store = int(bool(self.outstanding_store))
        self.fifo_wr_ack = int(bool(self.fifo_wr_ack))
        self.or1200_sb_fifo = int(bool(rd and not empty))

        o['dcsb_dat_o'] = self.mask(i['sbbiu_dat_i'], 32)
        o['dcsb_ack_o'] = self.fifo_wr_ack if sel else self.mask(i['sbbiu_ack_i'], 1)
        o['dcsb_err_o'] = 0 if sel else self.mask(i['sbbiu_err_i'], 1)
        if sel:
            o['sbbiu_dat_o'] = self.mask(fifo_word >> 32, 32)
            o['sbbiu_adr_o'] = self.mask(fifo_word, 32)
            o['sbbiu_cyc_o'] = 1
            o['sbbiu_stb_o'] = 1
            o['sbbiu_we_o'] = 1
            o['sbbiu_sel_o'] = self.mask(fifo_word >> 64, 4)
            o['sbbiu_cab_o'] = 0
        else:
            o['sbbiu_dat_o'] = self.mask(i['dcsb_dat_i'], 32)
            o['sbbiu_adr_o'] = self.mask(i['dcsb_adr_i'], 32)
            o['sbbiu_cyc_o'] = self.mask(i['dcsb_cyc_i'], 1)
            o['sbbiu_stb_o'] = self.mask(i['dcsb_stb_i'], 1)
            o['sbbiu_we_o'] = self.mask(i['dcsb_we_i'], 1)
            o['sbbiu_sel_o'] = self.mask(i['dcsb_sel_i'], 4)
            o['sbbiu_cab_o'] = self.mask(i['dcsb_cab_i'], 1)
        return o

    def advance(self, i):
        if self.mask(i['rst'], 1):
            self.fifo = []
            self.last_fifo_word = 0
            self.outstanding_store = 0
            self.fifo_wr_ack = 0
            return
        if not self.sb_implemented:
            return

        empty = len(self.fifo) == 0
        full = len(self.fifo) >= self.fifo_depth
        sel = int(bool(not empty or self.outstanding_store))
        rd = int(not self.outstanding_store)
        wr = int(bool(self.mask(i['dcsb_cyc_i'], 1) and self.mask(i['dcsb_stb_i'], 1) and self.mask(i['dcsb_we_i'], 1) and not full and not self.fifo_wr_ack))
        payload = (self.mask(i['dcsb_sel_i'], 4) << 64) | (self.mask(i['dcsb_dat_i'], 32) << 32) | self.mask(i['dcsb_adr_i'], 32)

        if self.mask(i['sbbiu_ack_i'], 1):
            self.outstanding_store = 0
        elif sel or wr:
            self.outstanding_store = 1

        if rd and self.fifo:
            self.last_fifo_word = self.fifo.pop(0)
        if wr:
            self.fifo.append(self.mask(payload, 68))
        self.fifo_wr_ack = wr
