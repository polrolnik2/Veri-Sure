"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        names = (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger',
            'nan_output_0', 'nan_output', 'inf_round_down', 'out_inf',
            'out_0', 'out_1', 'out_2', 'out', 'ex_enable', 'underflow',
            'overflow', 'inexact', 'exception', 'invalid'
        )
        for name in names:
            setattr(self, name, 0)
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1

    def outputs(self, i):
        probes = (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger',
            'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down',
            'out_inf', 'out_0', 'out_1', 'out_2', 'exp_2047', 'exp_2046'
        )
        for name in probes:
            setattr(self, name, getattr(self, name))
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self.out
        o['ex_enable'] = self.ex_enable
        o['underflow'] = self.underflow
        o['overflow'] = self.overflow
        o['inexact'] = self.inexact
        o['exception'] = self.exception
        o['invalid'] = self.invalid
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not i['enable']:
            return

        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        candidate = self.mask(i['in_except'], 64)
        exponent = self.mask(i['exponent_in'], 12)
        remainder = self.mask(i['mantissa_in'], 2)
        op = self.mask(i['fpu_op'], 3)
        mode = self.mask(i['rmode'], 2)

        frac_mask = (1 << 52) - 1
        magnitude_mask = (1 << 63) - 1
        sign_a = (opa >> 63) & 1
        sign_b = (opb >> 63) & 1
        sign_result = (candidate >> 63) & 1
        exp_a = (opa >> 52) & 0x7ff
        exp_b = (opb >> 52) & 0x7ff
        frac_a = opa & frac_mask
        frac_b = opb & frac_mask

        a_zero = (opa & magnitude_mask) == 0
        b_zero = (opb & magnitude_mask) == 0
        result_zero = (candidate & magnitude_mask) == 0
        a_nan = exp_a == 0x7ff and frac_a != 0
        b_nan = exp_b == 0x7ff and frac_b != 0
        a_qnan = a_nan and ((frac_a >> 51) & 1) != 0
        b_qnan = b_nan and ((frac_b >> 51) & 1) != 0
        a_snan = a_nan and not a_qnan
        b_snan = b_nan and not b_qnan
        a_inf = exp_a == 0x7ff and frac_a == 0
        b_inf = exp_b == 0x7ff and frac_b == 0
        a_pos_inf = a_inf and sign_a == 0
        b_pos_inf = b_inf and sign_b == 0
        a_neg_inf = a_inf and sign_a == 1
        b_neg_inf = b_inf and sign_b == 1

        is_add = op == 0
        is_sub = op == 1
        is_mul = op == 2
        is_div = op == 3
        nan_input = a_nan or b_nan
        snan_input = a_snan or b_snan

        div_zero_by_zero = is_div and a_zero and b_zero
        div_inf_by_inf = is_div and a_inf and b_inf
        div_by_zero = is_div and b_zero and not a_zero
        div_by_inf = is_div and b_inf and not a_inf and not a_nan
        mul_zero_by_inf = is_mul and ((a_zero and b_inf) or (b_zero and a_inf))
        mul_inf = is_mul and (a_inf or b_inf)
        div_inf = is_div and a_inf and not b_inf
        add_inf = is_add and (a_inf or b_inf)
        sub_inf = is_sub and (a_inf or b_inf)

        invalid_add = is_add and ((a_pos_inf and b_neg_inf) or (a_neg_inf and b_pos_inf))
        invalid_sub = is_sub and ((a_pos_inf and b_pos_inf) or (a_neg_inf and b_neg_inf))
        addsub_inf_invalid = invalid_add or invalid_sub
        addsub_inf = (is_add or is_sub) and (a_inf or b_inf) and not addsub_inf_invalid
        invalid_arithmetic = addsub_inf_invalid or mul_zero_by_inf or div_zero_by_zero or div_inf_by_inf
        invalid_trigger = snan_input or invalid_arithmetic
        nan_out_trigger = nan_input or invalid_arithmetic

        mul_uf = is_mul and not a_zero and not b_zero and result_zero
        div_uf = div_by_inf or (is_div and not a_zero and not b_zero and result_zero)
        underflow_trigger = mul_uf or div_uf

        out_inf_trigger = (
            (mul_inf and not mul_zero_by_inf)
            or div_inf
            or addsub_inf
            or div_by_zero
            or exponent > 2046
        )
        out_pos_inf = out_inf_trigger and sign_result == 0
        out_neg_inf = out_inf_trigger and sign_result == 1
        round_nearest = mode == 0
        round_to_zero = mode == 1
        round_to_pos_inf = mode == 2
        round_to_neg_inf = mode == 3
        inf_round_down_trigger = (
            (out_pos_inf and (round_to_zero or round_to_neg_inf))
            or (out_neg_inf and (round_to_zero or round_to_pos_inf))
        )

        overflow_trigger = out_inf_trigger and not nan_input
        inexact_trigger = (not nan_input) and (
            remainder != 0 or out_inf_trigger or underflow_trigger
        )
        except_trigger = invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger
        enable_trigger = nan_out_trigger or except_trigger

        self.in_et_zero = int(result_zero)
        self.input_et_zero = int(result_zero)
        self.opa_et_zero = int(a_zero)
        self.opb_et_zero = int(b_zero)
        self.add = int(is_add)
        self.subtract = int(is_sub)
        self.multiply = int(is_mul)
        self.divide = int(is_div)
        self.opa_qnan = int(a_qnan)
        self.opb_qnan = int(b_qnan)
        self.opa_snan = int(a_snan)
        self.opb_snan = int(b_snan)
        self.opa_pos_inf = int(a_pos_inf)
        self.opb_pos_inf = int(b_pos_inf)
        self.opa_neg_inf = int(a_neg_inf)
        self.opb_neg_inf = int(b_neg_inf)
        self.opa_inf = int(a_inf)
        self.opb_inf = int(b_inf)
        self.nan_input = int(nan_input)
        self.snan_input = int(snan_input)
        self.div_by_0 = int(div_by_zero)
        self.div_0_by_0 = int(div_zero_by_zero)
        self.div_inf_by_inf = int(div_inf_by_inf)
        self.div_by_inf = int(div_by_inf)
        self.mul_0_by_inf = int(mul_zero_by_inf)
        self.mul_inf = int(mul_inf)
        self.div_inf = int(div_inf)
        self.add_inf = int(add_inf)
        self.sub_inf = int(sub_inf)
        self.addsub_inf_invalid = int(addsub_inf_invalid)
        self.addsub_inf = int(addsub_inf)
        self.out_inf_trigger = int(out_inf_trigger)
        self.out_pos_inf = int(out_pos_inf)
        self.out_neg_inf = int(out_neg_inf)
        self.round_nearest = int(round_nearest)
        self.round_to_zero = int(round_to_zero)
        self.round_to_pos_inf = int(round_to_pos_inf)
        self.round_to_neg_inf = int(round_to_neg_inf)
        self.inf_round_down_trigger = int(inf_round_down_trigger)
        self.mul_uf = int(mul_uf)
        self.div_uf = int(div_uf)
        self.underflow_trigger = int(underflow_trigger)
        self.invalid_trigger = int(invalid_trigger)
        self.overflow_trigger = int(overflow_trigger)
        self.inexact_trigger = int(inexact_trigger)
        self.except_trigger = int(except_trigger)
        self.enable_trigger = int(enable_trigger)
        self.nan_out_trigger = int(nan_out_trigger)
        self.snan_trigger = int(snan_input)

        infinity_magnitude = 0x7ff << 52
        max_finite_magnitude = (0x7fe << 52) | frac_mask
        self.out_inf = self.mask(infinity_magnitude, 63) if out_inf_trigger else 0
        self.inf_round_down = self.mask(max_finite_magnitude, 63) if inf_round_down_trigger else 0

        choose_a_nan = a_nan or (invalid_arithmetic and not nan_input)
        self.a_nan = int(choose_a_nan)
        if nan_input:
            selected_fraction = frac_a if a_nan else frac_b
        else:
            selected_fraction = frac_a
        selected_fraction |= 1 << 51
        nan_magnitude = (0x7ff << 52) | (selected_fraction & frac_mask)
        self.nan_output_0 = self.mask(nan_magnitude, 63) if nan_out_trigger else 0
        self.nan_output = self.nan_output_0

        underflow_result = (sign_result << 63) if underflow_trigger else candidate
        infinity_result = (sign_result << 63) | (
            max_finite_magnitude if inf_round_down_trigger else infinity_magnitude
        )
        self.out_0 = self.mask(underflow_result, 64)
        self.out_1 = self.mask(infinity_result if out_inf_trigger else self.out_0, 64)
        nan_result = (sign_result << 63) | nan_magnitude
        self.out_2 = self.mask(nan_result if nan_out_trigger else self.out_1, 64)
        self.out = self.out_2

        self.invalid = int(invalid_trigger)
        self.overflow = int(overflow_trigger)
        self.underflow = int(underflow_trigger)
        self.inexact = int(inexact_trigger)
        self.exception = int(except_trigger)
        self.ex_enable = int(enable_trigger)
