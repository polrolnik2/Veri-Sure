"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        self._probe_names = [
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger',
            'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output',
            'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2'
        ]
        self._regs = {name: 0 for name in self._probe_names}
        for name in ('out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid'):
            self._regs[name] = 0
        self._regs['exp_2047'] = 2047
        self._regs['exp_2046'] = 2046
        self._regs['mantissa_max'] = (1 << 52) - 1

    def outputs(self, i):
        for name in self._probe_names:
            setattr(self, name, self._regs[name])
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self._regs['out']
        o['ex_enable'] = self._regs['ex_enable']
        o['underflow'] = self._regs['underflow']
        o['overflow'] = self._regs['overflow']
        o['inexact'] = self._regs['inexact']
        o['exception'] = self._regs['exception']
        o['invalid'] = self._regs['invalid']
        return o

    def _derive(self, i):
        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        candidate = self.mask(i['in_except'], 64)
        exponent = self.mask(i['exponent_in'], 12)
        mantissa = self.mask(i['mantissa_in'], 2)
        op = self.mask(i['fpu_op'], 3)
        mode = self.mask(i['rmode'], 2)

        frac_mask = (1 << 52) - 1
        magnitude_mask = (1 << 63) - 1
        opa_exp = (opa >> 52) & 0x7ff
        opb_exp = (opb >> 52) & 0x7ff
        opa_frac = opa & frac_mask
        opb_frac = opb & frac_mask
        opa_zero = int((opa & magnitude_mask) == 0)
        opb_zero = int((opb & magnitude_mask) == 0)
        opa_nan = int(opa_exp == 0x7ff and opa_frac != 0)
        opb_nan = int(opb_exp == 0x7ff and opb_frac != 0)
        opa_qnan = int(opa_nan and ((opa_frac >> 51) & 1))
        opb_qnan = int(opb_nan and ((opb_frac >> 51) & 1))
        opa_snan = int(opa_nan and not ((opa_frac >> 51) & 1))
        opb_snan = int(opb_nan and not ((opb_frac >> 51) & 1))
        opa_inf = int(opa_exp == 0x7ff and opa_frac == 0)
        opb_inf = int(opb_exp == 0x7ff and opb_frac == 0)
        opa_sign = (opa >> 63) & 1
        opb_sign = (opb >> 63) & 1
        opa_pos_inf = int(opa_inf and not opa_sign)
        opb_pos_inf = int(opb_inf and not opb_sign)
        opa_neg_inf = int(opa_inf and opa_sign)
        opb_neg_inf = int(opb_inf and opb_sign)
        nan_input = int(opa_nan or opb_nan)
        snan_input = int(opa_snan or opb_snan)

        add = int(op == 0)
        subtract = int(op == 1)
        multiply = int(op == 2)
        divide = int(op == 3)
        round_nearest = int(mode == 0)
        round_to_zero = int(mode == 1)
        round_to_pos_inf = int(mode == 2)
        round_to_neg_inf = int(mode == 3)

        in_zero = int((candidate & magnitude_mask) == 0)
        div_0_by_0 = int(divide and opa_zero and opb_zero)
        div_inf_by_inf = int(divide and opa_inf and opb_inf)
        div_by_0 = int(divide and opb_zero and not opa_zero and not opa_inf and not opa_nan)
        div_by_inf = int(divide and opb_inf and not opa_inf and not opa_nan)
        mul_0_by_inf = int(multiply and ((opa_zero and opb_inf) or (opa_inf and opb_zero)))
        mul_inf = int(multiply and (opa_inf or opb_inf))
        div_inf = int(divide and (opa_inf or opb_inf))
        add_inf = int(add and (opa_inf or opb_inf))
        sub_inf = int(subtract and (opa_inf or opb_inf))

        add_invalid = bool(add and ((opa_pos_inf and opb_neg_inf) or (opa_neg_inf and opb_pos_inf)))
        sub_invalid = bool(subtract and ((opa_pos_inf and opb_pos_inf) or (opa_neg_inf and opb_neg_inf)))
        addsub_inf_invalid = int(add_invalid or sub_invalid)
        addsub_inf = int((add_inf or sub_inf) and not addsub_inf_invalid)

        valid_addsub_inf = bool(addsub_inf and not nan_input)
        valid_mul_inf = bool(mul_inf and not mul_0_by_inf and not nan_input)
        valid_div_inf = bool(divide and opa_inf and not opb_inf and not opb_nan and not nan_input)
        valid_inf_result = valid_addsub_inf or valid_mul_inf or valid_div_inf
        out_inf_trigger = int(valid_inf_result or div_by_0 or exponent > 2046)

        sign = (candidate >> 63) & 1
        out_pos_inf = int(out_inf_trigger and not sign)
        out_neg_inf = int(out_inf_trigger and sign)
        inf_round_down_trigger = int(
            (out_pos_inf and (round_to_zero or round_to_neg_inf)) or
            (out_neg_inf and (round_to_zero or round_to_pos_inf))
        )

        finite_inputs = not nan_input and not opa_inf and not opb_inf
        mul_uf = int(multiply and finite_inputs and not opa_zero and not opb_zero and in_zero)
        div_uf = int(
            divide and not nan_input and (
                div_by_inf or
                (finite_inputs and not opa_zero and not opb_zero and in_zero)
            )
        )
        underflow_trigger = int(bool(mul_uf or div_uf))
        invalid_trigger = int(bool(snan_input or addsub_inf_invalid or mul_0_by_inf or div_0_by_0 or div_inf_by_inf))
        overflow_trigger = int(bool(out_inf_trigger and not nan_input))
        inexact_trigger = int(bool(not nan_input and (mantissa != 0 or out_inf_trigger or underflow_trigger)))
        except_trigger = int(bool(invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger))
        nan_out_trigger = int(bool(nan_input or invalid_trigger))
        enable_trigger = int(bool(nan_out_trigger or out_inf_trigger or underflow_trigger or inexact_trigger))

        if nan_input:
            payload_source = opa if opa_nan else opb
        else:
            payload_source = opa
        nan_fraction = (payload_source & frac_mask) | (1 << 51)
        nan_magnitude = (0x7ff << 52) | nan_fraction
        nan_value = self.mask((sign << 63) | nan_magnitude, 64) if nan_out_trigger else 0
        nan_output = self.mask(nan_magnitude, 63) if nan_out_trigger else 0

        inf_magnitude = 0x7ff << 52
        max_finite_magnitude = (0x7fe << 52) | frac_mask
        inf_round_down = max_finite_magnitude if inf_round_down_trigger else 0
        out_inf_value = inf_magnitude if out_inf_trigger else 0

        out_0 = self.mask(((sign << 63) if underflow_trigger else candidate), 64)
        out_1 = out_0
        if out_inf_trigger:
            magnitude = max_finite_magnitude if inf_round_down_trigger else inf_magnitude
            out_1 = self.mask((sign << 63) | magnitude, 64)
        out_2 = nan_value if nan_out_trigger else out_1

        return {
            'in_et_zero': in_zero,
            'opa_et_zero': opa_zero,
            'opb_et_zero': opb_zero,
            'input_et_zero': in_zero,
            'add': add,
            'subtract': subtract,
            'multiply': multiply,
            'divide': divide,
            'opa_qnan': opa_qnan,
            'opb_qnan': opb_qnan,
            'opa_snan': opa_snan,
            'opb_snan': opb_snan,
            'opa_pos_inf': opa_pos_inf,
            'opb_pos_inf': opb_pos_inf,
            'opa_neg_inf': opa_neg_inf,
            'opb_neg_inf': opb_neg_inf,
            'opa_inf': opa_inf,
            'opb_inf': opb_inf,
            'nan_input': nan_input,
            'snan_input': snan_input,
            'a_nan': int(bool(opa_nan)),
            'div_by_0': div_by_0,
            'div_0_by_0': div_0_by_0,
            'div_inf_by_inf': div_inf_by_inf,
            'div_by_inf': div_by_inf,
            'mul_0_by_inf': mul_0_by_inf,
            'mul_inf': mul_inf,
            'div_inf': div_inf,
            'add_inf': add_inf,
            'sub_inf': sub_inf,
            'addsub_inf_invalid': addsub_inf_invalid,
            'addsub_inf': addsub_inf,
            'out_inf_trigger': out_inf_trigger,
            'out_pos_inf': out_pos_inf,
            'out_neg_inf': out_neg_inf,
            'round_nearest': round_nearest,
            'round_to_zero': round_to_zero,
            'round_to_pos_inf': round_to_pos_inf,
            'round_to_neg_inf': round_to_neg_inf,
            'inf_round_down_trigger': inf_round_down_trigger,
            'mul_uf': mul_uf,
            'div_uf': div_uf,
            'underflow_trigger': underflow_trigger,
            'invalid_trigger': invalid_trigger,
            'overflow_trigger': overflow_trigger,
            'inexact_trigger': inexact_trigger,
            'except_trigger': except_trigger,
            'enable_trigger': enable_trigger,
            'nan_out_trigger': nan_out_trigger,
            'snan_trigger': snan_input,
            'exp_2047': 2047,
            'exp_2046': 2046,
            'nan_output_0': nan_output,
            'nan_output': nan_output,
            'mantissa_max': frac_mask,
            'inf_round_down': self.mask(inf_round_down, 63),
            'out_inf': self.mask(out_inf_value, 63),
            'out_0': out_0,
            'out_1': out_1,
            'out_2': out_2,
            'out': out_2,
            'ex_enable': enable_trigger,
            'underflow': underflow_trigger,
            'overflow': overflow_trigger,
            'inexact': inexact_trigger,
            'exception': except_trigger,
            'invalid': invalid_trigger
        }

    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not i['enable']:
            return
        self._regs.update(self._derive(i))
