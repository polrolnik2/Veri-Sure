"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        self._out = 0
        self._ex_enable = 0
        self._underflow = 0
        self._overflow = 0
        self._inexact = 0
        self._exception = 0
        self._invalid = 0
        self._p = dict((name, 0) for name in (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger',
            'nan_output_0', 'nan_output', 'inf_round_down', 'out_inf',
            'out_0', 'out_1', 'out_2'
        ))
        for name, value in self._p.items():
            setattr(self, name, value)
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1

    def _calc(self, i):
        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        normal = self.mask(i['in_except'], 64)
        exponent_in = self.mask(i['exponent_in'], 12)
        mantissa_in = self.mask(i['mantissa_in'], 2)
        fpu_op = self.mask(i['fpu_op'], 3)
        rmode = self.mask(i['rmode'], 2)

        frac_mask = (1 << 52) - 1
        exp_mask = (1 << 11) - 1
        mag_mask = (1 << 63) - 1
        sign = (normal >> 63) & 1
        a_exp = (opa >> 52) & exp_mask
        b_exp = (opb >> 52) & exp_mask
        a_frac = opa & frac_mask
        b_frac = opb & frac_mask
        a_zero = (opa & mag_mask) == 0
        b_zero = (opb & mag_mask) == 0
        in_zero = (normal & mag_mask) == 0
        a_nan = a_exp == 2047 and a_frac != 0
        b_nan = b_exp == 2047 and b_frac != 0
        a_qnan = a_nan and ((a_frac >> 51) & 1) == 1
        b_qnan = b_nan and ((b_frac >> 51) & 1) == 1
        a_snan = a_nan and not a_qnan
        b_snan = b_nan and not b_qnan
        a_inf = a_exp == 2047 and a_frac == 0
        b_inf = b_exp == 2047 and b_frac == 0
        a_pos_inf = a_inf and ((opa >> 63) & 1) == 0
        b_pos_inf = b_inf and ((opb >> 63) & 1) == 0
        a_neg_inf = a_inf and ((opa >> 63) & 1) == 1
        b_neg_inf = b_inf and ((opb >> 63) & 1) == 1

        add = fpu_op == 0
        subtract = fpu_op == 1
        multiply = fpu_op == 2
        divide = fpu_op == 3
        nan_input = a_nan or b_nan
        snan_input = a_snan or b_snan

        add_inf = add and (a_inf or b_inf)
        sub_inf = subtract and (a_inf or b_inf)
        bad_add = add and ((a_pos_inf and b_neg_inf) or (a_neg_inf and b_pos_inf))
        bad_sub = subtract and ((a_pos_inf and b_pos_inf) or (a_neg_inf and b_neg_inf))
        addsub_inf_invalid = bad_add or bad_sub
        addsub_inf = add_inf or sub_inf

        mul_0_by_inf = multiply and ((a_zero and b_inf) or (b_zero and a_inf))
        mul_inf = multiply and (a_inf or b_inf)
        div_0_by_0 = divide and a_zero and b_zero
        div_inf_by_inf = divide and a_inf and b_inf
        div_by_0 = divide and b_zero and not a_zero
        div_by_inf = divide and b_inf
        div_inf = divide and a_inf

        valid_mul_inf = mul_inf and not mul_0_by_inf
        valid_div_inf = divide and a_inf and not b_inf
        valid_addsub_inf = addsub_inf and not addsub_inf_invalid
        out_inf_trigger = (valid_mul_inf or valid_div_inf or valid_addsub_inf or
                           div_by_0 or exponent_in > 2046)

        finite_div_by_inf = divide and b_inf and not a_inf and not a_nan
        mul_uf = multiply and not a_zero and not b_zero and in_zero
        div_uf = finite_div_by_inf or (divide and not a_zero and not b_zero and in_zero)
        underflow_trigger = mul_uf or div_uf

        invalid_trigger = (snan_input or addsub_inf_invalid or mul_0_by_inf or
                            div_0_by_0 or div_inf_by_inf)
        overflow_trigger = out_inf_trigger and not nan_input
        inexact_trigger = (not nan_input) and (mantissa_in != 0 or out_inf_trigger or underflow_trigger)
        except_trigger = invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger
        nan_out_trigger = nan_input or invalid_trigger
        enable_trigger = nan_out_trigger or except_trigger

        out_pos_inf = out_inf_trigger and sign == 0
        out_neg_inf = out_inf_trigger and sign == 1
        round_down = out_inf_trigger and (
            (sign == 0 and rmode in (1, 3)) or
            (sign == 1 and rmode in (1, 2))
        )

        infinity_magnitude = 2047 << 52
        max_finite_magnitude = (2046 << 52) | frac_mask
        inf_round_down = max_finite_magnitude if round_down else 0
        out_inf = infinity_magnitude if out_inf_trigger else 0

        out_0 = ((sign << 63) if underflow_trigger else normal)
        if out_inf_trigger:
            magnitude = max_finite_magnitude if round_down else infinity_magnitude
            out_1 = (sign << 63) | magnitude
        else:
            out_1 = out_0

        a_nan_selected = a_nan or not nan_input
        if a_nan or not nan_input:
            selected_frac = a_frac
        else:
            selected_frac = b_frac
        nan_magnitude = (2047 << 52) | (selected_frac | (1 << 51))
        nan_output = nan_magnitude & mag_mask
        out_2 = ((sign << 63) | nan_output) if nan_out_trigger else out_1

        underflow = int(bool(underflow_trigger))
        overflow = int(bool(overflow_trigger))
        inexact = int(bool(inexact_trigger))
        invalid = int(bool(invalid_trigger))
        exception = int(bool(invalid or overflow or underflow or inexact))
        ex_enable = int(bool(enable_trigger))

        p = {
            'in_et_zero': int(bool(in_zero)),
            'opa_et_zero': int(bool(a_zero)),
            'opb_et_zero': int(bool(b_zero)),
            'input_et_zero': int(bool(a_zero or b_zero)),
            'add': int(bool(add)), 'subtract': int(bool(subtract)),
            'multiply': int(bool(multiply)), 'divide': int(bool(divide)),
            'opa_qnan': int(bool(a_qnan)), 'opb_qnan': int(bool(b_qnan)),
            'opa_snan': int(bool(a_snan)), 'opb_snan': int(bool(b_snan)),
            'opa_pos_inf': int(bool(a_pos_inf)), 'opb_pos_inf': int(bool(b_pos_inf)),
            'opa_neg_inf': int(bool(a_neg_inf)), 'opb_neg_inf': int(bool(b_neg_inf)),
            'opa_inf': int(bool(a_inf)), 'opb_inf': int(bool(b_inf)),
            'nan_input': int(bool(nan_input)), 'snan_input': int(bool(snan_input)),
            'a_nan': int(bool(nan_out_trigger and a_nan_selected)),
            'div_by_0': int(bool(div_by_0)), 'div_0_by_0': int(bool(div_0_by_0)),
            'div_inf_by_inf': int(bool(div_inf_by_inf)), 'div_by_inf': int(bool(div_by_inf)),
            'mul_0_by_inf': int(bool(mul_0_by_inf)), 'mul_inf': int(bool(mul_inf)),
            'div_inf': int(bool(div_inf)), 'add_inf': int(bool(add_inf)),
            'sub_inf': int(bool(sub_inf)),
            'addsub_inf_invalid': int(bool(addsub_inf_invalid)),
            'addsub_inf': int(bool(addsub_inf)),
            'out_inf_trigger': int(bool(out_inf_trigger)),
            'out_pos_inf': int(bool(out_pos_inf)), 'out_neg_inf': int(bool(out_neg_inf)),
            'round_nearest': int(rmode == 0), 'round_to_zero': int(rmode == 1),
            'round_to_pos_inf': int(rmode == 2), 'round_to_neg_inf': int(rmode == 3),
            'inf_round_down_trigger': int(bool(round_down)),
            'mul_uf': int(bool(mul_uf)), 'div_uf': int(bool(div_uf)),
            'underflow_trigger': int(bool(underflow_trigger)),
            'invalid_trigger': int(bool(invalid_trigger)),
            'overflow_trigger': int(bool(overflow_trigger)),
            'inexact_trigger': int(bool(inexact_trigger)),
            'except_trigger': int(bool(except_trigger)),
            'enable_trigger': int(bool(enable_trigger)),
            'nan_out_trigger': int(bool(nan_out_trigger)),
            'snan_trigger': int(bool(snan_input)),
            'nan_output_0': nan_output, 'nan_output': nan_output,
            'inf_round_down': inf_round_down, 'out_inf': out_inf,
            'out_0': self.mask(out_0, 64), 'out_1': self.mask(out_1, 64),
            'out_2': self.mask(out_2, 64)
        }
        return {
            'probes': p,
            'out': self.mask(out_2, 64),
            'ex_enable': ex_enable,
            'underflow': underflow,
            'overflow': overflow,
            'inexact': inexact,
            'exception': exception,
            'invalid': invalid
        }

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self._out
        o['ex_enable'] = self._ex_enable
        o['underflow'] = self._underflow
        o['overflow'] = self._overflow
        o['inexact'] = self._inexact
        o['exception'] = self._exception
        o['invalid'] = self._invalid
        for name, value in self._p.items():
            setattr(self, name, value)
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not i['enable']:
            return
        result = self._calc(i)
        self._p = result['probes']
        self._out = result['out']
        self._ex_enable = result['ex_enable']
        self._underflow = result['underflow']
        self._overflow = result['overflow']
        self._inexact = result['inexact']
        self._exception = result['exception']
        self._invalid = result['invalid']
