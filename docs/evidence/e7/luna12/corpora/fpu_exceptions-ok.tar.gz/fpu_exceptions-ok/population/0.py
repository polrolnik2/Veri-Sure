"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        probe_names = (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan',
            'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf',
            'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input',
            'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf',
            'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf',
            'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047',
            'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max',
            'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2'
        )
        self._p = {name: 0 for name in probe_names}
        self._p['exp_2047'] = 2047
        self._p['exp_2046'] = 2046
        self._p['mantissa_max'] = (1 << 52) - 1
        self._out = {
            'out': 0, 'ex_enable': 0, 'underflow': 0, 'overflow': 0,
            'inexact': 0, 'exception': 0, 'invalid': 0
        }
        for name, value in self._p.items():
            setattr(self, name, value)

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self._out['out']
        o['ex_enable'] = self._out['ex_enable']
        o['underflow'] = self._out['underflow']
        o['overflow'] = self._out['overflow']
        o['inexact'] = self._out['inexact']
        o['exception'] = self._out['exception']
        o['invalid'] = self._out['invalid']
        for name, value in self._p.items():
            setattr(self, name, value)
        return o

    def _compute(self, i):
        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        normal = self.mask(i['in_except'], 64)
        exponent = self.mask(i['exponent_in'], 12)
        mantissa = self.mask(i['mantissa_in'], 2)
        fpu_op = self.mask(i['fpu_op'], 3)
        rmode = self.mask(i['rmode'], 2)
        fraction_mask = (1 << 52) - 1
        magnitude_mask = (1 << 63) - 1

        def decode(x):
            exp = (x >> 52) & 0x7ff
            frac = x & fraction_mask
            zero = int((x & magnitude_mask) == 0)
            nan = int(exp == 0x7ff and frac != 0)
            qnan = int(nan and ((frac >> 51) & 1))
            snan = int(nan and not ((frac >> 51) & 1))
            inf = int(exp == 0x7ff and frac == 0)
            pos_inf = int(inf and not (x >> 63))
            neg_inf = int(inf and bool(x >> 63))
            return zero, nan, qnan, snan, inf, pos_inf, neg_inf

        az, an, aq, ass, ai, api, ani = decode(opa)
        bz, bn, bq, bss, bi, bpi, bni = decode(opb)
        in_zero = int((normal & magnitude_mask) == 0)
        add = int(fpu_op == 0)
        subtract = int(fpu_op == 1)
        multiply = int(fpu_op == 2)
        divide = int(fpu_op == 3)
        nan_input = int(an or bn)
        snan_input = int(ass or bss)

        div_0_by_0 = int(divide and az and bz)
        div_inf_by_inf = int(divide and ai and bi)
        div_by_0 = int(divide and bz and not az)
        div_by_inf = int(divide and bi and not ai)
        mul_0_by_inf = int(multiply and ((az and bi) or (bz and ai)))
        mul_inf = int(multiply and (ai or bi))
        div_inf = int(divide and ai and not bi)
        add_inf = int(add and (ai or bi))
        sub_inf = int(subtract and (ai or bi))

        invalid_add = bool(add and ((api and bni) or (ani and bpi)))
        invalid_sub = bool(subtract and ((api and bpi) or (ani and bni)))
        addsub_inf_invalid = int(invalid_add or invalid_sub)
        addsub_inf = int((add or subtract) and (ai or bi))
        invalid_trigger = int(snan_input or addsub_inf_invalid or mul_0_by_inf or div_0_by_0 or div_inf_by_inf)

        valid_addsub_inf = bool(addsub_inf and not addsub_inf_invalid)
        valid_mul_inf = bool(mul_inf and not mul_0_by_inf)
        valid_div_inf = bool(divide and ((ai and not bi) or div_by_0))
        out_inf_trigger = int(valid_addsub_inf or valid_mul_inf or valid_div_inf or div_by_0 or exponent > 2046)

        sign = normal & (1 << 63)
        negative = int(bool(sign))
        out_pos_inf = int(out_inf_trigger and not negative)
        out_neg_inf = int(out_inf_trigger and negative)
        round_down = int(out_inf_trigger and (
            ((not negative) and rmode in (1, 3)) or
            (negative and rmode in (1, 2))
        ))
        infinity_magnitude = 2047 << 52
        max_finite_magnitude = (2046 << 52) | fraction_mask
        inf_round_down = max_finite_magnitude if round_down else 0
        out_inf = (max_finite_magnitude if round_down else infinity_magnitude) if out_inf_trigger else 0

        finite_a = not ai and not an
        finite_b = not bi and not bn
        div_by_inf_finite = bool(divide and bi and finite_a)
        mul_uf = int(multiply and in_zero and not az and not bz and finite_a and finite_b)
        div_uf = int(div_by_inf_finite or (
            divide and in_zero and not az and not bz and finite_a and finite_b
        ))
        underflow_trigger = int(mul_uf or div_uf)
        overflow_trigger = int(out_inf_trigger and not nan_input)
        inexact_trigger = int((bool(mantissa) or out_inf_trigger or underflow_trigger) and not nan_input)
        except_trigger = int(bool(invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger))
        enable_trigger = 1
        nan_out_trigger = int(nan_input or invalid_trigger)

        selected_nan = opa if an else (opb if bn else opa)
        nan_fraction = (selected_nan & fraction_mask) | (1 << 51)
        nan_magnitude = ((2047 << 52) | nan_fraction) & magnitude_mask
        nan_output_0 = nan_magnitude if nan_out_trigger else 0
        nan_output = nan_magnitude if nan_out_trigger else 0

        out_0 = sign if underflow_trigger else normal
        if out_inf_trigger:
            out_1 = sign | out_inf
        else:
            out_1 = out_0
        out_2 = (sign | nan_output) if nan_out_trigger else out_1
        out_value = self.mask(out_2, 64)

        p = {
            'in_et_zero': in_zero,
            'opa_et_zero': az,
            'opb_et_zero': bz,
            'input_et_zero': int(bool(az or bz)),
            'add': add,
            'subtract': subtract,
            'multiply': multiply,
            'divide': divide,
            'opa_qnan': aq,
            'opb_qnan': bq,
            'opa_snan': ass,
            'opb_snan': bss,
            'opa_pos_inf': api,
            'opb_pos_inf': bpi,
            'opa_neg_inf': ani,
            'opb_neg_inf': bni,
            'opa_inf': ai,
            'opb_inf': bi,
            'nan_input': nan_input,
            'snan_input': snan_input,
            'a_nan': an,
            'div_by_0': div_by_0,
            'div_0_by_0': div_0_by_0,
            'div_inf_by_inf': div_inf_by_inf,
            'div_by_inf': div_by_inf,
            'mul_0_by_inf': mul_0_by_inf,
            'mul_inf': mul_inf,
            'div_inf': div_inf,
            'add_inf': add_inf,
            'sub_inf': sub_inf,
            'addsub_inf_invalid': addsub_inf_invalid,
            'addsub_inf': addsub_inf,
            'out_inf_trigger': out_inf_trigger,
            'out_pos_inf': out_pos_inf,
            'out_neg_inf': out_neg_inf,
            'round_nearest': int(rmode == 0),
            'round_to_zero': int(rmode == 1),
            'round_to_pos_inf': int(rmode == 2),
            'round_to_neg_inf': int(rmode == 3),
            'inf_round_down_trigger': round_down,
            'mul_uf': mul_uf,
            'div_uf': div_uf,
            'underflow_trigger': underflow_trigger,
            'invalid_trigger': invalid_trigger,
            'overflow_trigger': overflow_trigger,
            'inexact_trigger': inexact_trigger,
            'except_trigger': except_trigger,
            'enable_trigger': enable_trigger,
            'nan_out_trigger': nan_out_trigger,
            'snan_trigger': snan_input,
            'exp_2047': 2047,
            'exp_2046': 2046,
            'nan_output_0': nan_output_0,
            'nan_output': nan_output,
            'mantissa_max': fraction_mask,
            'inf_round_down': inf_round_down,
            'out_inf': out_inf,
            'out_0': self.mask(out_0, 64),
            'out_1': self.mask(out_1, 64),
            'out_2': out_value
        }
        out = {
            'out': out_value,
            'ex_enable': except_trigger,
            'underflow': underflow_trigger,
            'overflow': overflow_trigger,
            'inexact': inexact_trigger,
            'exception': except_trigger,
            'invalid': invalid_trigger
        }
        return out, p

    def advance(self, i):
        if self.mask(i['rst'], 1):
            self.reset()
            return
        if not self.mask(i['enable'], 1):
            return
        next_out, next_probes = self._compute(i)
        self._out = next_out
        self._p = next_probes
