"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        self.out = 0
        self.ex_enable = 0
        self.underflow = 0
        self.overflow = 0
        self.inexact = 0
        self.exception = 0
        self.invalid = 0
        boolean_probes = (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger'
        )
        self._probe = {}
        for name in boolean_probes:
            self._probe[name] = False
        self._probe['exp_2047'] = 2047
        self._probe['exp_2046'] = 2046
        self._probe['nan_output_0'] = 0
        self._probe['nan_output'] = 0
        self._probe['mantissa_max'] = (1 << 52) - 1
        self._probe['inf_round_down'] = 0
        self._probe['out_inf'] = 0
        self._probe['out_0'] = 0
        self._probe['out_1'] = 0
        self._probe['out_2'] = 0
        for name, value in self._probe.items():
            setattr(self, name, value)

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self.out
        o['ex_enable'] = self.ex_enable
        o['underflow'] = self.underflow
        o['overflow'] = self.overflow
        o['inexact'] = self.inexact
        o['exception'] = self.exception
        o['invalid'] = self.invalid
        for name, value in self._probe.items():
            setattr(self, name, value)
        return o

    def _decode_inputs(self, i):
        opa = self.mask(int(i['opa']), 64)
        opb = self.mask(int(i['opb']), 64)
        in_except = self.mask(int(i['in_except']), 64)
        exponent_in = self.mask(int(i['exponent_in']), 12)
        mantissa_in = self.mask(int(i['mantissa_in']), 2)
        fpu_op = self.mask(int(i['fpu_op']), 3)
        rmode = self.mask(int(i['rmode']), 2)

        opa_exp = (opa >> 52) & 0x7ff
        opb_exp = (opb >> 52) & 0x7ff
        opa_frac = opa & ((1 << 52) - 1)
        opb_frac = opb & ((1 << 52) - 1)
        opa_zero = (opa & ((1 << 63) - 1)) == 0
        opb_zero = (opb & ((1 << 63) - 1)) == 0
        opa_nan = opa_exp == 2047 and opa_frac != 0
        opb_nan = opb_exp == 2047 and opb_frac != 0
        opa_qnan = opa_nan and bool((opa_frac >> 51) & 1)
        opb_qnan = opb_nan and bool((opb_frac >> 51) & 1)
        opa_snan = opa_nan and not opa_qnan
        opb_snan = opb_nan and not opb_qnan
        opa_inf = opa_exp == 2047 and opa_frac == 0
        opb_inf = opb_exp == 2047 and opb_frac == 0

        return {
            'opa': opa,
            'opb': opb,
            'in_except': in_except,
            'exponent_in': exponent_in,
            'mantissa_in': mantissa_in,
            'fpu_op': fpu_op,
            'rmode': rmode,
            'opa_frac': opa_frac,
            'opb_frac': opb_frac,
            'opa_zero': opa_zero,
            'opb_zero': opb_zero,
            'input_zero': (in_except & ((1 << 63) - 1)) == 0,
            'opa_nan': opa_nan,
            'opb_nan': opb_nan,
            'opa_qnan': opa_qnan,
            'opb_qnan': opb_qnan,
            'opa_snan': opa_snan,
            'opb_snan': opb_snan,
            'opa_inf': opa_inf,
            'opb_inf': opb_inf,
            'opa_pos_inf': opa_inf and ((opa >> 63) == 0),
            'opb_pos_inf': opb_inf and ((opb >> 63) == 0),
            'opa_neg_inf': opa_inf and ((opa >> 63) != 0),
            'opb_neg_inf': opb_inf and ((opb >> 63) != 0),
            'nan_input': opa_nan or opb_nan,
            'snan_input': opa_snan or opb_snan,
            'add': fpu_op == 0,
            'subtract': fpu_op == 1,
            'multiply': fpu_op == 2,
            'divide': fpu_op == 3
        }

    def _compute(self, i):
        d = self._decode_inputs(i)
        sign = (d['in_except'] >> 63) & 1
        add = d['add']
        subtract = d['subtract']
        multiply = d['multiply']
        divide = d['divide']
        opa_inf = d['opa_inf']
        opb_inf = d['opb_inf']
        opa_zero = d['opa_zero']
        opb_zero = d['opb_zero']
        nan_input = d['nan_input']

        div_0_by_0 = divide and opa_zero and opb_zero
        div_inf_by_inf = divide and opa_inf and opb_inf
        div_by_0 = divide and opb_zero and not opa_zero
        div_by_inf = divide and opb_inf and not opa_inf and not nan_input
        mul_0_by_inf = multiply and ((opa_zero and opb_inf) or (opb_zero and opa_inf))
        mul_inf = multiply and (opa_inf or opb_inf)
        div_inf = divide and opa_inf and not opb_inf
        add_inf = add and (opa_inf or opb_inf)
        sub_inf = subtract and (opa_inf or opb_inf)

        addsub_inf_invalid = (
            (add and ((d['opa_pos_inf'] and d['opb_neg_inf']) or
                      (d['opa_neg_inf'] and d['opb_pos_inf']))) or
            (subtract and ((d['opa_pos_inf'] and d['opb_pos_inf']) or
                           (d['opa_neg_inf'] and d['opb_neg_inf'])))
        )
        addsub_inf = (add or subtract) and (opa_inf or opb_inf)
        invalid_trigger = (
            d['snan_input'] or addsub_inf_invalid or mul_0_by_inf or
            div_0_by_0 or div_inf_by_inf
        )
        nan_out_trigger = nan_input or invalid_trigger

        valid_mul_inf = mul_inf and not mul_0_by_inf and not nan_input
        valid_div_zero = div_by_0 and not div_0_by_0 and not nan_input
        valid_div_inf = div_inf and not div_inf_by_inf and not nan_input
        valid_addsub_inf = addsub_inf and not addsub_inf_invalid and not nan_input
        out_inf_trigger = (
            valid_mul_inf or valid_div_zero or valid_div_inf or
            valid_addsub_inf or d['exponent_in'] > 2046
        )
        out_pos_inf = out_inf_trigger and sign == 0
        out_neg_inf = out_inf_trigger and sign == 1

        rmode = d['rmode']
        round_nearest = rmode == 0
        round_to_zero = rmode == 1
        round_to_pos_inf = rmode == 2
        round_to_neg_inf = rmode == 3
        inf_round_down_trigger = (
            (out_pos_inf and (round_to_zero or round_to_neg_inf)) or
            (out_neg_inf and (round_to_zero or round_to_pos_inf))
        )

        mul_uf = (
            multiply and d['input_zero'] and not opa_zero and not opb_zero
        )
        div_uf = divide and (
            div_by_inf or
            (d['input_zero'] and not opa_zero and not opb_zero)
        )
        underflow_trigger = mul_uf or div_uf
        overflow_trigger = out_inf_trigger and not nan_input
        inexact_trigger = (
            (d['mantissa_in'] != 0 or out_inf_trigger or underflow_trigger)
            and not nan_input
        )
        except_trigger = (
            invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger
        )
        enable_trigger = (
            nan_out_trigger or out_inf_trigger or underflow_trigger or
            invalid_trigger or inexact_trigger
        )

        mantissa_max = (1 << 52) - 1
        infinity_magnitude = 2047 << 52
        max_finite_magnitude = (2046 << 52) | mantissa_max
        inf_round_down = max_finite_magnitude if inf_round_down_trigger else 0
        if out_inf_trigger:
            out_inf = max_finite_magnitude if inf_round_down_trigger else infinity_magnitude
        else:
            out_inf = 0

        if nan_input:
            selected_frac = d['opa_frac'] if d['opa_nan'] else d['opb_frac']
        else:
            selected_frac = d['opa_frac']
        nan_magnitude = (2047 << 52) | selected_frac | (1 << 51)

        signed_zero = sign << 63
        out_0 = signed_zero if underflow_trigger else d['in_except']
        if out_inf_trigger:
            out_1 = (sign << 63) | out_inf
        else:
            out_1 = out_0
        if nan_out_trigger:
            out_2 = (sign << 63) | nan_magnitude
        else:
            out_2 = out_1

        probes = {
            'in_et_zero': bool(d['input_zero']),
            'opa_et_zero': bool(opa_zero),
            'opb_et_zero': bool(opb_zero),
            'input_et_zero': bool(d['input_zero']),
            'add': bool(add),
            'subtract': bool(subtract),
            'multiply': bool(multiply),
            'divide': bool(divide),
            'opa_qnan': bool(d['opa_qnan']),
            'opb_qnan': bool(d['opb_qnan']),
            'opa_snan': bool(d['opa_snan']),
            'opb_snan': bool(d['opb_snan']),
            'opa_pos_inf': bool(d['opa_pos_inf']),
            'opb_pos_inf': bool(d['opb_pos_inf']),
            'opa_neg_inf': bool(d['opa_neg_inf']),
            'opb_neg_inf': bool(d['opb_neg_inf']),
            'opa_inf': bool(opa_inf),
            'opb_inf': bool(opb_inf),
            'nan_input': bool(nan_input),
            'snan_input': bool(d['snan_input']),
            'a_nan': bool(d['opa_nan']),
            'div_by_0': bool(div_by_0),
            'div_0_by_0': bool(div_0_by_0),
            'div_inf_by_inf': bool(div_inf_by_inf),
            'div_by_inf': bool(div_by_inf),
            'mul_0_by_inf': bool(mul_0_by_inf),
            'mul_inf': bool(mul_inf),
            'div_inf': bool(div_inf),
            'add_inf': bool(add_inf),
            'sub_inf': bool(sub_inf),
            'addsub_inf_invalid': bool(addsub_inf_invalid),
            'addsub_inf': bool(addsub_inf),
            'out_inf_trigger': bool(out_inf_trigger),
            'out_pos_inf': bool(out_pos_inf),
            'out_neg_inf': bool(out_neg_inf),
            'round_nearest': bool(round_nearest),
            'round_to_zero': bool(round_to_zero),
            'round_to_pos_inf': bool(round_to_pos_inf),
            'round_to_neg_inf': bool(round_to_neg_inf),
            'inf_round_down_trigger': bool(inf_round_down_trigger),
            'mul_uf': bool(mul_uf),
            'div_uf': bool(div_uf),
            'underflow_trigger': bool(underflow_trigger),
            'invalid_trigger': bool(invalid_trigger),
            'overflow_trigger': bool(overflow_trigger),
            'inexact_trigger': bool(inexact_trigger),
            'except_trigger': bool(except_trigger),
            'enable_trigger': bool(enable_trigger),
            'nan_out_trigger': bool(nan_out_trigger),
            'snan_trigger': bool(d['snan_input']),
            'exp_2047': 2047,
            'exp_2046': 2046,
            'nan_output_0': self.mask(nan_magnitude, 63),
            'nan_output': self.mask(nan_magnitude, 63),
            'mantissa_max': mantissa_max,
            'inf_round_down': self.mask(inf_round_down, 63),
            'out_inf': self.mask(out_inf, 63),
            'out_0': self.mask(out_0, 64),
            'out_1': self.mask(out_1, 64),
            'out_2': self.mask(out_2, 64)
        }
        return {
            'out': self.mask(out_2, 64),
            'ex_enable': int(enable_trigger),
            'underflow': int(underflow_trigger),
            'overflow': int(overflow_trigger),
            'inexact': int(inexact_trigger),
            'exception': int(except_trigger),
            'invalid': int(invalid_trigger),
            'probes': probes
        }

    def advance(self, i):
        if int(i['rst']) & 1:
            self.reset()
            return
        if not (int(i['enable']) & 1):
            return
        values = self._compute(i)
        self.out = values['out']
        self.ex_enable = values['ex_enable']
        self.underflow = values['underflow']
        self.overflow = values['overflow']
        self.inexact = values['inexact']
        self.exception = values['exception']
        self.invalid = values['invalid']
        self._probe = values['probes']
