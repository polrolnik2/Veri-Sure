"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        for name in 'ex_enable underflow overflow inexact exception invalid in_et_zero opa_et_zero opb_et_zero input_et_zero add subtract multiply divide opa_qnan opb_qnan opa_snan opb_snan opa_pos_inf opb_pos_inf opa_neg_inf opb_neg_inf opa_inf opb_inf nan_input snan_input a_nan div_by_0 div_0_by_0 div_inf_by_inf div_by_inf mul_0_by_inf mul_inf div_inf add_inf sub_inf addsub_inf_invalid addsub_inf out_inf_trigger out_pos_inf out_neg_inf round_nearest round_to_zero round_to_pos_inf round_to_neg_inf inf_round_down_trigger mul_uf div_uf underflow_trigger invalid_trigger overflow_trigger inexact_trigger except_trigger enable_trigger nan_out_trigger snan_trigger'.split():
            setattr(self, name, False)
        for name in 'out nan_output_0 nan_output inf_round_down out_inf out_0 out_1 out_2'.split():
            setattr(self, name, 0)

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self.mask(self.out, 64)
        o['ex_enable'] = int(self.ex_enable)
        o['underflow'] = int(self.underflow)
        o['overflow'] = int(self.overflow)
        o['inexact'] = int(self.inexact)
        o['exception'] = int(self.exception)
        o['invalid'] = int(self.invalid)

        probe_values = {
            'in_et_zero': bool(self.in_et_zero),
            'opa_et_zero': bool(self.opa_et_zero),
            'opb_et_zero': bool(self.opb_et_zero),
            'input_et_zero': bool(self.input_et_zero),
            'add': bool(self.add),
            'subtract': bool(self.subtract),
            'multiply': bool(self.multiply),
            'divide': bool(self.divide),
            'opa_qnan': bool(self.opa_qnan),
            'opb_qnan': bool(self.opb_qnan),
            'opa_snan': bool(self.opa_snan),
            'opb_snan': bool(self.opb_snan),
            'opa_pos_inf': bool(self.opa_pos_inf),
            'opb_pos_inf': bool(self.opb_pos_inf),
            'opa_neg_inf': bool(self.opa_neg_inf),
            'opb_neg_inf': bool(self.opb_neg_inf),
            'opa_inf': bool(self.opa_inf),
            'opb_inf': bool(self.opb_inf),
            'nan_input': bool(self.nan_input),
            'snan_input': bool(self.snan_input),
            'a_nan': bool(self.a_nan),
            'div_by_0': bool(self.div_by_0),
            'div_0_by_0': bool(self.div_0_by_0),
            'div_inf_by_inf': bool(self.div_inf_by_inf),
            'div_by_inf': bool(self.div_by_inf),
            'mul_0_by_inf': bool(self.mul_0_by_inf),
            'mul_inf': bool(self.mul_inf),
            'div_inf': bool(self.div_inf),
            'add_inf': bool(self.add_inf),
            'sub_inf': bool(self.sub_inf),
            'addsub_inf_invalid': bool(self.addsub_inf_invalid),
            'addsub_inf': bool(self.addsub_inf),
            'out_inf_trigger': bool(self.out_inf_trigger),
            'out_pos_inf': bool(self.out_pos_inf),
            'out_neg_inf': bool(self.out_neg_inf),
            'round_nearest': bool(self.round_nearest),
            'round_to_zero': bool(self.round_to_zero),
            'round_to_pos_inf': bool(self.round_to_pos_inf),
            'round_to_neg_inf': bool(self.round_to_neg_inf),
            'inf_round_down_trigger': bool(self.inf_round_down_trigger),
            'mul_uf': bool(self.mul_uf),
            'div_uf': bool(self.div_uf),
            'underflow_trigger': bool(self.underflow_trigger),
            'invalid_trigger': bool(self.invalid_trigger),
            'overflow_trigger': bool(self.overflow_trigger),
            'inexact_trigger': bool(self.inexact_trigger),
            'except_trigger': bool(self.except_trigger),
            'enable_trigger': bool(self.enable_trigger),
            'nan_out_trigger': bool(self.nan_out_trigger),
            'snan_trigger': bool(self.snan_trigger),
            'exp_2047': 2047,
            'exp_2046': 2046,
            'nan_output_0': self.mask(self.nan_output_0, 63),
            'nan_output': self.mask(self.nan_output, 63),
            'mantissa_max': self.mask((1 << 52) - 1, 52),
            'inf_round_down': self.mask(self.inf_round_down, 63),
            'out_inf': self.mask(self.out_inf, 63),
            'out_0': self.mask(self.out_0, 64),
            'out_1': self.mask(self.out_1, 64),
            'out_2': self.mask(self.out_2, 64),
        }
        for name, value in probe_values.items():
            setattr(self, name, value)
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
        elif i['enable']:
            values = self._calculate(i)
            for name, value in values.items():
                setattr(self, name, value)

    def _calculate(self, i):
        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        normal = self.mask(i['in_except'], 64)
        exponent = self.mask(i['exponent_in'], 12)
        remainder = self.mask(i['mantissa_in'], 2)
        op = self.mask(i['fpu_op'], 3)
        mode = self.mask(i['rmode'], 2)

        frac_mask = (1 << 52) - 1
        exp_a = (opa >> 52) & 0x7ff
        exp_b = (opb >> 52) & 0x7ff
        frac_a = opa & frac_mask
        frac_b = opb & frac_mask
        sign_a = (opa >> 63) & 1
        sign_b = (opb >> 63) & 1
        zero_a = (opa & ((1 << 63) - 1)) == 0
        zero_b = (opb & ((1 << 63) - 1)) == 0
        nan_a = exp_a == 0x7ff and frac_a != 0
        nan_b = exp_b == 0x7ff and frac_b != 0
        qnan_a = nan_a and bool((frac_a >> 51) & 1)
        qnan_b = nan_b and bool((frac_b >> 51) & 1)
        snan_a = nan_a and not bool((frac_a >> 51) & 1)
        snan_b = nan_b and not bool((frac_b >> 51) & 1)
        inf_a = exp_a == 0x7ff and frac_a == 0
        inf_b = exp_b == 0x7ff and frac_b == 0
        pos_inf_a = inf_a and sign_a == 0
        pos_inf_b = inf_b and sign_b == 0
        neg_inf_a = inf_a and sign_a == 1
        neg_inf_b = inf_b and sign_b == 1

        add = op == 0
        subtract = op == 1
        multiply = op == 2
        divide = op == 3
        nan_input = nan_a or nan_b
        snan_input = snan_a or snan_b
        input_zero = (normal & ((1 << 63) - 1)) == 0

        div_0_by_0 = divide and zero_a and zero_b
        div_inf_by_inf = divide and inf_a and inf_b
        div_by_0 = divide and zero_b and not zero_a
        div_by_inf = divide and inf_b and not inf_a
        mul_0_by_inf = multiply and ((zero_a and inf_b) or (zero_b and inf_a))
        mul_inf = multiply and (inf_a or inf_b)
        div_inf = divide and inf_a and not inf_b
        add_inf = add and (inf_a or inf_b)
        sub_inf = subtract and (inf_a or inf_b)

        invalid_addsub = (add and ((pos_inf_a and neg_inf_b) or (neg_inf_a and pos_inf_b))) or (subtract and ((pos_inf_a and pos_inf_b) or (neg_inf_a and neg_inf_b)))
        addsub_inf = add_inf or sub_inf
        valid_addsub_inf = addsub_inf and not invalid_addsub
        valid_mul_inf = mul_inf and not mul_0_by_inf
        valid_inf_result = valid_mul_inf or div_inf or div_by_0 or valid_addsub_inf
        out_inf_trigger = valid_inf_result or (exponent > 2046)

        underflow_zero = input_zero
        mul_uf = multiply and not zero_a and not zero_b and underflow_zero
        div_uf = div_by_inf or (divide and not zero_a and not zero_b and underflow_zero)
        underflow_trigger = mul_uf or div_uf

        invalid_trigger = snan_input or invalid_addsub or mul_0_by_inf or div_0_by_0 or div_inf_by_inf
        nan_out_trigger = nan_input or invalid_trigger
        overflow_trigger = out_inf_trigger and not nan_input
        inexact_trigger = (remainder != 0 or out_inf_trigger or underflow_trigger) and not nan_input
        except_trigger = invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger

        sign = (normal >> 63) & 1
        out_pos_inf = out_inf_trigger and sign == 0
        out_neg_inf = out_inf_trigger and sign == 1
        round_down = out_inf_trigger and ((out_pos_inf and mode in (1, 3)) or (out_neg_inf and mode in (1, 2)))
        max_finite = (2046 << 52) | frac_mask
        infinity_magnitude = 2047 << 52
        inf_round_down = max_finite if round_down else 0
        out_inf = infinity_magnitude if out_inf_trigger else 0

        out_0 = ((sign << 63) if underflow_trigger else normal)
        if out_inf_trigger:
            magnitude = max_finite if round_down else infinity_magnitude
            out_1 = (sign << 63) | magnitude
        else:
            out_1 = out_0

        if nan_out_trigger:
            if nan_input:
                payload = frac_a if nan_a else frac_b
                a_nan = bool(nan_a)
            else:
                payload = frac_a
                a_nan = True
            payload = self.mask(payload | (1 << 51), 52)
            nan_output_0 = self.mask((2047 << 52) | payload, 63)
        else:
            a_nan = False
            nan_output_0 = 0
        nan_output = nan_output_0
        out_2 = ((sign << 63) | nan_output) if nan_out_trigger else out_1
        out = self.mask(out_2, 64)
        ex_enable = nan_out_trigger or out_inf_trigger or underflow_trigger or remainder != 0

        return {
            'out': out,
            'ex_enable': bool(ex_enable),
            'underflow': bool(underflow_trigger),
            'overflow': bool(overflow_trigger),
            'inexact': bool(inexact_trigger),
            'exception': bool(except_trigger),
            'invalid': bool(invalid_trigger),
            'in_et_zero': bool(input_zero),
            'opa_et_zero': bool(zero_a),
            'opb_et_zero': bool(zero_b),
            'input_et_zero': bool(input_zero),
            'add': bool(add),
            'subtract': bool(subtract),
            'multiply': bool(multiply),
            'divide': bool(divide),
            'opa_qnan': bool(qnan_a),
            'opb_qnan': bool(qnan_b),
            'opa_snan': bool(snan_a),
            'opb_snan': bool(snan_b),
            'opa_pos_inf': bool(pos_inf_a),
            'opb_pos_inf': bool(pos_inf_b),
            'opa_neg_inf': bool(neg_inf_a),
            'opb_neg_inf': bool(neg_inf_b),
            'opa_inf': bool(inf_a),
            'opb_inf': bool(inf_b),
            'nan_input': bool(nan_input),
            'snan_input': bool(snan_input),
            'a_nan': bool(a_nan),
            'div_by_0': bool(div_by_0),
            'div_0_by_0': bool(div_0_by_0),
            'div_inf_by_inf': bool(div_inf_by_inf),
            'div_by_inf': bool(div_by_inf),
            'mul_0_by_inf': bool(mul_0_by_inf),
            'mul_inf': bool(mul_inf),
            'div_inf': bool(div_inf),
            'add_inf': bool(add_inf),
            'sub_inf': bool(sub_inf),
            'addsub_inf_invalid': bool(invalid_addsub),
            'addsub_inf': bool(addsub_inf),
            'out_inf_trigger': bool(out_inf_trigger),
            'out_pos_inf': bool(out_pos_inf),
            'out_neg_inf': bool(out_neg_inf),
            'round_nearest': bool(mode == 0),
            'round_to_zero': bool(mode == 1),
            'round_to_pos_inf': bool(mode == 2),
            'round_to_neg_inf': bool(mode == 3),
            'inf_round_down_trigger': bool(round_down),
            'mul_uf': bool(mul_uf),
            'div_uf': bool(div_uf),
            'underflow_trigger': bool(underflow_trigger),
            'invalid_trigger': bool(invalid_trigger),
            'overflow_trigger': bool(overflow_trigger),
            'inexact_trigger': bool(inexact_trigger),
            'except_trigger': bool(except_trigger),
            'enable_trigger': bool(ex_enable),
            'nan_out_trigger': bool(nan_out_trigger),
            'snan_trigger': bool(snan_input),
            'nan_output_0': nan_output_0,
            'nan_output': nan_output,
            'inf_round_down': self.mask(inf_round_down, 63),
            'out_inf': self.mask(out_inf, 63),
            'out_0': self.mask(out_0, 64),
            'out_1': self.mask(out_1, 64),
            'out_2': self.mask(out_2, 64),
        }
