"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        self._probe_names = (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger',
            'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output',
            'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2'
        )
        self._probe_state = {name: 0 for name in self._probe_names}
        self._probe_state['exp_2047'] = 2047
        self._probe_state['exp_2046'] = 2046
        self._probe_state['mantissa_max'] = (1 << 52) - 1
        for name in self._probe_names:
            setattr(self, name, self._probe_state[name])
        self.out = 0
        self.ex_enable = 0
        self.underflow = 0
        self.overflow = 0
        self.inexact = 0
        self.exception = 0
        self.invalid = 0


    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self.out
        o['ex_enable'] = self.ex_enable
        o['underflow'] = self.underflow
        o['overflow'] = self.overflow
        o['inexact'] = self.inexact
        o['exception'] = self.exception
        o['invalid'] = self.invalid
        for name in self._probe_names:
            setattr(self, name, self._probe_state[name])
        return o


    def _derive(self, i):
        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        normal = self.mask(i['in_except'], 64)
        exponent_in = self.mask(i['exponent_in'], 12)
        mantissa_in = self.mask(i['mantissa_in'], 2)
        fpu_op = self.mask(i['fpu_op'], 3)
        rmode = self.mask(i['rmode'], 2)

        frac_mask = (1 << 52) - 1
        low63_mask = (1 << 63) - 1
        sign = (normal >> 63) & 1

        opa_frac = opa & frac_mask
        opb_frac = opb & frac_mask
        opa_exp = (opa >> 52) & 0x7ff
        opb_exp = (opb >> 52) & 0x7ff
        opa_zero = int((opa & low63_mask) == 0)
        opb_zero = int((opb & low63_mask) == 0)
        result_zero = int((normal & low63_mask) == 0)

        opa_nan = int(opa_exp == 2047 and opa_frac != 0)
        opb_nan = int(opb_exp == 2047 and opb_frac != 0)
        opa_qnan = int(opa_nan and ((opa_frac >> 51) & 1))
        opb_qnan = int(opb_nan and ((opb_frac >> 51) & 1))
        opa_snan = int(opa_nan and not ((opa_frac >> 51) & 1))
        opb_snan = int(opb_nan and not ((opb_frac >> 51) & 1))
        opa_inf = int(opa_exp == 2047 and opa_frac == 0)
        opb_inf = int(opb_exp == 2047 and opb_frac == 0)
        opa_pos_inf = int(opa_inf and not ((opa >> 63) & 1))
        opb_pos_inf = int(opb_inf and not ((opb >> 63) & 1))
        opa_neg_inf = int(opa_inf and ((opa >> 63) & 1))
        opb_neg_inf = int(opb_inf and ((opb >> 63) & 1))

        add = int(fpu_op == 0)
        subtract = int(fpu_op == 1)
        multiply = int(fpu_op == 2)
        divide = int(fpu_op == 3)
        nan_input = int(opa_nan or opb_nan)
        snan_input = int(opa_snan or opb_snan)

        div_0_by_0 = int(divide and opa_zero and opb_zero)
        div_by_0 = int(divide and opb_zero and not opa_zero)
        div_inf_by_inf = int(divide and opa_inf and opb_inf)
        div_by_inf = int(divide and opb_inf)
        mul_0_by_inf = int(multiply and ((opa_zero and opb_inf) or (opa_inf and opb_zero)))
        mul_inf = int(multiply and (opa_inf or opb_inf))
        div_inf = int(divide and opa_inf and not opb_inf)
        add_inf = int(add and (opa_inf or opb_inf))
        sub_inf = int(subtract and (opa_inf or opb_inf))

        invalid_add = bool(add and ((opa_pos_inf and opb_neg_inf) or (opa_neg_inf and opb_pos_inf)))
        invalid_sub = bool(subtract and ((opa_pos_inf and opb_pos_inf) or (opa_neg_inf and opb_neg_inf)))
        addsub_inf_invalid = int(invalid_add or invalid_sub)
        addsub_inf = int((add_inf or sub_inf) and not addsub_inf_invalid)

        valid_inf = bool(
            (mul_inf and not mul_0_by_inf)
            or (div_inf and not div_inf_by_inf)
            or addsub_inf
        )
        out_inf_trigger = int(valid_inf or div_by_0 or exponent_in > 2046)
        out_pos_inf = int(out_inf_trigger and not sign)
        out_neg_inf = int(out_inf_trigger and sign)

        round_nearest = int(rmode == 0)
        round_to_zero = int(rmode == 1)
        round_to_pos_inf = int(rmode == 2)
        round_to_neg_inf = int(rmode == 3)
        inf_round_down_trigger = int(
            out_inf_trigger
            and ((not sign and (round_to_zero or round_to_neg_inf))
                 or (sign and (round_to_zero or round_to_pos_inf)))
        )

        finite_a = not opa_inf and not opa_nan
        finite_b = not opb_inf and not opb_nan
        mul_uf = int(
            multiply and not opa_zero and not opb_zero and result_zero
            and finite_a and finite_b
        )
        div_by_inf_underflow = bool(div_by_inf and finite_a)
        div_tiny_underflow = bool(
            divide and not opa_zero and not opb_zero and result_zero
            and finite_a and finite_b
        )
        div_uf = int(div_by_inf_underflow or div_tiny_underflow)
        underflow_trigger = int(mul_uf or div_uf)

        invalid_trigger = int(
            snan_input or addsub_inf_invalid or mul_0_by_inf
            or div_0_by_0 or div_inf_by_inf
        )
        overflow_trigger = int(out_inf_trigger and not nan_input)
        inexact_trigger = int(
            (bool(mantissa_in) or bool(out_inf_trigger) or bool(underflow_trigger))
            and not nan_input
        )
        except_trigger = int(
            invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger
        )
        nan_out_trigger = int(nan_input or invalid_trigger)
        enable_trigger = int(
            nan_out_trigger or out_inf_trigger or underflow_trigger or inexact_trigger
        )

        exp_2047 = 2047
        exp_2046 = 2046
        mantissa_max = frac_mask
        out_inf_mag = exp_2047 << 52
        inf_round_down_mag = (exp_2046 << 52) | mantissa_max
        inf_round_down = inf_round_down_mag if inf_round_down_trigger else 0
        selected_inf_mag = inf_round_down_mag if inf_round_down_trigger else out_inf_mag

        if underflow_trigger:
            out_0 = sign << 63
        else:
            out_0 = normal
        if out_inf_trigger:
            out_1 = (sign << 63) | selected_inf_mag
        else:
            out_1 = out_0

        a_nan = int(bool(opa_nan) or (bool(invalid_trigger) and not nan_input))
        if nan_input:
            selected_frac = opa_frac if opa_nan else opb_frac
        elif invalid_trigger:
            selected_frac = opa_frac
        else:
            selected_frac = 0
        nan_bits = ((exp_2047 << 52) | (selected_frac | (1 << 51))) if nan_out_trigger else 0
        nan_output_0 = nan_bits
        nan_output = nan_bits
        out_2 = ((sign << 63) | nan_bits) if nan_out_trigger else out_1
        out_value = self.mask(out_2, 64)

        probes = {
            'in_et_zero': result_zero,
            'opa_et_zero': opa_zero,
            'opb_et_zero': opb_zero,
            'input_et_zero': result_zero,
            'add': add,
            'subtract': subtract,
            'multiply': multiply,
            'divide': divide,
            'opa_qnan': opa_qnan,
            'opb_qnan': opb_qnan,
            'opa_snan': opa_snan,
            'opb_snan': opb_snan,
            'opa_pos_inf': opa_pos_inf,
            'opb_pos_inf': opb_pos_inf,
            'opa_neg_inf': opa_neg_inf,
            'opb_neg_inf': opb_neg_inf,
            'opa_inf': opa_inf,
            'opb_inf': opb_inf,
            'nan_input': nan_input,
            'snan_input': snan_input,
            'a_nan': a_nan,
            'div_by_0': div_by_0,
            'div_0_by_0': div_0_by_0,
            'div_inf_by_inf': div_inf_by_inf,
            'div_by_inf': div_by_inf,
            'mul_0_by_inf': mul_0_by_inf,
            'mul_inf': mul_inf,
            'div_inf': div_inf,
            'add_inf': add_inf,
            'sub_inf': sub_inf,
            'addsub_inf_invalid': addsub_inf_invalid,
            'addsub_inf': addsub_inf,
            'out_inf_trigger': out_inf_trigger,
            'out_pos_inf': out_pos_inf,
            'out_neg_inf': out_neg_inf,
            'round_nearest': round_nearest,
            'round_to_zero': round_to_zero,
            'round_to_pos_inf': round_to_pos_inf,
            'round_to_neg_inf': round_to_neg_inf,
            'inf_round_down_trigger': inf_round_down_trigger,
            'mul_uf': mul_uf,
            'div_uf': div_uf,
            'underflow_trigger': underflow_trigger,
            'invalid_trigger': invalid_trigger,
            'overflow_trigger': overflow_trigger,
            'inexact_trigger': inexact_trigger,
            'except_trigger': except_trigger,
            'enable_trigger': enable_trigger,
            'nan_out_trigger': nan_out_trigger,
            'snan_trigger': snan_input,
            'exp_2047': exp_2047,
            'exp_2046': exp_2046,
            'nan_output_0': self.mask(nan_output_0, 63),
            'nan_output': self.mask(nan_output, 63),
            'mantissa_max': mantissa_max,
            'inf_round_down': self.mask(inf_round_down, 63),
            'out_inf': self.mask(out_inf_mag if out_inf_trigger else 0, 63),
            'out_0': self.mask(out_0, 64),
            'out_1': self.mask(out_1, 64),
            'out_2': self.mask(out_2, 64)
        }
        return {
            'probes': probes,
            'out': out_value,
            'ex_enable': enable_trigger,
            'underflow': underflow_trigger,
            'overflow': overflow_trigger,
            'inexact': inexact_trigger,
            'exception': except_trigger,
            'invalid': invalid_trigger
        }


    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not i['enable']:
            return
        d = self._derive(i)
        for name in self._probe_names:
            self._probe_state[name] = d['probes'][name]
        self.out = self.mask(d['out'], 64)
        self.ex_enable = self.mask(d['ex_enable'], 1)
        self.underflow = self.mask(d['underflow'], 1)
        self.overflow = self.mask(d['overflow'], 1)
        self.inexact = self.mask(d['inexact'], 1)
        self.exception = self.mask(d['exception'], 1)
        self.invalid = self.mask(d['invalid'], 1)
