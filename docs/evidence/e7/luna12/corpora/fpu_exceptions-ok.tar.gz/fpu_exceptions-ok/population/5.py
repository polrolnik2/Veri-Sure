"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    PROBE_NAMES = (
        'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
        'add', 'subtract', 'multiply', 'divide',
        'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
        'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
        'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
        'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
        'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
        'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
        'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
        'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
        'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
        'overflow_trigger', 'inexact_trigger', 'except_trigger',
        'enable_trigger', 'nan_out_trigger', 'snan_trigger',
        'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output',
        'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2'
    )

    def reset(self):
        for name in self.PROBE_NAMES:
            setattr(self, name, 0)
        self.out = 0
        self.ex_enable = 0
        self.underflow = 0
        self.overflow = 0
        self.inexact = 0
        self.exception = 0
        self.invalid = 0
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self.mask(self.out, 64)
        o['ex_enable'] = self.ex_enable
        o['underflow'] = self.underflow
        o['overflow'] = self.overflow
        o['inexact'] = self.inexact
        o['exception'] = self.exception
        o['invalid'] = self.invalid
        for name in self.PROBE_NAMES:
            setattr(self, name, getattr(self, name))
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not i['enable']:
            return

        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        candidate = self.mask(i['in_except'], 64)
        exponent = self.mask(i['exponent_in'], 12)
        mantissa = self.mask(i['mantissa_in'], 2)
        op = self.mask(i['fpu_op'], 3)
        mode = self.mask(i['rmode'], 2)

        frac_mask = (1 << 52) - 1
        exp_a = (opa >> 52) & 0x7ff
        exp_b = (opb >> 52) & 0x7ff
        frac_a = opa & frac_mask
        frac_b = opb & frac_mask
        zero_mask = (1 << 63) - 1
        opa_zero = (opa & zero_mask) == 0
        opb_zero = (opb & zero_mask) == 0
        result_zero = (candidate & zero_mask) == 0

        opa_nan = exp_a == 0x7ff and frac_a != 0
        opb_nan = exp_b == 0x7ff and frac_b != 0
        opa_qnan = opa_nan and bool(frac_a & (1 << 51))
        opb_qnan = opb_nan and bool(frac_b & (1 << 51))
        opa_snan = opa_nan and not opa_qnan
        opb_snan = opb_nan and not opb_qnan
        opa_inf = exp_a == 0x7ff and frac_a == 0
        opb_inf = exp_b == 0x7ff and frac_b == 0
        opa_pos_inf = opa_inf and not bool(opa >> 63)
        opb_pos_inf = opb_inf and not bool(opb >> 63)
        opa_neg_inf = opa_inf and bool(opa >> 63)
        opb_neg_inf = opb_inf and bool(opb >> 63)
        nan_input = opa_nan or opb_nan
        snan_input = opa_snan or opb_snan

        is_add = op == 0
        is_subtract = op == 1
        is_multiply = op == 2
        is_divide = op == 3

        div_0_by_0 = is_divide and opa_zero and opb_zero
        div_inf_by_inf = is_divide and opa_inf and opb_inf
        div_by_0 = (is_divide and opb_zero and not opa_zero
                    and not opa_inf and not opa_nan)
        div_by_inf = (is_divide and opb_inf and not opa_inf and not opa_nan)
        mul_0_by_inf = is_multiply and (
            (opa_zero and opb_inf) or (opb_zero and opa_inf)
        )
        mul_inf = is_multiply and (opa_inf or opb_inf)
        div_inf = is_divide and opa_inf and not opb_inf and not nan_input
        add_inf = is_add and (opa_inf or opb_inf)
        sub_inf = is_subtract and (opa_inf or opb_inf)

        add_invalid = is_add and (
            (opa_pos_inf and opb_neg_inf) or (opa_neg_inf and opb_pos_inf)
        )
        sub_invalid = is_subtract and (
            (opa_pos_inf and opb_pos_inf) or (opa_neg_inf and opb_neg_inf)
        )
        addsub_inf_invalid = add_invalid or sub_invalid
        addsub_inf = add_inf or sub_inf
        invalid_arithmetic = (
            addsub_inf_invalid or mul_0_by_inf or div_0_by_0 or div_inf_by_inf
        )

        valid_addsub_inf = addsub_inf and not addsub_inf_invalid and not nan_input
        valid_mul_inf = mul_inf and not mul_0_by_inf and not nan_input
        out_inf_trigger = (
            valid_addsub_inf or valid_mul_inf or div_inf or div_by_0
            or exponent > 2046
        )

        sign = (candidate >> 63) & 1
        round_nearest = mode == 0
        round_to_zero = mode == 1
        round_to_pos_inf = mode == 2
        round_to_neg_inf = mode == 3
        out_pos_inf = out_inf_trigger and not sign
        out_neg_inf = out_inf_trigger and bool(sign)
        inf_round_down_trigger = (
            (out_pos_inf and (round_to_zero or round_to_neg_inf))
            or (out_neg_inf and (round_to_zero or round_to_pos_inf))
        )

        mul_uf = (
            is_multiply and result_zero and not opa_zero and not opb_zero
            and not nan_input and not opa_inf and not opb_inf
        )
        div_uf = (
            div_by_inf
            or (is_divide and result_zero and not opa_zero and not opb_zero
                and not opa_inf and not opb_inf and not nan_input)
        )
        underflow_trigger = mul_uf or div_uf
        invalid_trigger = snan_input or invalid_arithmetic
        overflow_trigger = out_inf_trigger and not nan_input
        inexact_trigger = (
            (mantissa != 0 or out_inf_trigger or underflow_trigger)
            and not nan_input
        )
        except_trigger = (
            invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger
        )
        nan_out_trigger = nan_input or invalid_arithmetic
        enable_trigger = (
            nan_out_trigger or out_inf_trigger or underflow_trigger or inexact_trigger
        )

        # The first selection is normal result versus signed zero for underflow.
        out_0 = ((sign << 63) if underflow_trigger else candidate)

        # The second selection replaces that intermediate with infinity or max finite.
        infinity_magnitude = 0x7ff << 52
        max_finite_magnitude = (0x7fe << 52) | frac_mask
        inf_round_down = max_finite_magnitude if inf_round_down_trigger else 0
        out_inf = infinity_magnitude if out_inf_trigger else 0
        out_1 = out_0
        if out_inf_trigger:
            magnitude = max_finite_magnitude if inf_round_down_trigger else infinity_magnitude
            out_1 = (sign << 63) | magnitude

        # Input NaNs take precedence over generated invalid-operation NaNs.
        nan_magnitude = 0
        if nan_input:
            selected_fraction = frac_a if opa_nan else frac_b
            nan_magnitude = (0x7ff << 52) | selected_fraction | (1 << 51)
        elif invalid_arithmetic:
            nan_magnitude = (0x7ff << 52) | frac_a | (1 << 51)
        nan_output_0 = nan_magnitude
        nan_output = nan_magnitude
        out_2 = out_1
        if nan_out_trigger:
            out_2 = (sign << 63) | nan_magnitude

        values = {name: 0 for name in self.PROBE_NAMES}
        values.update({
            'in_et_zero': int(result_zero),
            'opa_et_zero': int(opa_zero),
            'opb_et_zero': int(opb_zero),
            'input_et_zero': int(opa_zero or opb_zero),
            'add': int(is_add),
            'subtract': int(is_subtract),
            'multiply': int(is_multiply),
            'divide': int(is_divide),
            'opa_qnan': int(opa_qnan),
            'opb_qnan': int(opb_qnan),
            'opa_snan': int(opa_snan),
            'opb_snan': int(opb_snan),
            'opa_pos_inf': int(opa_pos_inf),
            'opb_pos_inf': int(opb_pos_inf),
            'opa_neg_inf': int(opa_neg_inf),
            'opb_neg_inf': int(opb_neg_inf),
            'opa_inf': int(opa_inf),
            'opb_inf': int(opb_inf),
            'nan_input': int(nan_input),
            'snan_input': int(snan_input),
            'a_nan': int(opa_nan),
            'div_by_0': int(div_by_0),
            'div_0_by_0': int(div_0_by_0),
            'div_inf_by_inf': int(div_inf_by_inf),
            'div_by_inf': int(div_by_inf),
            'mul_0_by_inf': int(mul_0_by_inf),
            'mul_inf': int(mul_inf),
            'div_inf': int(div_inf),
            'add_inf': int(add_inf),
            'sub_inf': int(sub_inf),
            'addsub_inf_invalid': int(addsub_inf_invalid),
            'addsub_inf': int(addsub_inf),
            'out_inf_trigger': int(out_inf_trigger),
            'out_pos_inf': int(out_pos_inf),
            'out_neg_inf': int(out_neg_inf),
            'round_nearest': int(round_nearest),
            'round_to_zero': int(round_to_zero),
            'round_to_pos_inf': int(round_to_pos_inf),
            'round_to_neg_inf': int(round_to_neg_inf),
            'inf_round_down_trigger': int(inf_round_down_trigger),
            'mul_uf': int(mul_uf),
            'div_uf': int(div_uf),
            'underflow_trigger': int(underflow_trigger),
            'invalid_trigger': int(invalid_trigger),
            'overflow_trigger': int(overflow_trigger),
            'inexact_trigger': int(inexact_trigger),
            'except_trigger': int(except_trigger),
            'enable_trigger': int(enable_trigger),
            'nan_out_trigger': int(nan_out_trigger),
            'snan_trigger': int(snan_input),
            'exp_2047': 2047,
            'exp_2046': 2046,
            'nan_output_0': self.mask(nan_output_0, 63),
            'nan_output': self.mask(nan_output, 63),
            'mantissa_max': frac_mask,
            'inf_round_down': self.mask(inf_round_down, 63),
            'out_inf': self.mask(out_inf, 63),
            'out_0': self.mask(out_0, 64),
            'out_1': self.mask(out_1, 64),
            'out_2': self.mask(out_2, 64),
        })
        for name in self.PROBE_NAMES:
            setattr(self, name, values[name])

        self.out = self.mask(out_2, 64)
        self.ex_enable = int(enable_trigger)
        self.underflow = int(underflow_trigger)
        self.overflow = int(overflow_trigger)
        self.inexact = int(inexact_trigger)
        self.exception = int(except_trigger)
        self.invalid = int(invalid_trigger)
