"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        self.out = 0
        self.ex_enable = 0
        self.underflow = 0
        self.overflow = 0
        self.inexact = 0
        self.exception = 0
        self.invalid = 0
        names = (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger',
            'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output',
            'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2'
        )
        self._probes = {name: 0 for name in names}
        self._probes['exp_2047'] = 2047
        self._probes['exp_2046'] = 2046
        self._probes['mantissa_max'] = (1 << 52) - 1
        self._probes['inf_round_down'] = (2046 << 52) | ((1 << 52) - 1)
        self._probes['out_inf'] = 2047 << 52
        self._s0_inf_trigger = 0
        self._s0_round_down = 0
        self._s0_sign = 0
        self._s0_nan_trigger = 0
        self._s1_nan_trigger = 0
        self._s1_sign = 0
        zero_status = {
            'ex_enable': 0,
            'underflow': 0,
            'overflow': 0,
            'inexact': 0,
            'exception': 0,
            'invalid': 0
        }
        self._status_s0 = dict(zero_status)
        self._status_s1 = dict(zero_status)
        self._status_s2 = dict(zero_status)


    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self.out
        o['ex_enable'] = self.ex_enable
        o['underflow'] = self.underflow
        o['overflow'] = self.overflow
        o['inexact'] = self.inexact
        o['exception'] = self.exception
        o['invalid'] = self.invalid
        for name, value in self._probes.items():
            setattr(self, name, value)
        return o


    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not i['enable']:
            return

        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        result = self.mask(i['in_except'], 64)
        exponent_in = self.mask(i['exponent_in'], 12)
        mantissa_in = self.mask(i['mantissa_in'], 2)
        fpu_op = self.mask(i['fpu_op'], 3)
        rmode = self.mask(i['rmode'], 2)

        sign_a = (opa >> 63) & 1
        sign_b = (opb >> 63) & 1
        result_sign = (result >> 63) & 1
        frac_mask = (1 << 52) - 1
        frac_a = opa & frac_mask
        frac_b = opb & frac_mask
        exp_a = (opa >> 52) & 0x7ff
        exp_b = (opb >> 52) & 0x7ff
        opa_zero = int((opa & ((1 << 63) - 1)) == 0)
        opb_zero = int((opb & ((1 << 63) - 1)) == 0)
        result_zero = int((result & ((1 << 63) - 1)) == 0)
        opa_nan = int(exp_a == 0x7ff and frac_a != 0)
        opb_nan = int(exp_b == 0x7ff and frac_b != 0)
        opa_qnan = int(opa_nan and ((frac_a >> 51) & 1))
        opb_qnan = int(opb_nan and ((frac_b >> 51) & 1))
        opa_snan = int(opa_nan and not ((frac_a >> 51) & 1))
        opb_snan = int(opb_nan and not ((frac_b >> 51) & 1))
        opa_inf = int(exp_a == 0x7ff and frac_a == 0)
        opb_inf = int(exp_b == 0x7ff and frac_b == 0)
        opa_pos_inf = int(opa_inf and not sign_a)
        opb_pos_inf = int(opb_inf and not sign_b)
        opa_neg_inf = int(opa_inf and sign_a)
        opb_neg_inf = int(opb_inf and sign_b)
        nan_input = int(opa_nan or opb_nan)
        snan_input = int(opa_snan or opb_snan)

        add = int(fpu_op == 0)
        subtract = int(fpu_op == 1)
        multiply = int(fpu_op == 2)
        divide = int(fpu_op == 3)
        add_inf = int(add and (opa_inf or opb_inf))
        sub_inf = int(subtract and (opa_inf or opb_inf))
        add_invalid = int(add and ((opa_pos_inf and opb_neg_inf) or (opa_neg_inf and opb_pos_inf)))
        sub_invalid = int(subtract and ((opa_pos_inf and opb_pos_inf) or (opa_neg_inf and opb_neg_inf)))
        addsub_inf_invalid = int(add_invalid or sub_invalid)
        addsub_inf = int((add or subtract) and (opa_inf or opb_inf))

        div_0_by_0 = int(divide and opa_zero and opb_zero)
        div_inf_by_inf = int(divide and opa_inf and opb_inf)
        div_by_0 = int(divide and opb_zero and not opa_zero)
        div_by_inf = int(divide and opb_inf and not opa_inf and not nan_input)
        mul_0_by_inf = int(multiply and ((opa_zero and opb_inf) or (opb_zero and opa_inf)))
        mul_inf = int(multiply and (opa_inf or opb_inf))
        div_inf = int(divide and opa_inf and not opb_inf)

        invalid_trigger = int(snan_input or addsub_inf_invalid or mul_0_by_inf or div_0_by_0 or div_inf_by_inf)
        nan_out_trigger = int(nan_input or invalid_trigger)
        valid_addsub_inf = bool(addsub_inf and not addsub_inf_invalid and not nan_input)
        valid_mul_inf = bool(mul_inf and not mul_0_by_inf and not nan_input)
        valid_div_inf = bool(div_inf and not nan_input)
        valid_inf_result = bool(valid_addsub_inf or valid_mul_inf or valid_div_inf)
        out_inf_trigger = int(valid_inf_result or div_by_0 or exponent_in > 2046)
        out_pos_inf = int(out_inf_trigger and not result_sign)
        out_neg_inf = int(out_inf_trigger and result_sign)

        round_nearest = int(rmode == 0)
        round_to_zero = int(rmode == 1)
        round_to_pos_inf = int(rmode == 2)
        round_to_neg_inf = int(rmode == 3)
        inf_round_down_trigger = int(
            (out_pos_inf and (round_to_zero or round_to_neg_inf)) or
            (out_neg_inf and (round_to_zero or round_to_pos_inf))
        )

        mul_uf = int(
            multiply and result_zero and not opa_zero and not opb_zero and
            not opa_inf and not opb_inf and not nan_input
        )
        div_uf = int(
            (div_by_inf or (
                divide and result_zero and not opa_zero and not opb_zero and
                not opa_inf and not opb_inf and not nan_input
            ))
        )
        underflow_trigger = int(mul_uf or div_uf)
        overflow_trigger = int(out_inf_trigger and not nan_input)
        inexact_trigger = int((mantissa_in != 0 or out_inf_trigger or underflow_trigger) and not nan_input)
        except_trigger = int(invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger)
        enable_trigger = int(nan_out_trigger or out_inf_trigger or underflow_trigger or inexact_trigger)

        if opa_nan:
            selected_frac = frac_a
            a_nan = 1
        elif opb_nan:
            selected_frac = frac_b
            a_nan = 0
        elif invalid_trigger:
            selected_frac = frac_a
            a_nan = 1
        else:
            selected_frac = 0
            a_nan = 0
        nan_value = 0
        if nan_out_trigger:
            nan_value = (0x7ff << 52) | (selected_frac | (1 << 51))
        nan_value = self.mask(nan_value, 63)

        underflow_value = (result_sign << 63) if underflow_trigger else result
        inf_magnitude = ((2046 << 52) | frac_mask) if inf_round_down_trigger else (2047 << 52)
        if out_inf_trigger:
            infinity_value = (result_sign << 63) | inf_magnitude
        else:
            infinity_value = underflow_value
        if nan_out_trigger:
            nan_selected_value = (result_sign << 63) | nan_value
        else:
            nan_selected_value = infinity_value

        old_probes = self._probes
        old_s0_inf_trigger = self._s0_inf_trigger
        old_s0_round_down = self._s0_round_down
        old_s0_sign = self._s0_sign
        old_s0_nan_trigger = self._s0_nan_trigger
        old_s1_nan_trigger = self._s1_nan_trigger
        old_s1_sign = self._s1_sign

        next_out_0 = self.mask(underflow_value, 64)
        if old_s0_inf_trigger:
            old_inf_magnitude = ((2046 << 52) | frac_mask) if old_s0_round_down else (2047 << 52)
            next_out_1 = self.mask((old_s0_sign << 63) | old_inf_magnitude, 64)
        else:
            next_out_1 = old_probes['out_0']
        if old_s1_nan_trigger:
            next_out_2 = self.mask((old_s1_sign << 63) | old_probes['nan_output'], 64)
        else:
            next_out_2 = old_probes['out_1']
        next_out = old_probes['out_2']
        next_nan_output = old_probes['nan_output_0']

        next_probes = {
            'in_et_zero': result_zero,
            'opa_et_zero': opa_zero,
            'opb_et_zero': opb_zero,
            'input_et_zero': int(opa_zero or opb_zero),
            'add': add,
            'subtract': subtract,
            'multiply': multiply,
            'divide': divide,
            'opa_qnan': opa_qnan,
            'opb_qnan': opb_qnan,
            'opa_snan': opa_snan,
            'opb_snan': opb_snan,
            'opa_pos_inf': opa_pos_inf,
            'opb_pos_inf': opb_pos_inf,
            'opa_neg_inf': opa_neg_inf,
            'opb_neg_inf': opb_neg_inf,
            'opa_inf': opa_inf,
            'opb_inf': opb_inf,
            'nan_input': nan_input,
            'snan_input': snan_input,
            'a_nan': a_nan,
            'div_by_0': div_by_0,
            'div_0_by_0': div_0_by_0,
            'div_inf_by_inf': div_inf_by_inf,
            'div_by_inf': div_by_inf,
            'mul_0_by_inf': mul_0_by_inf,
            'mul_inf': mul_inf,
            'div_inf': div_inf,
            'add_inf': add_inf,
            'sub_inf': sub_inf,
            'addsub_inf_invalid': addsub_inf_invalid,
            'addsub_inf': addsub_inf,
            'out_inf_trigger': out_inf_trigger,
            'out_pos_inf': out_pos_inf,
            'out_neg_inf': out_neg_inf,
            'round_nearest': round_nearest,
            'round_to_zero': round_to_zero,
            'round_to_pos_inf': round_to_pos_inf,
            'round_to_neg_inf': round_to_neg_inf,
            'inf_round_down_trigger': inf_round_down_trigger,
            'mul_uf': mul_uf,
            'div_uf': div_uf,
            'underflow_trigger': underflow_trigger,
            'invalid_trigger': invalid_trigger,
            'overflow_trigger': overflow_trigger,
            'inexact_trigger': inexact_trigger,
            'except_trigger': except_trigger,
            'enable_trigger': enable_trigger,
            'nan_out_trigger': nan_out_trigger,
            'snan_trigger': snan_input,
            'exp_2047': 2047,
            'exp_2046': 2046,
            'nan_output_0': nan_value,
            'nan_output': next_nan_output,
            'mantissa_max': frac_mask,
            'inf_round_down': (2046 << 52) | frac_mask,
            'out_inf': 2047 << 52,
            'out_0': next_out_0,
            'out_1': next_out_1,
            'out_2': next_out_2
        }

        new_status = {
            'ex_enable': enable_trigger,
            'underflow': underflow_trigger,
            'overflow': overflow_trigger,
            'inexact': inexact_trigger,
            'exception': except_trigger,
            'invalid': invalid_trigger
        }
        old_status_s0 = self._status_s0
        old_status_s1 = self._status_s1
        old_status_s2 = self._status_s2
        self._status_s0 = new_status
        self._status_s1 = old_status_s0
        self._status_s2 = old_status_s1
        self.out = self.mask(next_out, 64)
        self.ex_enable = old_status_s2['ex_enable']
        self.underflow = old_status_s2['underflow']
        self.overflow = old_status_s2['overflow']
        self.inexact = old_status_s2['inexact']
        self.exception = old_status_s2['exception']
        self.invalid = old_status_s2['invalid']

        self._s1_nan_trigger = old_s0_nan_trigger
        self._s1_sign = old_s0_sign
        self._s0_inf_trigger = out_inf_trigger
        self._s0_round_down = inf_round_down_trigger
        self._s0_sign = result_sign
        self._s0_nan_trigger = nan_out_trigger
        self._probes = next_probes
