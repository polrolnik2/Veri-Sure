"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        names = (
            'out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid',
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf',
            'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf',
            'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf',
            'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger',
            'nan_out_trigger', 'snan_trigger', 'nan_output_0', 'nan_output', 'inf_round_down',
            'out_inf', 'out_0', 'out_1', 'out_2'
        )
        for name in names:
            setattr(self, name, 0)

    def _calculate(self, i):
        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        candidate = self.mask(i['in_except'], 64)
        exponent_in = self.mask(i['exponent_in'], 12)
        mantissa_in = self.mask(i['mantissa_in'], 2)
        fpu_op = self.mask(i['fpu_op'], 3)
        rmode = self.mask(i['rmode'], 2)

        frac_mask = (1 << 52) - 1
        low63_mask = (1 << 63) - 1
        opa_exp = (opa >> 52) & 0x7ff
        opb_exp = (opb >> 52) & 0x7ff
        opa_frac = opa & frac_mask
        opb_frac = opb & frac_mask
        opa_zero = (opa & low63_mask) == 0
        opb_zero = (opb & low63_mask) == 0
        in_zero = (candidate & low63_mask) == 0

        opa_nan = opa_exp == 0x7ff and opa_frac != 0
        opb_nan = opb_exp == 0x7ff and opb_frac != 0
        opa_qnan = opa_nan and bool(opa_frac & (1 << 51))
        opb_qnan = opb_nan and bool(opb_frac & (1 << 51))
        opa_snan = opa_nan and not bool(opa_frac & (1 << 51))
        opb_snan = opb_nan and not bool(opb_frac & (1 << 51))
        opa_inf = opa_exp == 0x7ff and opa_frac == 0
        opb_inf = opb_exp == 0x7ff and opb_frac == 0
        opa_sign = (opa >> 63) & 1
        opb_sign = (opb >> 63) & 1
        result_sign = (candidate >> 63) & 1

        add = fpu_op == 0
        subtract = fpu_op == 1
        multiply = fpu_op == 2
        divide = fpu_op == 3
        nan_input = opa_nan or opb_nan
        snan_input = opa_snan or opb_snan

        opa_pos_inf = opa_inf and opa_sign == 0
        opa_neg_inf = opa_inf and opa_sign == 1
        opb_pos_inf = opb_inf and opb_sign == 0
        opb_neg_inf = opb_inf and opb_sign == 1

        div_0_by_0 = divide and opa_zero and opb_zero
        div_inf_by_inf = divide and opa_inf and opb_inf
        div_by_0 = divide and opb_zero and not opa_zero and not opa_inf and not opa_nan
        div_by_inf = divide and opb_inf and not opa_inf
        mul_0_by_inf = multiply and ((opa_zero and opb_inf) or (opb_zero and opa_inf))
        mul_inf = multiply and (opa_inf or opb_inf)
        div_inf = divide and opa_inf and not opb_inf
        add_inf = add and (opa_inf or opb_inf)
        sub_inf = subtract and (opa_inf or opb_inf)

        add_invalid = add and ((opa_pos_inf and opb_neg_inf) or (opa_neg_inf and opb_pos_inf))
        sub_invalid = subtract and ((opa_pos_inf and opb_pos_inf) or (opa_neg_inf and opb_neg_inf))
        addsub_inf_invalid = add_invalid or sub_invalid
        addsub_inf = (add or subtract) and (opa_inf or opb_inf)

        invalid_trigger = snan_input or addsub_inf_invalid or mul_0_by_inf or div_0_by_0 or div_inf_by_inf
        nan_out_trigger = nan_input or invalid_trigger
        div_valid_inf = div_inf and not div_inf_by_inf
        valid_inf_operation = (
            (mul_inf and not mul_0_by_inf)
            or div_valid_inf
            or ((add_inf or sub_inf) and not addsub_inf_invalid)
        )
        out_inf_trigger = valid_inf_operation or div_by_0 or exponent_in > 2046

        mul_uf = (
            multiply and not opa_zero and not opb_zero and in_zero
            and not opa_inf and not opb_inf and not nan_input
        )
        div_uf = div_by_inf or (
            divide and not opa_zero and not opb_zero and in_zero
            and not opa_inf and not opb_inf and not nan_input
        )
        underflow_trigger = (mul_uf or div_uf) and not nan_input

        round_nearest = rmode == 0
        round_to_zero = rmode == 1
        round_to_pos_inf = rmode == 2
        round_to_neg_inf = rmode == 3
        inf_round_down_trigger = out_inf_trigger and (
            (result_sign == 0 and (round_to_zero or round_to_neg_inf))
            or (result_sign == 1 and (round_to_zero or round_to_pos_inf))
        )

        overflow_trigger = out_inf_trigger and not nan_input
        inexact_trigger = not nan_input and (
            mantissa_in != 0 or out_inf_trigger or underflow_trigger
        )
        except_trigger = invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger
        enable_trigger = nan_out_trigger or out_inf_trigger or underflow_trigger or inexact_trigger or invalid_trigger

        infinity_magnitude = 2047 << 52
        max_finite_magnitude = (2046 << 52) | frac_mask
        out_inf_value = infinity_magnitude if out_inf_trigger else 0
        inf_round_down_value = max_finite_magnitude if inf_round_down_trigger else 0

        out_0 = ((result_sign << 63) if underflow_trigger else candidate)
        if out_inf_trigger:
            magnitude = max_finite_magnitude if inf_round_down_trigger else infinity_magnitude
            out_1 = (result_sign << 63) | magnitude
        else:
            out_1 = out_0

        a_nan = opa_nan or not opb_nan
        if opa_nan:
            selected_fraction = opa_frac
        elif opb_nan:
            selected_fraction = opb_frac
        else:
            selected_fraction = opa_frac
        selected_fraction |= 1 << 51
        nan_magnitude = ((0x7ff << 52) | selected_fraction) & low63_mask
        nan_output = nan_magnitude if nan_out_trigger else 0
        nan_output_0 = nan_output
        out_2 = ((result_sign << 63) | nan_magnitude) if nan_out_trigger else out_1

        return {
            'out': self.mask(out_2, 64),
            'ex_enable': int(bool(enable_trigger)),
            'underflow': int(bool(underflow_trigger)),
            'overflow': int(bool(overflow_trigger)),
            'inexact': int(bool(inexact_trigger)),
            'exception': int(bool(except_trigger)),
            'invalid': int(bool(invalid_trigger)),
            'in_et_zero': int(bool(in_zero)),
            'opa_et_zero': int(bool(opa_zero)),
            'opb_et_zero': int(bool(opb_zero)),
            'input_et_zero': int(bool(opa_zero or opb_zero)),
            'add': int(bool(add)),
            'subtract': int(bool(subtract)),
            'multiply': int(bool(multiply)),
            'divide': int(bool(divide)),
            'opa_qnan': int(bool(opa_qnan)),
            'opb_qnan': int(bool(opb_qnan)),
            'opa_snan': int(bool(opa_snan)),
            'opb_snan': int(bool(opb_snan)),
            'opa_pos_inf': int(bool(opa_pos_inf)),
            'opb_pos_inf': int(bool(opb_pos_inf)),
            'opa_neg_inf': int(bool(opa_neg_inf)),
            'opb_neg_inf': int(bool(opb_neg_inf)),
            'opa_inf': int(bool(opa_inf)),
            'opb_inf': int(bool(opb_inf)),
            'nan_input': int(bool(nan_input)),
            'snan_input': int(bool(snan_input)),
            'a_nan': int(bool(a_nan)),
            'div_by_0': int(bool(div_by_0)),
            'div_0_by_0': int(bool(div_0_by_0)),
            'div_inf_by_inf': int(bool(div_inf_by_inf)),
            'div_by_inf': int(bool(div_by_inf)),
            'mul_0_by_inf': int(bool(mul_0_by_inf)),
            'mul_inf': int(bool(mul_inf)),
            'div_inf': int(bool(div_inf)),
            'add_inf': int(bool(add_inf)),
            'sub_inf': int(bool(sub_inf)),
            'addsub_inf_invalid': int(bool(addsub_inf_invalid)),
            'addsub_inf': int(bool(addsub_inf)),
            'out_inf_trigger': int(bool(out_inf_trigger)),
            'out_pos_inf': int(bool(out_inf_trigger and result_sign == 0)),
            'out_neg_inf': int(bool(out_inf_trigger and result_sign == 1)),
            'round_nearest': int(bool(round_nearest)),
            'round_to_zero': int(bool(round_to_zero)),
            'round_to_pos_inf': int(bool(round_to_pos_inf)),
            'round_to_neg_inf': int(bool(round_to_neg_inf)),
            'inf_round_down_trigger': int(bool(inf_round_down_trigger)),
            'mul_uf': int(bool(mul_uf)),
            'div_uf': int(bool(div_uf)),
            'underflow_trigger': int(bool(underflow_trigger)),
            'invalid_trigger': int(bool(invalid_trigger)),
            'overflow_trigger': int(bool(overflow_trigger)),
            'inexact_trigger': int(bool(inexact_trigger)),
            'except_trigger': int(bool(except_trigger)),
            'enable_trigger': int(bool(enable_trigger)),
            'nan_out_trigger': int(bool(nan_out_trigger)),
            'snan_trigger': int(bool(snan_input)),
            'nan_output_0': nan_output_0,
            'nan_output': nan_output,
            'inf_round_down': inf_round_down_value,
            'out_inf': out_inf_value,
            'out_0': self.mask(out_0, 64),
            'out_1': self.mask(out_1, 64),
            'out_2': self.mask(out_2, 64)
        }

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self.out
        o['ex_enable'] = self.ex_enable
        o['underflow'] = self.underflow
        o['overflow'] = self.overflow
        o['inexact'] = self.inexact
        o['exception'] = self.exception
        o['invalid'] = self.invalid

        boolean_probes = (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf',
            'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf',
            'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf',
            'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf',
            'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger',
            'nan_out_trigger', 'snan_trigger'
        )
        for name in boolean_probes:
            setattr(self, name, bool(getattr(self, name)))

        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not i['enable']:
            return
        values = self._calculate(i)
        for name, value in values.items():
            setattr(self, name, value)
