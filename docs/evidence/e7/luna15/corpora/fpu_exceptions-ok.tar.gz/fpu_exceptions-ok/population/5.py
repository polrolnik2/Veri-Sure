"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        self.out = 0
        self.ex_enable = 0
        self.underflow = 0
        self.overflow = 0
        self.inexact = 0
        self.exception = 0
        self.invalid = 0
        flag_names = (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger'
        )
        for name in flag_names:
            setattr(self, name, False)
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1
        self.nan_output_0 = 0
        self.nan_output = 0
        self.inf_round_down = 0
        self.out_inf = 0
        self.out_0 = 0
        self.out_1 = 0
        self.out_2 = 0

    def _calculate(self, i):
        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        normal = self.mask(i['in_except'], 64)
        exponent = self.mask(i['exponent_in'], 12)
        mantissa = self.mask(i['mantissa_in'], 2)
        op = self.mask(i['fpu_op'], 3)
        rmode = self.mask(i['rmode'], 2)

        frac_mask = (1 << 52) - 1
        quiet_bit = 1 << 51
        sign_a = (opa >> 63) & 1
        sign_b = (opb >> 63) & 1
        sign_result = (normal >> 63) & 1
        exp_a = (opa >> 52) & 0x7ff
        exp_b = (opb >> 52) & 0x7ff
        frac_a = opa & frac_mask
        frac_b = opb & frac_mask

        zero_a = (opa & ((1 << 63) - 1)) == 0
        zero_b = (opb & ((1 << 63) - 1)) == 0
        zero_result = (normal & ((1 << 63) - 1)) == 0
        nan_a = exp_a == 2047 and frac_a != 0
        nan_b = exp_b == 2047 and frac_b != 0
        qnan_a = nan_a and bool(frac_a & quiet_bit)
        qnan_b = nan_b and bool(frac_b & quiet_bit)
        snan_a = nan_a and not bool(frac_a & quiet_bit)
        snan_b = nan_b and not bool(frac_b & quiet_bit)
        inf_a = exp_a == 2047 and frac_a == 0
        inf_b = exp_b == 2047 and frac_b == 0
        pos_inf_a = inf_a and sign_a == 0
        pos_inf_b = inf_b and sign_b == 0
        neg_inf_a = inf_a and sign_a == 1
        neg_inf_b = inf_b and sign_b == 1

        is_add = op == 0
        is_sub = op == 1
        is_mul = op == 2
        is_div = op == 3
        nan_input = nan_a or nan_b
        snan_input = snan_a or snan_b
        input_zero = zero_a or zero_b

        div_0_by_0 = is_div and zero_a and zero_b
        div_inf_by_inf = is_div and inf_a and inf_b
        div_by_0 = is_div and zero_b and not zero_a and not inf_a and not nan_input
        div_by_inf = is_div and inf_b and not inf_a and not nan_a
        mul_0_by_inf = is_mul and ((zero_a and inf_b) or (zero_b and inf_a))
        mul_inf = is_mul and (inf_a or inf_b)
        div_inf = is_div and inf_a and not inf_b
        add_inf = is_add and (inf_a or inf_b)
        sub_inf = is_sub and (inf_a or inf_b)
        addsub_inf = (is_add or is_sub) and (inf_a or inf_b)

        addsub_inf_invalid = (
            (is_add and ((pos_inf_a and neg_inf_b) or (neg_inf_a and pos_inf_b))) or
            (is_sub and ((pos_inf_a and pos_inf_b) or (neg_inf_a and neg_inf_b)))
        )
        invalid_trigger = (
            snan_input or addsub_inf_invalid or mul_0_by_inf or
            div_0_by_0 or div_inf_by_inf
        )
        nan_out_trigger = nan_input or invalid_trigger

        valid_addsub_inf = addsub_inf and not addsub_inf_invalid
        valid_mul_inf = mul_inf and not mul_0_by_inf
        out_inf_trigger = (
            valid_addsub_inf or valid_mul_inf or div_inf or div_by_0 or
            exponent > 2046
        )

        finite_div_by_inf = div_by_inf
        mul_uf = (
            is_mul and not zero_a and not zero_b and zero_result and
            not nan_input and not inf_a and not inf_b
        )
        div_uf = (
            is_div and not zero_a and not zero_b and zero_result and
            not nan_input and not inf_a and not inf_b
        )
        underflow_trigger = finite_div_by_inf or mul_uf or div_uf
        overflow_trigger = out_inf_trigger and not nan_input
        inexact_trigger = (
            (mantissa != 0 or out_inf_trigger or underflow_trigger) and
            not nan_input
        )
        except_trigger = (
            invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger
        )

        round_nearest = rmode == 0
        round_to_zero = rmode == 1
        round_to_pos_inf = rmode == 2
        round_to_neg_inf = rmode == 3
        round_down = out_inf_trigger and (
            (sign_result == 0 and (round_to_zero or round_to_neg_inf)) or
            (sign_result == 1 and (round_to_zero or round_to_pos_inf))
        )

        infinity_magnitude = 2047 << 52
        max_finite_magnitude = (2046 << 52) | frac_mask
        out_inf_magnitude = infinity_magnitude if out_inf_trigger else 0
        inf_round_down_magnitude = max_finite_magnitude if round_down else 0

        stage_0 = ((sign_result << 63) if underflow_trigger else normal)
        if out_inf_trigger:
            magnitude = max_finite_magnitude if round_down else infinity_magnitude
            stage_1 = (sign_result << 63) | magnitude
        else:
            stage_1 = stage_0

        a_nan = nan_out_trigger and (nan_a or not nan_input)
        nan_a_magnitude = (2047 << 52) | (frac_a | quiet_bit)
        nan_b_magnitude = (2047 << 52) | (frac_b | quiet_bit)
        nan_output_0 = nan_a_magnitude if nan_out_trigger else 0
        if nan_out_trigger:
            if nan_a:
                nan_magnitude = nan_a_magnitude
            elif nan_b:
                nan_magnitude = nan_b_magnitude
            else:
                nan_magnitude = nan_a_magnitude
            stage_2 = (sign_result << 63) | nan_magnitude
        else:
            nan_magnitude = 0
            stage_2 = stage_1

        enable_trigger = nan_out_trigger or out_inf_trigger or underflow_trigger or inexact_trigger
        return {
            'out': self.mask(stage_2, 64),
            'ex_enable': int(bool(enable_trigger)),
            'underflow': int(bool(underflow_trigger)),
            'overflow': int(bool(overflow_trigger)),
            'inexact': int(bool(inexact_trigger)),
            'exception': int(bool(except_trigger)),
            'invalid': int(bool(invalid_trigger)),
            'in_et_zero': bool(zero_result),
            'opa_et_zero': bool(zero_a),
            'opb_et_zero': bool(zero_b),
            'input_et_zero': bool(input_zero),
            'add': bool(is_add),
            'subtract': bool(is_sub),
            'multiply': bool(is_mul),
            'divide': bool(is_div),
            'opa_qnan': bool(qnan_a),
            'opb_qnan': bool(qnan_b),
            'opa_snan': bool(snan_a),
            'opb_snan': bool(snan_b),
            'opa_pos_inf': bool(pos_inf_a),
            'opb_pos_inf': bool(pos_inf_b),
            'opa_neg_inf': bool(neg_inf_a),
            'opb_neg_inf': bool(neg_inf_b),
            'opa_inf': bool(inf_a),
            'opb_inf': bool(inf_b),
            'nan_input': bool(nan_input),
            'snan_input': bool(snan_input),
            'a_nan': bool(a_nan),
            'div_by_0': bool(div_by_0),
            'div_0_by_0': bool(div_0_by_0),
            'div_inf_by_inf': bool(div_inf_by_inf),
            'div_by_inf': bool(div_by_inf),
            'mul_0_by_inf': bool(mul_0_by_inf),
            'mul_inf': bool(mul_inf),
            'div_inf': bool(div_inf),
            'add_inf': bool(add_inf),
            'sub_inf': bool(sub_inf),
            'addsub_inf_invalid': bool(addsub_inf_invalid),
            'addsub_inf': bool(addsub_inf),
            'out_inf_trigger': bool(out_inf_trigger),
            'out_pos_inf': bool(out_inf_trigger and sign_result == 0),
            'out_neg_inf': bool(out_inf_trigger and sign_result == 1),
            'round_nearest': bool(round_nearest),
            'round_to_zero': bool(round_to_zero),
            'round_to_pos_inf': bool(round_to_pos_inf),
            'round_to_neg_inf': bool(round_to_neg_inf),
            'inf_round_down_trigger': bool(round_down),
            'mul_uf': bool(mul_uf),
            'div_uf': bool(div_uf),
            'underflow_trigger': bool(underflow_trigger),
            'invalid_trigger': bool(invalid_trigger),
            'overflow_trigger': bool(overflow_trigger),
            'inexact_trigger': bool(inexact_trigger),
            'except_trigger': bool(except_trigger),
            'enable_trigger': bool(enable_trigger),
            'nan_out_trigger': bool(nan_out_trigger),
            'snan_trigger': bool(snan_input),
            'nan_output_0': self.mask(nan_output_0, 63),
            'nan_output': self.mask(nan_magnitude, 63),
            'inf_round_down': self.mask(inf_round_down_magnitude, 63),
            'out_inf': self.mask(out_inf_magnitude, 63),
            'out_0': self.mask(stage_0, 64),
            'out_1': self.mask(stage_1, 64),
            'out_2': self.mask(stage_2, 64)
        }

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self.out
        o['ex_enable'] = self.ex_enable
        o['underflow'] = self.underflow
        o['overflow'] = self.overflow
        o['inexact'] = self.inexact
        o['exception'] = self.exception
        o['invalid'] = self.invalid

        flag_names = (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger'
        )
        for name in flag_names:
            setattr(self, name, bool(getattr(self, name)))

        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1
        self.nan_output_0 = self.nan_output_0
        self.nan_output = self.nan_output
        self.inf_round_down = self.inf_round_down
        self.out_inf = self.out_inf
        self.out_0 = self.out_0
        self.out_1 = self.out_1
        self.out_2 = self.out_2
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not i['enable']:
            return
        next_state = self._calculate(i)
        for name, value in next_state.items():
            setattr(self, name, value)
