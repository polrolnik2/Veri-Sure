"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        self._state = {
            'out': 0, 'ex_enable': 0, 'underflow': 0, 'overflow': 0,
            'inexact': 0, 'exception': 0, 'invalid': 0,
            'in_et_zero': 0, 'opa_et_zero': 0, 'opb_et_zero': 0,
            'input_et_zero': 0, 'add': 0, 'subtract': 0, 'multiply': 0,
            'divide': 0, 'opa_qnan': 0, 'opb_qnan': 0, 'opa_snan': 0,
            'opb_snan': 0, 'opa_pos_inf': 0, 'opb_pos_inf': 0,
            'opa_neg_inf': 0, 'opb_neg_inf': 0, 'opa_inf': 0, 'opb_inf': 0,
            'nan_input': 0, 'snan_input': 0, 'a_nan': 0, 'div_by_0': 0,
            'div_0_by_0': 0, 'div_inf_by_inf': 0, 'div_by_inf': 0,
            'mul_0_by_inf': 0, 'mul_inf': 0, 'div_inf': 0, 'add_inf': 0,
            'sub_inf': 0, 'addsub_inf_invalid': 0, 'addsub_inf': 0,
            'out_inf_trigger': 0, 'out_pos_inf': 0, 'out_neg_inf': 0,
            'round_nearest': 0, 'round_to_zero': 0, 'round_to_pos_inf': 0,
            'round_to_neg_inf': 0, 'inf_round_down_trigger': 0,
            'mul_uf': 0, 'div_uf': 0, 'underflow_trigger': 0,
            'invalid_trigger': 0, 'overflow_trigger': 0, 'inexact_trigger': 0,
            'except_trigger': 0, 'enable_trigger': 0, 'nan_out_trigger': 0,
            'snan_trigger': 0, 'nan_output_0': 0, 'nan_output': 0,
            'inf_round_down': 0, 'out_inf': 0, 'out_0': 0, 'out_1': 0,
            'out_2': 0
        }

    def outputs(self, i):
        o = {p: self._state[p] for p in self.OUTPUT_PORTS}
        for name in (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan',
            'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf',
            'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input',
            'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf',
            'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf',
            'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'nan_output_0',
            'nan_output', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2'
        ):
            setattr(self, name, self._state[name])
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not i['enable']:
            return

        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        candidate = self.mask(i['in_except'], 64)
        exponent_in = self.mask(i['exponent_in'], 12)
        mantissa_in = self.mask(i['mantissa_in'], 2)
        fpu_op = self.mask(i['fpu_op'], 3)
        rmode = self.mask(i['rmode'], 2)

        frac_mask = (1 << 52) - 1
        low63_mask = (1 << 63) - 1
        a_sign = (opa >> 63) & 1
        b_sign = (opb >> 63) & 1
        result_sign = (candidate >> 63) & 1
        a_exp = (opa >> 52) & 0x7ff
        b_exp = (opb >> 52) & 0x7ff
        a_frac = opa & frac_mask
        b_frac = opb & frac_mask

        a_zero = (opa & low63_mask) == 0
        b_zero = (opb & low63_mask) == 0
        result_zero = (candidate & low63_mask) == 0
        a_nan = a_exp == 0x7ff and a_frac != 0
        b_nan = b_exp == 0x7ff and b_frac != 0
        a_qnan = a_nan and bool(a_frac & (1 << 51))
        b_qnan = b_nan and bool(b_frac & (1 << 51))
        a_snan = a_nan and not bool(a_frac & (1 << 51))
        b_snan = b_nan and not bool(b_frac & (1 << 51))
        a_inf = a_exp == 0x7ff and a_frac == 0
        b_inf = b_exp == 0x7ff and b_frac == 0
        a_pos_inf = a_inf and not a_sign
        b_pos_inf = b_inf and not b_sign
        a_neg_inf = a_inf and bool(a_sign)
        b_neg_inf = b_inf and bool(b_sign)

        add = fpu_op == 0
        subtract = fpu_op == 1
        multiply = fpu_op == 2
        divide = fpu_op == 3
        nan_input = a_nan or b_nan
        snan_input = a_snan or b_snan

        addsub_inf = (add or subtract) and (a_inf or b_inf)
        add_inf = add and (a_inf or b_inf)
        sub_inf = subtract and (a_inf or b_inf)
        addsub_inf_invalid = (
            (add and ((a_pos_inf and b_neg_inf) or (a_neg_inf and b_pos_inf)))
            or (subtract and ((a_pos_inf and b_pos_inf) or (a_neg_inf and b_neg_inf)))
        )
        mul_0_by_inf = multiply and ((a_zero and b_inf) or (b_zero and a_inf))
        mul_inf = multiply and (a_inf or b_inf)
        div_0_by_0 = divide and a_zero and b_zero
        div_inf_by_inf = divide and a_inf and b_inf
        div_by_0 = divide and b_zero and not a_zero and not nan_input
        div_by_inf = divide and b_inf and not a_inf and not nan_input
        div_inf = divide and a_inf and not b_inf and not nan_input

        invalid_trigger = (
            snan_input or addsub_inf_invalid or mul_0_by_inf
            or div_0_by_0 or div_inf_by_inf
        )
        nan_out_trigger = nan_input or invalid_trigger

        valid_addsub_inf = addsub_inf and not addsub_inf_invalid and not nan_input
        valid_mul_inf = mul_inf and not mul_0_by_inf and not nan_input
        valid_div_inf = (div_inf or div_by_0) and not nan_input
        out_inf_trigger = (
            valid_addsub_inf or valid_mul_inf or valid_div_inf
            or (exponent_in > 2046)
        )

        round_nearest = rmode == 0
        round_to_zero = rmode == 1
        round_to_pos_inf = rmode == 2
        round_to_neg_inf = rmode == 3
        inf_round_down_trigger = out_inf_trigger and (
            (not result_sign and (round_to_zero or round_to_neg_inf))
            or (result_sign and (round_to_zero or round_to_pos_inf))
        )

        mul_uf = (
            multiply and not a_zero and not b_zero and not a_inf and not b_inf
            and not nan_input and result_zero
        )
        div_uf = (
            divide and not a_zero and not b_zero and not a_inf and not b_inf
            and not nan_input and result_zero
        )
        underflow_trigger = (div_by_inf or mul_uf or div_uf) and not nan_input
        overflow_trigger = out_inf_trigger and not nan_input
        inexact_trigger = (
            not nan_input
            and (mantissa_in != 0 or out_inf_trigger or underflow_trigger)
        )
        except_trigger = (
            invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger
        )
        enable_trigger = (
            nan_out_trigger or out_inf_trigger or underflow_trigger or inexact_trigger
        )

        sign_word = result_sign << 63
        out_0 = sign_word if underflow_trigger else candidate
        infinity_magnitude = 0x7ff << 52
        max_finite_magnitude = (0x7fe << 52) | frac_mask
        selected_inf_magnitude = (
            max_finite_magnitude if inf_round_down_trigger else infinity_magnitude
        )
        out_1 = (
            sign_word | selected_inf_magnitude if out_inf_trigger else out_0
        )

        use_a_nan = a_nan or not b_nan
        selected_fraction = a_frac if use_a_nan else b_frac
        nan_magnitude = (0x7ff << 52) | ((selected_fraction | (1 << 51)) & frac_mask)
        nan_output = nan_magnitude if nan_out_trigger else 0
        out_2 = sign_word | nan_output if nan_out_trigger else out_1

        n = dict(self._state)
        n.update({
            'out': self.mask(out_2, 64),
            'ex_enable': int(enable_trigger),
            'underflow': int(underflow_trigger),
            'overflow': int(overflow_trigger),
            'inexact': int(inexact_trigger),
            'exception': int(except_trigger),
            'invalid': int(invalid_trigger),
            'in_et_zero': int(result_zero),
            'opa_et_zero': int(a_zero),
            'opb_et_zero': int(b_zero),
            'input_et_zero': int(a_zero or b_zero),
            'add': int(add),
            'subtract': int(subtract),
            'multiply': int(multiply),
            'divide': int(divide),
            'opa_qnan': int(a_qnan),
            'opb_qnan': int(b_qnan),
            'opa_snan': int(a_snan),
            'opb_snan': int(b_snan),
            'opa_pos_inf': int(a_pos_inf),
            'opb_pos_inf': int(b_pos_inf),
            'opa_neg_inf': int(a_neg_inf),
            'opb_neg_inf': int(b_neg_inf),
            'opa_inf': int(a_inf),
            'opb_inf': int(b_inf),
            'nan_input': int(nan_input),
            'snan_input': int(snan_input),
            'a_nan': int(nan_out_trigger and use_a_nan),
            'div_by_0': int(div_by_0),
            'div_0_by_0': int(div_0_by_0),
            'div_inf_by_inf': int(div_inf_by_inf),
            'div_by_inf': int(div_by_inf),
            'mul_0_by_inf': int(mul_0_by_inf),
            'mul_inf': int(mul_inf),
            'div_inf': int(div_inf),
            'add_inf': int(add_inf),
            'sub_inf': int(sub_inf),
            'addsub_inf_invalid': int(addsub_inf_invalid),
            'addsub_inf': int(addsub_inf),
            'out_inf_trigger': int(out_inf_trigger),
            'out_pos_inf': int(out_inf_trigger and not result_sign),
            'out_neg_inf': int(out_inf_trigger and bool(result_sign)),
            'round_nearest': int(round_nearest),
            'round_to_zero': int(round_to_zero),
            'round_to_pos_inf': int(round_to_pos_inf),
            'round_to_neg_inf': int(round_to_neg_inf),
            'inf_round_down_trigger': int(inf_round_down_trigger),
            'mul_uf': int(mul_uf),
            'div_uf': int(div_uf),
            'underflow_trigger': int(underflow_trigger),
            'invalid_trigger': int(invalid_trigger),
            'overflow_trigger': int(overflow_trigger),
            'inexact_trigger': int(inexact_trigger),
            'except_trigger': int(except_trigger),
            'enable_trigger': int(enable_trigger),
            'nan_out_trigger': int(nan_out_trigger),
            'snan_trigger': int(snan_input),
            'nan_output_0': self.mask(nan_output, 63),
            'nan_output': self.mask(nan_output, 63),
            'inf_round_down': self.mask(max_finite_magnitude, 63),
            'out_inf': self.mask(infinity_magnitude, 63),
            'out_0': self.mask(out_0, 64),
            'out_1': self.mask(out_1, 64),
            'out_2': self.mask(out_2, 64)
        })
        self._state = n
