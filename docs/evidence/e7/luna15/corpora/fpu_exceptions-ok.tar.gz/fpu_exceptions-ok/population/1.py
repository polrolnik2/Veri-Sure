"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        names = (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger',
            'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output',
            'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2'
        )
        self._p = dict((name, 0) for name in names)
        self._p['exp_2047'] = 2047
        self._p['exp_2046'] = 2046
        self._p['mantissa_max'] = (1 << 52) - 1
        for name, value in self._p.items():
            setattr(self, name, value)
        self.out = 0
        self.ex_enable = 0
        self.underflow = 0
        self.overflow = 0
        self.inexact = 0
        self.exception = 0
        self.invalid = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self.out
        o['ex_enable'] = self.ex_enable
        o['underflow'] = self.underflow
        o['overflow'] = self.overflow
        o['inexact'] = self.inexact
        o['exception'] = self.exception
        o['invalid'] = self.invalid
        for name, value in self._p.items():
            setattr(self, name, value)
        return o

    def _calc(self, i):
        a = self.mask(i['opa'], 64)
        b = self.mask(i['opb'], 64)
        candidate = self.mask(i['in_except'], 64)
        op = self.mask(i['fpu_op'], 3)
        mode = self.mask(i['rmode'], 2)
        exponent = self.mask(i['exponent_in'], 12)
        remainder = self.mask(i['mantissa_in'], 2)
        frac_mask = (1 << 52) - 1
        exp_a = (a >> 52) & 2047
        exp_b = (b >> 52) & 2047
        frac_a = a & frac_mask
        frac_b = b & frac_mask
        zero_a = (a & ((1 << 63) - 1)) == 0
        zero_b = (b & ((1 << 63) - 1)) == 0
        nan_a = exp_a == 2047 and frac_a != 0
        nan_b = exp_b == 2047 and frac_b != 0
        qnan_a = nan_a and bool(frac_a & (1 << 51))
        qnan_b = nan_b and bool(frac_b & (1 << 51))
        snan_a = nan_a and not bool(frac_a & (1 << 51))
        snan_b = nan_b and not bool(frac_b & (1 << 51))
        inf_a = exp_a == 2047 and frac_a == 0
        inf_b = exp_b == 2047 and frac_b == 0
        neg_a = bool((a >> 63) & 1)
        neg_b = bool((b >> 63) & 1)
        nan_input = nan_a or nan_b
        snan_input = snan_a or snan_b
        is_add = op == 0
        is_sub = op == 1
        is_mul = op == 2
        is_div = op == 3

        div_0_by_0 = is_div and zero_a and zero_b
        div_inf_by_inf = is_div and inf_a and inf_b
        div_by_0 = is_div and zero_b and not zero_a and not inf_a and not nan_input
        div_by_inf = is_div and inf_b and not inf_a and not nan_input
        mul_0_by_inf = is_mul and ((zero_a and inf_b) or (inf_a and zero_b))
        mul_inf = is_mul and (inf_a or inf_b)
        div_inf = is_div and inf_a and not inf_b
        add_inf = is_add and (inf_a or inf_b)
        sub_inf = is_sub and (inf_a or inf_b)
        addsub_inf_invalid = (is_add and ((inf_a and not neg_a and inf_b and neg_b) or (inf_a and neg_a and inf_b and not neg_b))) or (is_sub and ((inf_a and not neg_a and inf_b and not neg_b) or (inf_a and neg_a and inf_b and neg_b)))
        addsub_inf = (add_inf or sub_inf) and not addsub_inf_invalid

        valid_mul_inf = mul_inf and not mul_0_by_inf
        valid_div_inf = div_inf and not div_inf_by_inf
        valid_addsub_inf = addsub_inf
        out_inf_trigger = ((valid_mul_inf or valid_div_inf or valid_addsub_inf) and not nan_input) or div_by_0 or exponent > 2046
        sign = (candidate >> 63) & 1
        out_pos_inf = out_inf_trigger and not sign
        out_neg_inf = out_inf_trigger and bool(sign)
        round_nearest = mode == 0
        round_to_zero = mode == 1
        round_to_pos_inf = mode == 2
        round_to_neg_inf = mode == 3
        inf_round_down_trigger = out_inf_trigger and ((out_pos_inf and (round_to_zero or round_to_neg_inf)) or (out_neg_inf and (round_to_zero or round_to_pos_inf)))

        candidate_zero = (candidate & ((1 << 63) - 1)) == 0
        mul_uf = is_mul and candidate_zero and not zero_a and not zero_b and not inf_a and not inf_b and not nan_input
        div_uf = is_div and (div_by_inf or (candidate_zero and not zero_a and not zero_b and not inf_a and not inf_b and not nan_input))
        underflow_trigger = mul_uf or div_uf
        invalid_trigger = snan_input or addsub_inf_invalid or mul_0_by_inf or div_0_by_0 or div_inf_by_inf
        overflow_trigger = out_inf_trigger and not nan_input
        inexact_trigger = not nan_input and (remainder != 0 or out_inf_trigger or underflow_trigger)
        except_trigger = invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger
        nan_out_trigger = nan_input or invalid_trigger
        enable_trigger = nan_out_trigger or out_inf_trigger or underflow_trigger or inexact_trigger

        if nan_input:
            selected_nan = a if nan_a else b
            nan_fraction = selected_nan & frac_mask
        else:
            nan_fraction = frac_a
        nan_fraction |= 1 << 51
        nan_magnitude = (2047 << 52) | nan_fraction
        infinity_magnitude = 2047 << 52
        maximum_magnitude = (2046 << 52) | frac_mask
        signed_zero = sign << 63
        stage_0 = signed_zero if underflow_trigger else candidate
        stage_1 = stage_0
        if out_inf_trigger:
            stage_1 = (sign << 63) | (maximum_magnitude if inf_round_down_trigger else infinity_magnitude)
        stage_2 = stage_1
        if nan_out_trigger:
            stage_2 = (sign << 63) | nan_magnitude

        p = dict((name, 0) for name in self._p)
        p['in_et_zero'] = int(candidate_zero)
        p['opa_et_zero'] = int(zero_a)
        p['opb_et_zero'] = int(zero_b)
        p['input_et_zero'] = int(zero_a or zero_b)
        p['add'] = int(is_add)
        p['subtract'] = int(is_sub)
        p['multiply'] = int(is_mul)
        p['divide'] = int(is_div)
        p['opa_qnan'] = int(qnan_a)
        p['opb_qnan'] = int(qnan_b)
        p['opa_snan'] = int(snan_a)
        p['opb_snan'] = int(snan_b)
        p['opa_pos_inf'] = int(inf_a and not neg_a)
        p['opb_pos_inf'] = int(inf_b and not neg_b)
        p['opa_neg_inf'] = int(inf_a and neg_a)
        p['opb_neg_inf'] = int(inf_b and neg_b)
        p['opa_inf'] = int(inf_a)
        p['opb_inf'] = int(inf_b)
        p['nan_input'] = int(nan_input)
        p['snan_input'] = int(snan_input)
        p['a_nan'] = int(nan_a)
        p['div_by_0'] = int(div_by_0)
        p['div_0_by_0'] = int(div_0_by_0)
        p['div_inf_by_inf'] = int(div_inf_by_inf)
        p['div_by_inf'] = int(div_by_inf)
        p['mul_0_by_inf'] = int(mul_0_by_inf)
        p['mul_inf'] = int(mul_inf)
        p['div_inf'] = int(div_inf)
        p['add_inf'] = int(add_inf)
        p['sub_inf'] = int(sub_inf)
        p['addsub_inf_invalid'] = int(addsub_inf_invalid)
        p['addsub_inf'] = int(addsub_inf)
        p['out_inf_trigger'] = int(out_inf_trigger)
        p['out_pos_inf'] = int(out_pos_inf)
        p['out_neg_inf'] = int(out_neg_inf)
        p['round_nearest'] = int(round_nearest)
        p['round_to_zero'] = int(round_to_zero)
        p['round_to_pos_inf'] = int(round_to_pos_inf)
        p['round_to_neg_inf'] = int(round_to_neg_inf)
        p['inf_round_down_trigger'] = int(inf_round_down_trigger)
        p['mul_uf'] = int(mul_uf)
        p['div_uf'] = int(div_uf)
        p['underflow_trigger'] = int(underflow_trigger)
        p['invalid_trigger'] = int(invalid_trigger)
        p['overflow_trigger'] = int(overflow_trigger)
        p['inexact_trigger'] = int(inexact_trigger)
        p['except_trigger'] = int(except_trigger)
        p['enable_trigger'] = int(enable_trigger)
        p['nan_out_trigger'] = int(nan_out_trigger)
        p['snan_trigger'] = int(snan_input)
        p['exp_2047'] = 2047
        p['exp_2046'] = 2046
        p['nan_output_0'] = nan_magnitude if nan_out_trigger else 0
        p['nan_output'] = nan_magnitude if nan_out_trigger else 0
        p['mantissa_max'] = frac_mask
        p['inf_round_down'] = maximum_magnitude
        p['out_inf'] = infinity_magnitude
        p['out_0'] = self.mask(stage_0, 64)
        p['out_1'] = self.mask(stage_1, 64)
        p['out_2'] = self.mask(stage_2, 64)

        invalid = int(invalid_trigger)
        overflow = int(overflow_trigger)
        underflow = int(underflow_trigger)
        inexact = int(inexact_trigger)
        exception = int(bool(invalid or overflow or underflow or inexact))
        ex_enable = int(bool(enable_trigger))
        return p, self.mask(stage_2, 64), ex_enable, underflow, overflow, inexact, exception, invalid

    def advance(self, i):
        if int(i['rst']):
            self.reset()
            return
        if not int(i['enable']):
            return
        p, out, ex_enable, underflow, overflow, inexact, exception, invalid = self._calc(i)
        self._p = p
        self.out = out
        self.ex_enable = ex_enable
        self.underflow = underflow
        self.overflow = overflow
        self.inexact = inexact
        self.exception = exception
        self.invalid = invalid
