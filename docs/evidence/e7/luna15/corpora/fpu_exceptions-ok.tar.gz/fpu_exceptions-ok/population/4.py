"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        names = (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047',
            'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max',
            'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2'
        )
        self._outputs = {
            'out': 0, 'ex_enable': 0, 'underflow': 0, 'overflow': 0,
            'inexact': 0, 'exception': 0, 'invalid': 0
        }
        self._probe_state = {name: 0 for name in names}
        self._probe_state['exp_2047'] = 2047
        self._probe_state['exp_2046'] = 2046
        self._probe_state['mantissa_max'] = (1 << 52) - 1
        for name, value in self._probe_state.items():
            setattr(self, name, value)

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        for name, value in self._probe_state.items():
            setattr(self, name, value)
        for name, value in self._outputs.items():
            o[name] = value
        return o

    def advance(self, i):
        if i['rst'] & 1:
            self.reset()
            return
        if not (i['enable'] & 1):
            return
        self._outputs, self._probe_state = self._compute(i)

    def _compute(self, i):
        mask52 = (1 << 52) - 1
        mask63 = (1 << 63) - 1
        a = self.mask(i['opa'], 64)
        b = self.mask(i['opb'], 64)
        normal = self.mask(i['in_except'], 64)
        exponent = self.mask(i['exponent_in'], 12)
        remainder = self.mask(i['mantissa_in'], 2)
        op = self.mask(i['fpu_op'], 3)
        mode = self.mask(i['rmode'], 2)

        a_exp = (a >> 52) & 0x7ff
        b_exp = (b >> 52) & 0x7ff
        a_frac = a & mask52
        b_frac = b & mask52
        a_sign = (a >> 63) & 1
        b_sign = (b >> 63) & 1
        sign = (normal >> 63) & 1

        a_zero = (a & mask63) == 0
        b_zero = (b & mask63) == 0
        in_zero = (normal & mask63) == 0
        a_nan = a_exp == 0x7ff and a_frac != 0
        b_nan = b_exp == 0x7ff and b_frac != 0
        a_qnan = a_nan and ((a_frac >> 51) & 1) != 0
        b_qnan = b_nan and ((b_frac >> 51) & 1) != 0
        a_snan = a_nan and not a_qnan
        b_snan = b_nan and not b_qnan
        a_inf = a_exp == 0x7ff and a_frac == 0
        b_inf = b_exp == 0x7ff and b_frac == 0
        a_pos_inf = a_inf and not a_sign
        b_pos_inf = b_inf and not b_sign
        a_neg_inf = a_inf and bool(a_sign)
        b_neg_inf = b_inf and bool(b_sign)

        is_add = op == 0
        is_sub = op == 1
        is_mul = op == 2
        is_div = op == 3
        nan_input = a_nan or b_nan
        snan_input = a_snan or b_snan

        div_0_by_0 = is_div and a_zero and b_zero
        div_inf_by_inf = is_div and a_inf and b_inf
        div_by_0 = is_div and b_zero and not a_zero and not a_nan
        div_by_inf = is_div and b_inf and not a_inf and not a_nan
        mul_0_by_inf = is_mul and ((a_zero and b_inf) or (a_inf and b_zero))
        mul_inf = is_mul and (a_inf or b_inf) and not mul_0_by_inf
        div_inf = is_div and ((a_inf and not b_inf) or div_by_0)
        add_inf = is_add and (a_inf or b_inf)
        sub_inf = is_sub and (a_inf or b_inf)

        add_invalid = is_add and ((a_pos_inf and b_neg_inf) or (a_neg_inf and b_pos_inf))
        sub_invalid = is_sub and ((a_pos_inf and b_pos_inf) or (a_neg_inf and b_neg_inf))
        addsub_inf_invalid = add_invalid or sub_invalid
        addsub_inf = (add_inf or sub_inf) and not addsub_inf_invalid
        invalid_trigger = snan_input or addsub_inf_invalid or mul_0_by_inf or div_0_by_0 or div_inf_by_inf

        a_finite = not a_inf and not a_nan
        b_finite = not b_inf and not b_nan
        mul_uf = is_mul and a_finite and b_finite and not a_zero and not b_zero and in_zero
        div_uf = is_div and a_finite and b_finite and not a_zero and not b_zero and in_zero
        underflow_trigger = div_by_inf or mul_uf or div_uf

        out_inf_trigger = addsub_inf or mul_inf or div_inf or div_by_0 or exponent > 2046
        out_pos_inf = out_inf_trigger and not sign
        out_neg_inf = out_inf_trigger and bool(sign)
        round_down = out_inf_trigger and (
            (not sign and mode in (1, 3)) or (bool(sign) and mode in (1, 2))
        )
        overflow_trigger = out_inf_trigger and not nan_input
        inexact_trigger = (remainder != 0 or out_inf_trigger or underflow_trigger) and not nan_input
        except_trigger = invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger

        nan_out_trigger = nan_input or invalid_trigger
        a_nan_selected = a_nan
        if a_nan_selected:
            nan_fraction = a_frac
        elif b_nan:
            nan_fraction = b_frac
        else:
            nan_fraction = a_frac
        nan_fraction = (nan_fraction | (1 << 51)) & mask52
        nan_magnitude = ((2047 << 52) | nan_fraction) & mask63
        stored_nan = nan_magnitude if nan_out_trigger else 0

        infinity_magnitude = 2047 << 52
        max_finite_magnitude = (2046 << 52) | mask52
        signed_zero = sign << 63
        out_0 = signed_zero if underflow_trigger else normal
        if out_inf_trigger:
            magnitude = max_finite_magnitude if round_down else infinity_magnitude
            out_1 = (sign << 63) | magnitude
        else:
            out_1 = out_0
        out_2 = ((sign << 63) | nan_magnitude) if nan_out_trigger else out_1

        enable_trigger = nan_out_trigger or out_inf_trigger or underflow_trigger or inexact_trigger or invalid_trigger
        probes = {
            'in_et_zero': int(in_zero),
            'opa_et_zero': int(a_zero),
            'opb_et_zero': int(b_zero),
            'input_et_zero': int(a_zero or b_zero),
            'add': int(is_add),
            'subtract': int(is_sub),
            'multiply': int(is_mul),
            'divide': int(is_div),
            'opa_qnan': int(a_qnan),
            'opb_qnan': int(b_qnan),
            'opa_snan': int(a_snan),
            'opb_snan': int(b_snan),
            'opa_pos_inf': int(a_pos_inf),
            'opb_pos_inf': int(b_pos_inf),
            'opa_neg_inf': int(a_neg_inf),
            'opb_neg_inf': int(b_neg_inf),
            'opa_inf': int(a_inf),
            'opb_inf': int(b_inf),
            'nan_input': int(nan_input),
            'snan_input': int(snan_input),
            'a_nan': int(a_nan_selected),
            'div_by_0': int(div_by_0),
            'div_0_by_0': int(div_0_by_0),
            'div_inf_by_inf': int(div_inf_by_inf),
            'div_by_inf': int(div_by_inf),
            'mul_0_by_inf': int(mul_0_by_inf),
            'mul_inf': int(mul_inf),
            'div_inf': int(div_inf),
            'add_inf': int(add_inf),
            'sub_inf': int(sub_inf),
            'addsub_inf_invalid': int(addsub_inf_invalid),
            'addsub_inf': int(addsub_inf),
            'out_inf_trigger': int(out_inf_trigger),
            'out_pos_inf': int(out_pos_inf),
            'out_neg_inf': int(out_neg_inf),
            'round_nearest': int(mode == 0),
            'round_to_zero': int(mode == 1),
            'round_to_pos_inf': int(mode == 2),
            'round_to_neg_inf': int(mode == 3),
            'inf_round_down_trigger': int(round_down),
            'mul_uf': int(mul_uf),
            'div_uf': int(div_uf),
            'underflow_trigger': int(underflow_trigger),
            'invalid_trigger': int(invalid_trigger),
            'overflow_trigger': int(overflow_trigger),
            'inexact_trigger': int(inexact_trigger),
            'except_trigger': int(except_trigger),
            'enable_trigger': int(enable_trigger),
            'nan_out_trigger': int(nan_out_trigger),
            'snan_trigger': int(snan_input),
            'exp_2047': 2047,
            'exp_2046': 2046,
            'nan_output_0': stored_nan,
            'nan_output': stored_nan,
            'mantissa_max': mask52,
            'inf_round_down': max_finite_magnitude,
            'out_inf': infinity_magnitude,
            'out_0': self.mask(out_0, 64),
            'out_1': self.mask(out_1, 64),
            'out_2': self.mask(out_2, 64)
        }
        result = {
            'out': self.mask(out_2, 64),
            'ex_enable': int(enable_trigger),
            'underflow': int(underflow_trigger),
            'overflow': int(overflow_trigger),
            'inexact': int(inexact_trigger),
            'exception': int(except_trigger),
            'invalid': int(invalid_trigger)
        }
        return result, probes
