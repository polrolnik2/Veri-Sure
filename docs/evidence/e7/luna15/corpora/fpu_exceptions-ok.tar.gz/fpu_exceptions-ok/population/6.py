"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        self._probe_names = (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047',
            'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max',
            'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2'
        )
        self._p = {name: 0 for name in self._probe_names}
        self._p['exp_2047'] = 2047
        self._p['exp_2046'] = 2046
        self._p['mantissa_max'] = (1 << 52) - 1
        self._out = 0
        self._ex_enable = 0
        self._underflow = 0
        self._overflow = 0
        self._inexact = 0
        self._exception = 0
        self._invalid = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self._out
        o['ex_enable'] = self._ex_enable
        o['underflow'] = self._underflow
        o['overflow'] = self._overflow
        o['inexact'] = self._inexact
        o['exception'] = self._exception
        o['invalid'] = self._invalid
        for name in self._probe_names:
            setattr(self, name, self._p[name])
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not i['enable']:
            return

        a = self.mask(i['opa'], 64)
        b = self.mask(i['opb'], 64)
        candidate = self.mask(i['in_except'], 64)
        exponent = self.mask(i['exponent_in'], 12)
        remainder = self.mask(i['mantissa_in'], 2)
        op = self.mask(i['fpu_op'], 3)
        mode = self.mask(i['rmode'], 2)

        fraction_mask = (1 << 52) - 1
        low_63_mask = (1 << 63) - 1
        a_exp = (a >> 52) & 0x7ff
        b_exp = (b >> 52) & 0x7ff
        a_fraction = a & fraction_mask
        b_fraction = b & fraction_mask
        a_sign = (a >> 63) & 1
        b_sign = (b >> 63) & 1
        result_sign = (candidate >> 63) & 1

        a_zero = (a & low_63_mask) == 0
        b_zero = (b & low_63_mask) == 0
        candidate_zero = (candidate & low_63_mask) == 0
        a_nan = a_exp == 0x7ff and a_fraction != 0
        b_nan = b_exp == 0x7ff and b_fraction != 0
        nan_input = a_nan or b_nan
        a_qnan = a_nan and ((a_fraction >> 51) & 1) == 1
        b_qnan = b_nan and ((b_fraction >> 51) & 1) == 1
        a_snan = a_nan and not a_qnan
        b_snan = b_nan and not b_qnan
        snan_input = a_snan or b_snan
        a_inf = a_exp == 0x7ff and a_fraction == 0
        b_inf = b_exp == 0x7ff and b_fraction == 0
        a_pos_inf = a_inf and a_sign == 0
        b_pos_inf = b_inf and b_sign == 0
        a_neg_inf = a_inf and a_sign == 1
        b_neg_inf = b_inf and b_sign == 1

        is_add = op == 0
        is_subtract = op == 1
        is_multiply = op == 2
        is_divide = op == 3

        addsub_invalid = (
            (is_add and ((a_pos_inf and b_neg_inf) or (a_neg_inf and b_pos_inf)))
            or (is_subtract and ((a_pos_inf and b_pos_inf) or (a_neg_inf and b_neg_inf)))
        )
        div_0_by_0 = is_divide and a_zero and b_zero
        div_inf_by_inf = is_divide and a_inf and b_inf
        div_by_0 = is_divide and b_zero and not a_zero
        div_by_inf = is_divide and b_inf and not a_inf and not nan_input
        mul_0_by_inf = is_multiply and ((a_zero and b_inf) or (b_zero and a_inf))

        mul_inf = is_multiply and (a_inf or b_inf)
        div_inf = is_divide and a_inf and not b_inf
        add_inf = is_add and (a_inf or b_inf)
        sub_inf = is_subtract and (a_inf or b_inf)
        addsub_inf = add_inf or sub_inf

        invalid_operations = addsub_invalid or mul_0_by_inf or div_0_by_0 or div_inf_by_inf
        invalid_trigger = snan_input or invalid_operations
        nan_out_trigger = nan_input or invalid_operations or snan_input

        valid_inf_result = (
            (add_inf and not addsub_invalid)
            or (sub_inf and not addsub_invalid)
            or (mul_inf and not mul_0_by_inf)
            or (div_inf and not div_inf_by_inf)
        ) and not nan_input
        out_inf_trigger = valid_inf_result or div_by_0 or exponent > 2046

        mul_uf = (
            is_multiply and candidate_zero and not a_zero and not b_zero
            and not a_inf and not b_inf and not nan_input
        )
        div_uf = (
            is_divide and candidate_zero and not a_zero and not b_zero
            and not a_inf and not b_inf and not nan_input
        )
        underflow_trigger = (div_by_inf or mul_uf or div_uf) and not nan_input
        overflow_trigger = out_inf_trigger and not nan_input
        inexact_trigger = (
            (remainder != 0 or out_inf_trigger or underflow_trigger)
            and not nan_input
        )
        except_trigger = invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger
        enable_trigger = nan_out_trigger or out_inf_trigger or underflow_trigger or inexact_trigger

        round_nearest = mode == 0
        round_to_zero = mode == 1
        round_to_pos_inf = mode == 2
        round_to_neg_inf = mode == 3
        inf_round_down_trigger = out_inf_trigger and (
            (not result_sign and (round_to_zero or round_to_neg_inf))
            or (result_sign and (round_to_zero or round_to_pos_inf))
        )

        if nan_input:
            selected_fraction = a_fraction if a_nan else b_fraction
            nan_fraction = selected_fraction | (1 << 51)
        elif invalid_operations:
            nan_fraction = a_fraction | (1 << 51)
        else:
            nan_fraction = 0
        nan_magnitude = ((0x7ff << 52) | nan_fraction) & low_63_mask
        nan_result = (result_sign << 63) | nan_magnitude

        infinity_magnitude = 0x7ff << 52
        max_finite_magnitude = ((0x7fe << 52) | fraction_mask) & low_63_mask
        signed_zero = result_sign << 63
        stage0 = signed_zero if underflow_trigger else candidate
        if out_inf_trigger:
            magnitude = max_finite_magnitude if inf_round_down_trigger else infinity_magnitude
            stage1 = (result_sign << 63) | magnitude
        else:
            stage1 = stage0
        stage2 = nan_result if nan_out_trigger else stage1

        self._p.update({
            'in_et_zero': int(candidate_zero),
            'opa_et_zero': int(a_zero),
            'opb_et_zero': int(b_zero),
            'input_et_zero': int(a_zero or b_zero),
            'add': int(is_add),
            'subtract': int(is_subtract),
            'multiply': int(is_multiply),
            'divide': int(is_divide),
            'opa_qnan': int(a_qnan),
            'opb_qnan': int(b_qnan),
            'opa_snan': int(a_snan),
            'opb_snan': int(b_snan),
            'opa_pos_inf': int(a_pos_inf),
            'opb_pos_inf': int(b_pos_inf),
            'opa_neg_inf': int(a_neg_inf),
            'opb_neg_inf': int(b_neg_inf),
            'opa_inf': int(a_inf),
            'opb_inf': int(b_inf),
            'nan_input': int(nan_input),
            'snan_input': int(snan_input),
            'a_nan': int(a_nan),
            'div_by_0': int(div_by_0),
            'div_0_by_0': int(div_0_by_0),
            'div_inf_by_inf': int(div_inf_by_inf),
            'div_by_inf': int(div_by_inf),
            'mul_0_by_inf': int(mul_0_by_inf),
            'mul_inf': int(mul_inf),
            'div_inf': int(div_inf),
            'add_inf': int(add_inf),
            'sub_inf': int(sub_inf),
            'addsub_inf_invalid': int(addsub_invalid),
            'addsub_inf': int(addsub_inf),
            'out_inf_trigger': int(out_inf_trigger),
            'out_pos_inf': int(out_inf_trigger and not result_sign),
            'out_neg_inf': int(out_inf_trigger and result_sign),
            'round_nearest': int(round_nearest),
            'round_to_zero': int(round_to_zero),
            'round_to_pos_inf': int(round_to_pos_inf),
            'round_to_neg_inf': int(round_to_neg_inf),
            'inf_round_down_trigger': int(inf_round_down_trigger),
            'mul_uf': int(mul_uf),
            'div_uf': int(div_uf),
            'underflow_trigger': int(underflow_trigger),
            'invalid_trigger': int(invalid_trigger),
            'overflow_trigger': int(overflow_trigger),
            'inexact_trigger': int(inexact_trigger),
            'except_trigger': int(except_trigger),
            'enable_trigger': int(enable_trigger),
            'nan_out_trigger': int(nan_out_trigger),
            'snan_trigger': int(snan_input),
            'nan_output_0': nan_magnitude,
            'nan_output': nan_magnitude,
            'inf_round_down': max_finite_magnitude if inf_round_down_trigger else 0,
            'out_inf': infinity_magnitude if out_inf_trigger else 0,
            'out_0': self.mask(stage0, 64),
            'out_1': self.mask(stage1, 64),
            'out_2': self.mask(stage2, 64)
        })

        self._out = self.mask(stage2, 64)
        self._ex_enable = int(enable_trigger)
        self._underflow = int(underflow_trigger)
        self._overflow = int(overflow_trigger)
        self._inexact = int(inexact_trigger)
        self._exception = int(except_trigger)
        self._invalid = int(invalid_trigger)
