"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        self._bit_probe_names = (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger'
        )
        for name in self._bit_probe_names:
            setattr(self, name, False)
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1
        self.nan_output_0 = 0
        self.nan_output = 0
        self.inf_round_down = 0
        self.out_inf = 0
        self.out_0 = 0
        self.out_1 = 0
        self.out_2 = 0
        self.out = 0
        self.ex_enable = 0
        self.underflow = 0
        self.overflow = 0
        self.inexact = 0
        self.exception = 0
        self.invalid = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self.mask(self.out, 64)
        o['ex_enable'] = int(bool(self.ex_enable))
        o['underflow'] = int(bool(self.underflow))
        o['overflow'] = int(bool(self.overflow))
        o['inexact'] = int(bool(self.inexact))
        o['exception'] = int(bool(self.exception))
        o['invalid'] = int(bool(self.invalid))
        for name in self._bit_probe_names:
            setattr(self, name, bool(getattr(self, name)))
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = self.mask(self.mantissa_max, 52)
        self.nan_output_0 = self.mask(self.nan_output_0, 63)
        self.nan_output = self.mask(self.nan_output, 63)
        self.inf_round_down = self.mask(self.inf_round_down, 63)
        self.out_inf = self.mask(self.out_inf, 63)
        self.out_0 = self.mask(self.out_0, 64)
        self.out_1 = self.mask(self.out_1, 64)
        self.out_2 = self.mask(self.out_2, 64)
        return o

    def _calculate(self, i):
        frac_mask = (1 << 52) - 1
        low63_mask = (1 << 63) - 1
        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        candidate = self.mask(i['in_except'], 64)
        exponent_in = self.mask(i['exponent_in'], 12)
        mantissa_in = self.mask(i['mantissa_in'], 2)
        fpu_op = self.mask(i['fpu_op'], 3)
        rmode = self.mask(i['rmode'], 2)

        opa_zero = (opa & low63_mask) == 0
        opb_zero = (opb & low63_mask) == 0
        candidate_zero = (candidate & low63_mask) == 0
        opa_exp = (opa >> 52) & 0x7ff
        opb_exp = (opb >> 52) & 0x7ff
        opa_frac = opa & frac_mask
        opb_frac = opb & frac_mask
        opa_nan = opa_exp == 0x7ff and opa_frac != 0
        opb_nan = opb_exp == 0x7ff and opb_frac != 0
        opa_qnan = opa_nan and bool(opa_frac & (1 << 51))
        opb_qnan = opb_nan and bool(opb_frac & (1 << 51))
        opa_snan = opa_nan and not bool(opa_frac & (1 << 51))
        opb_snan = opb_nan and not bool(opb_frac & (1 << 51))
        opa_inf = opa_exp == 0x7ff and opa_frac == 0
        opb_inf = opb_exp == 0x7ff and opb_frac == 0
        opa_sign = bool((opa >> 63) & 1)
        opb_sign = bool((opb >> 63) & 1)
        candidate_sign = bool((candidate >> 63) & 1)

        add = fpu_op == 0
        subtract = fpu_op == 1
        multiply = fpu_op == 2
        divide = fpu_op == 3
        nan_input = opa_nan or opb_nan
        snan_input = opa_snan or opb_snan
        div_0_by_0 = divide and opa_zero and opb_zero
        div_inf_by_inf = divide and opa_inf and opb_inf
        div_by_0 = (divide and opb_zero and not opa_zero and
                    not opa_inf and not opa_nan)
        div_by_inf = (divide and opb_inf and not opa_inf and not opa_nan)
        mul_0_by_inf = multiply and ((opa_zero and opb_inf) or
                                      (opb_zero and opa_inf))
        mul_inf = multiply and (opa_inf or opb_inf)
        div_inf = divide and opa_inf and not opb_inf

        addsub_inf_invalid = False
        if add:
            addsub_inf_invalid = ((opa_inf and opb_inf and
                                   (opa_sign != opb_sign)))
        elif subtract:
            addsub_inf_invalid = ((opa_inf and opb_inf and
                                   (opa_sign == opb_sign)))
        add_inf = add and (opa_inf or opb_inf)
        sub_inf = subtract and (opa_inf or opb_inf)
        addsub_inf = (add or subtract) and (opa_inf or opb_inf)

        invalid_trigger = (snan_input or addsub_inf_invalid or mul_0_by_inf or
                           div_0_by_0 or div_inf_by_inf)
        nan_out_trigger = nan_input or invalid_trigger
        valid_mul_inf = mul_inf and not mul_0_by_inf
        valid_div_inf = div_inf and not div_inf_by_inf
        valid_addsub_inf = addsub_inf and not addsub_inf_invalid
        out_inf_trigger = (valid_mul_inf or valid_div_inf or div_by_0 or
                           valid_addsub_inf or exponent_in > 2046)

        round_nearest = rmode == 0
        round_to_zero = rmode == 1
        round_to_pos_inf = rmode == 2
        round_to_neg_inf = rmode == 3
        inf_round_down_trigger = out_inf_trigger and (
            (not candidate_sign and (round_to_zero or round_to_neg_inf)) or
            (candidate_sign and (round_to_zero or round_to_pos_inf))
        )
        max_finite_mag = (2046 << 52) | frac_mask
        infinity_mag = 2047 << 52
        inf_round_down = max_finite_mag if inf_round_down_trigger else 0
        out_inf = infinity_mag if out_inf_trigger else 0
        out_pos_inf = out_inf_trigger and not candidate_sign
        out_neg_inf = out_inf_trigger and candidate_sign

        mul_uf = (multiply and not opa_zero and not opb_zero and
                  candidate_zero)
        div_uf = (divide and (div_by_inf or
                              (not opa_zero and not opb_zero and candidate_zero)))
        underflow_trigger = mul_uf or div_uf
        overflow_trigger = out_inf_trigger and not nan_input
        inexact_trigger = ((mantissa_in != 0 or out_inf_trigger or
                            underflow_trigger) and not nan_input)
        except_trigger = (invalid_trigger or overflow_trigger or
                          underflow_trigger or inexact_trigger)
        enable_trigger = nan_out_trigger or except_trigger

        if nan_input:
            nan_source = opa if opa_nan else opb
            nan_frac = nan_source & frac_mask
        else:
            nan_frac = opa & frac_mask
        nan_frac |= 1 << 51
        nan_magnitude = (2047 << 52) | nan_frac

        if underflow_trigger:
            out_0 = (int(candidate_sign) << 63)
        else:
            out_0 = candidate
        if out_inf_trigger:
            selected_inf_mag = (max_finite_mag if inf_round_down_trigger
                                else infinity_mag)
            out_1 = (int(candidate_sign) << 63) | selected_inf_mag
        else:
            out_1 = out_0
        if nan_out_trigger:
            out_2 = (int(candidate_sign) << 63) | nan_magnitude
        else:
            out_2 = out_1

        invalid = int(bool(invalid_trigger))
        overflow = int(bool(overflow_trigger))
        underflow = int(bool(underflow_trigger))
        inexact = int(bool(inexact_trigger))
        exception = int(bool(except_trigger))
        ex_enable = int(bool(enable_trigger))

        p = {
            'in_et_zero': candidate_zero,
            'opa_et_zero': opa_zero,
            'opb_et_zero': opb_zero,
            'input_et_zero': opa_zero or opb_zero,
            'add': add, 'subtract': subtract, 'multiply': multiply,
            'divide': divide,
            'opa_qnan': opa_qnan, 'opb_qnan': opb_qnan,
            'opa_snan': opa_snan, 'opb_snan': opb_snan,
            'opa_pos_inf': opa_inf and not opa_sign,
            'opb_pos_inf': opb_inf and not opb_sign,
            'opa_neg_inf': opa_inf and opa_sign,
            'opb_neg_inf': opb_inf and opb_sign,
            'opa_inf': opa_inf, 'opb_inf': opb_inf,
            'nan_input': nan_input, 'snan_input': snan_input,
            'a_nan': opa_nan,
            'div_by_0': div_by_0, 'div_0_by_0': div_0_by_0,
            'div_inf_by_inf': div_inf_by_inf, 'div_by_inf': div_by_inf,
            'mul_0_by_inf': mul_0_by_inf, 'mul_inf': mul_inf,
            'div_inf': div_inf, 'add_inf': add_inf, 'sub_inf': sub_inf,
            'addsub_inf_invalid': addsub_inf_invalid,
            'addsub_inf': addsub_inf,
            'out_inf_trigger': out_inf_trigger,
            'out_pos_inf': out_pos_inf, 'out_neg_inf': out_neg_inf,
            'round_nearest': round_nearest,
            'round_to_zero': round_to_zero,
            'round_to_pos_inf': round_to_pos_inf,
            'round_to_neg_inf': round_to_neg_inf,
            'inf_round_down_trigger': inf_round_down_trigger,
            'mul_uf': mul_uf, 'div_uf': div_uf,
            'underflow_trigger': underflow_trigger,
            'invalid_trigger': invalid_trigger,
            'overflow_trigger': overflow_trigger,
            'inexact_trigger': inexact_trigger,
            'except_trigger': except_trigger,
            'enable_trigger': enable_trigger,
            'nan_out_trigger': nan_out_trigger,
            'snan_trigger': snan_input,
            'exp_2047': 2047, 'exp_2046': 2046,
            'nan_output_0': nan_magnitude,
            'nan_output': nan_magnitude,
            'mantissa_max': frac_mask,
            'inf_round_down': inf_round_down,
            'out_inf': out_inf,
            'out_0': out_0, 'out_1': out_1, 'out_2': out_2,
            'out': out_2,
            'ex_enable': ex_enable, 'underflow': underflow,
            'overflow': overflow, 'inexact': inexact,
            'exception': exception, 'invalid': invalid
        }
        return p

    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not i['enable']:
            return
        p = self._calculate(i)
        for name in self._bit_probe_names:
            setattr(self, name, bool(p[name]))
        self.exp_2047 = self.mask(p['exp_2047'], 11)
        self.exp_2046 = self.mask(p['exp_2046'], 11)
        self.nan_output_0 = self.mask(p['nan_output_0'], 63)
        self.nan_output = self.mask(p['nan_output'], 63)
        self.mantissa_max = self.mask(p['mantissa_max'], 52)
        self.inf_round_down = self.mask(p['inf_round_down'], 63)
        self.out_inf = self.mask(p['out_inf'], 63)
        self.out_0 = self.mask(p['out_0'], 64)
        self.out_1 = self.mask(p['out_1'], 64)
        self.out_2 = self.mask(p['out_2'], 64)
        self.out = self.mask(p['out'], 64)
        self.ex_enable = p['ex_enable']
        self.underflow = p['underflow']
        self.overflow = p['overflow']
        self.inexact = p['inexact']
        self.exception = p['exception']
        self.invalid = p['invalid']
