"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['out', 'ex_enable', 'underflow', 'overflow', 'inexact', 'exception', 'invalid']
    PROBE_PORTS = ['in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero', 'add', 'subtract', 'multiply', 'divide', 'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan', 'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf', 'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan', 'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf', 'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf', 'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger', 'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero', 'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger', 'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger', 'overflow_trigger', 'inexact_trigger', 'except_trigger', 'enable_trigger', 'nan_out_trigger', 'snan_trigger', 'exp_2047', 'exp_2046', 'nan_output_0', 'nan_output', 'mantissa_max', 'inf_round_down', 'out_inf', 'out_0', 'out_1', 'out_2']
    PROBE_WIDTHS = {'in_et_zero': 1, 'opa_et_zero': 1, 'opb_et_zero': 1, 'input_et_zero': 1, 'add': 1, 'subtract': 1, 'multiply': 1, 'divide': 1, 'opa_qnan': 1, 'opb_qnan': 1, 'opa_snan': 1, 'opb_snan': 1, 'opa_pos_inf': 1, 'opb_pos_inf': 1, 'opa_neg_inf': 1, 'opb_neg_inf': 1, 'opa_inf': 1, 'opb_inf': 1, 'nan_input': 1, 'snan_input': 1, 'a_nan': 1, 'div_by_0': 1, 'div_0_by_0': 1, 'div_inf_by_inf': 1, 'div_by_inf': 1, 'mul_0_by_inf': 1, 'mul_inf': 1, 'div_inf': 1, 'add_inf': 1, 'sub_inf': 1, 'addsub_inf_invalid': 1, 'addsub_inf': 1, 'out_inf_trigger': 1, 'out_pos_inf': 1, 'out_neg_inf': 1, 'round_nearest': 1, 'round_to_zero': 1, 'round_to_pos_inf': 1, 'round_to_neg_inf': 1, 'inf_round_down_trigger': 1, 'mul_uf': 1, 'div_uf': 1, 'underflow_trigger': 1, 'invalid_trigger': 1, 'overflow_trigger': 1, 'inexact_trigger': 1, 'except_trigger': 1, 'enable_trigger': 1, 'nan_out_trigger': 1, 'snan_trigger': 1, 'exp_2047': 11, 'exp_2046': 11, 'nan_output_0': 63, 'nan_output': 63, 'mantissa_max': 52, 'inf_round_down': 63, 'out_inf': 63, 'out_0': 64, 'out_1': 64, 'out_2': 64}
    LATENCY_CYCLES = 0

    def reset(self):
        names = (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger',
            'nan_output_0', 'nan_output', 'inf_round_down', 'out_inf',
            'out_0', 'out_1', 'out_2'
        )
        for name in names:
            setattr(self, name, 0)
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.mantissa_max = (1 << 52) - 1
        self.out = 0
        self.ex_enable = 0
        self.underflow = 0
        self.overflow = 0
        self.inexact = 0
        self.exception = 0
        self.invalid = 0
        self._nan_delay = 0
        self._flags0 = {'underflow': 0, 'overflow': 0, 'inexact': 0, 'exception': 0, 'invalid': 0}
        self._flags1 = {'underflow': 0, 'overflow': 0, 'inexact': 0, 'exception': 0, 'invalid': 0}
        self._flags2 = {'underflow': 0, 'overflow': 0, 'inexact': 0, 'exception': 0, 'invalid': 0}
        self._enable0 = 0
        self._enable1 = 0
        self._enable2 = 0

    def _calculate(self, i):
        opa = self.mask(i['opa'], 64)
        opb = self.mask(i['opb'], 64)
        candidate = self.mask(i['in_except'], 64)
        exponent_in = self.mask(i['exponent_in'], 12)
        mantissa_in = self.mask(i['mantissa_in'], 2)
        fpu_op = self.mask(i['fpu_op'], 3)
        rmode = self.mask(i['rmode'], 2)
        fraction_mask = (1 << 52) - 1
        lower_mask = (1 << 63) - 1
        sign = (candidate >> 63) & 1

        opa_exp = (opa >> 52) & 2047
        opb_exp = (opb >> 52) & 2047
        opa_frac = opa & fraction_mask
        opb_frac = opb & fraction_mask
        opa_zero = (opa & lower_mask) == 0
        opb_zero = (opb & lower_mask) == 0
        opa_nan = opa_exp == 2047 and opa_frac != 0
        opb_nan = opb_exp == 2047 and opb_frac != 0
        opa_qnan = opa_nan and ((opa_frac >> 51) & 1) != 0
        opb_qnan = opb_nan and ((opb_frac >> 51) & 1) != 0
        opa_snan = opa_nan and not opa_qnan
        opb_snan = opb_nan and not opb_qnan
        opa_inf = opa_exp == 2047 and opa_frac == 0
        opb_inf = opb_exp == 2047 and opb_frac == 0
        opa_pos_inf = opa_inf and ((opa >> 63) & 1) == 0
        opb_pos_inf = opb_inf and ((opb >> 63) & 1) == 0
        opa_neg_inf = opa_inf and ((opa >> 63) & 1) == 1
        opb_neg_inf = opb_inf and ((opb >> 63) & 1) == 1
        nan_input = opa_nan or opb_nan
        snan_input = opa_snan or opb_snan

        add = fpu_op == 0
        subtract = fpu_op == 1
        multiply = fpu_op == 2
        divide = fpu_op == 3

        addsub_invalid = (add and ((opa_pos_inf and opb_neg_inf) or (opa_neg_inf and opb_pos_inf))) or (subtract and ((opa_pos_inf and opb_pos_inf) or (opa_neg_inf and opb_neg_inf)))
        mul_0_by_inf = multiply and ((opa_zero and opb_inf) or (opb_zero and opa_inf))
        div_0_by_0 = divide and opa_zero and opb_zero
        div_inf_by_inf = divide and opa_inf and opb_inf
        div_by_inf = divide and opb_inf
        div_by_0 = divide and opb_zero and not opa_zero and not opa_inf and not nan_input

        add_inf = add and (opa_inf or opb_inf) and not addsub_invalid
        sub_inf = subtract and (opa_inf or opb_inf) and not addsub_invalid
        addsub_inf = add_inf or sub_inf
        mul_inf = multiply and (opa_inf or opb_inf) and not mul_0_by_inf
        div_inf = divide and opa_inf and not opb_inf
        invalid_trigger = snan_input or addsub_invalid or mul_0_by_inf or div_0_by_0 or div_inf_by_inf
        nan_out_trigger = nan_input or addsub_invalid or mul_0_by_inf or div_0_by_0 or div_inf_by_inf

        out_inf_trigger = addsub_inf or mul_inf or div_inf or div_by_0 or exponent_in > 2046
        out_pos_inf = out_inf_trigger and sign == 0
        out_neg_inf = out_inf_trigger and sign == 1
        round_down = out_inf_trigger and ((sign == 0 and rmode in (1, 3)) or (sign == 1 and rmode in (1, 2)))

        candidate_zero = (candidate & lower_mask) == 0
        mul_uf = multiply and not nan_input and not opa_zero and not opb_zero and not opa_inf and not opb_inf and candidate_zero
        div_uf = divide and not nan_input and ((opb_inf and not opa_inf) or (not opa_zero and not opb_zero and not opa_inf and not opb_inf and candidate_zero))
        underflow_trigger = mul_uf or div_uf
        overflow_trigger = out_inf_trigger and not nan_input
        inexact_trigger = (mantissa_in != 0 or out_inf_trigger or underflow_trigger) and not nan_input
        except_trigger = invalid_trigger or overflow_trigger or underflow_trigger or inexact_trigger
        enable_trigger = nan_out_trigger or except_trigger

        if nan_input:
            selected_fraction = opa_frac if opa_nan else opb_frac
            nan_fraction = selected_fraction | (1 << 51)
        else:
            nan_fraction = opa_frac | (1 << 51)
        nan_lower = ((2047 << 52) | nan_fraction) & lower_mask

        infinity_magnitude = 2047 << 52
        max_finite_magnitude = (2046 << 52) | fraction_mask
        inf_round_down = max_finite_magnitude if round_down else 0
        out_inf = infinity_magnitude if out_inf_trigger else 0
        base_result = ((sign << 63) if underflow_trigger else candidate)

        probes = {
            'in_et_zero': int(candidate_zero),
            'opa_et_zero': int(opa_zero),
            'opb_et_zero': int(opb_zero),
            'input_et_zero': int(opa_zero or opb_zero),
            'add': int(add), 'subtract': int(subtract), 'multiply': int(multiply), 'divide': int(divide),
            'opa_qnan': int(opa_qnan), 'opb_qnan': int(opb_qnan),
            'opa_snan': int(opa_snan), 'opb_snan': int(opb_snan),
            'opa_pos_inf': int(opa_pos_inf), 'opb_pos_inf': int(opb_pos_inf),
            'opa_neg_inf': int(opa_neg_inf), 'opb_neg_inf': int(opb_neg_inf),
            'opa_inf': int(opa_inf), 'opb_inf': int(opb_inf),
            'nan_input': int(nan_input), 'snan_input': int(snan_input), 'a_nan': int(opa_nan),
            'div_by_0': int(div_by_0), 'div_0_by_0': int(div_0_by_0),
            'div_inf_by_inf': int(div_inf_by_inf), 'div_by_inf': int(div_by_inf),
            'mul_0_by_inf': int(mul_0_by_inf), 'mul_inf': int(mul_inf), 'div_inf': int(div_inf),
            'add_inf': int(add_inf), 'sub_inf': int(sub_inf),
            'addsub_inf_invalid': int(addsub_invalid), 'addsub_inf': int(addsub_inf),
            'out_inf_trigger': int(out_inf_trigger), 'out_pos_inf': int(out_pos_inf), 'out_neg_inf': int(out_neg_inf),
            'round_nearest': int(rmode == 0), 'round_to_zero': int(rmode == 1),
            'round_to_pos_inf': int(rmode == 2), 'round_to_neg_inf': int(rmode == 3),
            'inf_round_down_trigger': int(round_down), 'mul_uf': int(mul_uf), 'div_uf': int(div_uf),
            'underflow_trigger': int(underflow_trigger), 'invalid_trigger': int(invalid_trigger),
            'overflow_trigger': int(overflow_trigger), 'inexact_trigger': int(inexact_trigger),
            'except_trigger': int(except_trigger), 'enable_trigger': int(enable_trigger),
            'nan_out_trigger': int(nan_out_trigger), 'snan_trigger': int(snan_input),
            'nan_output_0': nan_lower, 'out_inf': out_inf, 'inf_round_down': inf_round_down
        }
        flags = {
            'underflow': int(underflow_trigger),
            'overflow': int(overflow_trigger),
            'inexact': int(inexact_trigger),
            'exception': int(except_trigger),
            'invalid': int(invalid_trigger)
        }
        return {
            'probes': probes,
            'flags': flags,
            'enable': int(enable_trigger),
            'base_result': self.mask(base_result, 64)
        }

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        o['out'] = self.mask(self.out, 64)
        o['ex_enable'] = int(bool(self.ex_enable))
        o['underflow'] = int(bool(self.underflow))
        o['overflow'] = int(bool(self.overflow))
        o['inexact'] = int(bool(self.inexact))
        o['exception'] = int(bool(self.exception))
        o['invalid'] = int(bool(self.invalid))

        boolean_probes = (
            'in_et_zero', 'opa_et_zero', 'opb_et_zero', 'input_et_zero',
            'add', 'subtract', 'multiply', 'divide',
            'opa_qnan', 'opb_qnan', 'opa_snan', 'opb_snan',
            'opa_pos_inf', 'opb_pos_inf', 'opa_neg_inf', 'opb_neg_inf',
            'opa_inf', 'opb_inf', 'nan_input', 'snan_input', 'a_nan',
            'div_by_0', 'div_0_by_0', 'div_inf_by_inf', 'div_by_inf',
            'mul_0_by_inf', 'mul_inf', 'div_inf', 'add_inf', 'sub_inf',
            'addsub_inf_invalid', 'addsub_inf', 'out_inf_trigger',
            'out_pos_inf', 'out_neg_inf', 'round_nearest', 'round_to_zero',
            'round_to_pos_inf', 'round_to_neg_inf', 'inf_round_down_trigger',
            'mul_uf', 'div_uf', 'underflow_trigger', 'invalid_trigger',
            'overflow_trigger', 'inexact_trigger', 'except_trigger',
            'enable_trigger', 'nan_out_trigger', 'snan_trigger'
        )
        for name in boolean_probes:
            setattr(self, name, bool(getattr(self, name)))
        self.exp_2047 = 2047
        self.exp_2046 = 2046
        self.nan_output_0 = self.mask(self.nan_output_0, 63)
        self.nan_output = self.mask(self.nan_output, 63)
        self.mantissa_max = (1 << 52) - 1
        self.inf_round_down = self.mask(self.inf_round_down, 63)
        self.out_inf = self.mask(self.out_inf, 63)
        self.out_0 = self.mask(self.out_0, 64)
        self.out_1 = self.mask(self.out_1, 64)
        self.out_2 = self.mask(self.out_2, 64)
        return o

    def advance(self, i):
        if i['rst']:
            self.reset()
            return
        if not i['enable']:
            return

        result = self._calculate(i)

        old_out_0 = self.out_0
        old_out_1 = self.out_1
        old_out_2 = self.out_2
        old_out_inf_trigger = self.out_inf_trigger
        old_round_down_trigger = self.inf_round_down_trigger
        old_out_inf = self.out_inf
        old_inf_round_down = self.inf_round_down
        old_nan_delay = self._nan_delay
        old_nan_output = self.nan_output
        old_nan_out_trigger = self.nan_out_trigger
        old_flags0 = self._flags0
        old_flags1 = self._flags1
        old_flags2 = self._flags2
        old_enable0 = self._enable0
        old_enable1 = self._enable1
        old_enable2 = self._enable2

        self.out = self.mask(old_out_2, 64)
        self.underflow = old_flags2['underflow']
        self.overflow = old_flags2['overflow']
        self.inexact = old_flags2['inexact']
        self.exception = old_flags2['exception']
        self.invalid = old_flags2['invalid']
        self.ex_enable = old_enable2

        next_out_1 = old_out_0
        if old_out_inf_trigger:
            magnitude = old_inf_round_down if old_round_down_trigger else old_out_inf
            next_out_1 = ((old_out_0 >> 63) << 63) | magnitude
        next_out_2 = old_out_1
        if old_nan_delay:
            next_out_2 = ((old_out_1 >> 63) << 63) | old_nan_output

        self.out_0 = result['base_result']
        self.out_1 = self.mask(next_out_1, 64)
        self.out_2 = self.mask(next_out_2, 64)
        self.nan_output = self.nan_output_0
        self._nan_delay = old_nan_out_trigger
        self._flags2 = old_flags1
        self._flags1 = old_flags0
        self._flags0 = result['flags']
        self._enable2 = old_enable1
        self._enable1 = old_enable0
        self._enable0 = result['enable']

        for name, value in result['probes'].items():
            setattr(self, name, value)
