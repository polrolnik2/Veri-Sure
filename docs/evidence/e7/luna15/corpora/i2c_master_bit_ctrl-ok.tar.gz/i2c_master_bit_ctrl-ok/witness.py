"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['clk_en', 'cnt_zero', 'slave_wait', 'scl_sync', 'cscl', 'csda', 'filter_cnt_expired', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'sta_condition', 'sto_condition', 'sscl_rise', 'sda_chk', 'in_idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence']
    PROBE_WIDTHS = {'clk_en': 1, 'cnt_zero': 1, 'slave_wait': 1, 'scl_sync': 1, 'cscl': 1, 'csda': 1, 'filter_cnt_expired': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'sta_condition': 1, 'sto_condition': 1, 'sscl_rise': 1, 'sda_chk': 1, 'in_idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self._reset_state()

    def _reset_state(self):
        self.state = 'idle'
        self.current_cmd = 0
        self.cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0
        self.scl_oen = 1
        self.sda_oen = 1
        self.sda_chk = 0
        self.cnt = 0
        self.filter_cnt = 0
        self.cSCL1 = 0
        self.cSCL2 = 0
        self.cSDA1 = 0
        self.cSDA2 = 0
        self.fscl = 7
        self.fsda = 7
        self.dscl = 1
        self.dsda = 1

    def _majority(self, history):
        return int(((history >> 0) & 1) + ((history >> 1) & 1) + ((history >> 2) & 1) >= 2)

    def _signals(self, i):
        sscl = self._majority(self.fscl)
        ssda = self._majority(self.fsda)
        slave_wait = bool(self.scl_oen and not sscl)
        scl_sync = bool(self.scl_oen and self.dscl and not sscl)
        sta_condition = bool(not ssda and self.dsda and sscl)
        sto_condition = bool(ssda and not self.dsda and sscl)
        sscl_rise = bool(not self.dscl and sscl)
        ena = bool(i['ena'] & 1)
        clk_en = bool(not slave_wait and (self.cnt == 0 or not ena or scl_sync))
        return {
            'sscl': sscl,
            'ssda': ssda,
            'slave_wait': slave_wait,
            'scl_sync': scl_sync,
            'sta_condition': sta_condition,
            'sto_condition': sto_condition,
            'sscl_rise': sscl_rise,
            'clk_en': clk_en,
            'cnt_zero': self.cnt == 0,
            'filter_cnt_expired': self.filter_cnt == 0
        }

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        async_reset = (i['nReset'] & 1) == 0
        if async_reset:
            state = 'idle'
            cmd_ack = 0
            busy = 0
            al = 0
            dout = 0
            scl_oen = 1
            sda_oen = 1
            sda_chk = False
            cnt_zero = True
            clk_en = True
            slave_wait = False
            scl_sync = False
            cscl = False
            csda = False
            fscl = 7
            fsda = 7
            sscl = True
            ssda = True
            dscl = True
            dsda = True
            filter_cnt_expired = True
            sta_condition = False
            sto_condition = False
            sscl_rise = False
        else:
            state = self.state
            cmd_ack = self.cmd_ack
            busy = self.busy
            al = self.al
            dout = self.dout
            scl_oen = self.scl_oen
            sda_oen = self.sda_oen
            sda_chk = bool(self.sda_chk)
            sig = self._signals(i)
            cnt_zero = bool(sig['cnt_zero'])
            clk_en = bool(sig['clk_en'])
            slave_wait = bool(sig['slave_wait'])
            scl_sync = bool(sig['scl_sync'])
            cscl = bool(self.cSCL2)
            csda = bool(self.cSDA2)
            fscl = self.fscl & 7
            fsda = self.fsda & 7
            sscl = bool(sig['sscl'])
            ssda = bool(sig['ssda'])
            dscl = bool(self.dscl)
            dsda = bool(self.dsda)
            filter_cnt_expired = bool(sig['filter_cnt_expired'])
            sta_condition = bool(sig['sta_condition'])
            sto_condition = bool(sig['sto_condition'])
            sscl_rise = bool(sig['sscl_rise'])
        o['cmd_ack'] = int(cmd_ack)
        o['busy'] = int(busy)
        o['al'] = int(al)
        o['dout'] = int(dout)
        o['scl_o'] = 0
        o['scl_oen'] = int(scl_oen)
        o['sda_o'] = 0
        o['sda_oen'] = int(sda_oen)
        self.clk_en = bool(clk_en)
        self.cnt_zero = bool(cnt_zero)
        self.slave_wait = bool(slave_wait)
        self.scl_sync = bool(scl_sync)
        self.cscl = bool(cscl)
        self.csda = bool(csda)
        self.filter_cnt_expired = bool(filter_cnt_expired)
        self.fscl = int(fscl)
        self.fsda = int(fsda)
        self.sscl = bool(sscl)
        self.ssda = bool(ssda)
        self.dscl = bool(dscl)
        self.dsda = bool(dsda)
        self.sta_condition = bool(sta_condition)
        self.sto_condition = bool(sto_condition)
        self.sscl_rise = bool(sscl_rise)
        self.sda_chk = bool(sda_chk)
        self.in_idle = state == 'idle'
        self.fsm_active = state != 'idle'
        self.in_start_sequence = state.startswith('start_')
        self.in_stop_sequence = state.startswith('stop_')
        self.in_read_sequence = state.startswith('read_')
        self.in_write_sequence = state.startswith('write_')
        return o

    def _fsm_step(self, i, sig, arbitration_lost):
        self.cmd_ack = 0
        if arbitration_lost:
            self.al = 1
            self.state = 'idle'
            self.current_cmd = 0
            self.scl_oen = 1
            self.sda_oen = 1
            self.sda_chk = 0
            return
        if not (sig['clk_en'] and (i['ena'] & 1)):
            return
        if self.state == 'idle':
            cmd = i['cmd'] & 15
            if cmd == 1:
                self.current_cmd = 1
                self.state = 'start_release'
                self.scl_oen = 1
                self.sda_oen = 1
                self.sda_chk = 0
            elif cmd == 2:
                self.current_cmd = 2
                self.state = 'stop_drive_sda'
                self.sda_oen = 0
                self.sda_chk = 0
            elif cmd == 8:
                self.current_cmd = 8
                self.state = 'read_release_sda'
                self.sda_oen = 1
                self.sda_chk = 0
            elif cmd == 4:
                self.current_cmd = 4
                self.state = 'write_set_data'
                self.sda_oen = i['din'] & 1
                self.sda_chk = 0
            return
        if self.state == 'start_release':
            self.state = 'start_sda_low'
            self.sda_oen = 0
        elif self.state == 'start_sda_low':
            self.state = 'start_scl_low'
            self.scl_oen = 0
        elif self.state == 'start_scl_low':
            self.state = 'idle'
            self.current_cmd = 0
            self.cmd_ack = 1
        elif self.state == 'stop_drive_sda':
            self.state = 'stop_release_scl'
            self.scl_oen = 1
        elif self.state == 'stop_release_scl':
            self.state = 'stop_release_sda'
            self.sda_oen = 1
        elif self.state == 'stop_release_sda':
            self.state = 'idle'
            self.current_cmd = 0
            self.cmd_ack = 1
        elif self.state == 'read_release_sda':
            self.state = 'read_release_scl'
            self.scl_oen = 1
        elif self.state == 'read_release_scl':
            self.state = 'read_pull_scl_low'
            self.scl_oen = 0
        elif self.state == 'read_pull_scl_low':
            self.state = 'idle'
            self.current_cmd = 0
            self.cmd_ack = 1
        elif self.state == 'write_set_data':
            self.state = 'write_release_scl'
            self.scl_oen = 1
        elif self.state == 'write_release_scl':
            self.state = 'write_check'
            self.sda_chk = 1
        elif self.state == 'write_check':
            self.state = 'write_pull_scl_low'
            self.scl_oen = 0
            self.sda_chk = 0
        elif self.state == 'write_pull_scl_low':
            self.state = 'idle'
            self.current_cmd = 0
            self.cmd_ack = 1

    def advance(self, i):
        if (i['nReset'] & 1) == 0 or (i['rst'] & 1) != 0:
            self._reset_state()
            return
        sig = self._signals(i)
        old_cSCL1 = self.cSCL1
        old_cSCL2 = self.cSCL2
        old_cSDA1 = self.cSDA1
        old_cSDA2 = self.cSDA2
        self.cSCL1 = i['scl_i'] & 1
        self.cSCL2 = old_cSCL1
        self.cSDA1 = i['sda_i'] & 1
        self.cSDA2 = old_cSDA1
        if sig['sscl_rise']:
            self.dout = sig['ssda']
        if sig['sta_condition']:
            self.busy = 1
        elif sig['sto_condition']:
            self.busy = 0
        arbitration_lost = bool((self.sda_chk and self.sda_oen and not sig['ssda']) or (sig['sto_condition'] and self.state != 'idle' and self.current_cmd != 2))
        self.dscl = sig['sscl']
        self.dsda = sig['ssda']
        clk_cnt = i['clk_cnt'] & 65535
        ena = i['ena'] & 1
        if not ena:
            self.cnt = clk_cnt
        elif sig['scl_sync']:
            self.cnt = clk_cnt
        elif sig['slave_wait']:
            pass
        elif self.cnt == 0:
            self.cnt = clk_cnt
        else:
            self.cnt = (self.cnt - 1) & 65535
        if not ena:
            self.filter_cnt = 0
        elif self.filter_cnt == 0:
            sample_scl = old_cSCL2 & 1
            sample_sda = old_cSDA2 & 1
            self.fscl = ((self.fscl << 1) | sample_scl) & 7
            self.fsda = ((self.fsda << 1) | sample_sda) & 7
            self.filter_cnt = (clk_cnt >> 2) & 16383
        else:
            self.filter_cnt = (self.filter_cnt - 1) & 16383
        self._fsm_step(i, sig, arbitration_lost)
