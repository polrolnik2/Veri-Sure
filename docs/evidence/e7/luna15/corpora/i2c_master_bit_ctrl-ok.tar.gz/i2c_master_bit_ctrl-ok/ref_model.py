"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['clk_en', 'cnt_zero', 'slave_wait', 'scl_sync', 'cscl', 'csda', 'filter_cnt_expired', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'sta_condition', 'sto_condition', 'sscl_rise', 'sda_chk', 'in_idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence']
    PROBE_WIDTHS = {'clk_en': 1, 'cnt_zero': 1, 'slave_wait': 1, 'scl_sync': 1, 'cscl': 1, 'csda': 1, 'filter_cnt_expired': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'sta_condition': 1, 'sto_condition': 1, 'sscl_rise': 1, 'sda_chk': 1, 'in_idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = "idle"
        self.active_cmd = 0
        self.scl_oen_q = 1
        self.sda_oen_q = 1
        self.cmd_ack_q = 0
        self.busy_q = 0
        self.al_q = 0
        self.dout_q = 0
        self.cnt = 0
        self.div_clk_en = 1
        self.filter_cnt = 0
        self.metaSCL = 1
        self.metaSDA = 1
        self.cSCL = 1
        self.cSDA = 1
        self.fSCL = 7
        self.fSDA = 7
        self.dSCL = 1
        self.dSDA = 1

    def _signals(self):
        scl_sum = (self.fSCL & 1) + ((self.fSCL >> 1) & 1) + ((self.fSCL >> 2) & 1)
        sda_sum = (self.fSDA & 1) + ((self.fSDA >> 1) & 1) + ((self.fSDA >> 2) & 1)
        sscl = int(scl_sum >= 2)
        ssda = int(sda_sum >= 2)
        return {
            "sscl": sscl,
            "ssda": ssda,
            "sta_condition": int((not ssda) and self.dSDA and sscl),
            "sto_condition": int(ssda and (not self.dSDA) and sscl),
            "sscl_rise": int(sscl and (not self.dSCL)),
            "slave_wait": int(self.scl_oen_q and (not sscl)),
            "scl_sync": int(self.scl_oen_q and self.dSCL and (not sscl)),
        }

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        sig = self._signals()
        if not i["nReset"]:
            st = "idle"
            cmd_ack = 0
            busy = 0
            al = 0
            dout = 0
            scl_oen = 1
            sda_oen = 1
            cnt = 0
            clk_en = 1
            filter_cnt = 0
            cscl = 1
            csda = 1
            fscl = 7
            fsda = 7
            sig = {
                "sscl": 1,
                "ssda": 1,
                "sta_condition": 0,
                "sto_condition": 0,
                "sscl_rise": 0,
                "slave_wait": 0,
                "scl_sync": 0,
            }
            dscl = 1
            dsda = 1
        else:
            st = self.state
            cmd_ack = self.cmd_ack_q
            busy = self.busy_q
            al = self.al_q
            dout = self.dout_q
            scl_oen = self.scl_oen_q
            sda_oen = self.sda_oen_q
            cnt = self.cnt
            clk_en = self.div_clk_en
            filter_cnt = self.filter_cnt
            cscl = self.cSCL
            csda = self.cSDA
            fscl = self.fSCL
            fsda = self.fSDA
            dscl = self.dSCL
            dsda = self.dSDA

        o["cmd_ack"] = int(cmd_ack)
        o["busy"] = int(busy)
        o["al"] = int(al)
        o["dout"] = int(dout)
        o["scl_o"] = 0
        o["scl_oen"] = int(scl_oen)
        o["sda_o"] = 0
        o["sda_oen"] = int(sda_oen)

        self.clk_en = bool(clk_en)
        self.cnt_zero = bool(cnt == 0)
        self.slave_wait = bool(sig["slave_wait"])
        self.scl_sync = bool(sig["scl_sync"])
        self.cscl = bool(cscl)
        self.csda = bool(csda)
        self.filter_cnt_expired = bool(filter_cnt == 0)
        self.fscl = int(fscl)
        self.fsda = int(fsda)
        self.sscl = bool(sig["sscl"])
        self.ssda = bool(sig["ssda"])
        self.dscl = bool(dscl)
        self.dsda = bool(dsda)
        self.sta_condition = bool(sig["sta_condition"])
        self.sto_condition = bool(sig["sto_condition"])
        self.sscl_rise = bool(sig["sscl_rise"])
        self.sda_chk = bool(st == "write_check")
        self.in_idle = bool(st == "idle")
        self.fsm_active = bool(st != "idle")
        self.in_start_sequence = bool(st in ("start_release", "start_sda_low", "start_scl_low"))
        self.in_stop_sequence = bool(st in ("stop_sda_low", "stop_scl_high", "stop_sda_high"))
        self.in_read_sequence = bool(st in ("read_data_release", "read_scl_high", "read_scl_low"))
        self.in_write_sequence = bool(st in ("write_data", "write_scl_high", "write_check"))
        return o

    def advance(self, i):
        if (not i["nReset"]) or i["rst"]:
            self.reset()
            return

        sig = self._signals()
        old_cscl = self.cSCL
        old_csda = self.cSDA
        old_cnt = self.cnt
        timing_tick = bool(self.div_clk_en)
        ena = int(i["ena"])
        clk_cnt = self.mask(i["clk_cnt"], 16)

        arbitration_loss = bool(
            (self.state == "write_check" and self.sda_oen_q and not sig["ssda"])
            or (
                sig["sto_condition"]
                and self.state != "idle"
                and self.active_cmd != 2
            )
        )

        if sig["sta_condition"]:
            self.busy_q = 1
        elif sig["sto_condition"]:
            self.busy_q = 0

        if sig["sscl_rise"]:
            self.dout_q = int(sig["ssda"])

        self.dSCL = int(sig["sscl"])
        self.dSDA = int(sig["ssda"])

        if not ena:
            self.filter_cnt = 0
        elif self.filter_cnt == 0:
            self.fSCL = self.mask((self.fSCL << 1) | old_cscl, 3)
            self.fSDA = self.mask((self.fSDA << 1) | old_csda, 3)
            self.filter_cnt = self.mask(clk_cnt >> 2, 14)
        else:
            self.filter_cnt = self.mask(self.filter_cnt - 1, 14)

        self.cSCL = self.metaSCL
        self.cSDA = self.metaSDA
        self.metaSCL = self.mask(i["scl_i"], 1)
        self.metaSDA = self.mask(i["sda_i"], 1)

        self.cmd_ack_q = 0
        self.al_q = int(arbitration_loss)
        if arbitration_loss:
            self.state = "idle"
            self.active_cmd = 0
            self.scl_oen_q = 1
            self.sda_oen_q = 1
        elif timing_tick and ena and not sig["slave_wait"]:
            if self.state == "idle":
                cmd = self.mask(i["cmd"], 4)
                if cmd == 1:
                    self.state = "start_release"
                    self.active_cmd = 1
                elif cmd == 2:
                    self.state = "stop_sda_low"
                    self.active_cmd = 2
                elif cmd == 4:
                    self.state = "write_data"
                    self.active_cmd = 4
                elif cmd == 8:
                    self.state = "read_data_release"
                    self.active_cmd = 8
                else:
                    self.active_cmd = 0
            elif self.state == "start_release":
                self.scl_oen_q = 1
                self.sda_oen_q = 1
                self.state = "start_sda_low"
            elif self.state == "start_sda_low":
                self.scl_oen_q = 1
                self.sda_oen_q = 0
                self.state = "start_scl_low"
            elif self.state == "start_scl_low":
                self.scl_oen_q = 0
                self.state = "idle"
                self.active_cmd = 0
                self.cmd_ack_q = 1
            elif self.state == "stop_sda_low":
                self.scl_oen_q = 0
                self.sda_oen_q = 0
                self.state = "stop_scl_high"
            elif self.state == "stop_scl_high":
                self.scl_oen_q = 1
                self.state = "stop_sda_high"
            elif self.state == "stop_sda_high":
                self.sda_oen_q = 1
                self.state = "idle"
                self.active_cmd = 0
                self.cmd_ack_q = 1
            elif self.state == "read_data_release":
                self.scl_oen_q = 0
                self.sda_oen_q = 1
                self.state = "read_scl_high"
            elif self.state == "read_scl_high":
                self.scl_oen_q = 1
                self.state = "read_scl_low"
            elif self.state == "read_scl_low":
                self.scl_oen_q = 0
                self.state = "idle"
                self.active_cmd = 0
                self.cmd_ack_q = 1
            elif self.state == "write_data":
                self.scl_oen_q = 0
                self.sda_oen_q = self.mask(i["din"], 1)
                self.state = "write_scl_high"
            elif self.state == "write_scl_high":
                self.scl_oen_q = 1
                self.state = "write_check"
            elif self.state == "write_check":
                self.scl_oen_q = 0
                self.state = "idle"
                self.active_cmd = 0
                self.cmd_ack_q = 1

        if not ena:
            self.cnt = clk_cnt
            self.div_clk_en = 1
        elif sig["scl_sync"]:
            self.cnt = clk_cnt
            self.div_clk_en = 1
        elif sig["slave_wait"]:
            self.div_clk_en = 0
        elif old_cnt == 0:
            self.cnt = clk_cnt
            self.div_clk_en = 1
        else:
            self.cnt = self.mask(old_cnt - 1, 16)
            self.div_clk_en = 0
