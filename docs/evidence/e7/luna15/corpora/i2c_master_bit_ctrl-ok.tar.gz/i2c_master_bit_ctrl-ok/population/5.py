"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['clk_en', 'cnt_zero', 'slave_wait', 'scl_sync', 'cscl', 'csda', 'filter_cnt_expired', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'sta_condition', 'sto_condition', 'sscl_rise', 'sda_chk', 'in_idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence']
    PROBE_WIDTHS = {'clk_en': 1, 'cnt_zero': 1, 'slave_wait': 1, 'scl_sync': 1, 'cscl': 1, 'csda': 1, 'filter_cnt_expired': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'sta_condition': 1, 'sto_condition': 1, 'sscl_rise': 1, 'sda_chk': 1, 'in_idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = 'idle'
        self.scl_oen = 1
        self.sda_oen = 1
        self.cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0
        self.cnt = 0
        self.clk_en = 1
        self.filter_cnt = 0
        self.cSCL0 = 1
        self.cscl = 1
        self.cSDA0 = 1
        self.csda = 1
        self.fscl = 7
        self.fsda = 7
        self.sscl = 1
        self.ssda = 1
        self.dscl = 1
        self.dsda = 1
        self.write_data = 1
        self.cnt_zero = 1
        self.slave_wait = 0
        self.scl_sync = 0
        self.filter_cnt_expired = 1
        self.sta_condition = 0
        self.sto_condition = 0
        self.sscl_rise = 0
        self.sda_chk = 0
        self.in_idle = 1
        self.fsm_active = 0
        self.in_start_sequence = 0
        self.in_stop_sequence = 0
        self.in_read_sequence = 0
        self.in_write_sequence = 0

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        scl_ones = ((self.fscl >> 2) & 1) + ((self.fscl >> 1) & 1) + (self.fscl & 1)
        sda_ones = ((self.fsda >> 2) & 1) + ((self.fsda >> 1) & 1) + (self.fsda & 1)
        self.sscl = int(scl_ones >= 2)
        self.ssda = int(sda_ones >= 2)

        self.cnt_zero = int(self.cnt == 0)
        self.slave_wait = int(bool(self.scl_oen and not self.sscl))
        self.scl_sync = int(bool(self.scl_oen and self.dscl and not self.sscl))
        self.filter_cnt_expired = int(self.filter_cnt == 0)
        self.sta_condition = int(bool(not self.ssda and self.dsda and self.sscl))
        self.sto_condition = int(bool(self.ssda and not self.dsda and self.sscl))
        self.sscl_rise = int(bool(self.sscl and not self.dscl))
        self.sda_chk = int(self.state == 'write_c')
        self.in_idle = int(self.state == 'idle')
        self.fsm_active = int(self.state != 'idle')
        self.in_start_sequence = int(self.state.startswith('start_'))
        self.in_stop_sequence = int(self.state.startswith('stop_'))
        self.in_read_sequence = int(self.state.startswith('read_'))
        self.in_write_sequence = int(self.state.startswith('write_'))

        o['cmd_ack'] = self.cmd_ack
        o['busy'] = self.busy
        o['al'] = self.al
        o['dout'] = self.dout
        o['scl_o'] = 0
        o['scl_oen'] = self.scl_oen
        o['sda_o'] = 0
        o['sda_oen'] = self.sda_oen
        return o

    def advance(self, i):
        clk_cnt = self.mask(i['clk_cnt'], 16)

        # Reset is represented as a transition at this edge. The interface does
        # not provide a separate asynchronous-reset callback.
        if (not i['nReset']) or i['rst']:
            self.reset()
            self.cnt = clk_cnt
            return

        scl_ones = ((self.fscl >> 2) & 1) + ((self.fscl >> 1) & 1) + (self.fscl & 1)
        sda_ones = ((self.fsda >> 2) & 1) + ((self.fsda >> 1) & 1) + (self.fsda & 1)
        sscl = int(scl_ones >= 2)
        ssda = int(sda_ones >= 2)
        slave_wait = bool(self.scl_oen and not sscl)
        scl_sync = bool(self.scl_oen and self.dscl and not sscl)
        sta_condition = bool(not ssda and self.dsda and sscl)
        sto_condition = bool(ssda and not self.dsda and sscl)
        sscl_rise = bool(sscl and not self.dscl)
        sda_chk = self.state == 'write_c'

        old_cSCL0 = self.cSCL0
        old_cSDA0 = self.cSDA0
        old_cscl = self.cscl
        old_csda = self.csda

        # Synchronizer pipeline; filtering samples the previous second stage.
        self.cSCL0 = self.mask(i['scl_i'], 1)
        self.cscl = old_cSCL0
        self.cSDA0 = self.mask(i['sda_i'], 1)
        self.csda = old_cSDA0

        if not i['ena']:
            self.filter_cnt = 0
        elif self.filter_cnt == 0:
            self.filter_cnt = self.mask(clk_cnt >> 2, 14)
            self.fscl = self.mask((self.fscl << 1) | old_cscl, 3)
            self.fsda = self.mask((self.fsda << 1) | old_csda, 3)
        else:
            self.filter_cnt = self.mask(self.filter_cnt - 1, 14)

        # Delayed filtered values advance every clock, independently of ena.
        self.dscl = sscl
        self.dsda = ssda

        if sscl_rise:
            self.dout = ssda

        if sta_condition:
            self.busy = 1
        elif sto_condition:
            self.busy = 0

        arbitration_lost = bool(sda_chk and self.sda_oen and not ssda)
        unexpected_stop = bool(sto_condition and self.state != 'idle' and not self.state.startswith('stop_'))
        if arbitration_lost or unexpected_stop:
            self.al = 1

        self.cmd_ack = 0

        # Arbitration loss releases the bus and takes priority over normal phases.
        if self.al:
            self.state = 'idle'
            self.scl_oen = 1
            self.sda_oen = 1
        elif i['ena'] and self.clk_en and not slave_wait:
            if self.state == 'idle':
                self.scl_oen = 1
                self.sda_oen = 1
                command = self.mask(i['cmd'], 4)
                if command == 1:
                    self.state = 'start_a'
                elif command == 2:
                    self.state = 'stop_a'
                elif command == 4:
                    self.write_data = self.mask(i['din'], 1)
                    self.state = 'write_a'
                elif command == 8:
                    self.state = 'read_a'
            elif self.state == 'start_a':
                self.scl_oen = 1
                self.sda_oen = 1
                self.state = 'start_b'
            elif self.state == 'start_b':
                self.scl_oen = 1
                self.sda_oen = 0
                self.state = 'start_c'
            elif self.state == 'start_c':
                self.scl_oen = 0
                self.sda_oen = 0
                self.cmd_ack = 1
                self.state = 'idle'
            elif self.state == 'stop_a':
                self.scl_oen = 0
                self.sda_oen = 0
                self.state = 'stop_b'
            elif self.state == 'stop_b':
                self.scl_oen = 1
                self.sda_oen = 0
                self.state = 'stop_c'
            elif self.state == 'stop_c':
                self.scl_oen = 1
                self.sda_oen = 1
                self.cmd_ack = 1
                self.state = 'idle'
            elif self.state == 'read_a':
                self.scl_oen = 0
                self.sda_oen = 1
                self.state = 'read_b'
            elif self.state == 'read_b':
                self.scl_oen = 1
                self.sda_oen = 1
                self.state = 'read_c'
            elif self.state == 'read_c':
                self.scl_oen = 0
                self.sda_oen = 1
                self.cmd_ack = 1
                self.state = 'idle'
            elif self.state == 'write_a':
                self.scl_oen = 0
                self.sda_oen = self.write_data
                self.state = 'write_b'
            elif self.state == 'write_b':
                self.scl_oen = 1
                self.sda_oen = self.write_data
                self.state = 'write_c'
            elif self.state == 'write_c':
                self.scl_oen = 0
                self.sda_oen = self.write_data
                self.cmd_ack = 1
                self.state = 'idle'

        # Disabled operation reloads the divider. A detected synchronization
        # edge reloads before the persistent stretch-wait hold is applied.
        if not i['ena']:
            self.cnt = clk_cnt
            self.clk_en = 1
        elif scl_sync:
            self.cnt = clk_cnt
            self.clk_en = 1
        elif slave_wait:
            self.clk_en = 0
        elif self.cnt == 0:
            self.cnt = clk_cnt
            self.clk_en = 1
        else:
            self.cnt = self.mask(self.cnt - 1, 16)
            self.clk_en = 0

    def spec_scaffolding(self):
        return None
