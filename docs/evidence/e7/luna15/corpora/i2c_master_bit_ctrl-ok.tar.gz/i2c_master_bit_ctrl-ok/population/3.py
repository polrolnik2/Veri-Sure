"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['clk_en', 'cnt_zero', 'slave_wait', 'scl_sync', 'cscl', 'csda', 'filter_cnt_expired', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'sta_condition', 'sto_condition', 'sscl_rise', 'sda_chk', 'in_idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence']
    PROBE_WIDTHS = {'clk_en': 1, 'cnt_zero': 1, 'slave_wait': 1, 'scl_sync': 1, 'cscl': 1, 'csda': 1, 'filter_cnt_expired': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'sta_condition': 1, 'sto_condition': 1, 'sscl_rise': 1, 'sda_chk': 1, 'in_idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self.state = "idle"
        self.cnt = 0
        self.clk_en = False
        self.filter_cnt = 0
        self.cSCL = 1
        self.cSDA = 1
        self.fSCL = 7
        self.fSDA = 7
        self.dSCL = 1
        self.dSDA = 1
        self.cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0
        self.scl_oen = 1
        self.sda_oen = 1
        self.write_din = 1

    def _majority(self, samples):
        total = ((samples >> 2) & 1) + ((samples >> 1) & 1) + (samples & 1)
        return int(total >= 2)

    def outputs(self, i):
        reset_view = not (i["nReset"] & 1)

        if reset_view:
            state = "idle"
            cnt = 0
            clk_en = False
            filter_cnt = 0
            cSCL = 1
            cSDA = 1
            fSCL = 7
            fSDA = 7
            dSCL = 1
            dSDA = 1
            cmd_ack = 0
            busy = 0
            al = 0
            dout = 0
            scl_oen = 1
            sda_oen = 1
        else:
            state = self.state
            cnt = self.cnt
            clk_en = bool(self.clk_en)
            filter_cnt = self.filter_cnt
            cSCL = self.cSCL
            cSDA = self.cSDA
            fSCL = self.fSCL
            fSDA = self.fSDA
            dSCL = self.dSCL
            dSDA = self.dSDA
            cmd_ack = self.cmd_ack
            busy = self.busy
            al = self.al
            dout = self.dout
            scl_oen = self.scl_oen
            sda_oen = self.sda_oen

        sscl = self._majority(fSCL)
        ssda = self._majority(fSDA)
        sta_condition = bool((not ssda) and dSDA and sscl)
        sto_condition = bool(ssda and (not dSDA) and sscl)
        sscl_rise = bool(sscl and (not dSCL))
        slave_wait = bool(scl_oen and (not sscl))
        scl_sync = bool(scl_oen and dSCL and (not sscl))

        self.clk_en = bool(clk_en)
        self.cnt_zero = bool(cnt == 0)
        self.slave_wait = slave_wait
        self.scl_sync = scl_sync
        self.cscl = bool(cSCL)
        self.csda = bool(cSDA)
        self.filter_cnt_expired = bool(filter_cnt == 0)
        self.fscl = self.mask(fSCL, 3)
        self.fsda = self.mask(fSDA, 3)
        self.sscl = bool(sscl)
        self.ssda = bool(ssda)
        self.dscl = bool(dSCL)
        self.dsda = bool(dSDA)
        self.sta_condition = sta_condition
        self.sto_condition = sto_condition
        self.sscl_rise = sscl_rise
        self.sda_chk = bool(state == "write_check")
        self.in_idle = bool(state == "idle")
        self.fsm_active = bool(state != "idle")
        self.in_start_sequence = bool(state in ("start_release", "start_sda_low", "start_scl_low"))
        self.in_stop_sequence = bool(state in ("stop_sda_low", "stop_scl_high", "stop_sda_high"))
        self.in_read_sequence = bool(state in ("read_sda_release", "read_scl_high", "read_scl_low"))
        self.in_write_sequence = bool(state in ("write_setup", "write_scl_high", "write_check", "write_scl_low"))

        o = {p: None for p in self.OUTPUT_PORTS}
        o["cmd_ack"] = int(cmd_ack)
        o["busy"] = int(busy)
        o["al"] = int(al)
        o["dout"] = int(dout)
        o["scl_o"] = 0
        o["scl_oen"] = int(scl_oen)
        o["sda_o"] = 0
        o["sda_oen"] = int(sda_oen)
        return o

    def advance(self, i):
        if not (i["nReset"] & 1):
            self.reset()
            return
        if i["rst"] & 1:
            self.reset()
            return

        sscl = self._majority(self.fSCL)
        ssda = self._majority(self.fSDA)
        sta_condition = bool((not ssda) and self.dSDA and sscl)
        sto_condition = bool(ssda and (not self.dSDA) and sscl)
        sscl_rise = bool(sscl and (not self.dSCL))
        slave_wait = bool(self.scl_oen and (not sscl))
        scl_sync = bool(self.scl_oen and self.dSCL and (not sscl))

        old_state = self.state
        old_cnt = self.cnt
        old_clk_en = bool(self.clk_en)
        old_cSCL = self.cSCL
        old_cSDA = self.cSDA
        old_fSCL = self.fSCL
        old_fSDA = self.fSDA
        old_filter_cnt = self.filter_cnt
        old_scl_oen = self.scl_oen
        old_sda_oen = self.sda_oen

        active = old_state != "idle"
        requested_stop = old_state in ("stop_sda_low", "stop_scl_high", "stop_sda_high")
        arbitration_loss = bool(
            (old_state == "write_check" and old_sda_oen and not ssda)
            or (sto_condition and active and not requested_stop)
        )
        fsm_tick = bool(old_clk_en and (i["ena"] & 1) and not slave_wait)

        if sta_condition:
            self.busy = 1
        elif sto_condition:
            self.busy = 0

        if sscl_rise:
            self.dout = int(ssda)
        self.dSCL = int(sscl)
        self.dSDA = int(ssda)

        self.cSCL = i["scl_i"] & 1
        self.cSDA = i["sda_i"] & 1
        if not (i["ena"] & 1):
            self.filter_cnt = 0
        elif old_filter_cnt == 0:
            self.filter_cnt = (i["clk_cnt"] & 0xFFFF) >> 2
            self.fSCL = self.mask(((old_fSCL << 1) | old_cSCL), 3)
            self.fSDA = self.mask(((old_fSDA << 1) | old_cSDA), 3)
        else:
            self.filter_cnt = old_filter_cnt - 1

        self.cmd_ack = 0
        if arbitration_loss:
            self.al = 1
            self.state = "idle"
            self.scl_oen = 1
            self.sda_oen = 1
        elif fsm_tick:
            if old_state == "idle":
                cmd = i["cmd"] & 0xF
                if cmd == 1:
                    self.state = "start_release"
                    self.scl_oen = 1
                    self.sda_oen = 1
                elif cmd == 2:
                    self.state = "stop_sda_low"
                    self.scl_oen = 0
                    self.sda_oen = 0
                elif cmd == 8:
                    self.state = "read_sda_release"
                    self.scl_oen = 0
                    self.sda_oen = 1
                elif cmd == 4:
                    self.state = "write_setup"
                    self.write_din = i["din"] & 1
                    self.scl_oen = 0
                    self.sda_oen = self.write_din
            elif old_state == "start_release":
                self.state = "start_sda_low"
                self.scl_oen = 1
                self.sda_oen = 0
            elif old_state == "start_sda_low":
                self.state = "start_scl_low"
                self.scl_oen = 0
                self.sda_oen = 0
            elif old_state == "start_scl_low":
                self.state = "idle"
                self.cmd_ack = 1
            elif old_state == "stop_sda_low":
                self.state = "stop_scl_high"
                self.scl_oen = 1
                self.sda_oen = 0
            elif old_state == "stop_scl_high":
                self.state = "stop_sda_high"
                self.scl_oen = 1
                self.sda_oen = 1
            elif old_state == "stop_sda_high":
                self.state = "idle"
                self.cmd_ack = 1
            elif old_state == "read_sda_release":
                self.state = "read_scl_high"
                self.scl_oen = 1
                self.sda_oen = 1
            elif old_state == "read_scl_high":
                self.state = "read_scl_low"
                self.scl_oen = 0
                self.sda_oen = 1
            elif old_state == "read_scl_low":
                self.state = "idle"
                self.cmd_ack = 1
            elif old_state == "write_setup":
                self.state = "write_scl_high"
                self.scl_oen = 1
                self.sda_oen = self.write_din
            elif old_state == "write_scl_high":
                self.state = "write_check"
                self.scl_oen = 1
                self.sda_oen = self.write_din
            elif old_state == "write_check":
                self.state = "write_scl_low"
                self.scl_oen = 0
                self.sda_oen = self.write_din
            elif old_state == "write_scl_low":
                self.state = "idle"
                self.cmd_ack = 1

        if not (i["ena"] & 1):
            self.cnt = self.mask(i["clk_cnt"], 16)
            self.clk_en = True
        elif scl_sync:
            self.cnt = self.mask(i["clk_cnt"], 16)
            self.clk_en = True
        elif old_cnt == 0:
            self.cnt = self.mask(i["clk_cnt"], 16)
            self.clk_en = True
        elif slave_wait:
            self.cnt = old_cnt
            self.clk_en = False
        else:
            self.cnt = old_cnt - 1
            self.clk_en = False
