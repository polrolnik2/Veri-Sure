"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['clk_en', 'cnt_zero', 'slave_wait', 'scl_sync', 'cscl', 'csda', 'filter_cnt_expired', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'sta_condition', 'sto_condition', 'sscl_rise', 'sda_chk', 'in_idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence']
    PROBE_WIDTHS = {'clk_en': 1, 'cnt_zero': 1, 'slave_wait': 1, 'scl_sync': 1, 'cscl': 1, 'csda': 1, 'filter_cnt_expired': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'sta_condition': 1, 'sto_condition': 1, 'sscl_rise': 1, 'sda_chk': 1, 'in_idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self._state = 'idle'
        self._command = 0
        self._cmd_ack = 0
        self._busy = 0
        self._al = 0
        self._dout = 0
        self._scl_oen = 1
        self._sda_oen = 1
        self._cnt = 0
        self._clk_en = 1
        self._filter_cnt = 0
        self._cSCL = 1
        self._cSDA = 1
        self._fSCL = 7
        self._fSDA = 7
        self._dSCL = 1
        self._dSDA = 1

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        async_reset = (int(i['nReset']) & 1) == 0

        if async_reset:
            state = 'idle'
            cmd_ack = 0
            busy = 0
            al = 0
            dout = 0
            scl_oen = 1
            sda_oen = 1
            cnt_zero = True
            clk_en = True
            filter_cnt_expired = True
            cscl = 1
            csda = 1
            fscl = 7
            fsda = 7
            dscl = 1
            dsda = 1
        else:
            state = self._state
            cmd_ack = self._cmd_ack
            busy = self._busy
            al = self._al
            dout = self._dout
            scl_oen = self._scl_oen
            sda_oen = self._sda_oen
            cnt_zero = self._cnt == 0
            clk_en = bool(self._clk_en)
            filter_cnt_expired = self._filter_cnt == 0
            cscl = self._cSCL
            csda = self._cSDA
            fscl = self._fSCL
            fsda = self._fSDA
            dscl = self._dSCL
            dsda = self._dSDA

        sscl = int((((fscl >> 0) & 1) + ((fscl >> 1) & 1) + ((fscl >> 2) & 1)) >= 2)
        ssda = int((((fsda >> 0) & 1) + ((fsda >> 1) & 1) + ((fsda >> 2) & 1)) >= 2)
        sta_condition = (not ssda) and bool(dsda) and bool(sscl)
        sto_condition = bool(ssda) and (not bool(dsda)) and bool(sscl)
        sscl_rise = bool(sscl) and (not bool(dscl))
        slave_wait = bool(scl_oen) and (not bool(sscl))
        scl_sync = bool(scl_oen) and bool(dscl) and (not bool(sscl))
        sda_chk = state == 'write_check'

        self.clk_en = bool(clk_en)
        self.cnt_zero = bool(cnt_zero)
        self.slave_wait = bool(slave_wait)
        self.scl_sync = bool(scl_sync)
        self.cscl = bool(cscl)
        self.csda = bool(csda)
        self.filter_cnt_expired = bool(filter_cnt_expired)
        self.fscl = int(fscl)
        self.fsda = int(fsda)
        self.sscl = bool(sscl)
        self.ssda = bool(ssda)
        self.dscl = bool(dscl)
        self.dsda = bool(dsda)
        self.sta_condition = bool(sta_condition)
        self.sto_condition = bool(sto_condition)
        self.sscl_rise = bool(sscl_rise)
        self.sda_chk = bool(sda_chk)
        self.in_idle = state == 'idle'
        self.fsm_active = state != 'idle'
        self.in_start_sequence = state in ('start_release', 'start_sda_low', 'start_scl_low')
        self.in_stop_sequence = state in ('stop_sda_low', 'stop_scl_high', 'stop_sda_high')
        self.in_read_sequence = state in ('read_release_sda', 'read_scl_high', 'read_scl_low')
        self.in_write_sequence = state in ('write_data', 'write_scl_high', 'write_check', 'write_scl_low')

        o['cmd_ack'] = int(cmd_ack)
        o['busy'] = int(busy)
        o['al'] = int(al)
        o['dout'] = int(dout)
        o['scl_o'] = 0
        o['scl_oen'] = int(scl_oen)
        o['sda_o'] = 0
        o['sda_oen'] = int(sda_oen)
        return o

    def advance(self, i):
        if (int(i['nReset']) & 1) == 0 or (int(i['rst']) & 1) != 0:
            self.reset()
            return

        clk_cnt = self.mask(i['clk_cnt'], 16)
        ena = int(i['ena']) & 1
        din = int(i['din']) & 1
        cmd = self.mask(i['cmd'], 4)

        sscl = int((((self._fSCL >> 0) & 1) + ((self._fSCL >> 1) & 1) + ((self._fSCL >> 2) & 1)) >= 2)
        ssda = int((((self._fSDA >> 0) & 1) + ((self._fSDA >> 1) & 1) + ((self._fSDA >> 2) & 1)) >= 2)
        sta_condition = (not ssda) and bool(self._dSDA) and bool(sscl)
        sto_condition = bool(ssda) and (not bool(self._dSDA)) and bool(sscl)
        sscl_rise = bool(sscl) and (not bool(self._dSCL))
        slave_wait = bool(self._scl_oen) and (not bool(sscl))
        scl_sync = bool(self._scl_oen) and bool(self._dSCL) and (not bool(sscl))

        state = self._state
        old_clk_en = bool(self._clk_en)
        sda_chk = state == 'write_check'
        arbitration_loss = bool(sda_chk and self._sda_oen and not ssda)
        unexpected_stop = bool(sto_condition and state != 'idle' and self._command != 2)
        lost_now = bool(self._al or arbitration_loss or unexpected_stop)

        if sta_condition:
            self._busy = 1
        elif sto_condition:
            self._busy = 0
        if sscl_rise:
            self._dout = int(ssda)

        old_cSCL = self._cSCL
        old_cSDA = self._cSDA
        self._dSCL = int(sscl)
        self._dSDA = int(ssda)
        if ena:
            if self._filter_cnt == 0:
                self._filter_cnt = self.mask(clk_cnt >> 2, 14)
                self._fSCL = self.mask((self._fSCL << 1) | old_cSCL, 3)
                self._fSDA = self.mask((self._fSDA << 1) | old_cSDA, 3)
            else:
                self._filter_cnt -= 1
        else:
            self._filter_cnt = 0
        self._cSCL = int(i['scl_i']) & 1
        self._cSDA = int(i['sda_i']) & 1

        if lost_now:
            self._al = 1
            self._state = 'idle'
            self._command = 0
            self._scl_oen = 1
            self._sda_oen = 1
            self._cmd_ack = 0
        else:
            self._al = int(bool(self._al))
            self._cmd_ack = 0
            if old_clk_en and ena and not slave_wait:
                if state == 'idle':
                    if cmd in (1, 2, 4, 8):
                        self._command = cmd
                        if cmd == 1:
                            self._state = 'start_release'
                        elif cmd == 2:
                            self._state = 'stop_sda_low'
                        elif cmd == 8:
                            self._state = 'read_release_sda'
                        else:
                            self._state = 'write_data'
                    else:
                        self._command = 0
                        self._state = 'idle'
                elif state == 'start_release':
                    self._scl_oen = 1
                    self._sda_oen = 1
                    self._state = 'start_sda_low'
                elif state == 'start_sda_low':
                    self._scl_oen = 1
                    self._sda_oen = 0
                    self._state = 'start_scl_low'
                elif state == 'start_scl_low':
                    self._scl_oen = 0
                    self._sda_oen = 0
                    self._state = 'idle'
                    self._command = 0
                    self._cmd_ack = 1
                elif state == 'stop_sda_low':
                    self._scl_oen = 0
                    self._sda_oen = 0
                    self._state = 'stop_scl_high'
                elif state == 'stop_scl_high':
                    self._scl_oen = 1
                    self._sda_oen = 0
                    self._state = 'stop_sda_high'
                elif state == 'stop_sda_high':
                    self._scl_oen = 1
                    self._sda_oen = 1
                    self._state = 'idle'
                    self._command = 0
                    self._cmd_ack = 1
                elif state == 'read_release_sda':
                    self._scl_oen = 0
                    self._sda_oen = 1
                    self._state = 'read_scl_high'
                elif state == 'read_scl_high':
                    self._scl_oen = 1
                    self._sda_oen = 1
                    self._state = 'read_scl_low'
                elif state == 'read_scl_low':
                    self._scl_oen = 0
                    self._sda_oen = 1
                    self._state = 'idle'
                    self._command = 0
                    self._cmd_ack = 1
                elif state == 'write_data':
                    self._scl_oen = 0
                    self._sda_oen = din
                    self._state = 'write_scl_high'
                elif state == 'write_scl_high':
                    self._scl_oen = 1
                    self._sda_oen = din
                    self._state = 'write_check'
                elif state == 'write_check':
                    self._scl_oen = 1
                    self._sda_oen = din
                    self._state = 'write_scl_low'
                elif state == 'write_scl_low':
                    self._scl_oen = 0
                    self._sda_oen = din
                    self._state = 'idle'
                    self._command = 0
                    self._cmd_ack = 1

        if not ena:
            self._cnt = clk_cnt
            self._clk_en = 1
        elif scl_sync:
            self._cnt = clk_cnt
            self._clk_en = 1
        elif slave_wait:
            self._clk_en = 0
        elif self._cnt == 0:
            self._cnt = clk_cnt
            self._clk_en = 1
        else:
            self._cnt -= 1
            self._clk_en = 0
