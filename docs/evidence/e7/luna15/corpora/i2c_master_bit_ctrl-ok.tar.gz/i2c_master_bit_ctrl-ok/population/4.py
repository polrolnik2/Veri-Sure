"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['clk_en', 'cnt_zero', 'slave_wait', 'scl_sync', 'cscl', 'csda', 'filter_cnt_expired', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'sta_condition', 'sto_condition', 'sscl_rise', 'sda_chk', 'in_idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence']
    PROBE_WIDTHS = {'clk_en': 1, 'cnt_zero': 1, 'slave_wait': 1, 'scl_sync': 1, 'cscl': 1, 'csda': 1, 'filter_cnt_expired': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'sta_condition': 1, 'sto_condition': 1, 'sscl_rise': 1, 'sda_chk': 1, 'in_idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self._fsm = 'idle'
        self._cnt = 0
        self._clk_en = 0
        self._filter_cnt = 0
        self._cSCL = 1
        self._cSDA = 1
        self._fscl = 7
        self._fsda = 7
        self._dSCL = 1
        self._dSDA = 1
        self._cmd_ack = 0
        self._busy = 0
        self._al = 0
        self._dout = 0
        self._scl_oen = 1
        self._sda_oen = 1

    def _reset_state(self, i):
        self.reset()
        self._cnt = self.mask(i['clk_cnt'], 16)
        self._clk_en = 1

    def _signals(self, i):
        if not i['nReset']:
            fscl = 7
            fsda = 7
            sscl = 1
            ssda = 1
            dscl = 1
            dsda = 1
            state = 'idle'
            cnt = self.mask(i['clk_cnt'], 16)
            clk_en = 1
            filter_expired = 1
            cscl = 1
            csda = 1
            scl_oen = 1
            sda_oen = 1
            cmd_ack = 0
            busy = 0
            al = 0
            dout = 0
        else:
            fscl = self._fscl
            fsda = self._fsda
            sscl = int((((fscl >> 2) & 1) + ((fscl >> 1) & 1) + (fscl & 1)) >= 2)
            ssda = int((((fsda >> 2) & 1) + ((fsda >> 1) & 1) + (fsda & 1)) >= 2)
            dscl = self._dSCL
            dsda = self._dSDA
            state = self._fsm
            cnt = self._cnt
            clk_en = self._clk_en
            filter_expired = int(self._filter_cnt == 0)
            cscl = self._cSCL
            csda = self._cSDA
            scl_oen = self._scl_oen
            sda_oen = self._sda_oen
            cmd_ack = self._cmd_ack
            busy = self._busy
            al = self._al
            dout = self._dout

        sta = int((not ssda) and bool(dsda) and bool(sscl))
        sto = int(bool(ssda) and (not dsda) and bool(sscl))
        scl_sync = int(bool(scl_oen) and bool(dscl) and (not sscl))
        slave_wait = int(bool(scl_oen) and (not sscl))
        sscl_rise = int(bool(sscl) and (not dscl))
        sda_chk = int(state == 'write_c')
        return {
            'fscl': fscl, 'fsda': fsda, 'sscl': sscl, 'ssda': ssda,
            'dscl': dscl, 'dsda': dsda, 'sta_condition': sta,
            'sto_condition': sto, 'scl_sync': scl_sync,
            'slave_wait': slave_wait, 'sscl_rise': sscl_rise,
            'sda_chk': sda_chk, 'cnt_zero': int(cnt == 0),
            'clk_en': clk_en, 'filter_cnt_expired': filter_expired,
            'cscl': cscl, 'csda': csda, 'cmd_ack': cmd_ack,
            'busy': busy, 'al': al, 'dout': dout,
            'scl_oen': scl_oen, 'sda_oen': sda_oen,
            'in_idle': int(state == 'idle'),
            'fsm_active': int(state != 'idle'),
            'in_start_sequence': int(state.startswith('start_')),
            'in_stop_sequence': int(state.startswith('stop_')),
            'in_read_sequence': int(state.startswith('read_')),
            'in_write_sequence': int(state.startswith('write_'))
        }

    def outputs(self, i):
        v = self._signals(i)
        self.clk_en = bool(v['clk_en'])
        self.cnt_zero = bool(v['cnt_zero'])
        self.slave_wait = bool(v['slave_wait'])
        self.scl_sync = bool(v['scl_sync'])
        self.cscl = v['cscl']
        self.csda = v['csda']
        self.filter_cnt_expired = bool(v['filter_cnt_expired'])
        self.fscl = v['fscl']
        self.fsda = v['fsda']
        self.sscl = bool(v['sscl'])
        self.ssda = bool(v['ssda'])
        self.dscl = bool(v['dscl'])
        self.dsda = bool(v['dsda'])
        self.sta_condition = bool(v['sta_condition'])
        self.sto_condition = bool(v['sto_condition'])
        self.sscl_rise = bool(v['sscl_rise'])
        self.sda_chk = bool(v['sda_chk'])
        self.in_idle = bool(v['in_idle'])
        self.fsm_active = bool(v['fsm_active'])
        self.in_start_sequence = bool(v['in_start_sequence'])
        self.in_stop_sequence = bool(v['in_stop_sequence'])
        self.in_read_sequence = bool(v['in_read_sequence'])
        self.in_write_sequence = bool(v['in_write_sequence'])

        o = {p: None for p in self.OUTPUT_PORTS}
        o['cmd_ack'] = v['cmd_ack']
        o['busy'] = v['busy']
        o['al'] = v['al']
        o['dout'] = v['dout']
        o['scl_o'] = 0
        o['scl_oen'] = v['scl_oen']
        o['sda_o'] = 0
        o['sda_oen'] = v['sda_oen']
        return o

    def advance(self, i):
        if (not i['nReset']) or i['rst']:
            self._reset_state(i)
            return

        v = self._signals(i)
        old_state = self._fsm
        self._cmd_ack = 0

        if v['sta_condition']:
            self._busy = 1
        elif v['sto_condition']:
            self._busy = 0

        if v['sscl_rise']:
            self._dout = v['ssda']

        if i['ena']:
            if self._filter_cnt == 0:
                self._fscl = self.mask((self._fscl << 1) | self._cSCL, 3)
                self._fsda = self.mask((self._fsda << 1) | self._cSDA, 3)
                self._filter_cnt = self.mask(i['clk_cnt'] >> 2, 14)
            else:
                self._filter_cnt = self.mask(self._filter_cnt - 1, 14)
        else:
            self._filter_cnt = 0

        self._cSCL = self.mask(i['scl_i'], 1)
        self._cSDA = self.mask(i['sda_i'], 1)
        self._dSCL = v['sscl']
        self._dSDA = v['ssda']

        stop_states = ('stop_a', 'stop_b', 'stop_c')
        arbitration_lost = bool(v['sda_chk'] and self._sda_oen and not v['ssda'])
        unexpected_stop = bool(v['sto_condition'] and old_state != 'idle' and old_state not in stop_states)
        if arbitration_lost or unexpected_stop:
            self._al = 1
            self._fsm = 'idle'
            self._scl_oen = 1
            self._sda_oen = 1
        else:
            tick = bool(self._clk_en and i['ena'] and not v['slave_wait'])
            if tick:
                if old_state == 'idle':
                    cmd = self.mask(i['cmd'], 4)
                    if cmd == 1:
                        self._fsm = 'start_a'
                    elif cmd == 2:
                        self._fsm = 'stop_a'
                    elif cmd == 4:
                        self._fsm = 'write_a'
                    elif cmd == 8:
                        self._fsm = 'read_a'
                elif old_state == 'start_a':
                    self._scl_oen = 1
                    self._sda_oen = 1
                    self._fsm = 'start_b'
                elif old_state == 'start_b':
                    self._sda_oen = 0
                    self._fsm = 'start_c'
                elif old_state == 'start_c':
                    self._scl_oen = 0
                    self._fsm = 'idle'
                    self._cmd_ack = 1
                elif old_state == 'stop_a':
                    self._scl_oen = 0
                    self._sda_oen = 0
                    self._fsm = 'stop_b'
                elif old_state == 'stop_b':
                    self._scl_oen = 1
                    self._fsm = 'stop_c'
                elif old_state == 'stop_c':
                    self._sda_oen = 1
                    self._fsm = 'idle'
                    self._cmd_ack = 1
                elif old_state == 'read_a':
                    self._scl_oen = 0
                    self._sda_oen = 1
                    self._fsm = 'read_b'
                elif old_state == 'read_b':
                    self._scl_oen = 1
                    self._fsm = 'read_c'
                elif old_state == 'read_c':
                    self._scl_oen = 0
                    self._fsm = 'idle'
                    self._cmd_ack = 1
                elif old_state == 'write_a':
                    self._scl_oen = 0
                    self._sda_oen = self.mask(i['din'], 1)
                    self._fsm = 'write_b'
                elif old_state == 'write_b':
                    self._scl_oen = 1
                    self._fsm = 'write_c'
                elif old_state == 'write_c':
                    self._fsm = 'write_d'
                elif old_state == 'write_d':
                    self._scl_oen = 0
                    self._fsm = 'idle'
                    self._cmd_ack = 1

        if not i['ena']:
            self._cnt = self.mask(i['clk_cnt'], 16)
            self._clk_en = 1
        elif v['scl_sync']:
            self._cnt = self.mask(i['clk_cnt'], 16)
            self._clk_en = 1
        elif v['slave_wait']:
            self._clk_en = 0
        elif self._cnt == 0:
            self._cnt = self.mask(i['clk_cnt'], 16)
            self._clk_en = 1
        else:
            self._cnt = self.mask(self._cnt - 1, 16)
            self._clk_en = 0
