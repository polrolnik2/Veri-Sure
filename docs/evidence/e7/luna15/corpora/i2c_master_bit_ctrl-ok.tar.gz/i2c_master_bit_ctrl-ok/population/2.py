"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['clk_en', 'cnt_zero', 'slave_wait', 'scl_sync', 'cscl', 'csda', 'filter_cnt_expired', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'sta_condition', 'sto_condition', 'sscl_rise', 'sda_chk', 'in_idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence']
    PROBE_WIDTHS = {'clk_en': 1, 'cnt_zero': 1, 'slave_wait': 1, 'scl_sync': 1, 'cscl': 1, 'csda': 1, 'filter_cnt_expired': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'sta_condition': 1, 'sto_condition': 1, 'sscl_rise': 1, 'sda_chk': 1, 'in_idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self._state = 'idle'
        self._command = 'nop'
        self._cnt = 0
        self._clk_en = 1
        self._filter_cnt = 0
        self._cSCL = 3
        self._cSDA = 3
        self._fSCL = 7
        self._fSDA = 7
        self._dSCL = 1
        self._dSDA = 1
        self._scl_oen = 1
        self._sda_oen = 1
        self._sda_chk = 0
        self._cmd_ack = 0
        self._busy = 0
        self._al = 0
        self._dout = 0

    def _majority(self, value):
        return int(((value & 1) + ((value >> 1) & 1) + ((value >> 2) & 1)) >= 2)

    def _probe_values(self, i):
        reset_view = not i['nReset']
        if reset_view:
            cnt = 0
            clk_en = 1
            filter_cnt = 0
            cscl_reg = 3
            csda_reg = 3
            fscl = 7
            fsda = 7
            dscl = 1
            dsda = 1
            state = 'idle'
            scl_oen = 1
            sda_chk = 0
        else:
            cnt = self._cnt
            clk_en = self._clk_en
            filter_cnt = self._filter_cnt
            cscl_reg = self._cSCL
            csda_reg = self._cSDA
            fscl = self._fSCL
            fsda = self._fSDA
            dscl = self._dSCL
            dsda = self._dSDA
            state = self._state
            scl_oen = self._scl_oen
            sda_chk = self._sda_chk

        sscl = self._majority(fscl)
        ssda = self._majority(fsda)
        sta = int((not ssda) and dsda and sscl)
        sto = int(ssda and (not dsda) and sscl)
        sscl_rise = int(sscl and (not dscl))
        slave_wait = int(scl_oen and (not sscl))
        scl_sync = int(scl_oen and dscl and (not sscl))

        return {
            'clk_en': int(bool(clk_en)),
            'cnt_zero': int(cnt == 0),
            'slave_wait': slave_wait,
            'scl_sync': scl_sync,
            'cscl': (cscl_reg >> 1) & 1,
            'csda': (csda_reg >> 1) & 1,
            'filter_cnt_expired': int(filter_cnt == 0),
            'fscl': self.mask(fscl, 3),
            'fsda': self.mask(fsda, 3),
            'sscl': sscl,
            'ssda': ssda,
            'dscl': dscl,
            'dsda': dsda,
            'sta_condition': sta,
            'sto_condition': sto,
            'sscl_rise': sscl_rise,
            'sda_chk': int(bool(sda_chk)),
            'in_idle': int(state == 'idle'),
            'fsm_active': int(state != 'idle'),
            'in_start_sequence': int(state in ('start_a', 'start_b', 'start_c')),
            'in_stop_sequence': int(state in ('stop_a', 'stop_b', 'stop_c')),
            'in_read_sequence': int(state in ('read_a', 'read_b', 'read_c', 'read_d')),
            'in_write_sequence': int(state in ('write_a', 'write_b', 'write_c', 'write_d'))
        }

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        probes = self._probe_values(i)
        for name, value in probes.items():
            setattr(self, name, value)

        if not i['nReset']:
            o['cmd_ack'] = 0
            o['busy'] = 0
            o['al'] = 0
            o['dout'] = 0
            o['scl_o'] = 0
            o['scl_oen'] = 1
            o['sda_o'] = 0
            o['sda_oen'] = 1
        else:
            o['cmd_ack'] = int(bool(self._cmd_ack))
            o['busy'] = int(bool(self._busy))
            o['al'] = int(bool(self._al))
            o['dout'] = int(bool(self._dout))
            o['scl_o'] = 0
            o['scl_oen'] = int(bool(self._scl_oen))
            o['sda_o'] = 0
            o['sda_oen'] = int(bool(self._sda_oen))
        return o

    def advance(self, i):
        if not i['nReset'] or i['rst']:
            self.reset()
            return

        p = self._probe_values(i)
        old_sscl = p['sscl']
        old_ssda = p['ssda']
        old_state = self._state
        old_command = self._command
        old_cnt = self._cnt
        old_cSCL = self._cSCL
        old_cSDA = self._cSDA
        ena = int(bool(i['ena']))
        cmd = self.mask(i['cmd'], 4)

        self._cmd_ack = 0

        if p['sscl_rise']:
            self._dout = old_ssda
        if p['sta_condition']:
            self._busy = 1
        elif p['sto_condition']:
            self._busy = 0

        lose_arbitration = (self._sda_chk and not old_ssda) or (
            p['sto_condition'] and old_state != 'idle' and old_command != 'stop'
        )

        self._cSCL = self.mask(((old_cSCL & 1) << 1) | (i['scl_i'] & 1), 2)
        self._cSDA = self.mask(((old_cSDA & 1) << 1) | (i['sda_i'] & 1), 2)

        if not ena:
            self._filter_cnt = 0
        elif self._filter_cnt == 0:
            self._fSCL = self.mask((self._fSCL << 1) | ((old_cSCL >> 1) & 1), 3)
            self._fSDA = self.mask((self._fSDA << 1) | ((old_cSDA >> 1) & 1), 3)
            self._filter_cnt = self.mask(self.mask(i['clk_cnt'], 16) >> 2, 14)
        else:
            self._filter_cnt -= 1

        self._dSCL = old_sscl
        self._dSDA = old_ssda

        if lose_arbitration:
            self._al = 1
            self._state = 'idle'
            self._command = 'nop'
            self._scl_oen = 1
            self._sda_oen = 1
            self._sda_chk = 0
        elif self._al:
            if (old_state == 'idle' and cmd == 1 and ena and self._clk_en and not p['slave_wait']):
                self._al = 0
                self._state = 'start_a'
                self._command = 'start'
                self._sda_chk = 0
            else:
                self._state = 'idle'
                self._command = 'nop'
                self._scl_oen = 1
                self._sda_oen = 1
                self._sda_chk = 0
        else:
            tick = bool(self._clk_en and ena and not p['slave_wait'])
            if tick:
                if old_state == 'idle':
                    if cmd == 1:
                        self._state = 'start_a'
                        self._command = 'start'
                        self._sda_chk = 0
                    elif cmd == 2:
                        self._state = 'stop_a'
                        self._command = 'stop'
                        self._sda_chk = 0
                    elif cmd == 4:
                        self._state = 'write_a'
                        self._command = 'write'
                        self._sda_chk = 0
                    elif cmd == 8:
                        self._state = 'read_a'
                        self._command = 'read'
                        self._sda_chk = 0
                elif old_state == 'start_a':
                    self._scl_oen = 1
                    self._sda_oen = 1
                    self._state = 'start_b'
                elif old_state == 'start_b':
                    if p['sscl']:
                        self._sda_oen = 0
                        self._state = 'start_c'
                elif old_state == 'start_c':
                    self._scl_oen = 0
                    self._state = 'idle'
                    self._command = 'nop'
                    self._cmd_ack = 1
                elif old_state == 'stop_a':
                    self._scl_oen = 0
                    self._sda_oen = 0
                    self._state = 'stop_b'
                elif old_state == 'stop_b':
                    self._scl_oen = 1
                    self._state = 'stop_c'
                elif old_state == 'stop_c':
                    if p['sscl']:
                        self._sda_oen = 1
                        self._state = 'idle'
                        self._command = 'nop'
                        self._cmd_ack = 1
                elif old_state == 'read_a':
                    self._sda_oen = 1
                    self._state = 'read_b'
                elif old_state == 'read_b':
                    self._scl_oen = 1
                    self._state = 'read_c'
                elif old_state == 'read_c':
                    if p['sscl']:
                        self._scl_oen = 0
                        self._state = 'read_d'
                elif old_state == 'read_d':
                    self._state = 'idle'
                    self._command = 'nop'
                    self._cmd_ack = 1
                elif old_state == 'write_a':
                    self._sda_oen = int(bool(i['din'] & 1))
                    self._state = 'write_b'
                elif old_state == 'write_b':
                    self._scl_oen = 1
                    self._sda_chk = 1
                    self._state = 'write_c'
                elif old_state == 'write_c':
                    if p['sscl']:
                        self._scl_oen = 0
                        self._sda_chk = 0
                        self._state = 'write_d'
                elif old_state == 'write_d':
                    self._state = 'idle'
                    self._command = 'nop'
                    self._cmd_ack = 1

        if not ena:
            self._cnt = self.mask(i['clk_cnt'], 16)
            self._clk_en = 1
        elif p['slave_wait']:
            self._cnt = old_cnt
            self._clk_en = 0
        elif old_cnt == 0 or p['scl_sync']:
            self._cnt = self.mask(i['clk_cnt'], 16)
            self._clk_en = 1
        else:
            self._cnt = self.mask(old_cnt - 1, 16)
            self._clk_en = 0
