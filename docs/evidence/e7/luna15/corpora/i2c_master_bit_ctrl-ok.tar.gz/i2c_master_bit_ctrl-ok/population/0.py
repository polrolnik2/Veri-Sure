"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['clk_en', 'cnt_zero', 'slave_wait', 'scl_sync', 'cscl', 'csda', 'filter_cnt_expired', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'sta_condition', 'sto_condition', 'sscl_rise', 'sda_chk', 'in_idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence']
    PROBE_WIDTHS = {'clk_en': 1, 'cnt_zero': 1, 'slave_wait': 1, 'scl_sync': 1, 'cscl': 1, 'csda': 1, 'filter_cnt_expired': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'sta_condition': 1, 'sto_condition': 1, 'sscl_rise': 1, 'sda_chk': 1, 'in_idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self._reset_state()

    def _reset_state(self):
        self._state = 'idle'
        self._cnt = 0
        self._clk_en = 1
        self._filter_cnt = 0
        self._scl_meta = 1
        self._sda_meta = 1
        self._cscl = 1
        self._csda = 1
        self._fscl = 7
        self._fsda = 7
        self._dscl = 1
        self._dsda = 1
        self._busy = 0
        self._al = 0
        self._dout = 0
        self._cmd_ack = 0
        self._scl_oen = 1
        self._sda_oen = 1

    def _filtered(self):
        scl_ones = ((self._fscl >> 2) & 1) + ((self._fscl >> 1) & 1) + (self._fscl & 1)
        sda_ones = ((self._fsda >> 2) & 1) + ((self._fsda >> 1) & 1) + (self._fsda & 1)
        return int(scl_ones >= 2), int(sda_ones >= 2)

    def _is_stop_state(self, state=None):
        if state is None:
            state = self._state
        return state in ('stop_a', 'stop_b', 'stop_c')

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}

        # nReset is asynchronous, so a low level is observable before an edge.
        if not (i['nReset'] & 1):
            o['cmd_ack'] = 0
            o['busy'] = 0
            o['al'] = 0
            o['dout'] = 0
            o['scl_o'] = 0
            o['scl_oen'] = 1
            o['sda_o'] = 0
            o['sda_oen'] = 1
            self.clk_en = True
            self.cnt_zero = True
            self.slave_wait = False
            self.scl_sync = False
            self.cscl = 1
            self.csda = 1
            self.filter_cnt_expired = True
            self.fscl = 7
            self.fsda = 7
            self.sscl = True
            self.ssda = True
            self.dscl = True
            self.dsda = True
            self.sta_condition = False
            self.sto_condition = False
            self.sscl_rise = False
            self.sda_chk = False
            self.in_idle = True
            self.fsm_active = False
            self.in_start_sequence = False
            self.in_stop_sequence = False
            self.in_read_sequence = False
            self.in_write_sequence = False
            return o

        sscl, ssda = self._filtered()
        slave_wait = bool(self._scl_oen and not sscl)
        scl_sync = bool(self._scl_oen and self._dscl and not sscl)
        sta_condition = bool((not ssda) and self._dsda and sscl)
        sto_condition = bool(ssda and (not self._dsda) and sscl)
        sscl_rise = bool(sscl and (not self._dscl))

        o['cmd_ack'] = self._cmd_ack
        o['busy'] = self._busy
        o['al'] = self._al
        o['dout'] = self._dout
        o['scl_o'] = 0
        o['scl_oen'] = self._scl_oen
        o['sda_o'] = 0
        o['sda_oen'] = self._sda_oen

        self.clk_en = bool(self._clk_en)
        self.cnt_zero = bool(self._cnt == 0)
        self.slave_wait = slave_wait
        self.scl_sync = scl_sync
        self.cscl = self._cscl & 1
        self.csda = self._csda & 1
        self.filter_cnt_expired = bool(self._filter_cnt == 0)
        self.fscl = self._fscl & 7
        self.fsda = self._fsda & 7
        self.sscl = bool(sscl)
        self.ssda = bool(ssda)
        self.dscl = bool(self._dscl)
        self.dsda = bool(self._dsda)
        self.sta_condition = sta_condition
        self.sto_condition = sto_condition
        self.sscl_rise = sscl_rise
        self.sda_chk = bool(self._state == 'write_c')
        self.in_idle = bool(self._state == 'idle')
        self.fsm_active = bool(self._state != 'idle')
        self.in_start_sequence = bool(self._state in ('start_a', 'start_b', 'start_c'))
        self.in_stop_sequence = bool(self._state in ('stop_a', 'stop_b', 'stop_c'))
        self.in_read_sequence = bool(self._state in ('read_a', 'read_b', 'read_c', 'read_d'))
        self.in_write_sequence = bool(self._state in ('write_a', 'write_b', 'write_c', 'write_d'))
        return o

    def advance(self, i):
        if not (i['nReset'] & 1):
            self._reset_state()
            return
        if i['rst'] & 1:
            self._reset_state()
            return

        ena = i['ena'] & 1
        clk_cnt = self.mask(i['clk_cnt'], 16)
        sscl, ssda = self._filtered()
        slave_wait = bool(self._scl_oen and not sscl)
        scl_sync = bool(self._scl_oen and self._dscl and not sscl)
        sta_condition = bool((not ssda) and self._dsda and sscl)
        sto_condition = bool(ssda and (not self._dsda) and sscl)
        sscl_rise = bool(sscl and (not self._dscl))

        old_state = self._state
        old_clk_en = self._clk_en
        old_al = self._al
        old_sda_oen = self._sda_oen
        old_fscl = self._fscl
        old_fsda = self._fsda
        old_cscl = self._cscl
        old_csda = self._csda
        old_scl_meta = self._scl_meta
        old_sda_meta = self._sda_meta
        old_filter_cnt = self._filter_cnt

        if sta_condition:
            self._busy = 1
        elif sto_condition:
            self._busy = 0

        if sscl_rise:
            self._dout = ssda
        self._dscl = sscl
        self._dsda = ssda

        # The synchronizer runs continuously; filtering is gated by ena.
        self._scl_meta = i['scl_i'] & 1
        self._sda_meta = i['sda_i'] & 1
        self._cscl = old_scl_meta
        self._csda = old_sda_meta
        if not ena:
            self._filter_cnt = 0
        elif old_filter_cnt == 0:
            self._filter_cnt = self.mask(clk_cnt >> 2, 14)
            self._fscl = self.mask(((old_fscl << 1) | old_cscl), 3)
            self._fsda = self.mask(((old_fsda << 1) | old_csda), 3)
        else:
            self._filter_cnt = self.mask(old_filter_cnt - 1, 14)

        # One timing tick is generated by the prescaler and consumed by the FSM.
        if not ena:
            self._cnt = clk_cnt
            self._clk_en = 1
        elif scl_sync:
            self._cnt = clk_cnt
            self._clk_en = 1
        elif slave_wait:
            self._cnt = self._cnt
            self._clk_en = 0
        elif self._cnt == 0:
            self._cnt = clk_cnt
            self._clk_en = 1
        else:
            self._cnt = self.mask(self._cnt - 1, 16)
            self._clk_en = 0

        arbitration_loss = bool(
            (old_state == 'write_c' and old_sda_oen and not ssda)
            or (old_state != 'idle' and not self._is_stop_state(old_state) and sto_condition)
        )
        self._cmd_ack = 0

        if old_al or arbitration_loss:
            if arbitration_loss:
                self._al = 1
            self._state = 'idle'
            self._scl_oen = 1
            self._sda_oen = 1
            return

        if not ena or slave_wait or not old_clk_en:
            return

        if old_state == 'idle':
            cmd = self.mask(i['cmd'], 4)
            if cmd == 1:
                self._state = 'start_a'
            elif cmd == 2:
                self._state = 'stop_a'
            elif cmd == 4:
                self._state = 'write_a'
            elif cmd == 8:
                self._state = 'read_a'
        elif old_state == 'start_a':
            self._scl_oen = 1
            self._sda_oen = 1
            self._state = 'start_b'
        elif old_state == 'start_b':
            self._sda_oen = 0
            self._state = 'start_c'
        elif old_state == 'start_c':
            self._scl_oen = 0
            self._state = 'idle'
            self._cmd_ack = 1
        elif old_state == 'stop_a':
            self._scl_oen = 0
            self._sda_oen = 0
            self._state = 'stop_b'
        elif old_state == 'stop_b':
            self._scl_oen = 1
            self._state = 'stop_c'
        elif old_state == 'stop_c':
            self._sda_oen = 1
            self._state = 'idle'
            self._cmd_ack = 1
        elif old_state == 'read_a':
            self._scl_oen = 0
            self._sda_oen = 1
            self._state = 'read_b'
        elif old_state == 'read_b':
            self._scl_oen = 1
            self._state = 'read_c'
        elif old_state == 'read_c':
            self._state = 'read_d'
        elif old_state == 'read_d':
            self._scl_oen = 0
            self._state = 'idle'
            self._cmd_ack = 1
        elif old_state == 'write_a':
            self._scl_oen = 0
            self._sda_oen = i['din'] & 1
            self._state = 'write_b'
        elif old_state == 'write_b':
            self._scl_oen = 1
            self._state = 'write_c'
        elif old_state == 'write_c':
            self._state = 'write_d'
        elif old_state == 'write_d':
            self._scl_oen = 0
            self._state = 'idle'
            self._cmd_ack = 1
