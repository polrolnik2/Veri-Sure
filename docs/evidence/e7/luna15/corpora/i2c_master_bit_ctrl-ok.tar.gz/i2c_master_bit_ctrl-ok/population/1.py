"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['clk_en', 'cnt_zero', 'slave_wait', 'scl_sync', 'cscl', 'csda', 'filter_cnt_expired', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'sta_condition', 'sto_condition', 'sscl_rise', 'sda_chk', 'in_idle', 'fsm_active', 'in_start_sequence', 'in_stop_sequence', 'in_read_sequence', 'in_write_sequence']
    PROBE_WIDTHS = {'clk_en': 1, 'cnt_zero': 1, 'slave_wait': 1, 'scl_sync': 1, 'cscl': 1, 'csda': 1, 'filter_cnt_expired': 1, 'fscl': 3, 'fsda': 3, 'sscl': 1, 'ssda': 1, 'dscl': 1, 'dsda': 1, 'sta_condition': 1, 'sto_condition': 1, 'sscl_rise': 1, 'sda_chk': 1, 'in_idle': 1, 'fsm_active': 1, 'in_start_sequence': 1, 'in_stop_sequence': 1, 'in_read_sequence': 1, 'in_write_sequence': 1}
    LATENCY_CYCLES = 0

    def reset(self):
        self._reset_state(0)

    def _reset_state(self, prescale):
        self.state = 'idle'
        self.cnt = self.mask(prescale, 16)
        self.div_clk_en = 1
        self.filter_cnt = 0
        self.cSCL_meta = 1
        self.cSDA_meta = 1
        self.cSCL = 1
        self.cSDA = 1
        self.fSCL = 7
        self.fSDA = 7
        self.dSCL = 1
        self.dSDA = 1
        self.cmd_ack = 0
        self.busy = 0
        self.al = 0
        self.dout = 0
        self.scl_oen = 1
        self.sda_oen = 1

    def _sscl(self):
        a = self.fSCL & 1
        b = (self.fSCL >> 1) & 1
        c = (self.fSCL >> 2) & 1
        return (a & b) | (b & c) | (a & c)

    def _ssda(self):
        a = self.fSDA & 1
        b = (self.fSDA >> 1) & 1
        c = (self.fSDA >> 2) & 1
        return (a & b) | (b & c) | (a & c)

    def outputs(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        async_reset = (i['nReset'] & 1) == 0
        if async_reset:
            sscl = 1
            ssda = 1
            dscl = 1
            dsda = 1
            fscl = 7
            fsda = 7
            cscl = 1
            csda = 1
            clk_en = 1
            cnt_zero = int(self.mask(i['clk_cnt'], 16) == 0)
            filter_expired = 1
            sta = 0
            sto = 0
            sscl_rise = 0
            slave_wait = 0
            scl_sync = 0
            state = 'idle'
            sda_chk = 0
            cmd_ack = 0
            busy = 0
            al = 0
            dout = 0
            scl_oen = 1
            sda_oen = 1
        else:
            sscl = self._sscl()
            ssda = self._ssda()
            dscl = self.dSCL
            dsda = self.dSDA
            fscl = self.fSCL
            fsda = self.fSDA
            cscl = self.cSCL
            csda = self.cSDA
            clk_en = self.div_clk_en
            cnt_zero = int(self.cnt == 0)
            filter_expired = int(self.filter_cnt == 0)
            sta = int((not ssda) and dsda and sscl)
            sto = int(ssda and (not dsda) and sscl)
            sscl_rise = int(sscl and (not dscl))
            slave_wait = int(self.scl_oen and (not sscl))
            scl_sync = int(self.scl_oen and dscl and (not sscl))
            state = self.state
            sda_chk = int(state == 'write_c')
            cmd_ack = self.cmd_ack
            busy = self.busy
            al = self.al
            dout = self.dout
            scl_oen = self.scl_oen
            sda_oen = self.sda_oen

        self.clk_en = int(bool(clk_en))
        self.cnt_zero = bool(cnt_zero)
        self.slave_wait = bool(slave_wait)
        self.scl_sync = bool(scl_sync)
        self.cscl = cscl & 1
        self.csda = csda & 1
        self.filter_cnt_expired = bool(filter_expired)
        self.fscl = self.mask(fscl, 3)
        self.fsda = self.mask(fsda, 3)
        self.sscl = sscl & 1
        self.ssda = ssda & 1
        self.dscl = dscl & 1
        self.dsda = dsda & 1
        self.sta_condition = bool(sta)
        self.sto_condition = bool(sto)
        self.sscl_rise = bool(sscl_rise)
        self.sda_chk = bool(sda_chk)
        self.in_idle = state == 'idle'
        self.fsm_active = state != 'idle'
        self.in_start_sequence = state in ('start_a', 'start_b', 'start_c')
        self.in_stop_sequence = state in ('stop_a', 'stop_b', 'stop_c', 'stop_d')
        self.in_read_sequence = state in ('read_a', 'read_b', 'read_c', 'read_d', 'read_e')
        self.in_write_sequence = state in ('write_a', 'write_b', 'write_c', 'write_d', 'write_e')

        o['cmd_ack'] = cmd_ack & 1
        o['busy'] = busy & 1
        o['al'] = al & 1
        o['dout'] = dout & 1
        o['scl_o'] = 0
        o['scl_oen'] = scl_oen & 1
        o['sda_o'] = 0
        o['sda_oen'] = sda_oen & 1
        return o

    def advance(self, i):
        clk_cnt = self.mask(i['clk_cnt'], 16)
        if (i['nReset'] & 1) == 0:
            self._reset_state(clk_cnt)
            return
        if i['rst'] & 1:
            self._reset_state(clk_cnt)
            return

        ena = i['ena'] & 1
        old_sscl = self._sscl()
        old_ssda = self._ssda()
        old_dscl = self.dSCL
        old_dsda = self.dSDA
        old_cnt = self.cnt
        old_filter_cnt = self.filter_cnt
        old_clk_en = self.div_clk_en
        old_slave_wait = int(self.scl_oen and (not old_sscl))
        old_scl_sync = int(self.scl_oen and old_dscl and (not old_sscl))
        sta = int((not old_ssda) and old_dsda and old_sscl)
        sto = int(old_ssda and (not old_dsda) and old_sscl)
        sscl_rise = int(old_sscl and (not old_dscl))
        sda_chk = int(self.state == 'write_c')
        stop_states = ('stop_a', 'stop_b', 'stop_c', 'stop_d')
        active_unrequested_stop = (self.state != 'idle' and self.state not in stop_states and sto)
        arbitration_check_lost = (sda_chk and self.sda_oen and (not old_ssda))
        arbitration_lost_now = bool(self.al or arbitration_check_lost or active_unrequested_stop)

        if not ena:
            self.cnt = clk_cnt
            self.div_clk_en = 1
        elif old_scl_sync:
            self.cnt = clk_cnt
            self.div_clk_en = 1
        elif old_slave_wait:
            self.cnt = old_cnt
            self.div_clk_en = 0
        elif old_cnt == 0:
            self.cnt = clk_cnt
            self.div_clk_en = 1
        else:
            self.cnt = self.mask(old_cnt - 1, 16)
            self.div_clk_en = 0

        old_meta_scl = self.cSCL_meta
        old_meta_sda = self.cSDA_meta
        old_cSCL = self.cSCL
        old_cSDA = self.cSDA
        old_fSCL = self.fSCL
        old_fSDA = self.fSDA
        self.cSCL_meta = i['scl_i'] & 1
        self.cSDA_meta = i['sda_i'] & 1
        self.cSCL = old_meta_scl
        self.cSDA = old_meta_sda

        if not ena:
            self.filter_cnt = 0
        elif old_filter_cnt == 0:
            self.filter_cnt = self.mask(clk_cnt >> 2, 14)
            self.fSCL = self.mask((old_fSCL << 1) | old_cSCL, 3)
            self.fSDA = self.mask((old_fSDA << 1) | old_cSDA, 3)
        else:
            self.filter_cnt = self.mask(old_filter_cnt - 1, 14)

        self.dSCL = old_sscl
        self.dSDA = old_ssda
        if sscl_rise:
            self.dout = old_ssda
        if sta:
            self.busy = 1
        elif sto:
            self.busy = 0
        if arbitration_check_lost or active_unrequested_stop:
            self.al = 1

        self.cmd_ack = 0
        if arbitration_lost_now:
            self.state = 'idle'
            self.scl_oen = 1
            self.sda_oen = 1
            return

        if not (ena and old_clk_en and not old_slave_wait):
            return

        if self.state == 'idle':
            cmd = i['cmd'] & 15
            if cmd == 1:
                self.state = 'start_a'
            elif cmd == 2:
                self.state = 'stop_a'
            elif cmd == 8:
                self.state = 'read_a'
            elif cmd == 4:
                self.state = 'write_a'
        elif self.state == 'start_a':
            self.scl_oen = 1
            self.sda_oen = 1
            self.state = 'start_b'
        elif self.state == 'start_b':
            self.scl_oen = 1
            self.sda_oen = 0
            self.state = 'start_c'
        elif self.state == 'start_c':
            self.scl_oen = 0
            self.sda_oen = 0
            self.state = 'idle'
            self.cmd_ack = 1
        elif self.state == 'stop_a':
            self.scl_oen = 0
            self.sda_oen = 0
            self.state = 'stop_b'
        elif self.state == 'stop_b':
            self.scl_oen = 1
            self.state = 'stop_c'
        elif self.state == 'stop_c':
            self.scl_oen = 1
            self.sda_oen = 1
            self.state = 'stop_d'
        elif self.state == 'stop_d':
            self.state = 'idle'
            self.cmd_ack = 1
        elif self.state == 'read_a':
            self.scl_oen = 0
            self.sda_oen = 1
            self.state = 'read_b'
        elif self.state == 'read_b':
            self.scl_oen = 1
            self.sda_oen = 1
            self.state = 'read_c'
        elif self.state == 'read_c':
            if old_sscl:
                self.state = 'read_d'
        elif self.state == 'read_d':
            self.scl_oen = 0
            self.sda_oen = 1
            self.state = 'read_e'
        elif self.state == 'read_e':
            self.state = 'idle'
            self.cmd_ack = 1
        elif self.state == 'write_a':
            self.scl_oen = 0
            self.sda_oen = i['din'] & 1
            self.state = 'write_b'
        elif self.state == 'write_b':
            self.scl_oen = 1
            self.sda_oen = i['din'] & 1
            self.state = 'write_c'
        elif self.state == 'write_c':
            if old_sscl:
                self.state = 'write_d'
        elif self.state == 'write_d':
            self.scl_oen = 0
            self.sda_oen = i['din'] & 1
            self.state = 'write_e'
        elif self.state == 'write_e':
            self.state = 'idle'
            self.cmd_ack = 1
