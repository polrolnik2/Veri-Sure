"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['idle', 'clk_en', 'cnt_zero', 'slave_wait', 'scl_sync', 'cscl', 'csda', 'filter_cnt', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'sta_condition', 'sto_condition', 'active_command', 'sda_chk', 'start_sequence', 'stop_sequence', 'read_sequence', 'write_sequence', 'write_stable_high_phase', 'read_sample_window']
    LATENCY_CYCLES = 1

    def __init__(self):
        self.reset()


    def reset(self):
        self.state = 'IDLE'
        self.active_cmd = 0
        self.din_latched = 0
        self.cnt = 0
        self.filter_counter = 0
        self.c1_scl = 1
        self.c2_scl = 1
        self.c1_sda = 1
        self.c2_sda = 1
        self.f_scl = [1, 1, 1]
        self.f_sda = [1, 1, 1]
        self.s_scl = 1
        self.s_sda = 1
        self.d_scl = 1
        self.d_sda = 1
        self.busy_reg = 0
        self.al_reg = 0
        self.dout_reg = 0
        self.cmd_ack_reg = 0
        self.scl_oen_reg = 1
        self.sda_oen_reg = 1
        self._set_probes()


    def _set_probes(self, clk_en=0, cnt_zero=0, filter_tick=0,
                    scl_sync=0, slave_wait=0, sta=0, sto=0,
                    fscl=0, fsda=0):
        self.idle = self.state == 'IDLE'
        self.clk_en = bool(clk_en)
        self.cnt_zero = bool(cnt_zero)
        self.filter_cnt = bool(filter_tick)
        self.scl_sync = bool(scl_sync)
        self.slave_wait = bool(slave_wait)
        self.cscl = bool(self.c2_scl)
        self.csda = bool(self.c2_sda)
        self.fscl = bool(fscl)
        self.fsda = bool(fsda)
        self.sscl = bool(self.s_scl)
        self.ssda = bool(self.s_sda)
        self.dscl = bool(self.d_scl)
        self.dsda = bool(self.d_sda)
        self.sta_condition = bool(sta)
        self.sto_condition = bool(sto)
        self.active_command = self.state != 'IDLE'
        self.sda_chk = self.state == 'WRITE1' and bool(self.din_latched)
        self.start_sequence = self.state.startswith('START')
        self.stop_sequence = self.state.startswith('STOP')
        self.read_sequence = self.state.startswith('READ')
        self.write_sequence = self.state.startswith('WRITE')
        self.write_stable_high_phase = self.state == 'WRITE1'
        self.read_sample_window = self.state == 'READ1'


    def _reset_requested(self, i):
        if not int(i.get('nReset', 1)):
            self.reset()
            return True
        if int(i.get('rst', 0)):
            self.reset()
            return True
        return False


    def _update_inputs(self, i):
        old_scl = self.s_scl
        old_sda = self.s_sda
        self.c2_scl = self.c1_scl
        self.c1_scl = int(i.get('scl_i', 1)) & 1
        self.c2_sda = self.c1_sda
        self.c1_sda = int(i.get('sda_i', 1)) & 1
        interval = max(1, ((int(i.get('clk_cnt', 0)) & 0xffff) >> 2))
        tick = False
        if not int(i.get('ena', 0)):
            self.filter_counter = 0
        elif self.filter_counter == 0:
            tick = True
            self.filter_counter = interval - 1
        else:
            self.filter_counter -= 1
        if tick:
            self.f_scl = [self.f_scl[1], self.f_scl[2], self.c2_scl]
            self.f_sda = [self.f_sda[1], self.f_sda[2], self.c2_sda]
            self.s_scl = 1 if sum(self.f_scl) >= 2 else 0
            self.s_sda = 1 if sum(self.f_sda) >= 2 else 0
        self.d_scl = old_scl
        self.d_sda = old_sda
        sta = bool((not self.s_sda) and self.d_sda and self.s_scl)
        sto = bool(self.s_sda and (not self.d_sda) and self.s_scl)
        return tick, sta, sto, old_scl


    def _timing(self, i, slave_wait):
        value = int(i.get('clk_cnt', 0)) & 0xffff
        if not int(i.get('ena', 0)):
            self.cnt = value
            return False, False
        if slave_wait:
            return False, self.cnt == 0
        if self.cnt == 0:
            self.cnt = value
            return True, True
        self.cnt = (self.cnt - 1) & 0xffff
        return False, False


    def _drive_state(self):
        table = {
            'IDLE': (1, 1),
            'START0': (1, 1),
            'START1': (1, 0),
            'START2': (0, 0),
            'STOP0': (0, 0),
            'STOP1': (1, 0),
            'STOP2': (1, 1),
            'READ0': (0, 1),
            'READ1': (1, 1),
            'READ2': (0, 1),
            'WRITE0': (0, 0),
            'WRITE1': (1, 0),
            'WRITE2': (0, 0)
        }
        scl, sda = table.get(self.state, (1, 1))
        if self.state.startswith('WRITE') and self.din_latched:
            sda = 1
        return scl, sda


    def _advance_fsm(self, i, clk_en):
        if not clk_en:
            return 0
        if self.state == 'IDLE':
            command = int(i.get('cmd', 0)) & 0xf
            if command in (1, 2, 4, 8):
                self.active_cmd = command
                self.din_latched = int(i.get('din', 0)) & 1
                self.state = {1: 'START0', 2: 'STOP0', 4: 'WRITE0', 8: 'READ0'}[command]
            return 0
        if self.state == 'START0':
            self.state = 'START1'
        elif self.state == 'START1':
            self.state = 'START2'
        elif self.state == 'START2':
            self.state = 'IDLE'
            return 1
        elif self.state == 'STOP0':
            self.state = 'STOP1'
        elif self.state == 'STOP1':
            if self.s_scl:
                self.state = 'STOP2'
        elif self.state == 'STOP2':
            self.state = 'IDLE'
            return 1
        elif self.state == 'READ0':
            self.state = 'READ1'
        elif self.state == 'READ1':
            if self.s_scl:
                self.state = 'READ2'
        elif self.state == 'READ2':
            self.state = 'IDLE'
            return 1
        elif self.state == 'WRITE0':
            self.state = 'WRITE1'
        elif self.state == 'WRITE1':
            if self.s_scl:
                self.state = 'WRITE2'
        elif self.state == 'WRITE2':
            self.state = 'IDLE'
            return 1
        return 0


    def _outputs(self, clk_en=0, cnt_zero=0, filter_tick=0,
                 scl_sync=0, slave_wait=0, sta=0, sto=0,
                 fscl=0, fsda=0):
        self.scl_oen_reg, self.sda_oen_reg = self._drive_state()
        self._set_probes(clk_en, cnt_zero, filter_tick, scl_sync,
                         slave_wait, sta, sto, fscl, fsda)
        return {
            'cmd_ack': int(self.cmd_ack_reg),
            'busy': int(self.busy_reg),
            'al': int(self.al_reg),
            'dout': int(self.dout_reg),
            'scl_o': 0,
            'scl_oen': int(self.scl_oen_reg),
            'sda_o': 0,
            'sda_oen': int(self.sda_oen_reg)
        }


    def step(self, i):
        if self._reset_requested(i):
            return self._outputs()
        filter_tick, sta, sto, old_scl = self._update_inputs(i)
        if sta:
            self.busy_reg = 1
        if sto:
            self.busy_reg = 0
        if not old_scl and self.s_scl:
            self.dout_reg = int(self.s_sda)
        released_scl = self.scl_oen_reg == 1
        slave_wait = bool(released_scl and not self.s_scl and self.state != 'IDLE')
        scl_sync = bool(released_scl and self.d_scl and not self.s_scl)
        clk_en, cnt_zero = self._timing(i, slave_wait)
        if scl_sync:
            self.cnt = int(i.get('clk_cnt', 0)) & 0xffff
            clk_en = True
        unexpected_stop = bool(sto and self.state != 'IDLE' and self.active_cmd != 2)
        arbitration = bool(self.state == 'WRITE1' and self.din_latched and not self.s_sda)
        self.cmd_ack_reg = 0
        if arbitration or unexpected_stop:
            self.al_reg = 1
            self.state = 'IDLE'
            self.active_cmd = 0
            self.scl_oen_reg = 1
            self.sda_oen_reg = 1
        elif not self.al_reg:
            self.cmd_ack_reg = self._advance_fsm(i, clk_en and not slave_wait)
        if self.al_reg:
            self.scl_oen_reg = 1
            self.sda_oen_reg = 1
        return self._outputs(clk_en, cnt_zero, filter_tick, scl_sync,
                             slave_wait, sta, sto, filter_tick, filter_tick)
