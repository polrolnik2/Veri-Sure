"""Generated reference model. Do not edit.

Derived from the specification via specflow S1 + refmodel. Frozen once
gate G4 passes: after the RTL exists, a wrong-RTL hypothesis and a
wrong-model hypothesis compete for every failing check, and the model is
the cheaper one to 'fix' -- which is how a reference model gets
retrofitted to match broken RTL.
"""

from specflow.refmodel.base import RefModel


class Model(RefModel):
    OUTPUT_PORTS = ['cmd_ack', 'busy', 'al', 'dout', 'scl_o', 'scl_oen', 'sda_o', 'sda_oen']
    PROBE_PORTS = ['idle', 'cnt_zero', 'clk_en', 'slave_wait', 'scl_sync', 'cscl', 'csda', 'filter_cnt', 'filter_cnt_expired', 'fscl', 'fsda', 'sscl', 'ssda', 'dscl', 'dsda', 'sta_condition', 'sto_condition', 'active_command', 'sda_chk', 'filtered_scl_rise', 'start_sequence', 'stop_sequence', 'read_sequence', 'write_sequence']
    LATENCY_CYCLES = 1

    def __init__(self):
        self.reset()


    def reset(self):
        self.state = 'IDLE'
        self.cmd_latched = 0
        self.din_latched = 0
        self.cSCL1 = 1
        self.cSCL = 1
        self.cSDA1 = 1
        self.cSDA = 1
        self.fSCL = [1, 1, 1]
        self.fSDA = [1, 1, 1]
        self.sSCL = 1
        self.sSDA = 1
        self.dSCL = 1
        self.dSDA = 1
        self.cnt = 0
        self.filter_counter = 0
        self.cmd_ack_reg = 0
        self.busy_reg = 0
        self.al_reg = 0
        self.dout_reg = 0
        self._update_probes(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)


    def _majority(self, hist):
        return int(sum(hist) >= 2)


    def _outputs_for_state(self):
        scl_oen = 1
        sda_oen = 1
        if self.state in ('START_SDA_LOW', 'STOP_SDA_LOW', 'STOP_SCL_WAIT', 'WRITE_SET', 'WRITE_SCL_WAIT', 'WRITE_SCL_LOW'):
            sda_oen = 0
        if self.state in ('START_SCL_LOW', 'READ_SCL_LOW', 'WRITE_SCL_LOW', 'STOP_SDA_LOW'):
            scl_oen = 0
        if self.state in ('WRITE_SCL_WAIT', 'WRITE_SCL_LOW'):
            sda_oen = int(self.din_latched)
        return scl_oen, sda_oen


    def _update_probes(self, cnt_zero, clk_en, slave_wait, scl_sync,
                       filter_expired, sta, sto, filtered_rise,
                       sda_chk, fscl, fsda):
        self.idle = self.state == 'IDLE'
        self.cnt_zero = bool(cnt_zero)
        self.clk_en = bool(clk_en)
        self.slave_wait = bool(slave_wait)
        self.scl_sync = bool(scl_sync)
        self.cscl = bool(self.cSCL)
        self.csda = bool(self.cSDA)
        self.filter_cnt = bool(self.filter_counter == 0)
        self.filter_cnt_expired = bool(filter_expired)
        self.fscl = bool(fscl)
        self.fsda = bool(fsda)
        self.sscl = bool(self.sSCL)
        self.ssda = bool(self.sSDA)
        self.dscl = bool(self.dSCL)
        self.dsda = bool(self.dSDA)
        self.sta_condition = bool(sta)
        self.sto_condition = bool(sto)
        self.active_command = self.state != 'IDLE'
        self.sda_chk = bool(sda_chk)
        self.filtered_scl_rise = bool(filtered_rise)
        self.start_sequence = self.state in ('START_RELEASE', 'START_SDA_LOW', 'START_SCL_LOW')
        self.stop_sequence = self.state in ('STOP_SDA_LOW', 'STOP_SCL_WAIT', 'STOP_SDA_RELEASE')
        self.read_sequence = self.state in ('READ_RELEASE', 'READ_SCL_HIGH', 'READ_SCL_LOW')
        self.write_sequence = self.state in ('WRITE_SET', 'WRITE_SCL_WAIT', 'WRITE_SCL_LOW')


    def step(self, i):
        o = {p: None for p in self.OUTPUT_PORTS}
        nreset = int(i.get('nReset', 1)) & 1
        rst = int(i.get('rst', 0)) & 1
        ena = int(i.get('ena', 0)) & 1
        clk_cnt = int(i.get('clk_cnt', 0)) & 0xffff
        cmd = int(i.get('cmd', 0)) & 0xf
        din = int(i.get('din', 0)) & 1
        scl_i = int(i.get('scl_i', 1)) & 1
        sda_i = int(i.get('sda_i', 1)) & 1

        if not nreset or rst:
            self.reset()
        else:
            old_scl = self.sSCL
            old_sda = self.sSDA
            self.cSCL1 = scl_i
            self.cSCL = self.cSCL1
            self.cSDA1 = sda_i
            self.cSDA = self.cSDA1

            filter_expired = False
            if not ena:
                self.filter_counter = 0
            else:
                interval = clk_cnt >> 2
                if interval == 0:
                    filter_expired = True
                    self.filter_counter = 0
                elif self.filter_counter == 0:
                    filter_expired = True
                    self.filter_counter = interval
                else:
                    self.filter_counter = (self.filter_counter - 1) & 0xffff

            if filter_expired:
                self.fSCL = [self.fSCL[1], self.fSCL[2], self.cSCL]
                self.fSDA = [self.fSDA[1], self.fSDA[2], self.cSDA]
                self.dSCL = old_scl
                self.dSDA = old_sda
                self.sSCL = self._majority(self.fSCL)
                self.sSDA = self._majority(self.fSDA)

            sta = bool((not self.sSDA) and old_sda and self.sSCL)
            sto = bool(self.sSDA and (not old_sda) and self.sSCL)
            filtered_rise = bool(self.sSCL and not old_scl)
            if sta:
                self.busy_reg = 1
            if sto:
                self.busy_reg = 0
            if filtered_rise:
                self.dout_reg = self.sSDA

            scl_oen, sda_oen = self._outputs_for_state()
            slave_wait = bool(scl_oen and not self.sSCL)
            scl_sync = bool(scl_oen and old_scl and not self.sSCL)
            sda_chk = bool(self.state in ('WRITE_SCL_WAIT', 'WRITE_SCL_LOW') and self.din_latched)
            unexpected_stop = bool(sto and self.state != 'IDLE' and not self.state.startswith('STOP_'))
            lost = bool(unexpected_stop or (sda_chk and not self.sSDA))
            if lost:
                self.al_reg = 1
                self.state = 'IDLE'

            self.cmd_ack_reg = 0
            cnt_zero = self.cnt == 0
            clk_en = 0
            if not ena:
                self.cnt = clk_cnt
            elif slave_wait:
                clk_en = 0
            elif scl_sync or self.cnt == 0:
                self.cnt = clk_cnt
                clk_en = 1
            else:
                self.cnt = (self.cnt - 1) & 0xffff

            if ena and clk_en and not lost:
                if self.state == 'IDLE':
                    if cmd in (1, 2, 4, 8):
                        self.cmd_latched = cmd
                        self.din_latched = din
                        self.state = {1: 'START_RELEASE', 2: 'STOP_SDA_LOW', 4: 'WRITE_SET', 8: 'READ_RELEASE'}[cmd]
                elif self.state == 'START_RELEASE':
                    self.state = 'START_SDA_LOW'
                elif self.state == 'START_SDA_LOW':
                    self.state = 'START_SCL_LOW'
                elif self.state == 'START_SCL_LOW':
                    self.state = 'IDLE'
                    self.cmd_ack_reg = 1
                elif self.state == 'STOP_SDA_LOW':
                    self.state = 'STOP_SCL_WAIT'
                elif self.state == 'STOP_SCL_WAIT' and self.sSCL:
                    self.state = 'STOP_SDA_RELEASE'
                elif self.state == 'STOP_SDA_RELEASE':
                    self.state = 'IDLE'
                    self.cmd_ack_reg = 1
                elif self.state == 'READ_RELEASE':
                    self.state = 'READ_SCL_HIGH'
                elif self.state == 'READ_SCL_HIGH' and self.sSCL:
                    self.state = 'READ_SCL_LOW'
                elif self.state == 'READ_SCL_LOW':
                    self.state = 'IDLE'
                    self.cmd_ack_reg = 1
                elif self.state == 'WRITE_SET':
                    self.state = 'WRITE_SCL_WAIT'
                elif self.state == 'WRITE_SCL_WAIT' and self.sSCL:
                    self.state = 'WRITE_SCL_LOW'
                elif self.state == 'WRITE_SCL_LOW':
                    self.state = 'IDLE'
                    self.cmd_ack_reg = 1

            self._update_probes(cnt_zero, clk_en, slave_wait, scl_sync,
                                filter_expired, sta, sto, filtered_rise,
                                sda_chk, self._majority(self.fSCL),
                                self._majority(self.fSDA))

        scl_oen, sda_oen = self._outputs_for_state()
        if self.al_reg:
            scl_oen = 1
            sda_oen = 1
        o['cmd_ack'] = int(bool(self.cmd_ack_reg))
        o['busy'] = int(bool(self.busy_reg))
        o['al'] = int(bool(self.al_reg))
        o['dout'] = int(bool(self.dout_reg))
        o['scl_o'] = 0
        o['scl_oen'] = int(scl_oen)
        o['sda_o'] = 0
        o['sda_oen'] = int(sda_oen)
        return o
